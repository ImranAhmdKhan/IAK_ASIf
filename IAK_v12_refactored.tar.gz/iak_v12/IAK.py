#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IAK v12 — entry point.

Run:
    python IAK.py           # launch GUI
    python IAK.py --help    # show CLI options
"""
from __future__ import annotations

# Must be set before numpy is imported so OpenBLAS does not spawn its own
# OpenMP threads, causing deadlocks when xTB/CREST/ORCA also use OpenMP.
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import argparse
import sys

from iak.logging_setup import setup_logging


def main() -> None:
    parser = argparse.ArgumentParser(
        description="IAK — Intelligent Automated Kluster-generator Pipeline v12",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable DEBUG logging")
    parser.add_argument(
        "--no-gui",
        action="store_true",
        help="Start without the GUI (useful for batch/headless runs)",
    )
    args = parser.parse_args()

    setup_logging(verbose=args.verbose)

    if args.no_gui:
        print("IAK running in headless mode.  Import iak.pipeline.Pipeline to run jobs.")
        return

    from iak.gui import IAKApp
    app = IAKApp()
    app.mainloop()


if __name__ == "__main__":
    main()
