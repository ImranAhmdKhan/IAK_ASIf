"""
iak.constants
=============
Physical constants, unit-conversion factors, and chemistry look-up tables
used throughout the IAK package.  No GUI, no NumPy, no external imports.
"""
from __future__ import annotations

from typing import Dict

# ---------------------------------------------------------------------------
# Unit conversions
# ---------------------------------------------------------------------------
EH2KCAL: float = 627.509   # Hartree → kcal mol⁻¹
KCAL2KJ: float = 4.184     # kcal mol⁻¹ → kJ mol⁻¹

# ---------------------------------------------------------------------------
# Default external-tool command name
# ---------------------------------------------------------------------------
ORCA_CMD: str = "orca"

# ---------------------------------------------------------------------------
# Reaction type vocabulary
# ---------------------------------------------------------------------------
REACTION_TYPE_CHOICES = [
    "Non-covalent",
    "Covalent",
    "Substitution",
    "Addition",
    "Nucleophilic",
    "Electrophilic",
]

# Maps common user misspellings → canonical name
REACTION_TYPE_ALIASES: Dict[str, str] = {
    "nucleophillic":  "Nucleophilic",
    "nucleophilic":   "Nucleophilic",
    "electrophilic":  "Electrophilic",
    "electrophillic": "Electrophilic",
    "electriphillic": "Electrophilic",
}

# ---------------------------------------------------------------------------
# Periodic table: symbol → atomic number  (Z)
# Covers all elements through Og (118).  Used for charge/multiplicity checks.
# ---------------------------------------------------------------------------
ATOMIC_NUMBERS: Dict[str, int] = {
    "H": 1, "He": 2, "Li": 3, "Be": 4, "B": 5, "C": 6, "N": 7, "O": 8,
    "F": 9, "Ne": 10, "Na": 11, "Mg": 12, "Al": 13, "Si": 14, "P": 15,
    "S": 16, "Cl": 17, "Ar": 18, "K": 19, "Ca": 20, "Sc": 21, "Ti": 22,
    "V": 23, "Cr": 24, "Mn": 25, "Fe": 26, "Co": 27, "Ni": 28, "Cu": 29,
    "Zn": 30, "Ga": 31, "Ge": 32, "As": 33, "Se": 34, "Br": 35, "Kr": 36,
    "Rb": 37, "Sr": 38, "Y": 39, "Zr": 40, "Nb": 41, "Mo": 42, "Tc": 43,
    "Ru": 44, "Rh": 45, "Pd": 46, "Ag": 47, "Cd": 48, "In": 49, "Sn": 50,
    "Sb": 51, "Te": 52, "I": 53, "Xe": 54, "Cs": 55, "Ba": 56, "La": 57,
    "Ce": 58, "Pr": 59, "Nd": 60, "Pm": 61, "Sm": 62, "Eu": 63, "Gd": 64,
    "Tb": 65, "Dy": 66, "Ho": 67, "Er": 68, "Tm": 69, "Yb": 70, "Lu": 71,
    "Hf": 72, "Ta": 73, "W": 74, "Re": 75, "Os": 76, "Ir": 77, "Pt": 78,
    "Au": 79, "Hg": 80, "Tl": 81, "Pb": 82, "Bi": 83, "Po": 84, "At": 85,
    "Rn": 86, "Fr": 87, "Ra": 88, "Ac": 89, "Th": 90, "Pa": 91, "U": 92,
    "Np": 93, "Pu": 94, "Am": 95, "Cm": 96, "Bk": 97, "Cf": 98, "Es": 99,
    "Fm": 100, "Md": 101, "No": 102, "Lr": 103, "Rf": 104, "Db": 105,
    "Sg": 106, "Bh": 107, "Hs": 108, "Mt": 109, "Ds": 110, "Rg": 111,
    "Cn": 112, "Nh": 113, "Fl": 114, "Mc": 115, "Lv": 116, "Ts": 117,
    "Og": 118,
}

# ---------------------------------------------------------------------------
# Van-der-Waals radii (Å) — used for clash detection and display scaling
# Source: Bondi (1964) + later additions
# ---------------------------------------------------------------------------
VDW_RADII: Dict[str, float] = {
    "H": 1.20, "He": 1.40, "Li": 1.82, "Be": 1.53, "B": 1.92, "C": 1.70,
    "N": 1.55, "O": 1.52, "F": 1.47, "Ne": 1.54, "Na": 2.27, "Mg": 1.73,
    "Al": 1.84, "Si": 2.10, "P": 1.80, "S": 1.80, "Cl": 1.75, "Ar": 1.88,
    "K": 2.75, "Ca": 2.31, "Sc": 2.11, "Ti": 2.00, "V": 2.00, "Cr": 2.00,
    "Mn": 2.00, "Fe": 2.00, "Co": 2.00, "Ni": 1.63, "Cu": 1.40, "Zn": 1.39,
    "Ga": 1.87, "Ge": 2.11, "As": 1.85, "Se": 1.90, "Br": 1.85, "Kr": 2.02,
    "Rb": 3.03, "Sr": 2.49, "Pd": 1.63, "Ag": 1.72, "Cd": 1.58, "In": 1.93,
    "Sn": 2.17, "Te": 2.06, "I": 1.98, "Xe": 2.16, "Cs": 3.43, "Ba": 2.68,
    "Pt": 1.75, "Au": 1.66, "Hg": 1.55, "Tl": 1.96, "Pb": 2.02, "Bi": 2.07,
}

# ---------------------------------------------------------------------------
# CPK / standard element colours (hex) for the molecular viewer
# ---------------------------------------------------------------------------
CPK_COLORS: Dict[str, str] = {
    "H": "#FFFFFF", "He": "#D9FFFF", "Li": "#CC80FF", "Be": "#C2FF00",
    "B": "#FFB5B5", "C": "#909090", "N": "#3050F8", "O": "#FF0D0D",
    "F": "#90E050", "Ne": "#B3E3F5", "Na": "#AB5CF2", "Mg": "#8AFF00",
    "Al": "#BFA6A6", "Si": "#F0C8A0", "P": "#FF8000", "S": "#FFFF30",
    "Cl": "#1FF01F", "Ar": "#80D1E3", "K": "#8F40D4", "Ca": "#3DFF00",
    "Fe": "#E06633", "Co": "#F090A0", "Ni": "#50D050", "Cu": "#C88033",
    "Zn": "#7D80B0", "Br": "#A62929", "I": "#940094",
}
CPK_DEFAULT = "#FF1493"  # hot pink for unknown elements
