"""
IAK - Intelligent Automated Kluster-generator Pipeline v11.2 (refactored)
Package root — re-exports the public API surface so external code that did
``from iak_v11 import Pipeline, IAKApp`` keeps working unchanged.
"""
from iak.constants import EH2KCAL, KCAL2KJ, REACTION_TYPE_CHOICES, REACTION_TYPE_ALIASES
from iak.data import REACTION_LIBRARY, PREBIOTIC_DB
from iak.structures import Atom, Molecule, read_multi_xyz
from iak.chem import (
    kabsch_rmsd,
    score_geometry,
    generate_cluster,
    validate_charge_multiplicity,
    validate_reactant_product_atom_balance,
    suggest_multiplicity,
)
from iak.pipeline import Pipeline
from iak.engine import is_tool_available, inject_embedded_engines

__all__ = [
    "EH2KCAL", "KCAL2KJ", "REACTION_TYPE_CHOICES", "REACTION_TYPE_ALIASES",
    "REACTION_LIBRARY", "PREBIOTIC_DB",
    "Atom", "Molecule", "read_multi_xyz",
    "kabsch_rmsd", "score_geometry", "generate_cluster",
    "validate_charge_multiplicity", "validate_reactant_product_atom_balance",
    "suggest_multiplicity",
    "Pipeline",
    "is_tool_available", "inject_embedded_engines",
]
