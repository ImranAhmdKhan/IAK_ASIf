"""
iak.data
========
Curated chemistry databases:
  REACTION_LIBRARY  — supramolecular reaction presets for the Reaction Library tab.
  PREBIOTIC_DB      — prebiotic chemistry condition and thermodynamics database.

These are pure data — no logic, no imports beyond typing.
"""
from __future__ import annotations
from typing import Dict, List, Any

# =============================================================================
# REACTION LIBRARY — curated presets used by the Reaction Library tab
# Each entry: display name → {description, mechanism, distances, sites, refs}
# =============================================================================
REACTION_LIBRARY: Dict[str, Dict] = {
    # ── Non-covalent ──────────────────────────────────────────────────────────
    "Hydrogen Bond (O···H-N)": {
        "type": "Non-covalent", "distance": (1.8, 2.2),
        "description": "Classical O···H-N hydrogen bond. Donor: N-H; Acceptor: O.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Jeffrey, G. A. An Introduction to Hydrogen Bonding (1997).",
    },
    "Hydrogen Bond (N···H-O)": {
        "type": "Non-covalent", "distance": (1.8, 2.2),
        "description": "O-H hydrogen bond donated to N base.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Steiner, T. Angew. Chem. Int. Ed. 2002, 41, 48.",
    },
    "C-H···π (CH-pi)": {
        "type": "Non-covalent", "distance": (2.5, 3.2),
        "description": "Weak C-H···π interaction between C-H bond and aromatic ring.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Nishio, M. CrystEngComm 2004, 6, 130.",
    },
    "π-π Stacking": {
        "type": "Non-covalent", "distance": (3.3, 3.8),
        "description": "Face-to-face or edge-to-face aromatic π-π interaction.",
        "anchor_role": "acceptor", "guest_role": "nucleophile",
        "ref": "Hunter, C. A.; Sanders, J. K. M. J. Am. Chem. Soc. 1990, 112, 5525.",
    },
    "Van der Waals": {
        "type": "Non-covalent", "distance": (3.5, 5.0),
        "description": "Weak dispersion interaction between non-polar fragments.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "London, F. Trans. Faraday Soc. 1937, 33, 8b.",
    },
    "Halogen Bond (X···N)": {
        "type": "Non-covalent", "distance": (2.5, 3.5),
        "description": "σ-hole interaction: halogen X acts as Lewis acid toward N base.",
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Cavallo, G. et al. Chem. Rev. 2016, 116, 2478.",
    },
    "Ion-Dipole": {
        "type": "Non-covalent", "distance": (2.0, 3.5),
        "description": "Interaction between an ion and a polar molecule.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Electrostatics fundamentals.",
    },
    # ── Covalent / Substitution ───────────────────────────────────────────────
    "SN2 Nucleophilic Substitution": {
        "type": "Nucleophilic", "distance": (1.8, 2.5),
        "description": "Back-side attack of nucleophile on sp3 electrophilic C; inversion of configuration.",
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Clayden, J. Organic Chemistry (2001), Ch. 17.",
    },
    "SN1 Nucleophilic Substitution": {
        "type": "Nucleophilic", "distance": (2.0, 3.0),
        "description": "Ionisation then nucleophilic attack on planar carbocation.",
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Clayden, J. Organic Chemistry (2001), Ch. 17.",
    },
    "Nucleophilic Addition (Aldehyde/Ketone)": {
        "type": "Nucleophilic", "distance": (1.5, 2.2),
        "description": "Nu attacks carbonyl C of aldehyde or ketone; forms alkoxide.",
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "March's Advanced Organic Chemistry, 7th Ed.",
    },
    "Electrophilic Addition (Alkene)": {
        "type": "Electrophilic", "distance": (1.55, 2.1),
        "description": "Electrophile adds to π-bond of alkene via Markovnikov selectivity.",
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Clayden, J. Organic Chemistry (2001), Ch. 20.",
    },
    "Electrophilic Aromatic Substitution (EAS)": {
        "type": "Electrophilic", "distance": (1.8, 2.5),
        "description": "Electrophile attacks electron-rich aromatic ring; forms arenium ion.",
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "March's Advanced Organic Chemistry, 7th Ed.",
    },
    # ── Cycloadditions ────────────────────────────────────────────────────────
    "Diels-Alder [4+2]": {
        "type": "Addition", "distance": (2.0, 3.5),
        "description": "Concerted [4+2] cycloaddition: 1,3-diene + dienophile → cyclohexene.",
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Diels, O.; Alder, K. Liebigs Ann. Chem. 1928, 460, 98.",
    },
    "[2+2] Cycloaddition": {
        "type": "Addition", "distance": (2.0, 3.2),
        "description": "Photochemical [2+2] between two alkenes forming cyclobutane.",
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Woodward, R. B.; Hoffmann, R. J. Am. Chem. Soc. 1965, 87, 395.",
    },
    "1,3-Dipolar Cycloaddition": {
        "type": "Addition", "distance": (1.9, 3.0),
        "description": "1,3-dipole + dipolarophile → five-membered heterocycle (e.g., azide-alkyne CuAAC).",
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Huisgen, R. Angew. Chem. Int. Ed. 1963, 2, 565.",
    },
    # ── Organometallic ────────────────────────────────────────────────────────
    "Oxidative Addition": {
        "type": "Addition", "distance": (1.9, 2.8),
        "description": "Substrate A-B adds across metal centre M: M + A-B → M(A)(B).",
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Crabtree, R. H. The Organometallic Chemistry of the Transition Metals (2014).",
    },
    "Metal Coordination": {
        "type": "Non-covalent", "distance": (1.9, 2.5),
        "description": "Lewis-basic ligand donates lone pair to Lewis-acidic metal centre.",
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Cotton, F. A. Advanced Inorganic Chemistry.",
    },
    # ── Proton / Radical ──────────────────────────────────────────────────────
    "Proton Transfer": {
        "type": "Nucleophilic", "distance": (1.0, 1.8),
        "description": "Transfer of H⁺ from acid to base; Brønsted acid-base.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Brønsted, J. N. Recueil des Travaux Chimiques des Pays-Bas 1923, 42, 718.",
    },
    "Radical Abstraction (H-atom)": {
        "type": "Substitution", "distance": (1.6, 2.5),
        "description": "Radical species abstracts H atom from C-H; homolytic cleavage.",
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Fischer, H.; Radom, L. Angew. Chem. Int. Ed. 2001, 40, 1340.",
    },

    # ── Prebiotic Chemistry ────────────────────────────────────────────────────
    "Strecker Amino Acid Synthesis": {
        "type": "Nucleophilic", "distance": (1.5, 2.3),
        "description": (
            "HCN + NH3 add to an aldehyde (R-CHO) forming an α-aminonitrile; "
            "hydrolysis yields an α-amino acid. Key prebiotic route to glycine/alanine."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Strecker, A. Liebigs Ann. Chem. 1850, 75, 27; "
               "Miller, S. L. Science 1953, 117, 528.",
    },
    "HCN Oligomerisation (Purine Precursor)": {
        "type": "Addition", "distance": (1.4, 2.2),
        "description": (
            "Sequential HCN addition and cyclisation forming adenine (HCN pentamer) "
            "and other purine/pyrimidine bases under alkaline aqueous conditions."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Oró, J. Nature 1961, 191, 1193; "
               "Sanchez, R. A. et al. J. Mol. Biol. 1967, 30, 223.",
    },
    "Formose Reaction (Sugar Synthesis)": {
        "type": "Addition", "distance": (1.5, 2.5),
        "description": (
            "Base-catalysed autocatalytic aldol condensation of formaldehyde "
            "producing a mixture of sugars (ribose, glycolaldehyde, etc.) — "
            "Butlerow reaction; Ca(OH)₂ as catalyst."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Butlerow, A. C. R. Acad. Sci. 1861, 53, 145; "
               "Breslow, R. Tetrahedron Lett. 1959, 1, 22.",
    },
    "Phosphorylation by Metaphosphate": {
        "type": "Nucleophilic", "distance": (1.6, 2.4),
        "description": (
            "Nucleophilic attack of a hydroxyl group (sugar/nucleoside) on "
            "metaphosphate (PO₃⁻) or cyclic trimetaphosphate, forming a phosphate ester — "
            "prebiotic route to nucleotides."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Schwartz, A. W. Orig. Life Evol. Biosph. 2006, 36, 309; "
               "Krishnamurthy, R. Acc. Chem. Res. 2017, 50, 455.",
    },
    "Glycosidic Bond Formation (N-glycosylation)": {
        "type": "Nucleophilic", "distance": (1.4, 2.2),
        "description": (
            "N1/N9 of nucleobase attacks the anomeric C1 of a ribose/deoxyribose "
            "forming a β-N-glycosidic bond — key step in nucleoside biosynthesis. "
            "Prebiotic conditions: mild acid, mineral surfaces."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Fuller, W. D. et al. J. Mol. Evol. 1972, 1, 249; "
               "Islam, S. et al. Chem. Commun. 2017, 53, 3017.",
    },
    "Peptide Bond Formation (Amino Acid Condensation)": {
        "type": "Nucleophilic", "distance": (1.3, 2.0),
        "description": (
            "Nucleophilic attack of an amine nitrogen on an activated carbonyl "
            "forming a peptide bond (amide). Prebiotic activation: imidazole, "
            "N-carboxyanhydrides (NCA), or mineral-surface catalysis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Fox, S. W.; Harada, K. J. Am. Chem. Soc. 1960, 82, 3745; "
               "Danger, G. et al. Chem. Soc. Rev. 2012, 41, 5416.",
    },
    "Cyanamide-mediated Cyclisation": {
        "type": "Addition", "distance": (1.4, 2.2),
        "description": (
            "Cyanamide (H₂N-CN) reacts with amino acids or hydroxy compounds "
            "to form guanidinium, hydantoin, or diketopiperazine scaffolds — "
            "important prebiotic heterocycle-forming reactions."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Schimpl, A. et al. Naturwissenschaften 1965, 52, 560; "
               "Taillades, J. et al. J. Mol. Evol. 1998, 46, 319.",
    },
    "UV-photochemical Pyrimidine Synthesis": {
        "type": "Addition", "distance": (1.5, 2.4),
        "description": (
            "UV irradiation drives cyanoacetylene + cyanate (or urea) condensation "
            "to cytosine/uracil; also includes photochemical deamination of cytosine. "
            "Miller–Urey-type UV chemistry relevant to early Earth/Titan."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Ferris, J. P. et al. J. Am. Chem. Soc. 1968, 90, 6898; "
               "Powner, M. W. et al. Nature 2009, 459, 239.",
    },
    "Mineral-surface Catalysed Polymerisation": {
        "type": "Non-covalent", "distance": (2.0, 4.0),
        "description": (
            "Adsorption of activated mononucleotides or amino acids on clay "
            "minerals (montmorillonite, hydroxyapatite) followed by template-directed "
            "or concentration-driven oligomerisation — montmorillonite catalyses "
            "RNA oligomer formation."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Ferris, J. P. et al. Nature 1996, 381, 59; "
               "Bujdák, J. et al. Orig. Life Evol. Biosph. 1996, 26, 537.",
    },
    "Sulfur-mediated Thioester Formation": {
        "type": "Nucleophilic", "distance": (1.7, 2.5),
        "description": (
            "Thiol (R-SH) attacks an acyl compound forming a thioester (R-CO-SR'), "
            "an analogue of acetyl-CoA. Central to 'thioester world' hypothesis; "
            "can drive peptide bond formation and carbon fixation in hydrothermal vents."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "de Duve, C. Nature 1991, 352, 487; "
               "Weber, A. L. Orig. Life Evol. Biosph. 1998, 28, 259.",
    },
    "Reductive Amination (α-keto acid + NH3)": {
        "type": "Nucleophilic", "distance": (1.5, 2.3),
        "description": (
            "Condensation of an α-keto acid with NH₃ to form an imine, "
            "followed by reduction (H₂S, Fe²⁺, or UV) to an α-amino acid. "
            "Prebiotic alternative to Strecker; operates in hydrothermal systems."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Maden, B. E. H. Biochem. J. 1995, 311, 1; "
               "Huber, C.; Wächtershäuser, G. Science 1998, 281, 670.",
    },
    "Fischer–Tropsch-type (CO + H2 → Organics)": {
        "type": "Addition", "distance": (1.8, 3.0),
        "description": (
            "CO and H₂ (or CO₂ + H₂) react on iron/nickel mineral surfaces "
            "forming hydrocarbons, fatty acids, and alcohols — prebiotic membrane "
            "lipid and organic molecule source in early Earth/space environments."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "McCollom, T. M.; Seewald, J. S. Chem. Rev. 2007, 107, 382.",
    },
    "Phosphodiester Bond Hydrolysis / Formation": {
        "type": "Nucleophilic", "distance": (1.6, 2.4),
        "description": (
            "Nucleophilic attack on the phosphorus of a phosphodiester linkage "
            "(RNA backbone). Hydrolysis is the reverse; ligation forms oligonucleotides. "
            "Central to the RNA world and non-enzymatic RNA replication."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Westheimer, F. H. Science 1987, 235, 1173; "
               "Orgel, L. E. Crit. Rev. Biochem. Mol. Biol. 2004, 39, 99.",
    },
    "Aldol Condensation (Prebiotic C–C Bond)": {
        "type": "Addition", "distance": (1.4, 2.2),
        "description": (
            "Enolate addition to an aldehyde or ketone forming a β-hydroxy carbonyl. "
            "Under prebiotic conditions (amino acid catalysis, metal ions) drives "
            "C–C bond formation; key to formose and amino acid side-chain elongation."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Breslow, R. Chem. Commun. 1959, 1; "
               "Pizzarello, S.; Weber, A. L. Science 2004, 303, 1151.",
    },
    "Decarboxylation of β-keto Acids": {
        "type": "Substitution", "distance": (1.4, 2.5),
        "description": (
            "Thermal or metal-ion-assisted loss of CO₂ from β-keto acids "
            "(e.g., oxaloacetate → pyruvate) — operates in primitive metabolic "
            "cycles (reverse TCA) and hydrothermal environments."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Wächtershäuser, G. Microbiol. Rev. 1988, 52, 452; "
               "Smith, E.; Morowitz, H. J. Proc. Natl. Acad. Sci. 2004, 101, 13168.",
    },
    "HCN Hydrolysis to Formamide": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "Water attacks HCN carbon forming formamide (HCONH₂), "
            "a versatile prebiotic synthon for nucleobases, amino acids, and "
            "carbohydrates under UV or thermal activation."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Saladino, R. et al. Chem. Soc. Rev. 2012, 41, 5526.",
    },
    "Cyanoacetylene + Water → Cytosine": {
        "type": "Addition", "distance": (1.5, 2.5),
        "description": (
            "Cyanoacetylene (HC≡C-CN) reacts with cyanate or urea to form "
            "cytosine directly; key step in Sutherland's prebiotic pyrimidine "
            "nucleotide synthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Powner, M. W. et al. Nature 2009, 459, 239.",
    },
    "Iron–Sulfur Cluster Assembly": {
        "type": "Non-covalent", "distance": (2.2, 2.8),
        "description": (
            "Fe²⁺/Fe³⁺ and S²⁻ self-assemble into [Fe-S] clusters (e.g., [2Fe-2S], [4Fe-4S]) "
            "coordinated by cysteine or inorganic sulfide. Primitive electron-transfer cofactors "
            "in hydrothermal vent 'iron–sulfur world'."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Wächtershäuser, G. Prog. Biophys. Mol. Biol. 1992, 58, 85; "
               "Beinert, H. et al. Science 1997, 277, 653.",
    },
    "Non-enzymatic Template-directed RNA Copying": {
        "type": "Non-covalent", "distance": (3.2, 4.5),
        "description": (
            "Activated nucleotides (2-MeImpN or imidazolide-activated) bind to an "
            "RNA template via Watson–Crick H-bonds and polymerise in register — "
            "central experiment of the RNA-world hypothesis."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Orgel, L. E. Acc. Chem. Res. 1995, 28, 109; "
               "Szostak, J. W. J. Syst. Chem. 2012, 3, 2.",
    },
    "Phosphite Ester Oxidation (Prebiotic Phosphorylation)": {
        "type": "Substitution", "distance": (1.6, 2.4),
        "description": (
            "Phosphite (H₂PO₃⁻) oxidation by peroxides or UV yields reactive "
            "phosphate species that phosphorylate nucleosides/sugars without enzymes. "
            "Relevant under early Earth mildly reducing atmosphere."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Pasek, M. A. Proc. Natl. Acad. Sci. 2008, 105, 853.",
    },

    # ── Acid–Base & Proton-Coupled Reactions ──────────────────────────────────
    "Grotthuss Proton Hopping": {
        "type": "Non-covalent", "distance": (2.4, 3.0),
        "description": (
            "Rapid proton shuttling along a hydrogen-bond chain in water via "
            "formation/cleavage of O-H···O bonds without mass diffusion. "
            "Governs proton conductivity in biological membranes and aqueous solutions."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Agmon, N. Chem. Phys. Lett. 1995, 244, 456; "
               "Marx, D. ChemPhysChem 2006, 7, 1848.",
    },
    "Acid-catalysed Hydration of Alkene": {
        "type": "Addition", "distance": (1.6, 2.5),
        "description": (
            "H⁺ protonates an alkene forming a carbocation, which is trapped "
            "by water (Markovnikov) to yield an alcohol. Ubiquitous in industrial "
            "and enzymatic (hydratase) chemistry."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "March's Advanced Organic Chemistry, 7th Ed., Ch. 15.",
    },
    "Keto–Enol Tautomerism": {
        "type": "Non-covalent", "distance": (1.6, 2.8),
        "description": (
            "Proton transfer between α-carbon and carbonyl oxygen interconverting "
            "keto and enol tautomers. Acid/base or metal-ion catalysed; "
            "critical for enzyme active-site chemistry and DNA base mispairing."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Clayden, J. Organic Chemistry (2001), Ch. 21.",
    },

    # ── Organocatalysis ───────────────────────────────────────────────────────
    "Enamine Catalysis (List–Barbas)": {
        "type": "Nucleophilic", "distance": (1.4, 2.2),
        "description": (
            "Secondary amine (e.g. proline) condenses with a ketone/aldehyde "
            "to form a nucleophilic enamine intermediate, which adds to electrophiles "
            "(aldol, Mannich, Michael). Asymmetric induction via chiral catalyst."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "List, B. et al. J. Am. Chem. Soc. 2000, 122, 2395.",
    },
    "Iminium Ion Catalysis (MacMillan)": {
        "type": "Electrophilic", "distance": (1.5, 2.4),
        "description": (
            "Chiral amine condenses with an α,β-unsaturated aldehyde forming a "
            "LUMO-lowered iminium ion, activating the β-carbon toward Diels–Alder, "
            "Friedel–Crafts, or 1,4-addition. Paradigm of asymmetric organocatalysis."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Ahrendt, K. A. et al. J. Am. Chem. Soc. 2000, 122, 4243.",
    },
    "NHC (N-Heterocyclic Carbene) Catalysis": {
        "type": "Nucleophilic", "distance": (1.5, 2.3),
        "description": (
            "NHC reversibly adds to an aldehyde forming the Breslow intermediate "
            "(acyl anion equivalent / umpolung), enabling acyloin condensation, "
            "Stetter reaction, and oxidative NHC catalysis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Enders, D. et al. Chem. Rev. 2007, 107, 5606.",
    },
    "Phase-Transfer Catalysis (Ion Pair)": {
        "type": "Non-covalent", "distance": (3.0, 5.5),
        "description": (
            "Lipophilic quaternary ammonium or phosphonium salt transfers an "
            "anionic nucleophile from aqueous to organic phase as an ion pair, "
            "accelerating reactions at the phase boundary."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Starks, C. M. J. Am. Chem. Soc. 1971, 93, 195.",
    },
    "Photoredox Catalysis (Single Electron Transfer)": {
        "type": "Substitution", "distance": (2.5, 5.0),
        "description": (
            "Photoexcited Ru(II)/Ir(III) or organic dye undergoes single-electron "
            "transfer (SET) with substrate, generating radicals for C–C, C–N, "
            "or C–O bond formation; merged with asymmetric and metal catalysis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Prier, C. K. et al. Chem. Rev. 2013, 113, 5322.",
    },
    "Hydrogen-Bond Donor Catalysis (Thiourea/Squaramide)": {
        "type": "Non-covalent", "distance": (1.8, 2.8),
        "description": (
            "Bifunctional H-bond donor (thiourea, squaramide) binds an electrophile "
            "via dual N-H···O=C or N-H···anion interactions, lowering LUMO and "
            "activating toward asymmetric nucleophilic addition."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Takemoto, Y. Org. Biomol. Chem. 2005, 3, 4299.",
    },

    # ── Named Organic Reactions ───────────────────────────────────────────────
    "Wittig Olefination": {
        "type": "Addition", "distance": (1.5, 2.3),
        "description": (
            "Phosphorus ylide (Ph₃P=CHR) reacts with an aldehyde/ketone via [2+2] "
            "cycloaddition forming a betaine and oxaphosphetane, which collapses "
            "to an alkene + Ph₃P=O. Stereoselective (Z/E control by ylide stability)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Wittig, G.; Geissler, G. Liebigs Ann. Chem. 1953, 580, 44.",
    },
    "Grignard Addition": {
        "type": "Nucleophilic", "distance": (1.8, 2.8),
        "description": (
            "Organomagnesium halide (R-MgX) acts as a carbanion, adding to "
            "carbonyl electrophiles (aldehydes, ketones, esters, CO₂). "
            "Forms C–C bonds; quenched with water to give alcohol."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Grignard, V. C. R. Acad. Sci. 1900, 130, 1322.",
    },
    "Michael Addition (Conjugate Addition)": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Nucleophile (soft: enolate, thiol, amine) adds to the β-carbon of "
            "an α,β-unsaturated carbonyl (Michael acceptor) in a 1,4-fashion. "
            "Orbital-controlled; complementary to 1,2-addition."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Michael, A. J. Prakt. Chem. 1887, 35, 349.",
    },
    "Mannich Reaction": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Three-component reaction: ketone/aldehyde + formaldehyde + amine "
            "forming a β-amino carbonyl (Mannich base) via iminium intermediate. "
            "Key step in biosynthesis of alkaloids and β-lactam antibiotics."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Mannich, C.; Krösche, W. Arch. Pharm. 1912, 250, 647.",
    },
    "Aldol Addition / Condensation": {
        "type": "Nucleophilic", "distance": (1.4, 2.2),
        "description": (
            "Enolate (or enol) of a ketone/aldehyde adds to the carbonyl carbon "
            "of another (crossed or self-aldol) yielding a β-hydroxy carbonyl; "
            "dehydration gives the α,β-unsaturated product (aldol condensation)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "March's Advanced Organic Chemistry, 7th Ed., Ch. 16.",
    },
    "Claisen Condensation": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Base-mediated condensation of two esters (or ester + ketone, Claisen–Schmidt) "
            "forming a β-keto ester. Mechanism: enolate attacks ester carbonyl, "
            "then alkoxide leaves. Fundamental to fatty-acid biosynthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Claisen, L. Liebigs Ann. Chem. 1887, 237, 232.",
    },
    "Beckmann Rearrangement": {
        "type": "Substitution", "distance": (1.3, 2.2),
        "description": (
            "Acid-catalysed rearrangement of an oxime to an amide (lactam): "
            "anti-periplanar migration of R group to electrophilic nitrogen with "
            "loss of water. Industrial: cyclohexanone oxime → caprolactam (Nylon-6)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Beckmann, E. Ber. Dtsch. Chem. Ges. 1886, 19, 988.",
    },
    "Baeyer–Villiger Oxidation": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "Peracid oxidises a ketone to an ester (or cyclic ketone → lactone) "
            "via Criegee intermediate: O insertion with migration of the more "
            "electron-rich group. Stereospecific; enantioselective via enzymes (BVMO)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Baeyer, A.; Villiger, V. Ber. Dtsch. Chem. Ges. 1899, 32, 3625.",
    },
    "Sharpless Asymmetric Epoxidation": {
        "type": "Addition", "distance": (1.5, 2.5),
        "description": (
            "Ti(IV)/tartrate/TBHP complex delivers an oxygen atom to an allylic "
            "alcohol with high enantioselectivity. Mechanism: substrate binds Ti "
            "via allylic OH, O-transfer from TBHP occurs from a defined face."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Sharpless, K. B. et al. J. Am. Chem. Soc. 1980, 102, 5974.",
    },
    "Mitsunobu Reaction": {
        "type": "Substitution", "distance": (1.6, 2.5),
        "description": (
            "PPh₃/DIAD activate an alcohol as a leaving group, enabling SN2 "
            "displacement by a nucleophilic pronucleophile (acid, phenol, azide) "
            "with clean inversion of configuration."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Mitsunobu, O. Synthesis 1981, 1.",
    },
    "Suzuki–Miyaura Cross-Coupling": {
        "type": "Addition", "distance": (2.0, 2.8),
        "description": (
            "Pd(0)-catalysed coupling of an aryl/vinyl halide with a boronic acid "
            "via oxidative addition → transmetallation → reductive elimination. "
            "Most widely used cross-coupling; aqueous-compatible, air-stable."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Miyaura, N.; Suzuki, A. Chem. Rev. 1995, 95, 2457.",
    },
    "Heck Reaction": {
        "type": "Addition", "distance": (1.9, 2.8),
        "description": (
            "Pd-catalysed coupling of an aryl/vinyl halide with an alkene: "
            "oxidative addition → migratory insertion → β-hydride elimination "
            "gives a substituted alkene. Regioselective; key in pharmaceutical synthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Heck, R. F.; Nolley, J. P. J. Org. Chem. 1972, 37, 2320.",
    },
    "Buchwald–Hartwig Amination": {
        "type": "Addition", "distance": (1.9, 2.7),
        "description": (
            "Pd-catalysed C–N bond formation between an aryl halide and an amine: "
            "oxidative addition → amine coordination/deprotonation → reductive "
            "elimination. Gives diarylamines, anilines, N-aryl heterocycles."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Hartwig, J. F. Acc. Chem. Res. 1998, 31, 852.",
    },
    "Olefin Metathesis (Grubbs)": {
        "type": "Addition", "distance": (1.9, 2.9),
        "description": (
            "Ru or Mo carbene catalyst exchanges alkylidene fragments between "
            "two alkenes via [2+2] cycloaddition / retrocycloaddition. Types: "
            "RCM (ring-closing), CM (cross), ADMET. Nobel Prize 2005."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Grubbs, R. H. Angew. Chem. Int. Ed. 2006, 45, 3760.",
    },
    "CuAAC Click Reaction (Azide–Alkyne)": {
        "type": "Addition", "distance": (1.8, 2.8),
        "description": (
            "Cu(I)-catalysed regioselective [3+2] cycloaddition of azide + terminal "
            "alkyne giving 1,4-disubstituted 1,2,3-triazole. Bioorthogonal; "
            "'click chemistry' (Nobel Prize 2022, Sharpless, Meldal, Bertozzi)."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Rostovtsev, V. V. et al. Angew. Chem. Int. Ed. 2002, 41, 2596.",
    },
    "Reductive Elimination (Organometallic)": {
        "type": "Substitution", "distance": (1.8, 2.6),
        "description": (
            "Two cis ligands on a metal centre couple and are expelled, "
            "reducing the metal oxidation state by 2. Key step in Pd, Ni, Cu-catalysed "
            "cross-couplings forming C–C, C–N, C–O bonds."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Hartwig, J. F. Inorg. Chem. 2007, 46, 1936.",
    },
    "β-Hydride Elimination": {
        "type": "Substitution", "distance": (1.6, 2.4),
        "description": (
            "H on the β-carbon of an alkyl-metal complex transfers to the metal, "
            "forming an alkene + metal hydride. Termination step in Heck reaction, "
            "polymerisation, and isomerisation; requires syn-coplanar M–C–C–H."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Crabtree, R. H. Organometallic Chemistry of the Transition Metals (2014).",
    },

    # ── Enzymatic / Biochemical Analogues ────────────────────────────────────
    "Enzyme Acylation (Serine Protease)": {
        "type": "Nucleophilic", "distance": (1.3, 2.0),
        "description": (
            "Ser-His-Asp catalytic triad: His activates Ser nucleophile for attack "
            "on amide/ester carbonyl → tetrahedral intermediate → acyl-enzyme + "
            "amine release → water hydrolysis → free enzyme. Modelled as two "
            "successive BAC2 steps."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Stroud, R. M. Sci. Am. 1974, 231, 74.",
    },
    "Enzyme Phosphoryl Transfer (Kinase)": {
        "type": "Nucleophilic", "distance": (1.6, 2.4),
        "description": (
            "Protein kinase transfers γ-phosphate of ATP to Ser/Thr/Tyr OH via "
            "in-line nucleophilic substitution at phosphorus (SN2-like), "
            "with Mg²⁺ coordinating both ATP and substrate."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Knowles, J. R. Annu. Rev. Biochem. 1980, 49, 877.",
    },
    "Ribozyme Transesterification": {
        "type": "Nucleophilic", "distance": (1.6, 2.3),
        "description": (
            "2'-OH of an upstream ribose nucleophile attacks the adjacent "
            "phosphodiester, forming a 2',3'-cyclic phosphate + free 5'-OH "
            "(self-cleavage) or ligating two fragments (ligation). "
            "Metal-ion (Mg²⁺) or nucleobase general acid/base catalysis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Doherty, E. A.; Doudna, J. A. Annu. Rev. Biochem. 2000, 69, 597.",
    },
    "Coenzyme A Acyl Transfer (Thioester)": {
        "type": "Nucleophilic", "distance": (1.5, 2.3),
        "description": (
            "Nucleophile attacks the thioester carbonyl of an acyl-CoA "
            "(e.g. acetyl-CoA) expelling CoA-SH. Central in fatty-acid, "
            "polyketide, and terpenoid biosynthesis and the Krebs cycle."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Lynen, F. Biochem. J. 1954, 57, 191.",
    },
    "Glycosyl Transfer (Glycosyltransferase)": {
        "type": "Nucleophilic", "distance": (1.4, 2.2),
        "description": (
            "Nucleophile (acceptor OH) attacks anomeric carbon of a sugar-nucleoside "
            "diphosphate (e.g. UDP-glucose) with inversion (SN2) or retention "
            "(double-displacement) of configuration; key in glycan biosynthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Lairson, L. L. et al. Annu. Rev. Biochem. 2008, 77, 521.",
    },

    # ── Photochemistry ────────────────────────────────────────────────────────
    "Norrish Type I (α-cleavage)": {
        "type": "Substitution", "distance": (1.4, 2.2),
        "description": (
            "Photoexcited carbonyl compound undergoes homolytic α-C–C cleavage "
            "producing acyl and alkyl radicals (triplet or singlet excited state). "
            "Can proceed to decarbonylation, recombination, or disproportionation."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Norrish, R. G. W. Trans. Faraday Soc. 1937, 33, 1521.",
    },
    "Norrish Type II (γ-H Abstraction)": {
        "type": "Substitution", "distance": (2.4, 3.5),
        "description": (
            "Excited triplet carbonyl abstracts the γ-hydrogen via a six-membered "
            "transition state forming a 1,4-biradical; cyclisation gives cyclobutanol "
            "or fragmentation gives alkene + enol (retro-ene)."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Yang, N. C.; Yang, D. D. J. Am. Chem. Soc. 1958, 80, 2913.",
    },
    "Paternò–Büchi ([2+2] Photocycloaddition)": {
        "type": "Addition", "distance": (2.0, 3.2),
        "description": (
            "Photochemical [2+2] cycloaddition between an excited carbonyl (n→π*) "
            "and an alkene forming an oxetane. Regio- and stereoselective; "
            "used in synthesis of strained natural products."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Paternò, E.; Chieffi, G. Gazz. Chim. Ital. 1909, 39, 341.",
    },
    "Photoinduced Electron Transfer (PET)": {
        "type": "Non-covalent", "distance": (3.0, 6.0),
        "description": (
            "Photoexcited donor (D*) or acceptor (A*) transfers an electron "
            "across a short distance (Marcus theory). Creates radical ion pairs "
            "used in solar cells, photocatalysis, and biological photosystems."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Marcus, R. A. Angew. Chem. Int. Ed. 1993, 32, 1111.",
    },

    # ── Supramolecular / Host–Guest ────────────────────────────────────────────
    "Crown Ether–Cation Binding": {
        "type": "Non-covalent", "distance": (2.4, 3.2),
        "description": (
            "Macrocyclic polyether (crown ether) encapsulates a metal cation via "
            "multiple O···M ion-dipole interactions. Selectivity governed by "
            "size-match between cation and cavity; basis of molecular recognition."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Pedersen, C. J. J. Am. Chem. Soc. 1967, 89, 7017.",
    },
    "Cucurbituril Host–Guest Inclusion": {
        "type": "Non-covalent", "distance": (2.5, 4.0),
        "description": (
            "Cucurbit[n]uril barrel encapsulates hydrophobic guests in its apolar "
            "cavity; portal carbonyl groups bind protonated amines via ion-dipole. "
            "Among the strongest non-covalent binding known (Ka ~ 10¹⁵ M⁻¹)."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Barrow, S. J. et al. Chem. Rev. 2015, 115, 12320.",
    },
    "β-Cyclodextrin Inclusion Complex": {
        "type": "Non-covalent", "distance": (2.5, 5.0),
        "description": (
            "Hydrophobic guest molecule threads into the β-CD cavity driven by "
            "hydrophobic effect and van der Waals interactions; rim OH groups "
            "engage in H-bonding. Used in drug formulation and catalysis."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Szejtli, J. Chem. Rev. 1998, 98, 1743.",
    },
    "Anion–π Interaction": {
        "type": "Non-covalent", "distance": (2.8, 3.8),
        "description": (
            "Anion (Cl⁻, F⁻, carboxylate) interacts with the face of an "
            "electron-poor arene (NDI, triazine, TCNQ) via electrostatics and "
            "polarisation. Complementary to cation-π; relevant to ion channel design."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Frontera, A. et al. Chem. Rev. 2011, 111, 7157.",
    },
    "Cation–π Interaction": {
        "type": "Non-covalent", "distance": (2.8, 4.0),
        "description": (
            "Metal cation or protonated amine interacts with the face of an "
            "electron-rich arene via electrostatics and induction. "
            "Key in protein–ligand (Trp/Phe/Tyr) and K⁺-channel selectivity."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Dougherty, D. A. Science 1996, 271, 163.",
    },
    "Chalcogen Bond (S···N/O)": {
        "type": "Non-covalent", "distance": (2.8, 3.8),
        "description": (
            "σ-hole on a divalent sulfur or selenium atom interacts with a Lewis "
            "base (N, O, S). Analogous to halogen bonding but with Group 16 element; "
            "emerging in crystal engineering and catalysis."
        ),
        "anchor_role": "acceptor", "guest_role": "electrophile",
        "ref": "Gleiter, R. et al. Acc. Chem. Res. 2016, 49, 2666.",
    },

    # ── Atmospheric / Environmental Chemistry ────────────────────────────────
    "OH Radical Addition to Alkene (Troposphere)": {
        "type": "Addition", "distance": (1.5, 2.3),
        "description": (
            "Tropospheric •OH adds across C=C of alkenes (isoprene, terpenes) "
            "forming a β-hydroxy alkyl radical; subsequent O₂ addition initiates "
            "SOA (secondary organic aerosol) and ozone formation chemistry."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Atkinson, R. Chem. Rev. 1986, 86, 69.",
    },
    "Criegee Ozonolysis": {
        "type": "Addition", "distance": (1.6, 2.6),
        "description": (
            "O₃ adds to an alkene via [3+2] cycloaddition forming a primary "
            "ozonide (1,2,3-trioxolane), which fragments to a carbonyl + carbonyl "
            "oxide (Criegee zwitterion) → secondary ozonide or open-chain products."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Criegee, R. Angew. Chem. Int. Ed. 1975, 14, 745.",
    },
    "Stratospheric Cl• + O3 (Ozone Depletion)": {
        "type": "Substitution", "distance": (2.0, 3.0),
        "description": (
            "Cl atom (from CFC photolysis) abstracts an oxygen atom from O₃ "
            "forming ClO• + O₂; ClO• reacts with O• to regenerate Cl•. "
            "Chain mechanism; one Cl destroys ~10⁵ O₃ molecules."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Molina, M. J.; Rowland, F. S. Nature 1974, 249, 810.",
    },
    "CO₂ Capture by Amines (Post-combustion)": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "Primary/secondary amine reacts with CO₂ to form a carbamic acid "
            "or zwitterionic carbamate (R₂N-COO⁻ + H⁺). Basis of MEA scrubbing "
            "and solid sorbent DAC (direct air capture) technologies."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Rochelle, G. T. Science 2009, 325, 1652.",
    },

    # ── Classic Named Reactions — Carbon Skeleton Formation ───────────────────
    "Reformatsky Reaction": {
        "type": "Nucleophilic", "distance": (1.8, 2.8),
        "description": (
            "Zn inserts into an α-bromo ester forming a zinc enolate (Reformatsky reagent), "
            "which adds to aldehydes/ketones giving β-hydroxy esters after workup. "
            "Milder than Grignard; tolerates esters and ketones in the same molecule."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Reformatsky, S. Ber. Dtsch. Chem. Ges. 1887, 20, 1210.",
    },
    "Barbier Reaction": {
        "type": "Nucleophilic", "distance": (1.8, 2.8),
        "description": (
            "One-pot addition of an organohalide to a carbonyl compound mediated by "
            "Mg, Zn, In, or Sm metals in protic solvent. Precursor to the Grignard; "
            "In-mediated Barbier is aqueous-compatible and highly chemoselective."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Barbier, P. C. R. Acad. Sci. 1899, 128, 110.",
    },
    "Pinacol Coupling": {
        "type": "Addition", "distance": (1.9, 3.0),
        "description": (
            "Reductive coupling of two carbonyl compounds (aldehydes/ketones) via "
            "single-electron reduction (Mg/Hg, Ti³⁺, Sm²⁺, photocatalysis) forming "
            "a 1,2-diol (pinacol). Proceeds via ketyl radical intermediates; "
            "template-directed versions give high diastereoselectivity."
        ),
        "anchor_role": "electrophile", "guest_role": "electrophile",
        "ref": "Fittig, R. Liebigs Ann. Chem. 1859, 110, 17.",
    },
    "Tishchenko Reaction": {
        "type": "Nucleophilic", "distance": (1.5, 2.5),
        "description": (
            "Al(OiPr)₃ or base catalyses disproportionation of two aldehydes: "
            "one acts as hydride donor (Meerwein–Ponndorf–Verley), the other as "
            "acyl acceptor, giving an ester product. No oxidant or reductant required."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Tishchenko, W. J. Russ. Chem. Soc. 1906, 38, 355.",
    },
    "Corey–Fuchs Alkyne Synthesis": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "Aldehyde → gem-dibromo alkene (CBr₄/PPh₃, Wittig-type) → terminal "
            "alkyne via double deprotonation with n-BuLi and elimination. "
            "Two-step homologation; one-carbon extension to alkynes."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Corey, E. J.; Fuchs, P. L. Tetrahedron Lett. 1972, 36, 3769.",
    },
    "Seyferth–Gilbert Homologation": {
        "type": "Addition", "distance": (1.5, 2.4),
        "description": (
            "Bestmann–Ohira reagent (dimethyl diazomethylphosphonate) converts "
            "an aldehyde to a terminal alkyne under mild base conditions. "
            "Single step, tolerates sensitive functional groups."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Ohira, S. Synth. Commun. 1989, 19, 561.",
    },
    "Rupe / Meyer–Schuster Rearrangement": {
        "type": "Substitution", "distance": (1.4, 2.4),
        "description": (
            "Acid-catalysed 1,3-shift of a propargylic alcohol: Meyer–Schuster "
            "gives an α,β-unsaturated carbonyl (OH migrates); Rupe produces an "
            "enone via 1,2-hydride shift. Both proceed via propargylic cation."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Meyer, K. H.; Schuster, K. Ber. Dtsch. Chem. Ges. 1922, 55, 819.",
    },
    "Favorskii Rearrangement": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "Base-induced rearrangement of an α-halo ketone: enolate displaces "
            "halide forming a cyclopropanone intermediate, which opens with "
            "nucleophile (OR⁻, OH⁻) to give a ring-contracted ester or carboxylic acid."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Favorskii, A. E. J. Russ. Phys.-Chem. Soc. 1894, 26, 590.",
    },
    "Ramberg–Bäcklund Reaction": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "α-Halo sulfone undergoes base-induced episulfonyl carbanion cyclisation "
            "forming a 3-membered episulfone, which spontaneously cheleotropically "
            "extrudes SO₂ to give an alkene. Stereospecific (E/Z determined by cis/trans)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Ramberg, L.; Bäcklund, B. Ark. Kemi Mineral. Geol. 1940, 13A, 1.",
    },

    # ── Rearrangements ────────────────────────────────────────────────────────
    "Wagner–Meerwein Rearrangement": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "1,2-Alkyl or 1,2-aryl shift to an adjacent carbocation, "
            "stabilising the intermediate. Common in terpene biosynthesis (e.g., "
            "borneol↔camphene, norbornyl cation) and acid-catalysed cyclisations."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Meerwein, H. Liebigs Ann. Chem. 1914, 405, 129.",
    },
    "Pinacol Rearrangement": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "Acid-catalysed 1,2-shift in a 1,2-diol: protonation of one OH gives "
            "a carbocation; adjacent group migrates to give a carbonyl compound "
            "(pinacolone). Drives ring expansions in cyclic diols."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Fittig, R. Liebigs Ann. Chem. 1860, 114, 54.",
    },
    "Curtius Rearrangement": {
        "type": "Substitution", "distance": (1.3, 2.2),
        "description": (
            "Thermal rearrangement of an acyl azide to an isocyanate with loss of N₂ "
            "(concerted [1,2]-shift). Isocyanate is trapped by water (→ amine), "
            "alcohol (→ carbamate), or amine (→ urea). One-carbon shorter than starting acid."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Curtius, T. Ber. Dtsch. Chem. Ges. 1890, 23, 3023.",
    },
    "Lossen Rearrangement": {
        "type": "Substitution", "distance": (1.3, 2.2),
        "description": (
            "O-Acylated hydroxamic acid loses the leaving group forming a nitrene-like "
            "species that rearranges to an isocyanate via [1,2]-shift. "
            "Closely related to Curtius and Hofmann; proceeds under mild base."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Lossen, W. Liebigs Ann. Chem. 1872, 161, 347.",
    },
    "Hofmann Rearrangement": {
        "type": "Substitution", "distance": (1.3, 2.2),
        "description": (
            "Primary amide + Br₂/NaOH: N-bromination → loss of HBr → nitrene → "
            "[1,2]-alkyl shift to isocyanate → hydrolysis to primary amine (one C shorter). "
            "Mild; useful for decarboxylative amine synthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Hofmann, A. W. Ber. Dtsch. Chem. Ges. 1881, 14, 2725.",
    },
    "Wolff Rearrangement": {
        "type": "Substitution", "distance": (1.3, 2.1),
        "description": (
            "Thermal or photochemical rearrangement of an α-diazo ketone to a "
            "ketene via Wolff intermediate (carbene-like). Ketene trapped by water "
            "(→ carboxylic acid), alcohol (→ ester), or amine (→ amide). "
            "Arndt–Eistert one-carbon homologation uses this step."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Wolff, L. Liebigs Ann. Chem. 1912, 394, 23.",
    },
    "Smiles Rearrangement": {
        "type": "Substitution", "distance": (1.4, 2.3),
        "description": (
            "Intramolecular nucleophilic aromatic substitution: an alkoxide, "
            "thiolate, or amine attacks an activated arene via an ipso Meisenheimer "
            "complex, transferring the aryl group from O/S to N or vice versa."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Smiles, S.; Haworth, R. A. A. J. Chem. Soc. 1931, 956.",
    },

    # ── Nucleophilic Aromatic & Heterocyclic ──────────────────────────────────
    "SNAr (Nucleophilic Aromatic Substitution)": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "Nucleophile adds to an electron-poor arene bearing ortho/para electron-"
            "withdrawing groups forming a Meisenheimer complex; expulsion of leaving "
            "group (F, Cl, NO₂) gives the substituted arene. Stepwise addition-elimination."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Jackson, C. L.; Gazzolo, F. H. Am. Chem. J. 1900, 23, 376.",
    },
    "Chichibabin Amination": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "NaNH₂ adds to the 2-position of pyridine via addition–elimination: "
            "amide anion attacks C2, hydride is expelled as NaH, giving 2-aminopyridine. "
            "Classic route to α-amino heterocycles."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Chichibabin, A. E.; Zeide, O. A. J. Russ. Phys.-Chem. Soc. 1914, 46, 1216.",
    },
    "Meisenheimer Complex Formation": {
        "type": "Nucleophilic", "distance": (1.5, 2.5),
        "description": (
            "Anionic σ-complex formed by nucleophile addition to an electrophilic arene "
            "(stable when strong EWG present). Intermediate in SNAr; isolable with "
            "picryl ethers. Characterised by strong UV absorption and NMR."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Meisenheimer, J. Liebigs Ann. Chem. 1902, 323, 205.",
    },

    # ── Oxidation & Reduction ─────────────────────────────────────────────────
    "Swern Oxidation": {
        "type": "Substitution", "distance": (1.5, 2.3),
        "description": (
            "DMSO activated by oxalyl chloride reacts with an alcohol forming a "
            "chlorosulfonium intermediate; Et₃N base promotes [2,3]-sigmatropic-like "
            "elimination to give an aldehyde or ketone without overoxidation."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Omura, K.; Swern, D. Tetrahedron 1978, 34, 1651.",
    },
    "Dess–Martin Periodinane Oxidation": {
        "type": "Substitution", "distance": (1.5, 2.3),
        "description": (
            "Hypervalent iodine(V) periodinane (DMP) oxidises primary alcohols to "
            "aldehydes and secondary to ketones in CH₂Cl₂. Mild, fast, tolerates "
            "acid-sensitive substrates; mechanism: ligand exchange then reductive elimination."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Dess, D. B.; Martin, J. C. J. Org. Chem. 1983, 48, 4155.",
    },
    "Jones Oxidation (CrO₃/H₂SO₄)": {
        "type": "Substitution", "distance": (1.5, 2.4),
        "description": (
            "Chromium(VI) in acidic acetone oxidises primary alcohols to carboxylic acids "
            "and secondary alcohols to ketones via chromate ester formation and "
            "elimination. Strong; over-oxidises aldehydes."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Bowden, K. et al. J. Chem. Soc. 1946, 39.",
    },
    "Meerwein–Ponndorf–Verley Reduction": {
        "type": "Substitution", "distance": (1.7, 2.6),
        "description": (
            "Al(OiPr)₃-catalysed transfer hydrogenation: hydride shuttles from "
            "isopropanol to a carbonyl compound in a six-membered cyclic transition "
            "state. Chemoselective for C=O over C=C; reverse is Oppenauer oxidation."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Meerwein, H.; Schmidt, R. Liebigs Ann. Chem. 1925, 444, 221.",
    },
    "Birch Reduction": {
        "type": "Addition", "distance": (1.8, 3.0),
        "description": (
            "Dissolving metal (Na/Li in liquid NH₃/ROH) reduces arenes to "
            "1,4-cyclohexadienes via sequential SET → radical anion → protonation. "
            "Electron-rich arenes reduce at unsubstituted positions; "
            "electron-poor arenes at substituted."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Birch, A. J. J. Chem. Soc. 1944, 430.",
    },
    "Luche Reduction (CeCl₃/NaBH₄)": {
        "type": "Addition", "distance": (1.7, 2.6),
        "description": (
            "Ce³⁺ coordinates to the carbonyl oxygen, activating it toward selective "
            "1,2-reduction by NaBH₄. α,β-Unsaturated ketones give allylic alcohols "
            "(1,2-selectivity); conjugate reduction (1,4) is suppressed."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Luche, J.-L. J. Am. Chem. Soc. 1978, 100, 2226.",
    },
    "Nozaki–Hiyama–Kishi (NHK) Reaction": {
        "type": "Nucleophilic", "distance": (1.8, 2.8),
        "description": (
            "Cr(II)/Ni(II)-mediated coupling of vinyl/allyl/aryl halides with aldehydes "
            "in a single pot. Proceeds via radical → organochromium(III) → nucleophilic "
            "addition. Key for complex polyol natural product synthesis (e.g., Palytoxin)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Kishi, Y. et al. J. Am. Chem. Soc. 1986, 108, 6048.",
    },

    # ── Ring-Forming Named Reactions ──────────────────────────────────────────
    "Paal–Knorr Pyrrole Synthesis": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "1,4-Dicarbonyl compound reacts with a primary amine forming a pyrrole: "
            "double condensation (hemiaminal → enamine) with dehydration. "
            "Simple, one-pot; makes 2,5-substituted pyrroles."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Paal, C. Ber. Dtsch. Chem. Ges. 1884, 17, 2756.",
    },
    "Hantzsch Pyridine Synthesis": {
        "type": "Addition", "distance": (1.4, 2.3),
        "description": (
            "Two β-keto esters + aldehyde + NH₃ condense forming a 1,4-dihydropyridine "
            "(Hantzsch ester), oxidised to the pyridine. DHP is a synthetic "
            "NADH analogue used as hydride donor in transfer hydrogenations."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Hantzsch, A. Liebigs Ann. Chem. 1882, 215, 1.",
    },
    "Fischer Indole Synthesis": {
        "type": "Addition", "distance": (1.4, 2.4),
        "description": (
            "Arylhydrazone of a ketone/aldehyde undergoes acid-catalysed [3,3]-"
            "sigmatropic rearrangement (ene-hydrazine → imine → aromatisation), "
            "forming a 2-substituted indole with loss of NH₃."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Fischer, E.; Jourdan, F. Ber. Dtsch. Chem. Ges. 1883, 16, 2241.",
    },
    "Biginelli Reaction (DHPm Synthesis)": {
        "type": "Addition", "distance": (1.4, 2.4),
        "description": (
            "Three-component MCR: aldehyde + β-keto ester + urea condensing under "
            "acid catalysis to 3,4-dihydropyrimidinones (DHPm). Biologically active "
            "scaffold (antihypertensive, antiviral). Knoevenagel/Mannich cascade."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Biginelli, P. Gazz. Chim. Ital. 1893, 23, 360.",
    },
    "Ugi Four-Component Reaction": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Aldehyde + amine + carboxylic acid + isocyanide react in one step "
            "forming an α-acylaminoamide (Ugi adduct). α-Adduct-peptide bond mimics; "
            "combinatorial library synthesis. Mechanism via iminium + α-addition."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Ugi, I. et al. Angew. Chem. Int. Ed. 1959, 71, 386.",
    },
    "Passerini Three-Component Reaction": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "Aldehyde/ketone + carboxylic acid + isocyanide react (no amine) forming "
            "α-acyloxy amides via concerted proton-transfer/addition or stepwise "
            "ion-pair mechanism. Rapid assembly of complex α-oxyamide scaffolds."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Passerini, M. Gazz. Chim. Ital. 1921, 51, 126.",
    },
    "Stetter Reaction (Umpolung Conjugate Addition)": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "NHC (or cyanide) catalyses umpolung addition of an aldehyde to a Michael "
            "acceptor: Breslow intermediate acts as acyl anion equivalent adding "
            "1,4 to enones, nitroalkenes, or acrylates to give 1,4-diketones."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Stetter, H.; Schreckenberg, M. Angew. Chem. Int. Ed. 1973, 12, 81.",
    },
    "Knoevenagel Condensation": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Active-methylene compound (malonate, cyanoacetate, nitroalkane) condenses "
            "with aldehyde under amine/base catalysis forming an α,β-unsaturated "
            "product (Knoevenagel adduct) via Doebner modification when with pyridine."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Knoevenagel, E. Ber. Dtsch. Chem. Ges. 1898, 31, 2596.",
    },
    "Perkin Reaction": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Aromatic aldehyde + acid anhydride in the presence of base (carboxylate) "
            "gives an α,β-unsaturated carboxylic acid via Claisen-like condensation; "
            "classic route to cinnamic acids."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Perkin, W. H. J. Chem. Soc. 1868, 21, 53.",
    },
    "Darzens Glycidic Ester Synthesis": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "α-Halo ester enolate (from base) attacks an aldehyde/ketone, then the "
            "alkoxide displaces the halide intramolecularly giving a glycidic ester "
            "(α,β-epoxy ester). Saponification/decarboxylation gives one-carbon "
            "homologated aldehyde."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Darzens, G. C. R. Acad. Sci. 1904, 139, 1214.",
    },
    "Baylis–Hillman Reaction": {
        "type": "Nucleophilic", "distance": (1.5, 2.4),
        "description": (
            "DABCO (or phosphine) catalyses coupling of an aldehyde with an activated "
            "alkene (acrylate, acrylonitrile) at the α-position, giving an α-methylene "
            "β-hydroxy ester — densely functionalised product in one step."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Baylis, A. B.; Hillman, M. E. D. DE 2155113, 1972.",
    },
    "Stork Enamine Alkylation": {
        "type": "Nucleophilic", "distance": (1.4, 2.3),
        "description": (
            "Cyclic secondary amine condenses with a ketone forming an enamine, "
            "which acts as a masked enolate for alkylation or acylation. Hydrolysis "
            "liberates the α-substituted ketone — regioselective Stork enamine synthesis."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Stork, G. et al. J. Am. Chem. Soc. 1963, 85, 207.",
    },

    # ── Asymmetric / Chiral Reactions ─────────────────────────────────────────
    "Sharpless Dihydroxylation (AD)": {
        "type": "Addition", "distance": (1.7, 2.5),
        "description": (
            "OsO₄ (catalytic) + re-oxidant (K₃Fe(CN)₆) with chiral cinchona alkaloid "
            "ligand (DHQ or DHQD) dihydroxylates alkenes enantioselectively. "
            "AD-mix α/β gives opposite faces; broad substrate scope. Nobel 2001 (Sharpless)."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Sharpless, K. B. et al. J. Org. Chem. 1992, 57, 2768.",
    },
    "Jacobsen–Katsuki Epoxidation": {
        "type": "Addition", "distance": (1.6, 2.5),
        "description": (
            "Mn(III)-salen (Jacobsen) or Cr(III)-salen catalyst delivers oxygen "
            "from a terminal oxidant (m-CPBA, NaOCl) to an unfunctionalised alkene "
            "enantioselectively via a Mn(V)-oxo intermediate on the less hindered face."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Jacobsen, E. N. et al. J. Am. Chem. Soc. 1991, 113, 7063.",
    },
    "CBS Reduction (Corey–Bakshi–Shibata)": {
        "type": "Addition", "distance": (1.7, 2.6),
        "description": (
            "Oxazaborolidine (CBS catalyst) activates BH₃ for enantioselective "
            "hydride delivery to prochiral ketones giving chiral alcohols. "
            "Substrate coordinates to B; hydride delivered from BH₃ to Re or Si face."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Corey, E. J. et al. J. Am. Chem. Soc. 1987, 109, 5551.",
    },
    "BINAP-Rh/Ru Asymmetric Hydrogenation": {
        "type": "Addition", "distance": (1.7, 2.6),
        "description": (
            "Chiral BINAP–Rh(I) or Ru(II) complex hydrogenates prochiral alkenes "
            "(dehydroamino acids, itaconates) or ketones with high ee. "
            "Mechanism: oxidative addition of H₂ → migratory insertion → reductive "
            "elimination (Rh); outer-sphere for Ru/ketone."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Noyori, R.; Takaya, H. Acc. Chem. Res. 1990, 23, 345.",
    },

    # ── Elimination Reactions ─────────────────────────────────────────────────
    "E2 Elimination": {
        "type": "Substitution", "distance": (2.0, 3.0),
        "description": (
            "Concerted anti-periplanar removal of a β-hydrogen by base with "
            "departure of a leaving group (halide, OTs) forming an alkene. "
            "Second-order kinetics; Zaitsev (more-substituted) or Hofmann "
            "(less-substituted) product depending on base."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Hughes, E. D.; Ingold, C. K. J. Chem. Soc. 1935, 244.",
    },
    "E1cb Elimination": {
        "type": "Substitution", "distance": (1.5, 2.5),
        "description": (
            "Stepwise: base deprotonates β-H forming a stabilised carbanion "
            "(conjugate base), then the leaving group departs. Favoured when "
            "β-H is acidic (α to EWG) and leaving group is poor."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Ingold, C. K. Structure and Mechanism in Organic Chemistry (1953).",
    },
    "Chugaev Elimination (Xanthate Pyrolysis)": {
        "type": "Substitution", "distance": (2.3, 3.2),
        "description": (
            "Thermal syn-elimination of a xanthate ester (ROC(=S)SMe) via a five-"
            "membered cyclic transition state: β-H and xanthate depart simultaneously "
            "giving an alkene + COS + MeSH. Mild; no acid/base needed."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Chugaev, L. A. Ber. Dtsch. Chem. Ges. 1899, 32, 3332.",
    },
    "Cope Elimination": {
        "type": "Substitution", "distance": (2.2, 3.2),
        "description": (
            "Thermal syn-elimination of an amine oxide via a five-membered "
            "cyclic TS: β-H and N⁺-oxide oxygen depart giving an alkene + "
            "hydroxylamine. Mild (50–150 °C); stereospecific syn."
        ),
        "anchor_role": "acceptor", "guest_role": "donor_h",
        "ref": "Cope, A. C.; Trumbull, E. R. Org. React. 1960, 11, 317.",
    },

    # ── Sigmatropic & Pericyclic ───────────────────────────────────────────────
    "Cope Rearrangement [3,3]": {
        "type": "Addition", "distance": (1.9, 3.2),
        "description": (
            "Thermal [3,3]-sigmatropic rearrangement of a 1,5-diene: concerted "
            "chair or boat TS; no catalyst needed. Oxy-Cope variant (allylic alcohol "
            "substructure) irreversibly driven by enolisation. Key in total synthesis."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Cope, A. C. et al. J. Am. Chem. Soc. 1940, 62, 441.",
    },
    "Claisen Rearrangement [3,3]": {
        "type": "Addition", "distance": (1.9, 3.2),
        "description": (
            "Thermal [3,3]-sigmatropic rearrangement of an allyl vinyl ether to "
            "a γ,δ-unsaturated carbonyl compound. Aromatic Claisen (allyl aryl ether "
            "→ cyclohexadienone → phenol) is irreversible. Stereospecific chair-like TS."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Claisen, L. Ber. Dtsch. Chem. Ges. 1912, 45, 3157.",
    },
    "Ireland–Claisen Rearrangement": {
        "type": "Addition", "distance": (1.9, 3.2),
        "description": (
            "LDA/TMS enolate of an allyl ester undergoes [3,3]-sigmatropic "
            "rearrangement to give γ,δ-unsaturated carboxylic acids with high "
            "stereocontrol. E/Z enolate geometry controls product diastereoselectivity."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Ireland, R. E.; Mueller, R. H. J. Am. Chem. Soc. 1972, 94, 5897.",
    },
    "Ene Reaction": {
        "type": "Addition", "distance": (1.9, 3.2),
        "description": (
            "An alkene bearing an allylic C-H (ene component) reacts with an "
            "enophile (C=O, C=C, singlet O₂, DMAD) via a six-membered TS: "
            "allylic H transfers to enophile, new σ-bond forms, alkene migrates. "
            "Thermal; related to [1,5]-H shift."
        ),
        "anchor_role": "nucleophile", "guest_role": "electrophile",
        "ref": "Alder, K. et al. Liebigs Ann. Chem. 1943, 555, 1.",
    },
    "Cheletropic Reaction (SO₂ Extrusion)": {
        "type": "Substitution", "distance": (1.5, 2.5),
        "description": (
            "Concerted extrusion of a small molecule (SO₂, CO) from a cyclic "
            "compound via simultaneous breaking of two bonds at the same atom. "
            "Sulfolenes lose SO₂ at 100 °C releasing conjugated dienes (retro-cheletropic)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Woodward, R. B.; Hoffmann, R. J. Am. Chem. Soc. 1965, 87, 2511.",
    },

    # ── Transition-Metal Catalysis (Additional) ────────────────────────────────
    "Negishi Cross-Coupling": {
        "type": "Addition", "distance": (1.9, 2.8),
        "description": (
            "Pd (or Ni)-catalysed coupling of an organozinc reagent with an aryl, "
            "vinyl, or alkyl halide. Broader scope than Suzuki (alkyl-Zn tolerated); "
            "milder than Grignard. Nobel 2010 (Negishi, Suzuki, Heck)."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Negishi, E.-i. et al. J. Org. Chem. 1977, 42, 1821.",
    },
    "Kumada Coupling": {
        "type": "Addition", "distance": (1.9, 2.8),
        "description": (
            "Ni or Pd-catalysed coupling of a Grignard reagent (R-MgX) with an "
            "aryl/vinyl halide. First developed cross-coupling; functional group "
            "tolerance limited by Grignard reactivity but very atom-economical."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Kumada, M. et al. Tetrahedron Lett. 1972, 13, 4971.",
    },
    "Stille Cross-Coupling": {
        "type": "Addition", "distance": (1.9, 2.8),
        "description": (
            "Pd-catalysed coupling of an organostannane (R-SnBu₃) with an aryl/vinyl "
            "halide or triflate. Tolerates wide functional groups; air/water stable "
            "reagents. Tin toxicity limits large-scale use."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Stille, J. K. Angew. Chem. Int. Ed. 1986, 25, 508.",
    },
    "Sonogashira Coupling": {
        "type": "Addition", "distance": (1.8, 2.7),
        "description": (
            "Pd/Cu(I)-catalysed coupling of a terminal alkyne with an aryl or vinyl "
            "halide giving an internal alkyne. CuI co-catalyst activates alkyne via "
            "copper acetylide; often run under amine base/solvent."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Sonogashira, K. et al. Tetrahedron Lett. 1975, 16, 4467.",
    },
    "Wacker Oxidation": {
        "type": "Substitution", "distance": (2.0, 3.0),
        "description": (
            "Pd(II)/Cu(II)/O₂ catalyse oxidation of a terminal alkene to a methyl "
            "ketone (Markovnikov) or aldehyde (terminal): alkene coordinates to Pd, "
            "OH inserts, β-hydride elimination, Pd(0) re-oxidised by CuCl₂/O₂."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Smidt, J. et al. Angew. Chem. 1959, 71, 176.",
    },
    "Trost Tsuji Allylation (π-allyl Pd)": {
        "type": "Nucleophilic", "distance": (2.0, 3.2),
        "description": (
            "Pd(0) oxidatively adds to an allylic electrophile forming a π-allyl-Pd "
            "complex; soft nucleophile (malonate, β-keto ester, amine) attacks the "
            "allyl terminus with retention/inversion. Chiral PHOX ligands give high ee."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Trost, B. M.; Fullerton, T. J. J. Am. Chem. Soc. 1973, 95, 292.",
    },
    "C–H Activation / Functionalization": {
        "type": "Substitution", "distance": (2.0, 3.5),
        "description": (
            "Transition metal (Pd, Rh, Ru, Ni, Ir) inserts into an unreactive C–H "
            "bond via concerted metalation-deprotonation (CMD), oxidative addition, "
            "or σ-bond metathesis, enabling direct C–C/C–X bond formation without "
            "pre-functionalization."
        ),
        "anchor_role": "electrophile", "guest_role": "nucleophile",
        "ref": "Godula, K.; Sames, D. Science 2006, 312, 67.",
    },
    "Asymmetric Transfer Hydrogenation (Noyori–Ikariya)": {
        "type": "Addition", "distance": (1.7, 2.6),
        "description": (
            "Ru/Os-TsDPEN catalyst transfers H from formate or iPrOH to ketones/imines "
            "via outer-sphere mechanism (concerted NH···O + M-H). High ee for aryl ketones; "
            "no high-pressure H₂ needed. Nobel 2001."
        ),
        "anchor_role": "electrophile", "guest_role": "donor_h",
        "ref": "Noyori, R. et al. J. Am. Chem. Soc. 1995, 117, 7562.",
    },
}


PERIODIC_SYMBOLS = [
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
    "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
    "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe",
    "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf",
    "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs",
    "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
]

ATOMIC_NUMBERS = {symbol: idx + 1 for idx, symbol in enumerate(PERIODIC_SYMBOLS)}


def normalize_reaction_type(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return "Non-covalent"
    lowered = text.lower()
    if lowered in REACTION_TYPE_ALIASES:
        return REACTION_TYPE_ALIASES[lowered]
    for candidate in REACTION_TYPE_CHOICES:
        if lowered == candidate.lower():
            return candidate
    return "Non-covalent"


# =============================================================================
# PREBIOTIC REACTION CONDITION DATABASE
# =============================================================================
# Schema per reaction:
#   "env"      : list of compatible prebiotic environments
#   "T_K"      : (min, max, optimal) temperature in Kelvin
#   "pH"       : (min, max, optimal)
#   "P_atm"    : (min, max) pressure in atm  (None = ambient)
#   "atmosphere": list of required gas-phase components
#   "minerals"  : list of solid-phase catalysts / surfaces
#   "reactants" : dict  {SMILES/name: role}
#   "products"  : list of product names
#   "energy_kJ" : ΔG° in kJ/mol at ~298 K (positive = endergonic at STP)
#   "pathway"   : short mechanistic note
#   "refs"      : key literature references
#   "feasibility_notes": plain-text guidance
PREBIOTIC_DB: Dict[str, Dict] = {
    # ── AMINO ACID SYNTHESIS ─────────────────────────────────────────────────
    "Miller-Urey (amino acids)": {
        "category": "Amino Acid Synthesis",
        "env": ["Primitive atmosphere", "Tidal pool (spark discharge)"],
        "T_K": (273, 373, 298), "pH": (5.0, 8.0, 7.0), "P_atm": (0.5, 2.0),
        "atmosphere": ["H2", "NH3", "CH4", "H2O(g)"],
        "minerals": [],
        "reactants": {"H2": "reducing agent", "NH3": "nitrogen source",
                      "CH4": "carbon source", "H2O": "solvent/H source"},
        "products": ["Glycine", "Alanine", "Aspartic acid", "Glutamic acid",
                     "α-aminobutyric acid", "Serine"],
        "energy_kJ": 35.0,
        "pathway": "Lightning/UV spark → radical chain → amino-nitrile intermediate → hydrolysis",
        "refs": ["Miller S.L. Science 1953", "Miller & Urey Science 1959"],
        "feasibility_notes": (
            "Requires strongly reducing atmosphere (H2:CH4:NH3 ~1:2:1). "
            "Spark or UV energy input ~1000 kJ/mol net. Favoured at 25–60 °C aqueous phase. "
            "Modern volcanic gas ratios (CO/CO2 dominated) reduce yield significantly."
        ),
    },
    "Strecker synthesis (amino acids)": {
        "category": "Amino Acid Synthesis",
        "env": ["Aqueous solution", "Tidal pool", "Hydrothermal vent plume"],
        "T_K": (273, 373, 310), "pH": (6.0, 9.0, 7.5), "P_atm": (0.5, 2.0),
        "atmosphere": ["NH3", "HCN"],
        "minerals": [],
        "reactants": {"aldehyde (RCHO)": "C skeleton", "HCN": "CN− donor",
                      "NH3": "amino donor", "H2O": "solvent"},
        "products": ["α-amino acid (general)", "Glycine (from formaldehyde)",
                     "Alanine (from acetaldehyde)"],
        "energy_kJ": -15.0,
        "pathway": "R-CHO + NH3 → imine; imine + HCN → α-aminonitrile; hydrolysis → α-amino acid",
        "refs": ["Strecker A. Ann. Chem. Pharm. 1850", "Peltzer et al. 1984"],
        "feasibility_notes": (
            "Thermodynamically spontaneous (−ΔG). HCN concentration > 10⁻³ M required. "
            "Competing hydrolysis of HCN to formamide limits yield at T > 50 °C. "
            "Metal ion catalysis (Fe²⁺, Zn²⁺) accelerates."
        ),
    },
    "Peptide bond formation (mineral surface)": {
        "category": "Amino Acid Synthesis",
        "env": ["Mineral surface", "Drying lagoon", "Hydrothermal vent pore"],
        "T_K": (333, 423, 373), "pH": (4.0, 7.0, 5.5), "P_atm": (0.9, 3.0),
        "atmosphere": [],
        "minerals": ["Montmorillonite", "Hydroxyapatite", "Illite", "Serpentinite"],
        "reactants": {"amino acid": "monomer"},
        "products": ["Dipeptide", "Oligopeptide (≤10-mer)"],
        "energy_kJ": 17.0,
        "pathway": "Dry-wet cycle adsorption on clay → activated ester-like intermediate → condensation",
        "refs": ["Fox & Harada 1958", "Ferris et al. Science 1996", "Orgel L.E. 1998"],
        "feasibility_notes": (
            "Endergonic in dilute aqueous solution (+17 kJ/mol). Mineral concentration effect "
            "and evaporation drive equilibrium forward. Montmorillonite catalyses "
            "up to 55-mer peptides from activated amino acids. Temperature cycling (wet/dry) essential."
        ),
    },
    # ── NUCLEOBASE / NUCLEOTIDE SYNTHESIS ────────────────────────────────────
    "HCN polymerization → Adenine": {
        "category": "Nucleobase Synthesis",
        "env": ["Ice eutectic", "Concentrated HCN pool", "Cometary ice"],
        "T_K": (233, 310, 253), "pH": (8.0, 11.0, 9.5), "P_atm": (0.5, 1.5),
        "atmosphere": ["HCN", "NH3"],
        "minerals": [],
        "reactants": {"HCN": "sole C/N source", "NH3": "base catalyst"},
        "products": ["Adenine (HCN pentamer)", "DAMN (diaminomaleonitrile)", "AICN"],
        "energy_kJ": -80.0,
        "pathway": "5 HCN → DAMN intermediate → photocatalytic rearrangement → AICN → adenine",
        "refs": ["Oró J. BBRC 1960", "Sanchez et al. Science 1966", "Miyakawa et al. 2002"],
        "feasibility_notes": (
            "Ice-eutectic concentrates HCN to > 1 M. pH must be basic (NH3 buffer). "
            "Photolysis at 250–300 nm accelerates. Yield ~1% from HCN. "
            "Occurs in cometary ices (confirmed by Rosetta mission)."
        ),
    },
    "Formamide thermolysis → nucleobases": {
        "category": "Nucleobase Synthesis",
        "env": ["Hydrothermal vent", "Impact-heated crater lake", "Volcanic rock pore"],
        "T_K": (373, 573, 473), "pH": (4.0, 8.0, 6.0), "P_atm": (0.5, 50.0),
        "atmosphere": ["HCONH2"],
        "minerals": ["TiO2 (anatase)", "Meteorite powder", "Fe3O4", "ZnO"],
        "reactants": {"Formamide (HCONH2)": "sole carbon/nitrogen feedstock"},
        "products": ["Adenine", "Guanine", "Cytosine", "Uracil", "HCN", "Formaldehyde"],
        "energy_kJ": -30.0,
        "pathway": "Thermocatalytic condensation of formamide over mineral catalysts at 100–300 °C",
        "refs": ["Saladino et al. ChemBioChem 2001", "Saladino et al. Chem Soc Rev 2012"],
        "feasibility_notes": (
            "Single-feedstock synthesis of all four RNA bases + other biomolecules. "
            "TiO2 is the most effective catalyst (UV photocatalysis also works). "
            "High-temperature vents or meteorite impact craters are ideal settings."
        ),
    },
    "Purine synthesis (formaldehyde + HCN)": {
        "category": "Nucleobase Synthesis",
        "env": ["Aqueous pool", "Alkaline lake"],
        "T_K": (278, 343, 310), "pH": (8.5, 12.0, 10.0), "P_atm": (0.5, 1.5),
        "atmosphere": ["HCN", "HCHO"],
        "minerals": [],
        "reactants": {"HCN": "C1+N1 unit", "HCHO": "C1 unit"},
        "products": ["Hypoxanthine", "Xanthine", "Adenine", "Guanine"],
        "energy_kJ": -45.0,
        "pathway": "Purine formed via guanidine + aminoimidazole intermediates",
        "refs": ["Oró 1961", "Ferris & Orgel 1966"],
        "feasibility_notes": "Requires alkaline pH (>9). UV irradiation enhances guanine yield.",
    },
    "Pyrimidine synthesis (urea + cyanoacetylene)": {
        "category": "Nucleobase Synthesis",
        "env": ["Tidal flat", "Shallow lake (dry-wet cycle)"],
        "T_K": (273, 373, 323), "pH": (6.0, 10.0, 8.0), "P_atm": (0.5, 1.5),
        "atmosphere": ["HC≡C-CN", "Urea"],
        "minerals": [],
        "reactants": {"Urea (NH2CONH2)": "C+N donor", "Cyanoacetylene (HC≡CCN)": "C3N skeleton"},
        "products": ["Cytosine", "Uracil (via cytosine deamination)"],
        "energy_kJ": -55.0,
        "pathway": "Urea + cyanoacetylene → β-ureidoacrylonitrile → cytosine → uracil (pH 7 deamination)",
        "refs": ["Ferris et al. JACS 1968", "Robertson & Miller 1995"],
        "feasibility_notes": (
            "Cyanoacetylene formed in Miller-Urey type atmosphere. Concentrated urea pools (~1 M) "
            "needed. Dry-wet cycles on tidal flats enhance yields up to 50%."
        ),
    },
    "Ribose synthesis (Formose reaction)": {
        "category": "Sugar Synthesis",
        "env": ["Alkaline lake", "Mineral pore water"],
        "T_K": (273, 373, 333), "pH": (9.0, 13.0, 11.0), "P_atm": (0.5, 1.5),
        "atmosphere": ["HCHO"],
        "minerals": ["Ca(OH)2", "Pb(OH)2", "Borate minerals (colemanite)"],
        "reactants": {"Formaldehyde (HCHO)": "sole carbon source"},
        "products": ["D/L-Ribose", "D/L-Glucose", "D/L-Xylose", "Glycolaldehyde",
                     "Glyceraldehyde", "Erythrose"],
        "energy_kJ": -80.0,
        "pathway": "Formaldehyde autocatalytic aldol condensation: 2C → glycolaldehyde → 3C → 4C → 5C sugars",
        "refs": ["Butlerow A. 1861", "Breslow R. JACS 1959", "Müller et al. 1990"],
        "feasibility_notes": (
            "Highly non-selective — produces complex mixture of sugars. Borate minerals "
            "strongly stabilise ribose via 2,3-diol chelation. Boron-rich lakes (e.g., Turkey) "
            "proposed as ideal prebiotic sites. Formaldehyde from UV photolysis of CO2+H2O."
        ),
    },
    "Nucleoside formation (sugar + base)": {
        "category": "Nucleotide Synthesis",
        "env": ["Mineral surface", "Dry-wet cycle", "UV-exposed lagoon"],
        "T_K": (333, 423, 393), "pH": (4.5, 8.0, 6.0), "P_atm": (0.8, 2.0),
        "atmosphere": [],
        "minerals": ["Hydroxyapatite", "Montmorillonite", "Sepiolite"],
        "reactants": {"Ribose": "sugar", "Purine/Pyrimidine base": "heterocycle",
                      "Mg²⁺/Ca²⁺": "Lewis acid catalyst"},
        "products": ["Adenosine", "Guanosine", "Cytidine", "Uridine"],
        "energy_kJ": 25.0,
        "pathway": "Fischer glycosylation or phosphorolysis-like mechanism on mineral surface",
        "refs": ["Orgel L.E. PLoS Biol 2004", "Powner et al. Nature 2009"],
        "feasibility_notes": (
            "Traditionally the hardest step in prebiotic chemistry. "
            "Sutherland/Powner 2009 bypassed direct glycosylation via activated intermediates. "
            "UV light at 254 nm repairs unwanted β-isomers. Requires phosphate."
        ),
    },
    "Nucleotide phosphorylation": {
        "category": "Nucleotide Synthesis",
        "env": ["Volcanic hot spring", "Dry mineral surface"],
        "T_K": (313, 433, 373), "pH": (3.5, 7.0, 5.0), "P_atm": (0.8, 3.0),
        "atmosphere": [],
        "minerals": ["Hydroxyapatite", "Apatite", "Phosphoric acid rock"],
        "reactants": {"Nucleoside": "acceptor", "Orthophosphate/Polyphosphate": "phosphate donor",
                      "Urea": "condensing agent"},
        "products": ["AMP", "GMP", "CMP", "UMP", "5'-nucleotide triphosphates"],
        "energy_kJ": 30.0,
        "pathway": "Mineral-assisted condensation of phosphate onto 5'-OH; polyphosphate from volcanic HPO3",
        "refs": ["Osterberg & Orgel 1972", "Handschuh et al. 1973", "Yamagata et al. 1991"],
        "feasibility_notes": (
            "Polyphosphate is abundant near volcanoes. Urea or dicyandiamide as condensing agent. "
            "Dry conditions at 65–100 °C yield 10–20% 5'-NMP. "
            "Cyclophosphates are intermediates."
        ),
    },
    # ── RNA WORLD ────────────────────────────────────────────────────────────
    "RNA oligomerisation (template-directed)": {
        "category": "RNA World",
        "env": ["Mineral surface", "Ice eutectic"],
        "T_K": (233, 310, 273), "pH": (6.5, 8.5, 7.5), "P_atm": (0.8, 1.5),
        "atmosphere": [],
        "minerals": ["Montmorillonite"],
        "reactants": {"Activated NMPs (ImpA/ImpG)": "monomers",
                      "Mg²⁺": "cofactor", "Mn²⁺": "cofactor"},
        "products": ["RNA oligomers (up to 40-mers)", "tRNA-like structures"],
        "energy_kJ": -20.0,
        "pathway": "Imidazole-activated nucleotides adsorb on montmorillonite → 3'-5' phosphodiester bonds",
        "refs": ["Ferris et al. Nature 1996", "Ferris J.P. Orig Life 2002"],
        "feasibility_notes": (
            "Montmorillonite clay catalyses formation of oligomers with >80% 3'-5' regioselectivity. "
            "Ice eutectic also concentrates monomers (glacial melt hypothesis). "
            "Imidazolide activation = model for how early nucleotides were activated."
        ),
    },
    "Ribozyme self-cleavage": {
        "category": "RNA World",
        "env": ["Aqueous compartment", "Lipid vesicle"],
        "T_K": (273, 323, 308), "pH": (5.5, 8.5, 7.0), "P_atm": (0.8, 1.5),
        "atmosphere": [],
        "minerals": [],
        "reactants": {"RNA strand (≥15-mer)": "substrate + catalyst",
                      "Mg²⁺ (>1 mM)": "cofactor"},
        "products": ["Cleaved RNA fragments", "Ligated RNA"],
        "energy_kJ": -5.0,
        "pathway": "Hammerhead/hairpin ribozyme: Mg²⁺-assisted 2'-OH nucleophile attacks phosphodiester",
        "refs": ["Cech TR 1986 Nobel", "Guerrier-Takada et al. Cell 1983"],
        "feasibility_notes": (
            "Catalytic RNA is the core of the RNA World hypothesis. Mg²⁺ ≥ 2 mM essential. "
            "Activity maintained in simple vesicles. Temperature range 0–50 °C. "
            "pH optimum ~7 but active 5.5–8."
        ),
    },
    # ── LIPID / MEMBRANE ─────────────────────────────────────────────────────
    "Fatty acid vesicle formation": {
        "category": "Membrane Formation",
        "env": ["Alkaline hydrothermal vent (Lost City type)", "Ocean-atmosphere interface"],
        "T_K": (273, 353, 308), "pH": (7.5, 10.5, 8.5), "P_atm": (0.5, 2.0),
        "atmosphere": [],
        "minerals": [],
        "reactants": {"Oleic acid (C18:1)": "amphiphile", "Decanoic acid (C10:0)": "amphiphile",
                      "Na⁺/K⁺ ions": "counterions"},
        "products": ["Fatty acid vesicle (bilayer)", "Micellar aggregate"],
        "energy_kJ": -15.0,
        "pathway": "Self-assembly above CMC; bilayer seals into vesicle at pH > pKa(fatty acid) ~7",
        "refs": ["Deamer DW Orig Life 1985", "Hanczyc et al. Science 2003"],
        "feasibility_notes": (
            "Fatty acids from Fischer-Tropsch synthesis at hydrothermal vents. "
            "Vesicle formation favoured at pH 7.5–9 (oleate, pKa 8.5). "
            "Montmorillonite clay nucleates and stabilises vesicle formation. "
            "Vesicles can grow by incorporating monomers and divide under shear flow."
        ),
    },
    "Fischer-Tropsch lipid synthesis": {
        "category": "Membrane Formation",
        "env": ["Hydrothermal vent (serpentinisation)"],
        "T_K": (373, 673, 473), "pH": (8.0, 12.0, 10.5), "P_atm": (50, 500),
        "atmosphere": ["H2", "CO", "CO2"],
        "minerals": ["Fe/Ni catalysts", "Magnetite (Fe3O4)", "Serpentine"],
        "reactants": {"CO/CO2": "carbon source", "H2": "reductant"},
        "products": ["Alkanes (CnH2n+2)", "Fatty acids", "Alcohols", "Alkenes"],
        "energy_kJ": -165.0,
        "pathway": "CO + H2 → (Fe/Ni surface) → alkyl chains → fatty acids (oxidation)",
        "refs": ["McCollom & Seewald Geochim 2003", "Proskurowski et al. Science 2008"],
        "feasibility_notes": (
            "Confirmed at Lost City (30–90 °C, pH 9–11) and other off-axis hydrothermal vents. "
            "Serpentinisation produces H2 which drives FT synthesis. "
            "Short-chain fatty acids (C10–C16) are most relevant to membrane assembly."
        ),
    },
    # ── ENERGY CURRENCY ──────────────────────────────────────────────────────
    "Proton gradient (chemiosmosis precursor)": {
        "category": "Energy & Metabolism",
        "env": ["Alkaline hydrothermal vent (Lost City)"],
        "T_K": (303, 363, 333), "pH": (5.0, 12.0, None), "P_atm": (1.0, 5.0),
        "atmosphere": [],
        "minerals": ["FeS / NiS", "Greigite (Fe3S4)"],
        "reactants": {"H2 (vent)": "electron donor", "CO2 (ocean)": "electron acceptor",
                      "ΔpH (vent-ocean interface)": "free energy source"},
        "products": ["ATP analogue (polyphosphate)", "Acetate (acetyl-CoA analogue)", "CH4"],
        "energy_kJ": -30.0,
        "pathway": "Natural proton gradient across FeS membrane → protometabolism → Wood-Ljungdahl pathway analogue",
        "refs": ["Russell & Hall 1997", "Lane & Martin Nature 2010"],
        "feasibility_notes": (
            "Natural alkaline vent pH ~11 vs ocean pH ~5.5 at 4 Ga = ΔpH ~5.5. "
            "FeS/NiS minerals act as primitive electron transfer chains. "
            "Energy per proton ~20 kJ/mol (cf. ATP synthase 3 protons per ATP = ~60 kJ/mol). "
            "Core of the 'alkaline vent' origin-of-life hypothesis."
        ),
    },
    "Pyrite formation (FeS + H2S → FeS2)": {
        "category": "Energy & Metabolism",
        "env": ["Hydrothermal vent", "Anoxic ocean floor"],
        "T_K": (273, 473, 373), "pH": (3.0, 8.0, 5.0), "P_atm": (1, 300),
        "atmosphere": ["H2S", "CO2"],
        "minerals": ["FeS (mackinawite)", "FeS2 (pyrite)"],
        "reactants": {"FeS": "iron sulphide", "H2S": "sulphide source"},
        "products": ["FeS2 (pyrite)", "H2 (released)"],
        "energy_kJ": -41.9,
        "pathway": "FeS + H2S → FeS2 + H2  (Wächtershäuser 'iron-sulphur world')",
        "refs": ["Wächtershäuser G. Microbiol Mol Biol Rev 1988", "Heinen & Lauwers 1996"],
        "feasibility_notes": (
            "H2 released drives CO2 fixation via Wood-Ljungdahl. FeS surface is organic-chemistry "
            "catalyst (thioester precursors). Basis of Wächtershäuser surface-metabolism hypothesis."
        ),
    },
    "Polyphosphate synthesis (volcanic)": {
        "category": "Energy & Metabolism",
        "env": ["Volcanic fumarole", "Hot spring"],
        "T_K": (433, 773, 573), "pH": (1.0, 5.0, 2.5), "P_atm": (0.5, 5.0),
        "atmosphere": ["SO2", "HF", "HPO3"],
        "minerals": ["Apatite", "Hydroxyapatite"],
        "reactants": {"H3PO4 / HPO3": "phosphate source"},
        "products": ["Pyrophosphate (PP)", "Triphosphate", "Polyphosphate (polyPi)"],
        "energy_kJ": 32.0,
        "pathway": "Thermal condensation of orthophosphate at T > 160 °C; metaphosphate intermediate",
        "refs": ["Westheimer FH Science 1987", "Yamagata et al. 1991"],
        "feasibility_notes": (
            "Polyphosphate is thermodynamically accessible at volcanic temperatures. "
            "Acts as prebiotic ATP analogue (phosphoryl donor). "
            "Dissolves on contact with water — requires rapid utilisation or encapsulation."
        ),
    },
    # ── CARBON FIXATION ──────────────────────────────────────────────────────
    "CO2 fixation (reductive TCA precursor)": {
        "category": "Carbon Fixation",
        "env": ["Hydrothermal vent", "Iron-sulphur chemistry"],
        "T_K": (333, 473, 393), "pH": (4.0, 8.0, 6.0), "P_atm": (10, 200),
        "atmosphere": ["H2", "CO2", "CO"],
        "minerals": ["FeS", "NiS", "Co/Ni alloy"],
        "reactants": {"CO2": "carbon source", "H2": "electron donor", "FeS/NiS": "catalyst"},
        "products": ["Pyruvate", "Oxaloacetate", "Succinate", "Citrate", "Acetyl-CoA analogue"],
        "energy_kJ": -120.0,
        "pathway": "Reductive (reverse) TCA cycle: CO2 + H2 → acetate → pyruvate → C4 acids",
        "refs": ["Wächtershäuser 1990", "Smith & Morowitz 2004", "Muchowska et al. Nature 2019"],
        "feasibility_notes": (
            "Mineral-catalysed rTCA cycle demonstrated without enzymes using Fe/Ni sulfides. "
            "Produces α-keto acids directly relevant to amino acid synthesis. "
            "H2-rich vent environments provide thermodynamic drive."
        ),
    },
    "HCN hydrolysis → formamide → formate": {
        "category": "Carbon Fixation",
        "env": ["Primitive ocean", "Meteorite-impact lake"],
        "T_K": (273, 373, 320), "pH": (6.0, 10.0, 8.0), "P_atm": (0.5, 1.5),
        "atmosphere": ["HCN"],
        "minerals": [],
        "reactants": {"HCN": "carbon/nitrogen source", "H2O": "hydrolysis agent"},
        "products": ["Formamide (HCONH2)", "Formate (HCOO⁻)", "NH4⁺"],
        "energy_kJ": -40.0,
        "pathway": "HCN + H2O → formamide; formamide + H2O → formate + NH4⁺",
        "refs": ["Sanchez et al. 1967", "Saladino et al. 2012"],
        "feasibility_notes": (
            "HCN hydrolysis is fast at T > 50 °C, pH > 9. "
            "Formamide is a key intermediate for nucleobase synthesis (see Formamide thermolysis). "
            "HCN from lightning in N2/CH4 atmosphere or from HCN-rich cometary material."
        ),
    },
    # ── ATMOSPHERE & WATER ───────────────────────────────────────────────────
    "UV photolysis of water → O2 (Hadean)": {
        "category": "Atmospheric Chemistry",
        "env": ["Primitive atmosphere (UV irradiated)"],
        "T_K": (273, 400, 300), "pH": (None, None, None), "P_atm": (0.1, 2.0),
        "atmosphere": ["H2O(g)", "CO2", "N2"],
        "minerals": [],
        "reactants": {"H2O(g)": "substrate", "UV (200–280 nm)": "energy source"},
        "products": ["H2O2", "OH radical", "H radical", "O2 (trace)"],
        "energy_kJ": 285.0,
        "pathway": "H2O + hν → H• + OH•; OH• + OH• → H2O2; H2O2 + hν → 2 OH•",
        "refs": ["Kasting JF Icarus 1993", "Tian et al. Science 2005"],
        "feasibility_notes": (
            "Before ozone layer, UV flux at surface was 1000× modern. "
            "Drives both destructive (amino acid decomposition) and constructive (HCN from N2+CH4) chemistry. "
            "H2O2 builds up in early oceans → potential prebiotic oxidant."
        ),
    },
    "Nitrogen fixation (lightning)": {
        "category": "Atmospheric Chemistry",
        "env": ["Primitive atmosphere", "Volcanic plume"],
        "T_K": (4000, 30000, 10000), "pH": (None, None, None), "P_atm": (0.5, 2.0),
        "atmosphere": ["N2", "O2 (trace)", "H2O(g)"],
        "minerals": [],
        "reactants": {"N2": "nitrogen source", "O2": "oxidant", "H2O": "H source"},
        "products": ["NO", "NO2", "HNO3", "NH3 (at reducing conditions)"],
        "energy_kJ": 180.0,
        "pathway": "N2 + O2 → 2 NO (lightning, T > 4000 K); NO + O → NO2; NO2 + H2O → HNO3",
        "refs": ["Kasting & Walker 1981", "Navarro-González et al. 1998"],
        "feasibility_notes": (
            "Lightning N-fixation estimated 1–5 × 10⁹ mol N/yr on early Earth. "
            "In reducing atmosphere: N2 + 3H2 → 2NH3 (catalysed by FeS surfaces). "
            "Nitrate/nitrite rain essential prebiotic fixed-nitrogen source."
        ),
    },
    # ── MINERAL / HYDROTHERMAL ───────────────────────────────────────────────
    "Serpentinisation (H2 production)": {
        "category": "Geochemical",
        "env": ["Submarine hydrothermal vent (off-axis)", "Ophiolite"],
        "T_K": (373, 573, 473), "pH": (9.0, 13.0, 11.0), "P_atm": (50, 500),
        "atmosphere": [],
        "minerals": ["Olivine (Mg2SiO4)", "Pyroxene", "Serpentine", "Magnetite"],
        "reactants": {"Olivine/Pyroxene": "substrate", "H2O": "oxidant"},
        "products": ["Serpentine", "Magnetite (Fe3O4)", "H2", "CH4 (via methanation)"],
        "energy_kJ": -66.0,
        "pathway": "(Mg,Fe)2SiO4 + H2O → Mg3Si2O5(OH)4 + Fe3O4 + H2",
        "refs": ["Sleep et al. Nature 2004", "Kelley et al. Science 2001 (Lost City)"],
        "feasibility_notes": (
            "Lost City hydrothermal field produces H2 at ~90 mmol/kg fluid. "
            "H2 is the primary electron donor for early life. "
            "Also produces CH4 (10 mmol/kg) via Sabatier reaction. "
            "Ongoing at mid-ocean ridges globally."
        ),
    },
    "Carbonate mineralisation (Ca/Mg cycling)": {
        "category": "Geochemical",
        "env": ["Alkaline lake", "Shallow ocean"],
        "T_K": (273, 373, 298), "pH": (7.0, 10.5, 8.5), "P_atm": (0.5, 2.0),
        "atmosphere": ["CO2"],
        "minerals": ["Calcite (CaCO3)", "Dolomite (CaMgCO3)2", "Magnesite"],
        "reactants": {"CO2": "acid", "Ca²⁺ / Mg²⁺": "cations", "OH⁻": "base"},
        "products": ["CaCO3 (calcite/aragonite)", "CO3²⁻ (carbonate alkalinity)"],
        "energy_kJ": -12.0,
        "pathway": "CO2 + H2O ⇌ HCO3⁻ + H⁺; Ca²⁺ + CO3²⁻ → CaCO3↓",
        "refs": ["Kempe & Degens 1985", "Grotzinger & Knoll 1999"],
        "feasibility_notes": (
            "Carbonate precipitation controls ocean pH and alkalinity on geological timescales. "
            "Soda lakes (high Na2CO3) have been proposed as ideal prebiotic reaction vessels "
            "(Sutherland group, 2015). High carbonate concentrations drive dehydration reactions."
        ),
    },
}

