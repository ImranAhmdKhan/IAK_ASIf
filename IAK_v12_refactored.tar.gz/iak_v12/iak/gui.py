"""
iak.gui
=======
IAKApp — the main Tkinter GUI application.

All tabs, progress monitors, molecular viewers, plotting controls,
and prebiotic workflow panels live here.  The GUI depends on the
pure-logic modules (iak.chem, iak.pipeline, …) but not vice-versa,
enabling CLI and batch use without importing Tkinter.
"""
from __future__ import annotations

import logging
import math
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path
from tkinter import Toplevel, Text, colorchooser, filedialog, messagebox, simpledialog, ttk
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import numpy as np
import tkinter as tk

try:
    import matplotlib
    import matplotlib.patches as mpatches
    import matplotlib.path as mpath
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    from matplotlib.figure import Figure
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 — registers 3D projection
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

from iak.constants import EH2KCAL, KCAL2KJ, REACTION_TYPE_CHOICES, REACTION_TYPE_ALIASES, CPK_COLORS, CPK_DEFAULT, VDW_RADII
from iak.data import REACTION_LIBRARY, PREBIOTIC_DB
from iak.structures import Atom, Molecule, read_multi_xyz
from iak.chem import (
    normalize_reaction_type,
    atom_counts_for_molecule,
    atom_counts_to_formula,
    expected_cluster_atom_counts,
    validate_charge_multiplicity,
    kabsch_rmsd,
    score_geometry,
    generate_cluster,
    find_hbond_acceptors,
    find_hbond_donors,
)
from iak.config import Config, RunMode
from iak.pipeline import Pipeline
from iak.engine import (
    is_tool_available, inject_embedded_engines,
    XTB_URLS, CREST_URLS, ENGINE_DIR,
    XTB_DIR, CREST_DIR, ORCA_DIR, ORCA_IS_WINDOWS,
    get_wsl_path,
)
from iak.logging_setup import setup_logging



# ---------------------------------------------------------------------------
# GUI colour configuration
# ---------------------------------------------------------------------------
_C = {
    "bg": "#ffffff",
    "panel": "#f6f8fa",
    "border": "#d0d7de",
    "text": "#24292f",
    "muted": "#57606a",
    "dim": "#e1e4e8",
    "accent": "#0969da",
    "green": "#1a7f37",
    "yellow": "#bf8700",
    "red": "#cf222e",
    "entry": "#ffffff",
    "run": "#2da44e",
    "stop": "#a40e26",
    "hdr_bg": "#ffffff",
    "tab_act": "#ffffff",
    "tab_bg": "#f0f2f5",
}


# =============================================================================
# 1. ADVANCED MATPLOTLIB DRAWING HELPERS
# =============================================================================
def _draw_wavy(ax, x1, y1, x2, y2, n_waves=5, amp_frac=0.06, **kw):
    t = np.linspace(0, 1, 300)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    amp = amp_frac * length
    wave = amp * np.sin(n_waves * 2 * np.pi * t)
    ax.plot(x1 + t * dx + wave * px, y1 + t * dy + wave * py, **kw)


def _draw_zigzag(ax, x1, y1, x2, y2, n_zigs=7, amp_frac=0.05, **kw):
    n = n_zigs * 2 + 1
    t = np.linspace(0, 1, n)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    amp = amp_frac * length
    displace = np.array([amp * ((-1) ** i) if i % 2 == 1 else 0 for i in range(n)])
    ax.plot(x1 + t * dx + displace * px, y1 + t * dy + displace * py, **kw)


def _draw_curled(ax, x1, y1, x2, y2, rad=0.35, **kw):
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    cp = (mx + rad * length * px, my + rad * length * py)
    path = mpath.Path(
        [(x1, y1), cp, (x2, y2)],
        [mpath.Path.MOVETO, mpath.Path.CURVE3, mpath.Path.CURVE3],
    )
    lw = kw.pop("lw", kw.pop("linewidth", 1.0))
    color = kw.pop("color", "k")
    alpha = kw.pop("alpha", 1.0)
    ls = kw.pop("ls", kw.pop("linestyle", "-"))
    zorder = kw.pop("zorder", 3)
    ax.add_patch(
        mpatches.PathPatch(
            path,
            fill=False,
            edgecolor=color,
            linewidth=lw,
            alpha=alpha,
            linestyle=ls,
            zorder=zorder,
        )
    )


def _draw_fancy_arrow(
    ax,
    x1,
    y1,
    x2,
    y2,
    style="Straight",
    color="k",
    lw=1.0,
    alpha=0.75,
    zorder=10,
    head_size=0.012,
):
    kw = dict(color=color, lw=lw, alpha=alpha, zorder=zorder)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    gap = head_size * length
    bx2, by2 = x2 - gap * ux, y2 - gap * uy

    if style == "Wavy":
        _draw_wavy(ax, x1, y1, bx2, by2, n_waves=5, amp_frac=0.06, **kw)
    elif style == "Zigzag":
        _draw_zigzag(ax, x1, y1, bx2, by2, n_zigs=6, amp_frac=0.05, **kw)
    elif style in ("Curled (Arc)", "Curled"):
        _draw_curled(ax, x1, y1, bx2, by2, rad=0.30, **kw)
    elif style in ("Smooth (Bezier)", "Smooth"):
        xs = np.linspace(x1, bx2, 60)
        ts = (xs - x1) / max(bx2 - x1, 1e-9)
        ax.plot(xs, y1 + (by2 - y1) * (3 * ts**2 - 2 * ts**3), **kw)
    else:
        ax.plot([x1, bx2], [y1, by2], **kw)

    ax.annotate(
        "",
        xy=(x2, y2),
        xytext=(bx2, by2),
        arrowprops=dict(arrowstyle="->", color=color, lw=lw, alpha=alpha, mutation_scale=10 * lw),
        zorder=zorder + 1,
    )


# =============================================================================
# LOGGING INFRASTRUCTURE
# =============================================================================
class _QueueHandler(logging.Handler):
    def __init__(self, q: queue.Queue):
        super().__init__()
        self._q = q

    def emit(self, record: logging.LogRecord):
        self._q.put(self.format(record))


class SafeStreamHandler(logging.StreamHandler):
    def emit(self, record):
        try:
            msg = self.format(record)
            self.stream.write(msg + self.terminator)
            self.flush()
        except UnicodeEncodeError:
            msg = self.format(record)
            safe_msg = msg.encode(sys.stdout.encoding or "ascii", "replace").decode(sys.stdout.encoding or "ascii")
            try:
                self.stream.write(safe_msg + self.terminator)
                self.flush()
            except Exception:
                pass
        except Exception:
            self.handleError(record)


def setup_logging(verbose: bool = False, gui_queue: Optional[queue.Queue] = None):
    level = logging.DEBUG if verbose else logging.INFO
    logger = logging.getLogger("IAK")
    logger.setLevel(level)
    logger.handlers.clear()
    ch = SafeStreamHandler(sys.stdout)
    formatter = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s", datefmt="%H:%M:%S")
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    if gui_queue is not None:
        qh = _QueueHandler(gui_queue)
        qh.setFormatter(formatter)
        logger.addHandler(qh)
    return logger


# =============================================================================
# 2. EMBEDDED ENGINE MANAGER & WSL BRIDGE
# =============================================================================
ENGINE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "iak_engine")

XTB_URLS = [
    "https://github.com/grimme-lab/xtb/releases/download/v6.7.1/xtb-6.7.1-linux-x86_64.tar.xz",
    "https://github.com/grimme-lab/xtb/releases/download/v6.6.1/xtb-6.6.1-linux-x86_64.tar.xz",
]

CREST_URLS = [
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-x86_64-unknown-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-x86_64-pc-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-linux-x86_64.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.1/crest-x86_64-unknown-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v2.12/crest.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v2.11.2/crest.tar.xz",
]

XTB_DIR = None
CREST_DIR = None
ORCA_DIR = None
ORCA_IS_WINDOWS = False
_WSL_ORCA_EXISTS = None


def is_tool_available(tool_name):
    global _WSL_ORCA_EXISTS
    if tool_name == "xtb":
        return XTB_DIR is not None or shutil.which("xtb") is not None
    if tool_name == "crest":
        return CREST_DIR is not None or shutil.which("crest") is not None
    if tool_name == "orca":
        if ORCA_DIR is not None or shutil.which("orca") is not None or shutil.which("orca.exe") is not None:
            return True
        if sys.platform == "win32":
            if _WSL_ORCA_EXISTS is None:
                try:
                    proc = subprocess.run(
                        "wsl -e bash -c 'export PATH=\"/usr/bin:/bin:/usr/local/bin:$PATH\"; which orca'",
                        shell=True,
                        capture_output=True,
                        timeout=3,
                    )
                    _WSL_ORCA_EXISTS = proc.returncode == 0
                except Exception:
                    _WSL_ORCA_EXISTS = False
            return _WSL_ORCA_EXISTS
        return False
    return False


def get_wsl_path(win_path):
    drive, tail = os.path.splitdrive(win_path)
    if drive:
        return f"/mnt/{drive[0].lower()}{tail.replace(os.sep, '/')}"
    return win_path.replace(os.sep, "/")


def inject_embedded_engines():
    global XTB_DIR, CREST_DIR, ORCA_DIR, ORCA_IS_WINDOWS
    if not os.path.exists(ENGINE_DIR):
        return
    for root, dirs, files in os.walk(ENGINE_DIR):
        try:
            if "xtb" in files and os.path.basename(root) == "bin" and os.path.isfile(os.path.join(root, "xtb")):
                XTB_DIR = root
                if sys.platform == "win32":
                    subprocess.run(f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'xtb'))}\"", shell=True, capture_output=True)

            if "crest" in files and CREST_DIR is None and os.path.isfile(os.path.join(root, "crest")):
                CREST_DIR = root
                if sys.platform == "win32":
                    subprocess.run(f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'crest'))}\"", shell=True, capture_output=True)

            if ORCA_DIR is None:
                if "orca.exe" in files and os.path.isfile(os.path.join(root, "orca.exe")):
                    ORCA_DIR = root
                    ORCA_IS_WINDOWS = True
                elif "orca" in files and os.path.isfile(os.path.join(root, "orca")):
                    ORCA_DIR = root
                    ORCA_IS_WINDOWS = False
                    if sys.platform == "win32":
                        subprocess.run(f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'orca'))}\"", shell=True, capture_output=True)
                        subprocess.run(f"wsl chmod +x \"{get_wsl_path(root)}/orca_\"* 2>/dev/null", shell=True, capture_output=True)
        except OSError:
            continue


inject_embedded_engines()


# =============================================================================
# 3. CONFIGURATION & CORE DATA STRUCTURES
# =============================================================================
class RunMode(Enum):
    FAST = "fast"
    BALANCED = "balanced"
    THOROUGH = "thorough"


@dataclasses.dataclass
class Config:
    n_generate: int = 200
    n_keep_scored: int = 50
    n_keep_clustered: int = 40
    n_run_xtb: int = 20
    n_run_crest: int = 5
    rmsd_cutoff: float = 0.5
    clash_cutoff: float = 1.2
    xtb_method: str = "--gfn2"
    crest_method: str = "--gfn2"
    orca_method: str = "B97-3c Opt Freq"
    charge: int = 0
    multiplicity: int = 1
    energy_a: Optional[float] = None
    energy_b: Optional[float] = None
    xtb_ewin_kcal: float = 5.0
    crest_ewin_kcal: float = 3.0
    random_seed: int = 42
    max_placement_attempts: int = 50
    preopt_inputs: bool = True
    cores: int = 4
    exec_env: str = "Local (Subprocess)"
    goat_model: str = "uma-s-1"
    goat_device: str = "cuda"
    goat_task: str = "omol"
    maxcore: int = 2000

    @classmethod
    def from_mode(cls, mode: RunMode):
        if mode == RunMode.FAST:
            return cls(n_generate=50, n_keep_scored=20, n_keep_clustered=10, n_run_xtb=5, n_run_crest=1)
        if mode == RunMode.THOROUGH:
            return cls(
                n_generate=1000,
                n_keep_scored=300,
                n_keep_clustered=100,
                n_run_xtb=50,
                n_run_crest=10,
                xtb_ewin_kcal=10.0,
                crest_ewin_kcal=5.0,
            )
        return cls()


class Atom:
    __slots__ = ("symbol", "x", "y", "z")

    def __init__(self, s, x, y, z):
        self.symbol, self.x, self.y, self.z = s, x, y, z

    @property
    def coords(self):
        return np.array([self.x, self.y, self.z], dtype=float)

    @coords.setter
    def coords(self, v):
        self.x, self.y, self.z = float(v[0]), float(v[1]), float(v[2])


class Molecule:
    def __init__(self, atoms: List[Atom], name: str = "mol"):
        self.atoms = atoms
        self.name = name
        self.score = 0.0
        self.energy_eh = 0.0
        self.gibbs_eh = 0.0
        self.imag_freqs = 0
        self.lineage = []

    @classmethod
    def from_xyz(cls, path: str):
        if not path or not os.path.exists(path):
            return cls([])
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            raw = f.readlines()
        # Strip trailing whitespace per line but do NOT discard empty lines so
        # that the mandatory (possibly blank) comment line keeps its position.
        stripped = [l.strip() for l in raw]
        # Skip any leading blank lines before the atom count
        idx = 0
        while idx < len(stripped) and not stripped[idx]:
            idx += 1
        try:
            n = int(stripped[idx])
        except (ValueError, IndexError):
            raise ValueError(f"Invalid XYZ format in {path}")
        # The comment is always the very next line (even when empty)
        comment_line = stripped[idx + 1] if idx + 1 < len(stripped) else ""
        atoms = []
        for line in stripped[idx + 2 : idx + 2 + n]:
            p = line.split()
            if len(p) >= 4:
                try:
                    atoms.append(Atom(p[0], float(p[1]), float(p[2]), float(p[3])))
                except ValueError:
                    continue
        return cls(atoms, comment_line or "mol")

    def to_xyz(self, path, comment=""):
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(f"{len(self.atoms)}\n{comment}\n")
            for a in self.atoms:
                f.write(f"{a.symbol:<4} {a.x:15.6f} {a.y:15.6f} {a.z:15.6f}\n")

    def coords_array(self):
        return np.array([a.coords for a in self.atoms])

    def centroid(self):
        return np.mean(self.coords_array(), axis=0) if len(self.atoms) > 0 else np.array([0, 0, 0])

    def translate(self, v):
        for a in self.atoms:
            a.coords += v

    def rotate(self, R):
        for a in self.atoms:
            a.coords = R @ a.coords

    def merge(self, other):
        self.atoms.extend([Atom(a.symbol, a.x, a.y, a.z) for a in other.atoms])

    def n_atoms(self):
        return len(self.atoms)


def read_multi_xyz(path: str) -> List[Molecule]:
    mols = []
    if not os.path.exists(path):
        return mols
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        while True:
            line = f.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            try:
                n = int(line)
            except ValueError:
                continue
            comment = f.readline().strip()
            atoms = []
            for _ in range(n):
                p = f.readline().split()
                if len(p) >= 4:
                    atoms.append(Atom(p[0], float(p[1]), float(p[2]), float(p[3])))
            m = Molecule(atoms, name=comment)
            try:
                m.energy_eh = float(comment.split()[0])
            except Exception:
                pass
            mols.append(m)
    return mols


# =============================================================================
# 4. CHEMISTRY LOGIC & PLACEMENT
# =============================================================================
def _canonical_symbol(symbol: str) -> str:
    text = str(symbol or "").strip()
    if not text:
        return text
    return text[0].upper() + text[1:].lower()


def atom_counts_for_molecule(mol: Molecule) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    if not mol:
        return counts
    for atom in mol.atoms:
        symbol = _canonical_symbol(atom.symbol)
        counts[symbol] = counts.get(symbol, 0) + 1
    return counts


def _merge_weighted_atom_counts(target: Dict[str, int], source: Dict[str, int], scale: int):
    if scale <= 0:
        return
    for symbol, count in source.items():
        target[symbol] = target.get(symbol, 0) + count * scale


def expected_cluster_atom_counts(anchor_mol: Molecule, guest_mols: List[Molecule], n_anchor: int, n_guests_list: List[int]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    if n_anchor > 0 and anchor_mol is not None:
        _merge_weighted_atom_counts(counts, atom_counts_for_molecule(anchor_mol), n_anchor)
    for idx, guest in enumerate(guest_mols or []):
        copies = int(n_guests_list[idx]) if idx < len(n_guests_list) else 0
        if copies > 0:
            _merge_weighted_atom_counts(counts, atom_counts_for_molecule(guest), copies)
    return counts


def _formula_sort_key(symbol: str):
    if symbol == "C":
        return (0, symbol)
    if symbol == "H":
        return (1, symbol)
    return (2, symbol)


def atom_counts_to_formula(counts: Dict[str, int]) -> str:
    if not counts:
        return "(empty)"
    parts = []
    for symbol in sorted(counts.keys(), key=_formula_sort_key):
        count = counts[symbol]
        parts.append(f"{symbol}{count if count != 1 else ''}")
    return " ".join(parts)


def compare_atom_counts(reference: Dict[str, int], observed: Dict[str, int]) -> Tuple[bool, str]:
    if reference == observed:
        return True, "Atom counts match expected stoichiometry."
    return (
        False,
        f"Atom composition mismatch. Expected [{atom_counts_to_formula(reference)}] but got [{atom_counts_to_formula(observed)}].",
    )


def total_electrons_for_system(anchor_mol: Molecule, guest_mols: List[Molecule], n_anchor: int, n_guests_list: List[int], total_charge: int) -> Tuple[Optional[int], List[str]]:
    unknown_symbols = set()
    nuclear_charge = 0

    def _accumulate(mol: Molecule, copies: int):
        nonlocal nuclear_charge
        if not mol or copies <= 0:
            return
        for atom in mol.atoms:
            symbol = _canonical_symbol(atom.symbol)
            z = ATOMIC_NUMBERS.get(symbol)
            if z is None:
                unknown_symbols.add(symbol)
                continue
            nuclear_charge += z * copies

    _accumulate(anchor_mol, n_anchor)
    for idx, guest in enumerate(guest_mols or []):
        copies = int(n_guests_list[idx]) if idx < len(n_guests_list) else 0
        _accumulate(guest, copies)

    if unknown_symbols:
        return None, sorted(unknown_symbols)
    return nuclear_charge - int(total_charge), []


def suggest_multiplicity(total_electrons: int, current_mult: int) -> int:
    required_parity = 1 - (total_electrons % 2)
    upper = max(3, min(total_electrons + 1, max(current_mult + 8, 25)))
    candidates = [m for m in range(1, upper + 1) if m % 2 == required_parity]
    if not candidates:
        return max(1, current_mult)
    return min(candidates, key=lambda m: abs(m - current_mult))


def validate_charge_multiplicity(
    anchor_mol: Molecule,
    guest_mols: List[Molecule],
    n_anchor: int,
    n_guests_list: List[int],
    total_charge: int,
    multiplicity: int,
) -> Dict[str, Any]:
    result = {
        "valid": True,
        "total_electrons": None,
        "unknown_symbols": [],
        "suggested_multiplicity": multiplicity,
        "message": "Charge/multiplicity accepted.",
    }
    if multiplicity < 1:
        result["valid"] = False
        result["message"] = "Multiplicity must be >= 1."
        return result

    total_electrons, unknown_symbols = total_electrons_for_system(anchor_mol, guest_mols, n_anchor, n_guests_list, total_charge)
    result["total_electrons"] = total_electrons
    result["unknown_symbols"] = unknown_symbols

    if unknown_symbols:
        result["message"] = (
            "Electron-based validation skipped because atomic numbers are unavailable for: "
            + ", ".join(unknown_symbols)
        )
        return result

    if total_electrons is None or total_electrons <= 0:
        result["valid"] = False
        result["message"] = (
            f"Invalid total electron count ({total_electrons}) from charge {total_charge}. "
            "Please verify stoichiometry and charge."
        )
        return result

    parity_ok = (total_electrons % 2) != (multiplicity % 2)
    upper_limit = total_electrons + 1
    if multiplicity > upper_limit:
        parity_ok = False

    suggested = suggest_multiplicity(total_electrons, multiplicity)
    result["suggested_multiplicity"] = suggested
    if parity_ok:
        result["message"] = f"Total electrons: {total_electrons}. Charge/multiplicity parity is consistent."
        return result

    result["valid"] = False
    result["message"] = (
        f"Charge/multiplicity mismatch for {total_electrons} electrons (charge={total_charge}, multiplicity={multiplicity}). "
        f"Suggested multiplicity: {suggested}."
    )
    return result


def validate_reactant_product_atom_balance(reactant_mol: Molecule, product_mol: Molecule, reaction_type: str) -> Tuple[bool, str]:
    r_count = reactant_mol.n_atoms()
    p_count = product_mol.n_atoms()
    if r_count != p_count:
        return (
            False,
            f"{reaction_type} path requires equal atom count in reactant/product. Found {r_count} vs {p_count}.",
        )

    react_counts = atom_counts_for_molecule(reactant_mol)
    prod_counts = atom_counts_for_molecule(product_mol)
    if react_counts != prod_counts:
        return (
            False,
            f"{reaction_type} path requires atom-type conservation. Reactant [{atom_counts_to_formula(react_counts)}], "
            f"Product [{atom_counts_to_formula(prod_counts)}].",
        )
    return True, "Reactant/product atom balance validated."


def find_hbond_acceptors(mol):
    _acc_set = {"O", "N", "F"}
    return [i for i, a in enumerate(mol.atoms) if _canonical_symbol(a.symbol) in _acc_set]


def find_hbond_donors(mol):
    donors = []
    _don_heavy = {"N", "O", "S", "F"}
    heavy = {i: a for i, a in enumerate(mol.atoms) if _canonical_symbol(a.symbol) in _don_heavy}
    for i, a in enumerate(mol.atoms):
        if _canonical_symbol(a.symbol) == "H":
            for hj, ha in heavy.items():
                if np.linalg.norm(a.coords - ha.coords) < 1.2:
                    donors.append((i, hj))
                    break
    return donors


def find_nucleophilic_sites(mol):
    preferred = {"N", "O", "S", "P", "F", "Cl", "Br", "I"}
    sites = [i for i, atom in enumerate(mol.atoms) if _canonical_symbol(atom.symbol) in preferred]
    if sites:
        return sites
    return [i for i, atom in enumerate(mol.atoms) if _canonical_symbol(atom.symbol) != "H"]


def find_electrophilic_sites(mol):
    preferred = {"C", "B", "Si", "P", "S"}
    sites = [i for i, atom in enumerate(mol.atoms) if _canonical_symbol(atom.symbol) in preferred]
    if sites:
        return sites
    return [i for i in range(mol.n_atoms())]


def kabsch_rmsd(c1, c2):
    c1_c, c2_c = c1 - np.mean(c1, axis=0), c2 - np.mean(c2, axis=0)
    H = c1_c.T @ c2_c
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    return float(np.sqrt(np.mean(np.sum((c1_c - c2_c @ R.T) ** 2, axis=1))))


def score_geometry(mol):
    score = 0.0
    c = mol.coords_array()
    acc = find_hbond_acceptors(mol)
    don = [d[0] for d in find_hbond_donors(mol)]
    for d_idx in don:
        for a_idx in acc:
            dist = np.linalg.norm(c[d_idx] - c[a_idx])
            if 1.6 < dist < 2.3:
                score += 5.0 * np.exp(-0.5 * ((dist - 1.9) / 0.2) ** 2)
            elif dist < 1.3:
                score -= 25.0
    score -= np.max(np.linalg.norm(c - mol.centroid(), axis=1)) * 0.5
    mol.score = score
    return score


def _axis_angle_matrix(axis, angle):
    axis = axis / (np.linalg.norm(axis) + 1e-12)
    c, s = math.cos(angle), math.sin(angle)
    x, y, z = axis
    return np.array(
        [
            [c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s],
            [y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s],
            [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)],
        ]
    )


def _align_vectors(v_from, v_to):
    v_from = v_from / (np.linalg.norm(v_from) + 1e-12)
    v_to = v_to / (np.linalg.norm(v_to) + 1e-12)
    cross, dot = np.cross(v_from, v_to), np.dot(v_from, v_to)
    if np.linalg.norm(cross) < 1e-6:
        perp = np.array([1, 0, 0]) if abs(v_from[0]) < 0.9 else np.array([0, 1, 0])
        return _axis_angle_matrix(np.cross(v_from, perp), math.pi) if dot < 0 else np.eye(3)
    return _axis_angle_matrix(cross, math.acos(np.clip(dot, -1.0, 1.0)))


def _reaction_profile(reaction_type: str) -> Dict[str, Any]:
    profile_map = {
        "Non-covalent": {"target_role": "acceptor", "guest_role": "donor_h", "distance": (1.8, 2.2)},
        "Covalent": {"target_role": "electrophile", "guest_role": "nucleophile", "distance": (1.55, 2.05)},
        "Substitution": {"target_role": "electrophile", "guest_role": "nucleophile", "distance": (1.65, 2.15)},
        "Addition": {"target_role": "electrophile", "guest_role": "nucleophile", "distance": (1.60, 2.10)},
        "Nucleophilic": {"target_role": "electrophile", "guest_role": "nucleophile", "distance": (1.55, 2.00)},
        "Electrophilic": {"target_role": "nucleophile", "guest_role": "electrophile", "distance": (1.55, 2.00)},
    }
    return profile_map.get(normalize_reaction_type(reaction_type), profile_map["Non-covalent"])


def _pick_sites_by_role(mol: Molecule, role: str) -> List[int]:
    if role == "acceptor":
        return find_hbond_acceptors(mol)
    if role == "donor_h":
        return [idx for idx, _ in find_hbond_donors(mol)]
    if role == "nucleophile":
        return find_nucleophilic_sites(mol)
    if role == "electrophile":
        return find_electrophilic_sites(mol)
    return list(range(mol.n_atoms()))


def generate_cluster(anchor_in, guests_in, n_guests_list, rng, max_att=50, n_anchor=1, reaction_type="Non-covalent"):
    def _clone(mol: Molecule) -> Molecule:
        return Molecule([Atom(a.symbol, a.x, a.y, a.z) for a in mol.atoms], name=mol.name)

    cluster = Molecule([])
    if anchor_in is not None and anchor_in.n_atoms() > 0 and n_anchor > 0:
        cluster = _clone(anchor_in)
        for extra_idx in range(1, n_anchor):
            placed_anchor = False
            for _ in range(max(5, max_att // 2)):
                extra = _clone(anchor_in)
                extra.translate(-extra.centroid())
                direction = np.array([rng.uniform(-1.0, 1.0) for _ in range(3)], dtype=float)
                if np.linalg.norm(direction) < 1e-6:
                    direction = np.array([0.0, 0.0, 1.0], dtype=float)
                direction = direction / np.linalg.norm(direction)
                distance = rng.uniform(3.8, 6.4 + 0.25 * extra_idx)
                extra.translate(cluster.centroid() + direction * distance)
                clash = False
                existing = cluster.coords_array()
                candidate = extra.coords_array()
                for p in existing:
                    if np.min(np.linalg.norm(candidate - p, axis=1)) < 1.25:
                        clash = True
                        break
                if not clash:
                    cluster.merge(extra)
                    placed_anchor = True
                    break
            if not placed_anchor:
                return None

    placed_guests = []
    profile = _reaction_profile(reaction_type)

    if sum(n_guests_list) == 0:
        return cluster

    def _pick_target_molecule():
        available = []
        if cluster.n_atoms() > 0:
            available.append(cluster)
        available.extend(placed_guests)
        if not available:
            return None
        if len(available) > 1 and rng.random() > 0.4:
            return rng.choice(available)
        return available[0]

    for g_idx, guest_in in enumerate(guests_in):
        n_copies = int(n_guests_list[g_idx]) if g_idx < len(n_guests_list) else 0
        for _ in range(n_copies):
            success = False
            if guest_in is None or guest_in.n_atoms() == 0:
                # Nothing physical to place; count as placed so we don't abort
                success = True
                break
            for _ in range(max_att):
                g = _clone(guest_in)
                g.translate(-g.centroid())
                target_mol = _pick_target_molecule()
                if target_mol is None:
                    g.translate(np.array([rng.uniform(-1.2, 1.2) for _ in range(3)]))
                    placed_guests.append(g)
                    success = True
                    break

                target_sites = _pick_sites_by_role(target_mol, profile["target_role"])
                if not target_sites:
                    target_sites = list(range(target_mol.n_atoms()))
                if not target_sites:
                    break
                target_idx = rng.choice(target_sites)

                donor_pair = None
                if profile["guest_role"] == "donor_h":
                    donors = find_hbond_donors(g)
                    if donors:
                        donor_pair = rng.choice(donors)
                        guest_site = donor_pair[0]
                    else:
                        fallback = _pick_sites_by_role(g, "nucleophile")
                        guest_site = rng.choice(fallback if fallback else list(range(g.n_atoms())))
                else:
                    guest_sites = _pick_sites_by_role(g, profile["guest_role"])
                    if not guest_sites:
                        guest_sites = list(range(g.n_atoms()))
                    guest_site = rng.choice(guest_sites)

                out_vec = target_mol.atoms[target_idx].coords - target_mol.centroid()
                if np.linalg.norm(out_vec) < 0.1:
                    out_vec = np.array([0.0, 0.0, 1.0])

                if donor_pair is not None:
                    d_vec = g.atoms[donor_pair[0]].coords - g.atoms[donor_pair[1]].coords
                else:
                    d_vec = g.atoms[guest_site].coords - g.centroid()
                    if np.linalg.norm(d_vec) < 0.1:
                        d_vec = np.array([1.0, 0.0, 0.0])

                g.rotate(_align_vectors(d_vec, -out_vec))
                g.rotate(_axis_angle_matrix(out_vec, rng.uniform(0, 2 * math.pi)))

                dmin, dmax = profile["distance"]
                target_pos = target_mol.atoms[target_idx].coords + (out_vec / np.linalg.norm(out_vec)) * rng.uniform(dmin, dmax)
                g.translate(target_pos - g.atoms[guest_site].coords)

                clash = False
                for existing in [cluster] + placed_guests:
                    if existing.n_atoms() == 0:
                        continue
                    c1, c2 = existing.coords_array(), g.coords_array()
                    for p in c1:
                        if np.min(np.linalg.norm(c2 - p, axis=1)) < 1.25:
                            clash = True
                            break
                    if clash:
                        break
                if not clash:
                    placed_guests.append(g)
                    success = True
                    break
            if not success:
                return None
    for pg in placed_guests:
        cluster.merge(pg)
    return cluster


# =============================================================================
# 5. V11.2 JOB SUMMARY AND PROGRESS HELPERS
# =============================================================================
def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _fmt_duration(seconds: float):
    if seconds is None or seconds < 0 or math.isinf(seconds) or math.isnan(seconds):
        return "estimating"
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _safe_float(value):
    try:
        if value in (None, "", "N/A"):
            return None
        return float(value)
    except Exception:
        return None


def _safe_int(value):
    try:
        return int(value)
    except Exception:
        return None


def _validate_xyz(path: Optional[str], label: str, required: bool):
    record = {
        "label": label,
        "path": os.path.abspath(path) if path else "",
        "required": bool(required),
        "provided": bool(path),
        "valid": False,
        "result": "INCORRECT",
        "atoms_declared": 0,
        "atoms_parsed": 0,
        "message": "",
    }
    if not path:
        record["valid"] = not required
        record["result"] = "CORRECT" if record["valid"] else "INCORRECT"
        record["message"] = "Optional input not provided." if not required else "Required XYZ input was not provided."
        return record
    if not os.path.isfile(path):
        record["message"] = "File does not exist."
        return record
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            lines = [line.rstrip("\n") for line in handle]
        n_atoms = int(lines[0].strip())
        parsed = 0
        malformed = []
        for idx, line in enumerate(lines[2 : 2 + n_atoms], start=3):
            parts = line.split()
            if len(parts) < 4:
                malformed.append(idx)
                continue
            try:
                float(parts[1])
                float(parts[2])
                float(parts[3])
                parsed += 1
            except Exception:
                malformed.append(idx)
        record["atoms_declared"] = n_atoms
        record["atoms_parsed"] = parsed
        record["valid"] = n_atoms > 0 and parsed == n_atoms and not malformed
        record["result"] = "CORRECT" if record["valid"] else "INCORRECT"
        if record["valid"]:
            record["message"] = f"Valid XYZ with {n_atoms} atoms."
        elif malformed:
            record["message"] = f"Malformed coordinate lines: {', '.join(map(str, malformed[:8]))}."
        else:
            record["message"] = f"Declared {n_atoms} atoms but parsed {parsed}."
    except Exception as exc:
        record["message"] = f"Could not parse XYZ: {exc}"
    return record


class JobSummaryRecorder:
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.ratio = getattr(pipeline, "ratio_str", "unknown").replace("_", ":")
        self.started_at = _now()
        self.finished_at = ""
        self.status = "RUNNING"
        self.error = ""
        self.traceback = ""
        self.inputs: List[Dict[str, Any]] = []
        self.workflow: Dict[str, Any] = {}
        self.events: List[Dict[str, Any]] = []
        self.engine_results: List[Dict[str, Any]] = []

    @property
    def logs_dir(self):
        return self.pipeline.dirs.get("logs", os.path.join(self.pipeline.out_dir, "logs"))

    @property
    def comparison_dir(self):
        return self.pipeline.dirs.get("comparison", os.path.join(self.pipeline.out_dir, "05_Top_Models_Comparison"))

    @property
    def json_path(self):
        return os.path.join(self.logs_dir, f"Job_Summary_{self.ratio.replace(':', '_')}.json")

    @property
    def csv_path(self):
        return os.path.join(self.logs_dir, f"Job_Engine_Results_{self.ratio.replace(':', '_')}.csv")

    @property
    def markdown_path(self):
        return os.path.join(self.comparison_dir, "Job_Summary_Report.md")

    def capture_inputs(self, run_xtb, run_crest, run_orca):
        cfg = self.pipeline.config
        n_anchor = int(getattr(self.pipeline, "n_anchor", 1))
        n_guests_list = [int(x) for x in getattr(self.pipeline, "n_guests_list", [])]
        guest_paths = list(getattr(self.pipeline, "fragB_paths", []) or [])
        guest_required = sum(max(x, 0) for x in n_guests_list) > 0
        charge = _safe_int(cfg.charge)
        mult = _safe_int(cfg.multiplicity)
        cores = _safe_int(cfg.cores)
        maxcore = _safe_int(cfg.maxcore)
        reaction_type = normalize_reaction_type(getattr(self.pipeline, "reaction_type", "Non-covalent"))

        ratio_valid = n_anchor >= 0 and all(x >= 0 for x in n_guests_list)
        electron_check = {
            "valid": mult is not None and mult >= 1,
            "total_electrons": None,
            "unknown_symbols": [],
            "message": "Electron consistency check not executed.",
        }
        if charge is not None and mult is not None and mult >= 1:
            electron_check = validate_charge_multiplicity(
                self.pipeline.fragA,
                self.pipeline.fragBs,
                n_anchor,
                n_guests_list,
                charge,
                mult,
            )

        self.inputs = [
            _validate_xyz(getattr(self.pipeline, "fragA_path", ""), "Anchor A XYZ", n_anchor > 0),
            self._setting(
                "Stoichiometric ratio",
                self.ratio,
                True,
                ratio_valid,
                f"Anchor copies={n_anchor}; guest copies={n_guests_list or [0]}.",
            ),
            self._setting(
                "Charge",
                cfg.charge,
                True,
                charge is not None and (electron_check["total_electrons"] is None or electron_check["total_electrons"] > 0),
                "Integer charge accepted." if charge is not None else "Charge must be an integer.",
            ),
            self._setting(
                "Multiplicity",
                cfg.multiplicity,
                True,
                mult is not None and mult >= 1 and electron_check["valid"],
                electron_check["message"] if mult is not None and mult >= 1 else "Multiplicity must be >= 1.",
            ),
            self._setting(
                "Total Electrons",
                electron_check["total_electrons"] if electron_check["total_electrons"] is not None else "unknown",
                True,
                electron_check["valid"],
                electron_check["message"],
            ),
            self._setting("CPU cores", cfg.cores, True, cores is not None and cores >= 1, "Core count accepted." if cores is not None and cores >= 1 else "Cores must be >= 1."),
            self._setting("RAM per core", cfg.maxcore, True, maxcore is not None and maxcore >= 128, "MaxCore accepted." if maxcore is not None and maxcore >= 128 else "MaxCore is unusually low."),
            self._setting("ORCA method", cfg.orca_method, run_orca, bool(str(cfg.orca_method).strip()) or not run_orca, "Theory level recorded." if cfg.orca_method else "ORCA method is empty."),
            self._setting("Reaction Type", reaction_type, True, reaction_type in REACTION_TYPE_CHOICES, "Reaction mechanism selected."),
        ]

        if guest_paths:
            for idx, guest_path in enumerate(guest_paths):
                required = idx < len(n_guests_list) and n_guests_list[idx] > 0
                self.inputs.append(_validate_xyz(guest_path, f"Guest B{idx + 1} XYZ", required))
        else:
            self.inputs.append(
                self._setting(
                    "Guest queue",
                    "(empty)",
                    guest_required,
                    not guest_required,
                    "No guests queued." if not guest_required else "Guests are required by ratio but no guest files are queued.",
                )
            )

        if run_xtb:
            self.inputs.append(self._engine("xTB engine", "xtb"))
        if run_crest:
            self.inputs.append(self._engine("CREST engine", "crest"))
        if run_orca:
            self.inputs.append(self._engine("ORCA engine", "orca"))
        self.workflow = {
            "ratio": self.ratio,
            "output_directory": self.pipeline.out_dir,
            "run_xtb": bool(run_xtb),
            "run_crest": bool(run_crest),
            "run_orca": bool(run_orca),
            "reaction_type": reaction_type,
            "preopt_inputs": bool(cfg.preopt_inputs),
            "n_generate": cfg.n_generate,
            "n_keep_scored": cfg.n_keep_scored,
            "n_keep_clustered": cfg.n_keep_clustered,
            "n_run_xtb": cfg.n_run_xtb,
            "n_run_crest": cfg.n_run_crest,
            "n_anchor": n_anchor,
            "n_guests_list": n_guests_list,
            "charge": cfg.charge,
            "multiplicity": cfg.multiplicity,
            "orca_method": cfg.orca_method,
        }

    def _setting(self, label, value, required, valid, message):
        return {"label": label, "path": str(value), "required": required, "provided": value not in (None, ""), "valid": valid, "result": "CORRECT" if valid else "INCORRECT", "message": message}

    def _engine(self, label, engine):
        available = is_tool_available(engine)
        return self._setting(label, engine, True, available, "Engine detected." if available else "Engine missing or not on PATH/WSL/local engine folder.")

    def log_event(self, stage, message, level="INFO"):
        self.events.append({"time": _now(), "level": level, "stage": stage, "message": str(message)})

    def add_engine_result(self, engine, source, flags, result, elapsed):
        self.engine_results.append(
            {
                "time": _now(),
                "engine": engine.upper(),
                "source": source,
                "flags": flags,
                "status": result.get("status", "unknown"),
                "energy_eh": result.get("energy", ""),
                "gibbs_eh": result.get("gibbs", ""),
                "imaginary_frequencies": result.get("imag", ""),
                "path": result.get("path", ""),
                "best_path": result.get("best_path", ""),
                "elapsed_seconds": round(elapsed, 2),
            }
        )

    def to_dict(self):
        return {
            "schema": "IAK_JOB_SUMMARY_V11_2",
            "ratio": self.ratio,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "status": self.status,
            "error": self.error,
            "traceback": self.traceback,
            "workflow": self.workflow,
            "inputs": self.inputs,
            "events": self.events,
            "engine_results": self.engine_results,
        }

    def write(self):
        os.makedirs(self.logs_dir, exist_ok=True)
        os.makedirs(self.comparison_dir, exist_ok=True)
        with open(self.json_path, "w", encoding="utf-8") as handle:
            json.dump(self.to_dict(), handle, indent=2)
        with open(self.csv_path, "w", newline="", encoding="utf-8") as handle:
            fieldnames = ["time", "engine", "source", "flags", "status", "energy_eh", "gibbs_eh", "imaginary_frequencies", "path", "best_path", "elapsed_seconds"]
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for row in self.engine_results:
                writer.writerow(row)
        with open(self.markdown_path, "w", encoding="utf-8") as handle:
            handle.write(self._markdown())
        opts = getattr(self.pipeline.config, "report_options", {})
        if opts.get("ai_prompt", True):
            with open(os.path.join(self.comparison_dir, "AI_Summary_Prompt.txt"), "w", encoding="utf-8") as handle:
                handle.write(
                    "You are helping summarize an IAK computational chemistry job.\n"
                    "Use only the supplied JSON/CSV/report files from this folder.\n"
                    f"Ratio: {self.ratio}\n"
                    f"Status: {self.status}\n"
                    "Host-selected report sections: "
                    + ", ".join(k for k, v in opts.items() if v)
                    + "\n\n"
                    "Requested output: concise scientific summary, key thermodynamic values if present, failures/warnings, and a CSV-ready table.\n"
                )

    def _markdown(self):
        opts = getattr(self.pipeline.config, "report_options", {})
        enabled = lambda key: opts.get(key, True)
        correct = [x for x in self.inputs if x.get("valid")]
        incorrect = [x for x in self.inputs if not x.get("valid")]
        lines = [
            f"# IAK Job Summary Report: Ratio {self.ratio}",
            "",
            f"- **Status:** {self.status}",
            f"- **Started:** {self.started_at}",
            f"- **Finished:** {self.finished_at or 'Still running'}",
            f"- **Output Directory:** `{self.pipeline.out_dir}`",
            "",
            "## High-Level Input Assessment",
            "",
            f"- Correct inputs/settings: **{len(correct)}**",
            f"- Incorrect or missing inputs/settings: **{len(incorrect)}**",
        ]
        if self.error:
            lines.extend(["", f"> **Job Error:** {self.error}"])
        if enabled("inputs"):
            lines.extend(["", "## Input Correctness Table", "", "| Input / Setting | Given Value | Correct or Incorrect | Notes |", "|---|---:|---|---|"])
            for item in self.inputs:
                lines.append(f"| {item.get('label','')} | `{item.get('path','')}` | **{item.get('result','')}** | {item.get('message','')} |")
        if enabled("workflow"):
            lines.extend(["", "## Requested Workflow", "", "| Setting | Value |", "|---|---:|"])
            for key, value in self.workflow.items():
                lines.append(f"| {key} | `{value}` |")
        if enabled("engine_results"):
            lines.extend(["", "## Engine-Level Results", "", "| Engine | Source | Status | E(eh) | G(eh) | Imag | Elapsed |", "|---|---|---|---:|---:|---:|---:|"])
            if self.engine_results:
                for result in self.engine_results:
                    lines.append(f"| {result.get('engine','')} | `{result.get('source','')}` | {result.get('status','')} | {result.get('energy_eh','')} | {result.get('gibbs_eh','')} | {result.get('imaginary_frequencies','')} | {result.get('elapsed_seconds','')}s |")
            else:
                lines.append("| N/A | N/A | No engine jobs recorded yet | | | | |")
        if enabled("system_info"):
            lines.extend(["", "## System Info", "", f"- Platform: `{sys.platform}`", f"- Python: `{sys.version.split()[0]}`", f"- Working directory: `{os.getcwd()}`"])
        if enabled("timeline"):
            lines.extend(["", "## Timeline", "", "| Time | Level | Stage | Message |", "|---|---|---|---|"])
            for event in self.events[-100:]:
                lines.append(f"| {event.get('time','')} | {event.get('level','')} | {event.get('stage','')} | {event.get('message','')} |")
        return "\n".join(lines) + "\n"


# =============================================================================
# 6. WORKFLOW PIPELINE
# =============================================================================
class Pipeline:
    def __init__(self, fragA_path, fragB_paths, n_guests_list, config, out_dir, ratio_label=None, progress_cb=None, reaction_type="Non-covalent", n_anchor=1):
        self.fragA_path = fragA_path
        self.fragB_paths = fragB_paths if fragB_paths else []
        self.n_anchor = max(0, int(n_anchor))
        self.fragA = Molecule.from_xyz(fragA_path) if fragA_path and os.path.exists(fragA_path) else Molecule([])
        self.fragBs = [Molecule.from_xyz(p) if p and os.path.exists(p) else Molecule([]) for p in self.fragB_paths]
        self.n_guests_list = [max(0, int(x)) for x in (n_guests_list if isinstance(n_guests_list, list) else [n_guests_list])]
        self.reaction_type = normalize_reaction_type(reaction_type)
        self.config = config
        self.progress_cb = progress_cb
        self.progress_started = time.time()
        self.progress_percent = 0.0
        self.expected_atom_counts = expected_cluster_atom_counts(self.fragA, self.fragBs, self.n_anchor, self.n_guests_list)

        self.out_dir = os.path.abspath(out_dir)
        self.ratio_str = ratio_label if ratio_label else f"{self.n_anchor}_{'_'.join(map(str, self.n_guests_list))}"
        self.dirs = {
            "inputs": os.path.join(self.out_dir, "01_Inputs_and_Clusters"),
            "xtb": os.path.join(self.out_dir, "02_xTB_Results"),
            "crest": os.path.join(self.out_dir, "03_CREST_Results"),
            "orca": os.path.join(self.out_dir, "04_ORCA_Refinement"),
            "comparison": os.path.join(self.out_dir, "05_Top_Models_Comparison"),
            "logs": os.path.join(self.out_dir, "logs"),
        }
        for d in self.dirs.values():
            os.makedirs(d, exist_ok=True)
        if fragA_path and os.path.exists(fragA_path):
            shutil.copy2(fragA_path, os.path.join(self.dirs["inputs"], "raw_input_anchor.xyz"))
        for i, bp in enumerate(self.fragB_paths):
            if bp and os.path.exists(bp):
                shutil.copy2(bp, os.path.join(self.dirs["inputs"], f"raw_input_guest_{i}.xyz"))
        self.state_file = os.path.join(self.out_dir, "state.json")
        self.prov_file = os.path.join(self.out_dir, "provenance_manifest.json")
        self.state = json.load(open(self.state_file, "r", encoding="utf-8")) if os.path.exists(self.state_file) else {"gen": [], "filt": [], "xtb": {}, "crest": {}, "orca": {}}
        # Prune cached paths whose files have since been deleted so stages re-run cleanly.
        self.state["gen"] = [p for p in self.state.get("gen", []) if os.path.exists(p)]
        self.state["filt"] = [p for p in self.state.get("filt", []) if os.path.exists(p)]
        self.provenance = json.load(open(self.prov_file, "r", encoding="utf-8")) if os.path.exists(self.prov_file) else []
        self.job_summary = JobSummaryRecorder(self)

    def _validate_generated_cluster(self, mol: Molecule) -> Tuple[bool, str]:
        observed = atom_counts_for_molecule(mol)
        return compare_atom_counts(self.expected_atom_counts, observed)

    def save(self):
        with open(self.state_file, "w", encoding="utf-8") as f:
            json.dump(self.state, f, indent=4)
        with open(self.prov_file, "w", encoding="utf-8") as f:
            json.dump(self.provenance, f, indent=4)

    def _progress(self, stage, percent=None, status="running", message=""):
        if percent is not None:
            self.progress_percent = max(0.0, min(100.0, float(percent)))
        payload = {
            "job": self.ratio_str.replace("_", ":"),
            "stage": stage,
            "percent": self.progress_percent,
            "status": status,
            "message": message,
            "elapsed_seconds": time.time() - self.progress_started,
        }
        if self.progress_cb:
            try:
                self.progress_cb(payload)
            except Exception:
                pass

    def _record_engine_result(self, engine, source, flags, result, elapsed):
        self.job_summary.add_engine_result(engine, source, flags, result, elapsed)
        self.job_summary.write()

    def run(self, run_xtb=False, run_crest=False, run_orca=False, log_cb=None, status_cb=None):
        def _log(m):
            logging.getLogger("IAK").info(m)
            if log_cb:
                log_cb(m + "\n")

        self.progress_started = time.time()
        self.job_summary.capture_inputs(run_xtb, run_crest, run_orca)
        self.job_summary.log_event("Validation", "Captured job inputs, settings, and engine availability.")
        self.job_summary.write()
        self._progress("Validation", 3.0, "running", "Checking input correctness and engine readiness.")

        try:
            if run_orca and not is_tool_available("orca"):
                raise RuntimeError("Run ORCA DFT is checked, but ORCA is not installed or detected!\nPlease install it using the LOAD LOCAL ENGINE button.")

            if ORCA_DIR and " " in os.path.abspath(ORCA_DIR):
                _log("\n[CRITICAL WARNING] Your ORCA installation folder is inside a path with SPACES. IAK will self-heal and fall back if MPI fails.\n")

            _log("\nSCIENTIFIC NOTICE: Structures produced by this workflow are the lowest found under the current sampling settings. They are NOT guaranteed to be global minima.")
            _log(f"[INFO] Reaction mechanism: {self.reaction_type}")
            _log(f"[INFO] Expected atom composition: {atom_counts_to_formula(self.expected_atom_counts)}")

            if self.n_anchor > 0 and self.fragA.n_atoms() == 0:
                raise RuntimeError("Anchor stoichiometry is > 0 but Anchor A XYZ is missing or empty.")

            if sum(self.n_guests_list) == 0 and self.n_anchor <= 1:
                self._progress("Sampling/filtering", 12.0, "running", "Single Molecule Mode detected.")
                _log("\n[INFO] Single Molecule Mode detected. Bypassing cluster generation phase...")
                anchor_path = os.path.join(self.dirs["inputs"], "raw_input_anchor.xyz")
                if not self.state["gen"]:
                    self.state["gen"] = [anchor_path]
                if not self.state["filt"]:
                    self.state["filt"] = [anchor_path]
                    self.save()
                self.state["preopt_done"] = True
                self.save()
            else:
                if run_xtb and self.config.preopt_inputs and not self.state.get("preopt_done"):
                    self._progress("xTB", 14.0, "running", "Pre-optimizing input monomers with xTB.")
                    _log("Stabilizing input geometries using xTB before clustering...")
                    
                    if self.fragA.n_atoms() > 0:
                        p = os.path.join(self.dirs["inputs"], "preopt_anchor_start.xyz")
                        self.fragA.to_xyz(p)
                        res = self._run_engine_via_wrapper(p, "xtb", f"{self.config.xtb_method} --opt", log_cb, status_cb)
                        if res["status"] == "success":
                            self.fragA = Molecule.from_xyz(res["path"])
                            shutil.copy2(res["path"], os.path.join(self.dirs["inputs"], "stabilized_anchor.xyz"))
                            _log("-> Anchor geometry stabilized.")
                            
                    for i, mol in enumerate(self.fragBs):
                        if mol.n_atoms() == 0:
                            continue
                        p = os.path.join(self.dirs["inputs"], f"preopt_guest_{i}_start.xyz")
                        mol.to_xyz(p)
                        res = self._run_engine_via_wrapper(p, "xtb", f"{self.config.xtb_method} --opt", log_cb, status_cb)
                        if res["status"] == "success":
                            self.fragBs[i] = Molecule.from_xyz(res["path"])
                            shutil.copy2(res["path"], os.path.join(self.dirs["inputs"], f"stabilized_guest_{i}.xyz"))
                            _log(f"-> Guest {i} geometry stabilized.")
                            
                    self.state["preopt_done"] = True
                    self.save()

                if not self.state["gen"]:
                    self._progress("Sampling/filtering", 18.0, "running", f"Generating {self.config.n_generate} H-bonded seeds.")
                    _log(f"Generating {self.config.n_generate} H-bonded seeds...")
                    mols = []
                    for i in range(self.config.n_generate):
                        if i % max(1, self.config.n_generate // 20) == 0:
                            self._progress("Sampling/filtering", 18.0 + 7.0 * (i / max(self.config.n_generate, 1)), "running", f"Generated {i}/{self.config.n_generate} seeds.")
                        m = generate_cluster(
                            self.fragA,
                            self.fragBs,
                            self.n_guests_list,
                            random.Random(self.config.random_seed + i),
                            max_att=self.config.max_placement_attempts,
                            n_anchor=self.n_anchor,
                            reaction_type=self.reaction_type,
                        )
                        if m and m.n_atoms() > 0:
                            valid_atoms, atom_message = self._validate_generated_cluster(m)
                            if not valid_atoms:
                                _log(f"[ATOM-BALANCE WARNING] {atom_message}")
                            p = os.path.join(self.dirs["inputs"], f"cluster_{self.ratio_str}_raw_{i:03d}.xyz")
                            m.to_xyz(p)
                            mols.append(p)
                    self.state["gen"] = mols
                    self.save()
                    if not mols:
                        raise RuntimeError(f"Failed to generate ANY valid collision-free clusters for Ratio {self.ratio_str}.")

                if not self.state["filt"]:
                    self._progress("Sampling/filtering", 26.0, "running", "Scoring geometries and filtering RMSD duplicates.")
                    _log("Scoring geometries and filtering out RMSD duplicates...")
                    mols = [Molecule.from_xyz(p) for p in self.state["gen"]]
                    for m in mols:
                        score_geometry(m)
                    mols.sort(key=lambda x: x.score, reverse=True)
                    unique = []
                    for m in mols[: self.config.n_keep_scored]:
                        if not any(
                            u.n_atoms() == m.n_atoms() and
                            kabsch_rmsd(m.coords_array(), u.coords_array()) < self.config.rmsd_cutoff
                            for u in unique
                        ):
                            unique.append(m)
                    for i, m in enumerate(unique[: self.config.n_keep_clustered]):
                        p = os.path.join(self.dirs["inputs"], f"cluster_{self.ratio_str}_filt_{i:03d}.xyz")
                        m.to_xyz(p, f"Score: {m.score:.2f}")
                        self.state["filt"].append(p)
                    self.save()

            self._progress("Sampling/filtering", 29.0, "completed", "Cluster seeding and filtering complete.")

            if run_xtb:
                _log("\n=======================================================")
                _log(f"Running xTB Optimization on top {self.config.n_run_xtb} clustered geometries...")
                _log("=======================================================")
                targets = self.state["filt"][: self.config.n_run_xtb]
                total = max(len(targets), 1)
                for idx, p in enumerate(targets, start=1):
                    self._progress("xTB", 30.0 + 20.0 * ((idx - 1) / total), "running", f"xTB optimization {idx}/{total}.")
                    stem = Path(p).stem
                    if stem not in self.state["xtb"] or self.state["xtb"][stem].get("status") != "success":
                        res = self._run_engine_via_wrapper(p, "xtb", f"{self.config.xtb_method} --opt", log_cb, status_cb)
                        if res["status"] == "success":
                            final_name = os.path.join(self.dirs["xtb"], f"xtbopt_{stem}.xyz")
                            shutil.copy2(res["path"], final_name)
                            res["path"] = final_name
                        self.state["xtb"][stem] = res
                        self.save()
                self._progress("xTB", 51.0, "completed", "xTB optimizations complete.")

            if run_crest:
                self._progress("CREST", 52.0, "running", "Filtering xTB structures and promoting to CREST.")
                _log("\n=======================================================")
                _log("Filtering xTB results and promoting to CREST...")
                xtb_success = [(k, v) for k, v in self.state["xtb"].items() if v.get("status") == "success"]
                if not xtb_success:
                    _log("[ERROR] No successful xTB runs available for CREST. Did xTB fail?")
                else:
                    xtb_success.sort(key=lambda x: x[1].get("energy", 0))
                    min_e = xtb_success[0][1].get("energy", 0)
                    promoted_xtb = [(k, v) for k, v in xtb_success if (v["energy"] - min_e) * EH2KCAL <= self.config.xtb_ewin_kcal][: self.config.n_run_crest]
                    _log(f"Promoted {len(promoted_xtb)} xTB structures within {self.config.xtb_ewin_kcal} kcal/mol of minimum.")
                    total = max(len(promoted_xtb), 1)
                    for idx, (k, v) in enumerate(promoted_xtb, start=1):
                        self._progress("CREST", 55.0 + 15.0 * ((idx - 1) / total), "running", f"CREST search {idx}/{total}.")
                        if k not in self.state["crest"] or self.state["crest"][k].get("status") != "success":
                            res = self._run_engine_via_wrapper(v["path"], "crest", f"{self.config.crest_method} -T {self.config.cores}", log_cb, status_cb)
                            if res["status"] == "success":
                                final_conf = os.path.join(self.dirs["crest"], f"crest_conformers_{k}.xyz")
                                shutil.copy2(res["path"], final_conf)
                                res["path"] = final_conf
                                if "best_path" in res and os.path.exists(res["best_path"]):
                                    final_best = os.path.join(self.dirs["crest"], f"crest_best_{k}.xyz")
                                    shutil.copy2(res["best_path"], final_best)
                                    res["best_path"] = final_best
                            self.state["crest"][k] = res
                            self.save()
                self._progress("CREST", 71.0, "completed", "CREST conformer search complete.")

            if run_orca:
                self._progress("ORCA", 72.0, "running", "Aggregating CREST conformers and promoting to ORCA.")
                _log("\n=======================================================")
                _log("Aggregating CREST conformers and promoting to ORCA DFT...")
                all_confs = []
                for k, v in self.state["crest"].items():
                    if v.get("status") == "success" and "path" in v and os.path.exists(v["path"]):
                        mols = read_multi_xyz(v["path"])
                        for i, m in enumerate(mols):
                            m.lineage = [k, f"conf_{i}"]
                            all_confs.append(m)
                if not all_confs:
                    _log("[WARNING] No CREST conformers found. Falling back to best xTB-optimized structure(s) for ORCA.")
                    for k, v in self.state["xtb"].items():
                        if v.get("status") == "success" and "path" in v and os.path.exists(v["path"]):
                            m = Molecule.from_xyz(v["path"])
                            m.lineage = [k, "xtb_direct"]
                            m.energy_eh = v.get("energy", 0.0)
                            all_confs.append(m)
                if not all_confs:
                    _log("[ERROR] No structures available for ORCA. Ensure xTB or CREST ran successfully.")
                else:
                    all_confs.sort(key=lambda x: x.energy_eh)
                    min_crest_e = all_confs[0].energy_eh
                    unique_promoted = []
                    for m in all_confs:
                        rel_e = (m.energy_eh - min_crest_e) * EH2KCAL
                        if rel_e > self.config.crest_ewin_kcal:
                            continue
                        is_dup = any(
                            u.n_atoms() == m.n_atoms() and
                            kabsch_rmsd(m.coords_array(), u.coords_array()) < 0.25
                            for u in unique_promoted
                        )
                        if not is_dup and len(unique_promoted) < 10:
                            unique_promoted.append(m)
                    _log(f"Promoted top {len(unique_promoted)} highly unique conformers to ORCA.")
                    total = max(len(unique_promoted), 1)
                    for i, m in enumerate(unique_promoted):
                        self._progress("ORCA", 75.0 + 20.0 * (i / total), "running", f"ORCA refinement {i + 1}/{total}.")
                        stem = f"orca_target_{i:03d}"
                        if stem not in self.state["orca"] or self.state["orca"][stem].get("status") != "success":
                            inp_path = os.path.join(self.dirs["inputs"], f"{stem}.xyz")
                            m.to_xyz(inp_path)
                            res = self._run_orca_via_sandbox(inp_path, stem, log_cb, status_cb)
                            if res["status"] == "success":
                                res["lineage"] = " -> ".join(m.lineage)
                                if res["imag"] == 0:
                                    best_name = os.path.join(self.dirs["orca"], f"ORCA_MINIMUM_{stem}.xyz")
                                    shutil.copy2(res["path"], best_name)
                                    res["best_path"] = best_name
                                    _log("-> True Local Minimum Confirmed!")
                            self.state["orca"][stem] = res
                            self.save()

            self._progress("Reports", 96.0, "running", "Extracting top models and writing reports.")
            self._extract_top_models(log_cb)
            self._generate_markdown_report()
            self.job_summary.status = "SUCCESS"
            self.job_summary.finished_at = _now()
            self.job_summary.log_event("Complete", "Pipeline finished and final artifacts were written.")
            self.job_summary.write()
            self._progress("Complete", 100.0, "completed", "Job complete.")
            _log(f"\nPipeline Complete for Ratio {self.ratio_str.replace('_', ':')}. Check the '5. TOP 3 COMPARE' tab.")
        except Exception as exc:
            self.job_summary.status = "FAILED"
            self.job_summary.finished_at = _now()
            self.job_summary.error = str(exc)
            self.job_summary.traceback = traceback.format_exc()
            self.job_summary.log_event("Failure", str(exc), level="ERROR")
            self.job_summary.write()
            self._progress("Failed", max(self.progress_percent, 1.0), "failed", str(exc))
            raise

    def _run_engine_via_wrapper(self, xyz_path, engine, flags, log_cb, status_cb):
        fname = os.path.basename(xyz_path)
        stem = Path(xyz_path).stem
        wd = os.path.abspath(os.path.join(self.dirs.get(engine, self.dirs["inputs"]), f"job_{stem}"))
        os.makedirs(wd, exist_ok=True)
        shutil.copy2(xyz_path, os.path.join(wd, fname))
        if sys.platform == "win32":
            sh_path = os.path.abspath(os.path.join(wd, f"run_{engine}.sh"))
            with open(sh_path, "w", newline="\n", encoding="utf-8") as f:
                f.write("#!/bin/bash\n")
                wsl_wd = get_wsl_path(wd).replace("'", "'\\''")
                f.write(f"SANDBOX=\"/tmp/iak_{engine}_{stem}_$RANDOM\"\n")
                f.write("mkdir -p \"$SANDBOX\"\n")
                f.write(f"cp '{wsl_wd}/{fname}' \"$SANDBOX/\"\n")
                f.write("cd \"$SANDBOX\"\n")
                if engine == "xtb" and XTB_DIR:
                    wsl_xtb = get_wsl_path(os.path.abspath(XTB_DIR))
                    f.write(f"export PATH='{wsl_xtb}:/usr/bin:/bin:/usr/local/bin:$PATH'\n")
                    f.write(f"export XTBPATH='{get_wsl_path(os.path.abspath(os.path.join(XTB_DIR, '..', 'share', 'xtb')))}'\n")
                    exec_cmd = f"'{wsl_xtb}/xtb'"
                elif engine == "crest" and CREST_DIR:
                    wsl_crest = get_wsl_path(os.path.abspath(CREST_DIR))
                    f.write(f"export PATH='{wsl_crest}:/usr/bin:/bin:/usr/local/bin:$PATH'\n")
                    exec_cmd = f"'{wsl_crest}/crest'"
                else:
                    f.write("source ~/.bashrc 2>/dev/null\n")
                    f.write("source ~/.profile 2>/dev/null\n")
                    f.write("export PATH='/usr/bin:/bin:/usr/local/bin:$PATH'\n")
                    exec_cmd = engine
                f.write(f"export OMP_STACKSIZE=1G\nexport OMP_NUM_THREADS={self.config.cores}\nulimit -s unlimited\n")
                if engine in ("xtb", "crest") and self.config.charge != 0:
                    flags += f" --chrg {self.config.charge}"
                if engine in ("xtb", "crest") and self.config.multiplicity != 1:
                    flags += f" --uhf {self.config.multiplicity - 1}"
                f.write(f"{exec_cmd} '{fname}' {flags}\n")
                f.write(f"/bin/cp -r * '{wsl_wd}/' 2>/dev/null\n")
                f.write("cd /tmp\n")
                f.write("/bin/rm -rf \"$SANDBOX\"\n")
            cmd = f"wsl -e bash \"{get_wsl_path(sh_path)}\""
        else:
            cmd = f"cd '{wd}' && {engine} '{fname}' {flags}"

        if self.config.exec_env == "Docker Container":
            cmd = f"docker run --rm -v \"{wd}:/workspace\" -w /workspace {engine}_image bash run_{engine}.sh"
        elif self.config.exec_env == "SLURM Cluster":
            cmd = f"cd '{wd}' && sbatch --wait run_{engine}.sh"
        if status_cb:
            status_cb(engine, 1)
        if log_cb:
            log_cb(f"\n>>> Executing Sandbox Engine: {engine} {flags}\n")
        started = time.time()
        try:
            proc = subprocess.Popen(cmd, shell=True, cwd=wd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
            output = []
            for line in iter(proc.stdout.readline, ""):
                output.append(line)
                if log_cb:
                    log_cb(line)
            proc.wait()
            if engine == "xtb":
                opt_file = os.path.join(wd, "xtbopt.xyz")
                if not os.path.exists(opt_file):
                    opt_file = os.path.join(wd, fname)
                energy, success = 0.0, False
                for l in reversed(output):
                    if "total energy" in l.lower():
                        try:
                            parts = l.split()
                            energy = float(parts[parts.index("Eh") - 1]) if "Eh" in parts else float(parts[-2])
                            success = True
                            break
                        except Exception:
                            pass
                res = {"status": "success", "energy": energy, "path": opt_file} if success or os.path.exists(os.path.join(wd, "xtbopt.xyz")) else {"status": "failed"}
                self._record_engine_result(engine, stem, flags, res, time.time() - started)
                return res
            if engine == "crest":
                conf_file = os.path.join(wd, "crest_conformers.xyz")
                best_file = os.path.join(wd, "crest_best.xyz")
                res = {"status": "success", "path": conf_file, "best_path": best_file if os.path.exists(best_file) else conf_file} if os.path.exists(conf_file) else {"status": "failed"}
                self._record_engine_result(engine, stem, flags, res, time.time() - started)
                return res
        except Exception as e:
            if log_cb:
                log_cb(f"\n[Python Error] {e}\n")
        finally:
            if status_cb:
                status_cb(engine, -1)
        res = {"status": "failed"}
        self._record_engine_result(engine, stem, flags, res, time.time() - started)
        return res

    def _run_orca_via_sandbox(self, xyz_path, stem, log_cb, status_cb):
        wd = os.path.abspath(os.path.join(self.dirs["orca"], f"job_{stem}"))
        os.makedirs(wd, exist_ok=True)
        wsl_wd = get_wsl_path(wd).replace("'", "'\\''")
        mol = Molecule.from_xyz(xyz_path)

        if sys.platform == "win32" and not ORCA_IS_WINDOWS:
            has_mpi = subprocess.run("wsl -e bash -c 'export PATH=\"/usr/bin:/bin:/usr/local/bin:$PATH\"; which mpirun'", shell=True, capture_output=True).returncode == 0
        else:
            has_mpi = shutil.which("mpirun") is not None

        def _execute_orca(use_mpi: bool, skip_freq: bool):
            inp_file = os.path.join(wd, f"{stem}.inp")
            with open(inp_file, "w", encoding="utf-8", newline="\n") as f:
                base_method = self.config.orca_method.replace("Opt Freq", "").replace("TightOpt", "").replace("Opt", "").strip()
                task = "Opt" if skip_freq else "Opt Freq"
                f.write(f"! {base_method} {task}\n")
                f.write(f"%maxcore {self.config.maxcore}\n")
                if use_mpi:
                    f.write(f"%pal nprocs {self.config.cores} end\n")
                f.write("%geom\n  MaxIter 350\nend\n")
                f.write("%scf\n  MaxIter 350\nend\n")
                f.write(f"* xyz {self.config.charge} {self.config.multiplicity}\n")
                for a in mol.atoms:
                    f.write(f"{a.symbol:<4} {a.x:15.6f} {a.y:15.6f} {a.z:15.6f}\n")
                f.write("*\n")

            if sys.platform == "win32" and not ORCA_IS_WINDOWS:
                sh_path = os.path.abspath(os.path.join(wd, "run_orca.sh"))
                with open(sh_path, "w", newline="\n", encoding="utf-8") as f:
                    f.write("#!/bin/bash\n")
                    f.write(f"SANDBOX=\"/tmp/iak_orca_{stem}_$RANDOM\"\n")
                    f.write("mkdir -p \"$SANDBOX\"\n")
                    f.write(f"cp '{wsl_wd}/{stem}.inp' \"$SANDBOX/\"\n")
                    f.write("cd \"$SANDBOX\"\n")
                    f.write("export PATH='/usr/bin:/bin:/usr/local/bin:$PATH'\n")
                    f.write("ulimit -s unlimited 2>/dev/null\n")
                    f.write("export OMP_NUM_THREADS=1\nexport OMP_STACKSIZE=1G\n")
                    if ORCA_DIR:
                        wsl_orca = get_wsl_path(os.path.abspath(ORCA_DIR))
                        f.write("SAFE_ORCA=\"/tmp/iak_orca_bin\"\n")
                        f.write("/bin/rm -f $SAFE_ORCA\n")
                        f.write(f"/bin/ln -s '{wsl_orca}' $SAFE_ORCA\n")
                        f.write("export PATH=$SAFE_ORCA:$PATH\n")
                        f.write("export LD_LIBRARY_PATH=$SAFE_ORCA:/usr/lib/x86_64-linux-gnu:/usr/lib:$LD_LIBRARY_PATH\n")
                        exec_cmd = "orca"
                    else:
                        f.write("source ~/.bashrc 2>/dev/null\nsource ~/.profile 2>/dev/null\n")
                        exec_cmd = "orca"
                    if use_mpi:
                        f.write("REAL_MPI=$(which mpirun)\n")
                        f.write("if [ -z \"$REAL_MPI\" ]; then REAL_MPI=\"/usr/bin/mpirun\"; fi\n")
                        f.write("echo '#!/bin/bash' > ./mpirun\n")
                        f.write("echo \"$REAL_MPI \\\"\\$@\\\"\" >> ./mpirun\n")
                        f.write("chmod +x ./mpirun\n")
                        f.write("export PATH=\".:$PATH\"\n")
                    f.write("export OMPI_ALLOW_RUN_AS_ROOT=1\nexport OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1\n")
                    f.write("export OMPI_MCA_btl_vader_single_copy_mechanism=none\nexport OMPI_MCA_btl=\"^openib\"\n")
                    f.write("export OMPI_MCA_rmaps_base_oversubscribe=1\nexport OMPI_MCA_hwloc_base_binding_policy=none\n")
                    f.write(f"{exec_cmd} {stem}.inp > '{wsl_wd}/{stem}.out' 2>&1\n")
                    f.write(f"/bin/cp {stem}_trj.xyz '{wsl_wd}/' 2>/dev/null\n")
                    f.write(f"/bin/cp *xyz '{wsl_wd}/' 2>/dev/null\n")
                    f.write("cd /tmp\n")
                    f.write("/bin/rm -rf \"$SANDBOX\"\n")
                cmd = f"wsl -e bash \"{get_wsl_path(sh_path)}\""
            elif sys.platform == "win32" and ORCA_IS_WINDOWS:
                cmd = f"cd /d \"{wd}\" && \"{os.path.join(os.path.abspath(ORCA_DIR), 'orca.exe')}\" {stem}.inp > {stem}.out 2>&1"
            else:
                cmd = f"cd '{wd}' && {ORCA_CMD} {stem}.inp > {stem}.out 2>&1"

            if self.config.exec_env == "Docker Container":
                cmd = f"docker run --rm -v \"{wd}:/workspace\" -w /workspace orca_image bash run_orca.sh"
            elif self.config.exec_env == "SLURM Cluster":
                cmd = f"cd '{wd}' && sbatch --wait run_orca.sh"

            try:
                proc = subprocess.Popen(cmd, shell=True, cwd=wd)
                out_file = os.path.join(wd, f"{stem}.out")
                last_pos = 0
                while proc.poll() is None:
                    if os.path.exists(out_file):
                        try:
                            with open(out_file, "r", encoding="utf-8", errors="replace") as f:
                                f.seek(last_pos)
                                chunk = f.read()
                                if chunk and log_cb:
                                    for line in chunk.splitlines(True):
                                        log_cb(line)
                                last_pos = f.tell()
                        except Exception:
                            pass
                    time.sleep(0.5)
                if os.path.exists(out_file):
                    with open(out_file, "r", encoding="utf-8", errors="replace") as f:
                        f.seek(last_pos)
                        chunk = f.read()
                        if chunk and log_cb:
                            for line in chunk.splitlines(True):
                                log_cb(line)
                trj_file = os.path.join(wd, f"{stem}_trj.xyz")
                energy, gibbs, imag, success = 0.0, 0.0, 0, False
                mpirun_crashed, scf_crashed = False, False
                time.sleep(1.0)
                if os.path.exists(out_file):
                    with open(out_file, "r", encoding="utf-8", errors="replace") as f:
                        content = f.read()
                    if "FINAL SINGLE POINT ENERGY" in content:
                        for line in content.split("\n"):
                            if "FINAL SINGLE POINT ENERGY" in line:
                                energy = float(line.split()[-1])
                            if "Final Gibbs free energy" in line:
                                gibbs = float(line.split()[-2])
                            if "*** imaginary mode ***" in line:
                                imag += 1
                            if "ORCA TERMINATED NORMALLY" in line:
                                success = True
                    content_lower = content.lower()
                    if "mpirun: not found" in content_lower or "aborting the run" in content_lower or "mpi" in content_lower or "hwloc" in content_lower:
                        mpirun_crashed = True
                    if "scf not converged" in content_lower or "optimization did not converge" in content_lower or "std::bad_alloc" in content_lower or "command not found" in content_lower:
                        scf_crashed = True
                    if not success and not mpirun_crashed:
                        scf_crashed = True
                else:
                    scf_crashed = True
                if success and energy != 0.0:
                    opt_path = trj_file if os.path.exists(trj_file) else os.path.join(wd, f"{stem}.xyz")
                    return True, {"status": "success", "energy": energy, "gibbs": gibbs, "imag": imag, "path": opt_path}, False, False
                return False, {"status": "failed"}, mpirun_crashed, scf_crashed
            except Exception:
                return False, {"status": "failed"}, True, True

        if status_cb:
            status_cb("orca", 1)
        started = time.time()
        try:
            if log_cb:
                log_cb(f"\n>>> [Tier 1] Executing ORCA (Parallel {self.config.cores}-Core, Opt Freq): {stem}\n")
            success, res, mpi_crash, scf_crash = _execute_orca(use_mpi=has_mpi, skip_freq=False)
            if not success:
                if mpi_crash and has_mpi:
                    if log_cb:
                        log_cb(f"\n>>> [Tier 2] MPI Failed! Restarting in Serial Mode (1-Core, Opt Freq): {stem}\n")
                    success, res, mpi_crash, scf_crash = _execute_orca(use_mpi=False, skip_freq=False)
                if not success:
                    use_mpi_for_opt = has_mpi and not mpi_crash
                    cores = f"{self.config.cores}-Core" if use_mpi_for_opt else "1-Core"
                    if log_cb:
                        log_cb(f"\n>>> [Tier 3] Math/Memory Failed! Stripping Freq, forcing Opt-Only ({cores}): {stem}\n")
                    success, res, mpi_crash, scf_crash = _execute_orca(use_mpi=use_mpi_for_opt, skip_freq=True)
                    if not success and use_mpi_for_opt:
                        if log_cb:
                            log_cb(f"\n>>> [Tier 4] Ultimate Fallback: Serial Mode Opt-Only (1-Core): {stem}\n")
                        success, res, mpi_crash, scf_crash = _execute_orca(use_mpi=False, skip_freq=True)
            self._record_engine_result("orca", stem, self.config.orca_method, res, time.time() - started)
            return res
        finally:
            if status_cb:
                status_cb("orca", -1)

    def _extract_top_models(self, log_cb):
        comp_dir = self.dirs["comparison"]
        report = []
        best_xtb_k, best_xtb_e, best_xtb_path = None, float("inf"), None
        for k, v in self.state["xtb"].items():
            if v.get("status") == "success" and "energy" in v and v["energy"] < best_xtb_e:
                best_xtb_e, best_xtb_k, best_xtb_path = v["energy"], k, v["path"]
        if best_xtb_path and os.path.exists(best_xtb_path):
            shutil.copy2(best_xtb_path, os.path.join(comp_dir, "1_BEST_xTB.xyz"))
            report.append(f"xTB,{best_xtb_k},{best_xtb_e:.6f},N/A,N/A")

        best_crest_e, best_crest_path = float("inf"), None
        for k, v in self.state["crest"].items():
            if v.get("status") == "success" and "best_path" in v and os.path.exists(v["best_path"]):
                mols = read_multi_xyz(v["best_path"])
                if mols and mols[0].energy_eh < best_crest_e:
                    best_crest_e, best_crest_path = mols[0].energy_eh, v["best_path"]
        if best_crest_path:
            shutil.copy2(best_crest_path, os.path.join(comp_dir, "2_BEST_CREST.xyz"))
            report.append(f"CREST,-,{best_crest_e:.6f},N/A,N/A")

        best_orca_k, best_orca_e, best_orca_g, best_orca_path = None, float("inf"), 0.0, None
        for k, v in self.state["orca"].items():
            if v.get("status") == "success" and v.get("imag") == 0 and "energy" in v:
                rank_metric = v.get("gibbs") if v.get("gibbs", 0) != 0.0 else v["energy"]
                if rank_metric < best_orca_e:
                    best_orca_e, best_orca_g, best_orca_k, best_orca_path = rank_metric, v.get("gibbs", 0.0), k, v.get("best_path", v["path"])
        if best_orca_path is None:
            for k, v in self.state["orca"].items():
                if v.get("status") == "success" and "energy" in v:
                    rank_metric = v.get("gibbs") if v.get("gibbs", 0) != 0.0 else v["energy"]
                    if rank_metric < best_orca_e:
                        best_orca_e, best_orca_g, best_orca_k, best_orca_path = rank_metric, v.get("gibbs", 0.0), k, v.get("best_path", v["path"])
        if best_orca_path and os.path.exists(best_orca_path):
            shutil.copy2(best_orca_path, os.path.join(comp_dir, "3_BEST_ORCA.xyz"))
            binding_str = "N/A"
            if self.config.energy_a is not None and self.config.energy_b is not None:
                total_guests = sum(self.n_guests_list)
                delta_e_eh = best_orca_e - (self.config.energy_a + (total_guests * self.config.energy_b))
                binding_str = f"{delta_e_eh * EH2KCAL:.2f}"
            report.append(f"ORCA,{best_orca_k},{best_orca_e:.6f},{best_orca_g:.6f},{binding_str}")
        if report:
            with open(os.path.join(comp_dir, "Energy_Comparison.csv"), "w", encoding="utf-8") as f:
                f.write("Level_of_Theory,Source_ID,Total_Energy_Eh,Gibbs_Free_Energy_Eh,Binding_Energy_kcal_mol\n")
                for line in report:
                    f.write(line + "\n")
            if log_cb:
                log_cb("\n-> Extracted Top Models into 05_Top_Models_Comparison\n")

    def _generate_markdown_report(self):
        report_path = os.path.join(self.dirs["comparison"], "Post_CREST_Report.md")
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(f"# Workflow Analysis Report: Ratio {self.ratio_str.replace('_', ':')}\n\n")
            f.write("## Scientific Disclaimer\n")
            f.write("> The structures reported herein represent local minima found within the defined sampling depth and selected level of theory. They are **not guaranteed global minima**.\n\n")
            all_orca = self.state.get("orca", {})
            valid_orca = [(k, v) for k, v in all_orca.items() if v.get("status") == "success"]
            true_minima = [(k, v) for k, v in valid_orca if v.get("imag") == 0]
            f.write("## 1. Summary Metrics\n")
            f.write(f"- **ORCA Method Used:** {self.config.orca_method}\n")
            f.write(f"- **System Charge:** {self.config.charge}  |  **Multiplicity:** {self.config.multiplicity}\n")
            f.write(f"- **ORCA Conformers Evaluated:** {len(all_orca)}\n")
            f.write(f"- **Successful ORCA Completions:** {len(valid_orca)}\n")
            f.write(f"- **True Minima (0 Imag Freqs):** {len(true_minima)}\n\n")
            if not true_minima and valid_orca:
                f.write("> **WARNING:** No true minima were found. The best structure has been extracted anyway for inspection.\n\n")
            elif not valid_orca and len(all_orca) > 0:
                f.write("> **CRITICAL FAILURE:** All ORCA jobs crashed or failed to converge. Check `.out` files in `04_ORCA_Refinement`.\n\n")
            f.write("## 2. Minima Ranking (Gibbs Free Energy)\n")
            if valid_orca:
                valid_orca.sort(key=lambda x: x[1].get("gibbs") if x[1].get("gibbs", 0) != 0 else x[1].get("energy"))
                best_g = valid_orca[0][1].get("gibbs") if valid_orca[0][1].get("gibbs", 0) != 0 else valid_orca[0][1].get("energy")
                f.write("| ORCA ID | Parent Lineage | ΔG (kcal/mol) | Imag Freqs | Status |\n")
                f.write("|---|---|---|---|---|\n")
                for k, v in valid_orca:
                    val = v.get("gibbs") if v.get("gibbs", 0) != 0 else v.get("energy")
                    rel_g = (val - best_g) * EH2KCAL
                    f.write(f"| {k} | {v.get('lineage','N/A')} | {rel_g:.2f} | {v.get('imag')} | Success |\n")
                for k, v in all_orca.items():
                    if v.get("status") != "success":
                        f.write(f"| {k} | {v.get('lineage','N/A')} | N/A | N/A | FAILED |\n")
            else:
                f.write("*No valid minima found to rank.*\n")


# =============================================================================
# 7. GUI APPLICATION
# =============================================================================
class IAKApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("IAK v11.2 The Job-Report and Visual Analytics Edition")
        self.root.geometry("1500x1040")
        self.root.configure(bg=_C["bg"])
        self._q = queue.Queue()
        self._vars = {k: tk.StringVar(value=v) for k, v in {"a": "", "b": "", "ratio": "1:0, 1:1, 1:2", "mode": "balanced", "out": "run", "reaction_type": "Non-covalent"}.items()}
        self._vars_pes = {
            "scan_mode": tk.StringVar(value="coord"),
            "scan_type": tk.StringVar(value="distance"),  # distance | angle | dihedral
            "reactant": tk.StringVar(value=""),
            "product": tk.StringVar(value=""),
            "engine": tk.StringVar(value="xtb"),
            "c1_a1": tk.StringVar(value="1"), "c1_a2": tk.StringVar(value="2"),
            "c1_start": tk.StringVar(value="1.0"), "c1_end": tk.StringVar(value="2.5"), "c1_steps": tk.StringVar(value="10"),
            "use_c2": tk.BooleanVar(value=False),
            "c2_a1": tk.StringVar(value="3"), "c2_a2": tk.StringVar(value="4"),
            "c2_start": tk.StringVar(value="1.5"), "c2_end": tk.StringVar(value="3.0"), "c2_steps": tk.StringVar(value="10"),
            "run_ts": tk.BooleanVar(value=True),
            "predict_ts_spline": tk.BooleanVar(value=True),
            # Angle scan extras
            "ang_a3": tk.StringVar(value="3"),
            # Dihedral scan extras
            "dih_a3": tk.StringVar(value="3"), "dih_a4": tk.StringVar(value="4"),
        }
        # FES / Perturbation variables
        self._vars_fes = {
            "temperature": tk.StringVar(value="298.15"),
            "n_bins": tk.StringVar(value="50"),
            # Umbrella sampling
            "us_mol": tk.StringVar(value=""),
            "us_a1": tk.StringVar(value="1"), "us_a2": tk.StringVar(value="2"),
            "us_centers": tk.StringVar(value="1.0,1.2,1.4,1.6,1.8,2.0"),
            "us_spring_k": tk.StringVar(value="50.0"),
            "us_steps": tk.StringVar(value="5000"),
            "us_summary": tk.StringVar(value=""),
            # HILLS / metadynamics
            "hills_file": tk.StringVar(value=""),
            "hills_cv_min": tk.StringVar(value="1.0"),
            "hills_cv_max": tk.StringVar(value="4.0"),
            "hills_gamma": tk.StringVar(value=""),
            "hills_cv_label": tk.StringVar(value="Distance (Å)"),
            # FEP / TI
            "fep_file0": tk.StringVar(value=""),
            "fep_file1": tk.StringVar(value=""),
            "n_lambda": tk.StringVar(value="11"),
            "lambda_schedule": tk.StringVar(value="linear"),
            # Output dir
            "fes_out": tk.StringVar(value=""),
        }
        # NEB/TS-dedicated variables
        self._vars_neb = {
            "reactant": tk.StringVar(value=""),
            "product": tk.StringVar(value=""),
            "engine": tk.StringVar(value="xtb"),
            "images": tk.StringVar(value="8"),
            "spring_k": tk.StringVar(value="0.01"),
            "run_ts_refine": tk.BooleanVar(value=True),
            "ts_hess": tk.BooleanVar(value=True),
            "charge": tk.StringVar(value="0"),
            "mult": tk.StringVar(value="1"),
            "max_iter": tk.StringVar(value="500"),
        }
        # Prebiotic elucidation module variables
        self._vars_prebiotic = {
            # ── Environment conditions ──────────────────────────────────────
            "search_query":    tk.StringVar(value=""),
            "filter_env":      tk.StringVar(value="All"),
            "filter_category": tk.StringVar(value="All"),
            "T_K":             tk.StringVar(value="298"),
            "pH":              tk.StringVar(value="7.0"),
            "P_atm":           tk.StringVar(value="1.0"),
            "atmosphere":      tk.StringVar(value="N2, CO2, H2O"),
            "minerals":        tk.StringVar(value=""),
            # ── User-defined reactants & bonds ───────────────────────────────
            "user_reactants":  tk.StringVar(value=""),      # csv SMILES or names
            "user_products":   tk.StringVar(value=""),      # csv SMILES or names
            "bond_break":      tk.StringVar(value=""),      # "A1-A2,A3-A4" (1-based atom pairs)
            "bond_form":       tk.StringVar(value=""),      # "A1-A2" pairs to form
            "scan_dist_A1":    tk.StringVar(value="1"),
            "scan_dist_A2":    tk.StringVar(value="2"),
            "scan_start":      tk.StringVar(value="1.0"),
            "scan_end":        tk.StringVar(value="3.5"),
            "scan_steps":      tk.StringVar(value="20"),
            # ── Molecule & charge ────────────────────────────────────────────
            "charge":          tk.StringVar(value="0"),
            "mult":            tk.StringVar(value="1"),
            "mol_file":        tk.StringVar(value=""),
            "product_file":    tk.StringVar(value=""),      # for NEB/CREST product
            "output_dir":      tk.StringVar(value=""),
            # ── xTB settings ─────────────────────────────────────────────────
            "run_xtb_thermo":  tk.BooleanVar(value=True),
            "xtb_method":      tk.StringVar(value="--gfn2"),
            "xtb_solvent":     tk.StringVar(value=""),
            # ── CREST settings ───────────────────────────────────────────────
            "run_crest":       tk.BooleanVar(value=False),
            "crest_method":    tk.StringVar(value="--gfn2"),
            "crest_T":         tk.StringVar(value="298.15"),
            "crest_ewin":      tk.StringVar(value="6.0"),
            "crest_keep_n":    tk.StringVar(value="10"),
            # ── ORCA settings ────────────────────────────────────────────────
            "run_orca":        tk.BooleanVar(value=False),
            "orca_method":     tk.StringVar(value="B97-3c"),
            "orca_basis":      tk.StringVar(value="def2-mTZVP"),
            "orca_keywords":   tk.StringVar(value="Opt Freq"),
            "orca_neb":        tk.BooleanVar(value=False),
            "orca_nproc":      tk.StringVar(value="4"),
            "orca_maxcore":    tk.StringVar(value="2000"),
            # ── Report ───────────────────────────────────────────────────────
            "export_report":   tk.BooleanVar(value=True),
            "selected_rxn":    tk.StringVar(value=""),
        }
        self._guest_list: list[str] = []  # Multi-guest B paths
        for k, v in {
            "cores": "4",
            "maxcore": "2000",
            "charge": "0",
            "mult": "1",
            "xtb_method": "--gfn2",
            "crest_method": "--gfn2",
            "orca_method": "B97-3c Opt Freq",
            "exec_env": "Local (Subprocess)",
            "goat_model": "uma-s-1",
            "n_generate": "200",
            "n_keep_scored": "50",
            "n_keep_clustered": "40",
            "n_run_xtb": "20",
            "n_run_crest": "5",
            "rmsd_cutoff": "0.5",
            "xtb_ewin_kcal": "5.0",
            "crest_ewin_kcal": "3.0",
            "random_seed": "42",
            "max_placement_attempts": "50",
            "e_a": "",
            "e_b": "",
        }.items():
            self._vars[k] = tk.StringVar(value=v)
        self._vars_graph = {
            "dir1": tk.StringVar(value=""),
            "name1": tk.StringVar(value="Series 1"),
            "dir2": tk.StringVar(value=""),
            "name2": tk.StringVar(value="Series 2"),
            "method": tk.StringVar(value="ORCA"),
            "metric": tk.StringVar(value="Gibbs Free Energy (ΔG)"),
            "x_labels": tk.StringVar(value=""),
            "top_space": tk.BooleanVar(value=False),
            "conn_style": tk.StringVar(value="Smooth (Bezier)"),
            "delta_arrow": tk.StringVar(value="Straight"),
            "label_box": tk.StringVar(value="Rounded Box"),
            "series1_color": tk.StringVar(value="#17a2b8"),
            "series2_color": tk.StringVar(value="#ffc107"),
            "crest_color": tk.StringVar(value="#6c757d"),
            "orca_color": tk.StringVar(value="#388bfd"),
            "graph_bg": tk.StringVar(value="#ffffff"),
            "axis_color": tk.StringVar(value="#000000"),
            "grid_color": tk.StringVar(value="#b8b8b8"),
            "watermark_color": tk.StringVar(value="#6e6e6e"),
            "crop_xmin": tk.StringVar(value=""),
            "crop_xmax": tk.StringVar(value=""),
            "crop_ymin": tk.StringVar(value=""),
            "crop_ymax": tk.StringVar(value=""),
            "model_style": tk.StringVar(value="Ball-and-stick"),
            "model_bg": tk.StringVar(value="#ffffff"),
            "bond_color": tk.StringVar(value="#6b7280"),
            "atom_H": tk.StringVar(value="#f8fafc"),
            "atom_C": tk.StringVar(value="#4b5563"),
            "atom_N": tk.StringVar(value="#2563eb"),
            "atom_O": tk.StringVar(value="#dc2626"),
            "atom_F": tk.StringVar(value="#22c55e"),
            "atom_S": tk.StringVar(value="#facc15"),
            "atom_Cl": tk.StringVar(value="#16a34a"),
            "atom_other": tk.StringVar(value="#f97316"),
            "bond_mode": tk.StringVar(value="Covalent radii"),
            "bond_cutoff": tk.StringVar(value="1.85"),
            "bond_tolerance": tk.StringVar(value="0.45"),
            "show_bond_distances": tk.BooleanVar(value=False),
            "show_atom_labels": tk.BooleanVar(value=False),
            "show_3d_axes": tk.BooleanVar(value=True),
            "model_elev": tk.StringVar(value="18"),
            "model_azim": tk.StringVar(value="38"),
            "image_dpi": tk.StringVar(value="300"),
            "conformer_top_n": tk.StringVar(value="10"),
        }
        self._report_vars = {
            "inputs": tk.BooleanVar(value=True),
            "workflow": tk.BooleanVar(value=True),
            "engine_results": tk.BooleanVar(value=True),
            "thermodynamics": tk.BooleanVar(value=True),
            "images": tk.BooleanVar(value=True),
            "timeline": tk.BooleanVar(value=True),
            "system_info": tk.BooleanVar(value=True),
            "ai_prompt": tk.BooleanVar(value=True),
        }
        self.active_xtb, self.active_crest, self.active_orca = 0, 0, 0
        self.preview_tw = None
        self.preview_file = None
        self.is_running = False
        self.start_time = 0
        self._color_buttons = {}
        self._build_ui()
        setup_logging(gui_queue=self._q)
        self.root.after(100, self._poll_log)
        self.root.after(800, self._show_capabilities_popup)

    def mainloop(self):
        self.root.mainloop()

    def _show_capabilities_popup(self):
        self.cap_w = tk.Toplevel(self.root)
        self.cap_w.title("IAK Workflow Capabilities")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 360
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 270
        self.cap_w.geometry(f"720x520+{x}+{y}")
        self.cap_w.configure(bg=_C["panel"])
        self.cap_w.grab_set()
        self.cap_w.transient(self.root)
        tk.Label(self.cap_w, text="IAK v11.2 Workflow Capabilities", font=("Segoe UI", 16, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 10))
        caps = [
            "1. Intelligent H-bond logic docking for supramolecular assembly.",
            "2. Single Molecule Mode for isolated anchor runs.",
            "3. RMSD-based duplicate filtering and steric screening.",
            "4. xTB, CREST, and self-healing ORCA refinement pipeline.",
            "5. Per-job summary reports with input correctness checks.",
            "6. Live percent-complete and ETA progress monitor.",
            "7. JACS-grade graphing with custom colors, pan, zoom, and crop.",
            "8. Chemcraft-like molecular image styles and atom/bond color control.",
        ]
        for cap in caps:
            tk.Label(self.cap_w, text=cap, font=("Segoe UI", 11), bg=_C["panel"], fg=_C["text"], justify="left", anchor="w").pack(fill="x", padx=40, pady=8)

        def next_step():
            self.cap_w.destroy()
            self.root.after(100, self._show_guidelines_popup)

        tk.Button(self.cap_w, text="Next: Usage Guidelines", command=next_step, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=25).pack(pady=25)

    def _show_guidelines_popup(self):
        self.guide_w = tk.Toplevel(self.root)
        self.guide_w.title("IAK Usage Guidelines")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 360
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 300
        self.guide_w.geometry(f"720x600+{x}+{y}")
        self.guide_w.configure(bg=_C["panel"])
        self.guide_w.grab_set()
        self.guide_w.transient(self.root)
        tk.Label(self.guide_w, text="How to Use IAK", font=("Segoe UI", 16, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 5))
        guide_text = (
            "1. Select your Anchor (A) and Guest (B) .xyz files. Leave B empty for single molecule.\n"
            "2. Define Ratios such as 1:0, 1:1, 1:4. Use commas for batch queue.\n"
            "3. Set hardware resources and charge/multiplicity.\n"
            "4. Run the pipeline. Job reports are written into each ratio folder.\n"
            "5. Use Trend Analysis & Graphs for custom JACS-style plots and model images."
        )
        tk.Label(self.guide_w, text=guide_text, font=("Segoe UI", 11), bg=_C["panel"], fg=_C["text"], justify="left").pack(padx=40, pady=10)
        tk.Label(self.guide_w, text="Manual Engine Downloads:", font=("Segoe UI", 12, "bold"), bg=_C["panel"], fg=_C["yellow"]).pack(pady=(10, 5))

        def make_link(parent, text, url):
            lbl = tk.Label(parent, text=text, font=("Segoe UI", 10, "underline"), bg=_C["panel"], fg=_C["accent"], cursor="hand2")
            lbl.pack(pady=2)
            lbl.bind("<Button-1>", lambda e: webbrowser.open_new(url))

        make_link(self.guide_w, "xTB Releases (grimme-lab)", "https://github.com/grimme-lab/xtb/releases")
        make_link(self.guide_w, "CREST Releases (grimme-lab)", "https://github.com/grimme-lab/crest/releases")
        make_link(self.guide_w, "ORCA Forum", "https://orcaforum.kofo.mpg.de")
        tk.Label(self.guide_w, text="'Where molecules become meaning, and computation becomes discovery — inspired by Dr. Imran A. Khan,\nbrought to life by his team Asif Raza and Huma Basheer,\ncreating a platform where chemistry meets intelligence, innovation, and scientific excellence.'", font=("Segoe UI", 10, "bold", "italic"), bg=_C["panel"], fg="green", justify="center").pack(pady=30)
        tk.Button(self.guide_w, text="Enter Workspace", command=lambda: (self.guide_w.destroy(), self.root.after(100, self._show_startup_check)), bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=20).pack(pady=10)

    def _show_startup_check(self):
        self.sw = tk.Toplevel(self.root)
        self.sw.title("System Verification")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 225
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 150
        self.sw.geometry(f"450x300+{x}+{y}")
        self.sw.configure(bg=_C["panel"])
        self.sw.grab_set()
        self.sw.transient(self.root)
        tk.Label(self.sw, text="Checking Computational Engines...", font=("Segoe UI", 14, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 10))
        self.check_vars = {}
        self.check_btns = {}
        frame = tk.Frame(self.sw, bg=_C["panel"])
        frame.pack(fill="both", expand=True, padx=30)
        for engine in ["xTB", "CREST", "ORCA"]:
            row = tk.Frame(frame, bg=_C["panel"])
            row.pack(fill="x", pady=8)
            tk.Label(row, text=f"{engine}:", font=("Segoe UI", 11, "bold"), width=8, anchor="w", bg=_C["panel"], fg=_C["text"]).pack(side="left")
            status_lbl = tk.Label(row, text="Checking...", font=("Segoe UI", 11, "italic"), width=15, anchor="w", bg=_C["panel"], fg=_C["muted"])
            status_lbl.pack(side="left")
            btn = tk.Button(row, text="Add Manually", command=lambda e=engine: self._load_local_from_startup(e), bg=_C["yellow"], fg="black", font=("Segoe UI", 9, "bold"), relief="flat", cursor="hand2")
            btn.pack(side="right")
            btn.pack_forget()
            self.check_vars[engine] = status_lbl
            self.check_btns[engine] = btn
        self.sw_continue = tk.Button(self.sw, text="Continue to IAK", command=self.sw.destroy, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=20)
        self.sw_continue.pack(pady=20)
        self.sw_continue.pack_forget()
        threading.Thread(target=self._perform_startup_checks, daemon=True).start()

    def _perform_startup_checks(self):
        time.sleep(0.5)
        all_ready = True
        for engine in ["xTB", "CREST", "ORCA"]:
            is_avail = is_tool_available(engine.lower())
            if not is_avail:
                all_ready = False
            self.root.after(0, lambda e=engine, a=is_avail: self._update_startup_ui(e, a))
            time.sleep(0.4)
        self.root.after(0, lambda: self._finalize_startup_ui(all_ready))

    def _update_startup_ui(self, engine, is_avail):
        if not hasattr(self, "sw") or not self.sw.winfo_exists():
            return
        lbl, btn = self.check_vars.get(engine), self.check_btns.get(engine)
        if is_avail:
            lbl.config(text="Running", fg=_C["green"], font=("Segoe UI", 11, "bold"))
            btn.pack_forget()
        else:
            lbl.config(text="Missing", fg=_C["red"], font=("Segoe UI", 11, "bold"))
            btn.pack(side="right")

    def _finalize_startup_ui(self, all_ready):
        if not hasattr(self, "sw") or not self.sw.winfo_exists():
            return
        self.sw_continue.pack(pady=20)
        if all_ready:
            self.sw_continue.config(text="All Engines Ready - Start", bg=_C["green"])

    def _extract_local_worker(self, fp, engine, from_startup=False):
        """Extract a tar.xz / zip archive for a given engine into the tools directory."""
        try:
            dest = Path(fp).parent
            if fp.endswith(".zip"):
                import zipfile
                with zipfile.ZipFile(fp, "r") as z:
                    z.extractall(dest)
            else:
                import tarfile as _tf
                with _tf.open(fp) as t:
                    t.extractall(dest)
            msg = f"[{engine}] Extracted to {dest}"
            self.root.after(0, lambda m=msg: self._append_text(m + "\n"))
            if from_startup and hasattr(self, "check_vars") and engine in self.check_vars:
                self.root.after(0, lambda: self.check_vars[engine].config(
                    text=f"{engine} ✓ (local)", fg=_C["green"],
                    font=("Segoe UI", 11, "bold")))
        except Exception as exc:
            m = str(exc)
            self.root.after(0, lambda msg=m: self._append_text(f"[Extract ERROR] {msg}\n"))

    def _load_local(self):
        """Open a file dialog to select a local engine archive and extract it."""
        fp = filedialog.askopenfilename(
            title="Select Engine Archive (.tar.xz / .zip)",
            filetypes=[("Archives", "*.tar.xz *.tar.gz *.tgz *.zip"), ("All files", "*.*")]
        )
        if not fp:
            return
        self._append_text(f"[Load Local] Extracting {Path(fp).name} …\n")
        threading.Thread(target=self._extract_local_worker, args=(fp, Path(fp).stem), daemon=True).start()

    def _load_local_from_startup(self, engine):
        fp = filedialog.askopenfilename(parent=self.sw, title=f"Select {engine} Archive", filetypes=[("Archives", "*.tar.xz *.tar.gz *.tgz *.zip")])
        if fp:
            self.check_vars[engine].config(text="Extracting...", fg=_C["yellow"], font=("Segoe UI", 11, "italic"))
            self.check_btns[engine].pack_forget()
            threading.Thread(target=self._extract_local_worker, args=(fp, engine, True), daemon=True).start()

    def _choose_output_base(self):
        current = self._vars["out"].get().strip(" \"'") or "run"
        current_path = Path(current)
        initial_dir = str(current_path.parent) if current_path.parent != Path(".") else os.getcwd()
        parent = filedialog.askdirectory(title="Choose parent folder for IAK output", initialdir=initial_dir)
        if not parent:
            return
        default_name = current_path.name if current_path.name else "run"
        name = simpledialog.askstring(
            "Output Name",
            "Enter the output base name you want:",
            initialvalue=default_name,
            parent=self.root,
        )
        if not name:
            return
        clean_name = re.sub(r'[<>:"/\\\\|?*]+', "_", name.strip())
        if not clean_name:
            clean_name = "run"
        self._vars["out"].set(os.path.join(parent, clean_name))

    def _apply_mode_preset(self):
        mode = self._vars["mode"].get().strip().lower()
        if mode == "custom":
            return
        try:
            cfg = Config.from_mode(RunMode[mode.upper()])
        except Exception:
            cfg = Config.from_mode(RunMode.BALANCED)
        for key in [
            "n_generate",
            "n_keep_scored",
            "n_keep_clustered",
            "n_run_xtb",
            "n_run_crest",
            "rmsd_cutoff",
            "xtb_ewin_kcal",
            "crest_ewin_kcal",
            "random_seed",
            "max_placement_attempts",
            "xtb_method",
            "crest_method",
            "orca_method",
        ]:
            if key in self._vars:
                self._vars[key].set(str(getattr(cfg, key)))

    def _poll_log(self):
        while not self._q.empty():
            self._append_text(self._q.get() + "\n")
        self.root.after(100, self._poll_log)

    def _append_text(self, t):
        self.term.config(state="normal")
        self.term.insert("end", t)
        self.term.see("end")
        self.term.config(state="disabled")

    def _status_cb(self, mode, delta):
        if mode == "xtb":
            self.active_xtb += delta
        elif mode == "crest":
            self.active_crest += delta
        elif mode == "orca":
            self.active_orca += delta
        self.root.after(0, self._update_status_ui)

    def _update_status_ui(self):
        total = self.active_xtb + self.active_crest + self.active_orca
        color = _C["green"] if total > 0 else _C["dim"]
        icon = "ACTIVE" if total > 0 else "IDLE"
        self.live_status_lbl.config(text=f"[{icon}] JOBS: {self.active_xtb} xTB | {self.active_crest} CREST | {self.active_orca} ORCA", fg=color)

    def _update_timer(self):
        if self.is_running:
            elapsed = int(time.time() - self.start_time)
            hrs, mins, secs = elapsed // 3600, (elapsed % 3600) // 60, elapsed % 60
            self.timer_lbl.config(text=f"{hrs:02d}:{mins:02d}:{secs:02d}")
        self.root.after(1000, self._update_timer)

    def _update_installation_labels(self):
        xtb_ok, crest_ok, orca_ok = is_tool_available("xtb"), is_tool_available("crest"), is_tool_available("orca")
        self._xtb_lbl.config(text="xTB: Ready" if xtb_ok else "xTB: Missing", fg=_C["green"] if xtb_ok else _C["red"])
        self._crest_lbl.config(text="CREST: Ready" if crest_ok else "CREST: Missing", fg=_C["green"] if crest_ok else _C["red"])
        self._orca_lbl.config(text="ORCA: Ready" if orca_ok else "ORCA: Missing", fg=_C["green"] if orca_ok else _C["red"])

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook.Tab", padding=[15, 5], font=("Segoe UI", 10, "bold"))
        hdr = tk.Frame(self.root, bg=_C["hdr_bg"], pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="IAK PIPELINE v11.2", font=("Segoe UI", 20, "bold"), fg=_C["accent"], bg=_C["hdr_bg"]).pack(side="left", padx=20)
        stat_f = tk.Frame(hdr, bg=_C["hdr_bg"])
        stat_f.pack(side="left", padx=20)
        self._xtb_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._xtb_lbl.pack(side="left", padx=10)
        self._crest_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._crest_lbl.pack(side="left", padx=10)
        self._orca_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._orca_lbl.pack(side="left", padx=10)
        self.timer_lbl = tk.Label(hdr, text="00:00:00", font=("Consolas", 12, "bold"), fg=_C["accent"], bg=_C["hdr_bg"])
        self.timer_lbl.pack(side="right", padx=(10, 20))
        self.live_status_lbl = tk.Label(hdr, text="[IDLE] JOBS: 0 xTB | 0 CREST | 0 ORCA", font=("Segoe UI", 10, "bold"), fg=_C["dim"], bg=_C["hdr_bg"])
        self.live_status_lbl.pack(side="right", padx=10)
        self._update_installation_labels()
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=15, pady=15)
        self.tab_main = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_pes = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_neb = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_rxn = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_res = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_graph = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_table = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_fes = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_prebiotic = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_tutorial = tk.Frame(self.nb, bg=_C["bg"])
        self.nb.add(self.tab_main, text=" Workflow Pipeline ")
        self.nb.add(self.tab_pes, text=" PES Coordinate Scan ")
        self.nb.add(self.tab_neb, text=" NEB / TS Search ")
        self.nb.add(self.tab_rxn, text=" Reaction Library ")
        self.nb.add(self.tab_res, text=" Generated Results ")
        if MATPLOTLIB_AVAILABLE:
            self.nb.add(self.tab_graph, text=" Trend Analysis & Graphs ")
            self.nb.add(self.tab_table, text=" Thermodynamic Table ")
        self.nb.add(self.tab_fes, text=" FES & Perturbation ")
        self.nb.add(self.tab_prebiotic, text=" Prebiotic Chemistry ")
        self.nb.add(self.tab_tutorial, text=" PES Tutorial ")
        self._build_pipeline_tab(self.tab_main)
        self._build_pes_tab(self.tab_pes)
        self._build_neb_tab(self.tab_neb)
        self._build_reaction_library_tab(self.tab_rxn)
        self._build_results_tab(self.tab_res)
        if MATPLOTLIB_AVAILABLE:
            self._build_graph_tab(self.tab_graph)
            self._build_table_tab(self.tab_table)
        self._build_fes_tab(self.tab_fes)
        self._build_prebiotic_tab(self.tab_prebiotic)
        self._build_pes_tutorial_tab(self.tab_tutorial)
        self.root.after(1000, self._update_timer)

    def _build_pipeline_tab(self, parent):
        main = tk.PanedWindow(parent, orient=tk.HORIZONTAL, sashwidth=6, sashrelief=tk.RAISED, bg=_C["border"], bd=0)
        main.pack(fill="both", expand=True, padx=10, pady=10)
        left_wrapper = tk.Frame(main, bg=_C["bg"])
        left_canvas = tk.Canvas(left_wrapper, bg=_C["bg"], highlightthickness=0)
        left_scroll = tk.Scrollbar(left_wrapper, orient="vertical", command=left_canvas.yview)
        left = tk.Frame(left_canvas, bg=_C["bg"])
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.pack(side="left", fill="both", expand=True)
        left_scroll.pack(side="right", fill="y")
        canvas_window = left_canvas.create_window((0, 0), window=left, anchor="nw")
        left_canvas.bind("<Configure>", lambda e: left_canvas.itemconfig(canvas_window, width=e.width))
        left.bind("<Configure>", lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))

        wf = tk.LabelFrame(left, text=" 1. WORKFLOW SETUP ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        wf.pack(fill="x", pady=(0, 6))
        tk.Label(wf, text="Tip: Leave Guest list empty and set Ratio to '1:0' for single-molecule runs.",
                 bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 5))

        # ── Anchor (A) ──────────────────────────────────────────────────────────
        for lbl, var in [("Anchor (A) XYZ:", "a")]:
            f = tk.Frame(wf, bg=_C["panel"])
            f.pack(fill="x", pady=2)
            tk.Label(f, text=lbl, bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
            tk.Entry(f, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
            tk.Button(f, text="...", command=lambda v=var: self._vars[v].set(
                filedialog.askopenfilename(filetypes=[("XYZ", "*.xyz"), ("All", "*")])), bg=_C["accent"]).pack(side="left")

        # ── Multi-Guest (B) panel ────────────────────────────────────────────────
        gf = tk.LabelFrame(wf, text=" Guest (B) XYZ Files — Multiple Guests Supported ",
                           fg=_C["green"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=8, pady=6)
        gf.pack(fill="x", pady=(4, 2))

        # Listbox showing queued guests
        lb_frame = tk.Frame(gf, bg=_C["panel"])
        lb_frame.pack(fill="x")
        self._guest_lb = tk.Listbox(lb_frame, bg=_C["entry"], fg=_C["text"], selectmode="extended",
                                    height=4, font=("Consolas", 9), bd=0, highlightthickness=0,
                                    activestyle="dotbox")
        self._guest_lb.pack(side="left", fill="x", expand=True)
        lb_sb = tk.Scrollbar(lb_frame, orient="vertical", command=self._guest_lb.yview)
        lb_sb.pack(side="right", fill="y")
        self._guest_lb.config(yscrollcommand=lb_sb.set)

        # Populate listbox from _guest_list on startup
        def _refresh_guest_lb():
            self._guest_lb.delete(0, "end")
            for p in self._guest_list:
                self._guest_lb.insert("end", os.path.basename(p))
        _refresh_guest_lb()

        # Buttons: Add / Remove / Clear
        btn_row = tk.Frame(gf, bg=_C["panel"])
        btn_row.pack(fill="x", pady=(4, 0))

        def _add_guests():
            paths = filedialog.askopenfilenames(
                title="Select Guest (B) XYZ files",
                filetypes=[("XYZ files", "*.xyz"), ("All files", "*")])
            for p in paths:
                p = os.path.abspath(p)
                if p not in self._guest_list:
                    self._guest_list.append(p)
            # also update legacy _vars["b"] to first guest for backward compat
            if self._guest_list:
                self._vars["b"].set(self._guest_list[0])
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _remove_selected_guests():
            sel = list(self._guest_lb.curselection())
            for idx in reversed(sel):
                self._guest_list.pop(idx)
            if self._guest_list:
                self._vars["b"].set(self._guest_list[0])
            else:
                self._vars["b"].set("")
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _clear_all_guests():
            self._guest_list.clear()
            self._vars["b"].set("")
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _move_up():
            sel = list(self._guest_lb.curselection())
            if not sel or sel[0] == 0:
                return
            for idx in sel:
                self._guest_list[idx-1], self._guest_list[idx] = self._guest_list[idx], self._guest_list[idx-1]
            _refresh_guest_lb()
            for idx in sel:
                self._guest_lb.selection_set(idx-1)

        def _move_down():
            sel = list(self._guest_lb.curselection())
            if not sel or sel[-1] == len(self._guest_list)-1:
                return
            for idx in reversed(sel):
                self._guest_list[idx], self._guest_list[idx+1] = self._guest_list[idx+1], self._guest_list[idx]
            _refresh_guest_lb()
            for idx in sel:
                self._guest_lb.selection_set(idx+1)

        for txt, cmd, col in [
            ("+ Add Guest(s)",  _add_guests,            _C["green"]),
            ("- Remove Sel.",   _remove_selected_guests, _C["red"]),
            ("Clear All",       _clear_all_guests,       _C["dim"]),
            ("▲ Up",            _move_up,                _C["accent"]),
            ("▼ Down",          _move_down,              _C["accent"]),
        ]:
            tk.Button(btn_row, text=txt, command=cmd, bg=col, fg=_C["text"],
                      font=("Segoe UI", 8, "bold"), relief="flat", cursor="hand2",
                      padx=8, pady=2).pack(side="left", padx=2)

        self._guest_count_lbl = tk.Label(btn_row,
            text="0 guest(s) queued", bg=_C["panel"], fg=_C["muted"],
            font=("Segoe UI", 8, "italic"))
        self._guest_count_lbl.pack(side="left", padx=12)

        # ── Adduct Presets & Role Controls ──────────────────────────────────────
        adduct_row = tk.Frame(gf, bg=_C["panel"])
        adduct_row.pack(fill="x", pady=(6, 2))
        tk.Label(adduct_row, text="Adduct Presets:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        def _set_ratio(r, tip=""):
            self._vars["ratio"].set(r)
            if tip:
                self._append_text(f"\n[Adduct Preset] Ratio set to: {r} ({tip})\n")

        for label, ratio, tip in [
            ("1:1 Binary",    "1:1",     "1 anchor + 1 guest"),
            ("1:2 Binary",    "1:1, 1:2","scan 1:1 and 1:2"),
            ("1:1:1 Ternary", "1:1:1",   "1 anchor + guest1 + guest2"),
            ("1:2:1 Ternary", "1:2:1",   "1 anchor + 2×guest1 + 1×guest2"),
            ("2:1:1 Quaternary", "2:1:1","2 anchors + guest1 + guest2"),
            ("Scan 1:0→1:5",  ",".join(f"1:{i}" for i in range(6)), "stoichiometry sweep"),
        ]:
            tk.Button(adduct_row, text=label,
                      command=lambda r=ratio, t=tip: _set_ratio(r, t),
                      bg=_C["panel"], fg=_C["accent"],
                      font=("Segoe UI", 8), relief="groove", padx=6).pack(side="left", padx=2)

        role_row = tk.Frame(gf, bg=_C["panel"])
        role_row.pack(fill="x", pady=(2, 4))
        tk.Label(role_row, text="Role Swap:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        def _swap_roles():
            """Swap anchor A ↔ first guest B so the guest becomes the anchor and vice versa."""
            a_path = self._vars["a"].get().strip(" \"'")
            b_path = self._vars["b"].get().strip(" \"'")
            if not a_path and not self._guest_list:
                return messagebox.showwarning("Role Swap", "No Anchor or Guest files set.")
            b_first = self._guest_list[0] if self._guest_list else b_path
            new_b = a_path
            self._vars["a"].set(b_first)
            self._vars["b"].set(new_b)
            if self._guest_list:
                self._guest_list[0] = new_b if new_b else self._guest_list[0]
                _refresh_guest_lb()
                self._update_guest_count_label()
            self._append_text(f"\n[Role Swap] Anchor ↔ Guest1 swapped.\n  New Anchor: {b_first}\n  New Guest1: {new_b}\n")

        def _add_as_extra_anchor():
            """Promote the first guest to an additional anchor by duplicating the anchor entry."""
            b_path = self._vars["b"].get().strip(" \"'")
            a_path = self._vars["a"].get().strip(" \"'")
            if not b_path and not self._guest_list:
                return messagebox.showwarning("Role", "No Guest file set.")
            guest = self._guest_list[0] if self._guest_list else b_path
            self._append_text(
                f"\n[Multi-Anchor] To model 2 anchors, set Ratio to '2:...' — "
                f"IAK will place {os.path.basename(a_path or 'anchor')} twice.\n"
                f"  Guest kept as: {os.path.basename(guest)}\n"
            )
            self._vars["ratio"].set("2:1")

        tk.Button(role_row, text="⇄ Swap A ↔ B1", command=_swap_roles,
                  bg=_C["yellow"], fg="black", font=("Segoe UI", 8, "bold"),
                  relief="groove", padx=8).pack(side="left", padx=4)
        tk.Button(role_row, text="+ Promote B→2nd Anchor", command=_add_as_extra_anchor,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 8, "bold"),
                  relief="groove", padx=8).pack(side="left", padx=4)
        tk.Label(role_row,
                 text="Tip: Use ratio 2:1 for 2 anchors, 1:1:1 for ternary adduct with 2 guests",
                 bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 7, "italic")).pack(side="left", padx=8)

        # ── Ratios / Output ──────────────────────────────────────────────────────
        for lbl, var in [("Reaction Type:", "reaction_type"), ("Ratios (e.g., 1:0, 1:1, 2:1):", "ratio"), ("Base Output Name:", "out")]:
            f = tk.Frame(wf, bg=_C["panel"])
            f.pack(fill="x", pady=2)
            tk.Label(f, text=lbl, bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
            if var == "reaction_type":
                cb = ttk.Combobox(f, textvariable=self._vars[var], values=REACTION_TYPE_CHOICES, state="readonly")
                cb.pack(side="left", fill="x", expand=True, padx=5)
            else:
                tk.Entry(f, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
            if var == "out":
                tk.Button(f, text="...", command=self._choose_output_base, bg=_C["accent"]).pack(side="left")

        mode_row = tk.Frame(wf, bg=_C["panel"])
        mode_row.pack(fill="x", pady=2)
        tk.Label(mode_row, text="Preset Mode:", bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
        mode_cb = ttk.Combobox(mode_row, textvariable=self._vars["mode"], values=["fast", "balanced", "thorough", "custom"], width=16, state="readonly")
        mode_cb.pack(side="left", padx=5)
        mode_cb.bind("<<ComboboxSelected>>", lambda _e: self._apply_mode_preset())
        tk.Label(mode_row, text="Custom values below always override the preset.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 8, "italic")).pack(side="left", padx=8)

        cf = tk.LabelFrame(left, text=" 2. CHEMISTRY SETTINGS ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        cf.pack(fill="x", pady=(0, 6))
        for lbl, var, width in [("System Charge:", "charge", 10), ("Multiplicity:", "mult", 10), ("xTB Flags:", "xtb_method", 18), ("CREST Flags:", "crest_method", 18), ("ORCA Method:", "orca_method", 40)]:
            row = tk.Frame(cf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=width, bd=0).pack(side="left", fill="x", expand=var in {"orca_method", "xtb_method", "crest_method"}, padx=5)

        exec_row = tk.Frame(cf, bg=_C["panel"])
        exec_row.pack(fill="x", pady=2)
        tk.Label(exec_row, text="Execution Env:", bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
        ttk.Combobox(exec_row, textvariable=self._vars["exec_env"], values=["Local (Subprocess)", "Docker Container", "SLURM Cluster"], state="readonly", width=18).pack(side="left", padx=5)
        tk.Label(exec_row, text="GOAT/MLIP Model:", bg=_C["panel"], fg=_C["text"], width=15, anchor="w").pack(side="left", padx=(10, 0))
        ttk.Combobox(exec_row, textvariable=self._vars["goat_model"], values=["uma-s-1", "mace", "fairchem", "sevenn", "orb"], state="readonly", width=10).pack(side="left", padx=5)

        tf = tk.LabelFrame(left, text=" 3. THERMODYNAMICS (Optional) ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        tf.pack(fill="x", pady=(0, 6))
        tk.Label(tf, text="Input isolated ORCA energies (Eh) for Binding Affinity.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 5))
        for lbl, var in [("Monomer A Energy:", "e_a"), ("Monomer B Energy:", "e_b")]:
            row = tk.Frame(tf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)

        hf = tk.LabelFrame(left, text=" 4. HARDWARE RESOURCES ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        hf.pack(fill="x", pady=(0, 6))
        for lbl, var, note in [("CPU Cores:", "cores", "(16, 32+ for large systems)"), ("RAM/Core (MB):", "maxcore", "(Total = Cores * RAM)")]:
            row = tk.Frame(hf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=10, bd=0).pack(side="left", padx=5)
            tk.Label(row, text=note, bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=10)

        af = tk.LabelFrame(left, text=" 5. HOST-CONTROLLED SAMPLING AND FILTERS ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        af.pack(fill="x", pady=(0, 6))
        host_rows = [
            [("Generate Seeds", "n_generate"), ("Score Keep", "n_keep_scored"), ("Cluster Keep", "n_keep_clustered")],
            [("Run xTB", "n_run_xtb"), ("Run CREST", "n_run_crest"), ("Random Seed", "random_seed")],
            [("RMSD Cutoff", "rmsd_cutoff"), ("xTB Window kcal", "xtb_ewin_kcal"), ("CREST Window kcal", "crest_ewin_kcal")],
            [("Placement Attempts", "max_placement_attempts")],
        ]
        for row_items in host_rows:
            row = tk.Frame(af, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            for lbl, var in row_items:
                tk.Label(row, text=f"{lbl}:", bg=_C["panel"], fg=_C["text"], width=17, anchor="w").pack(side="left", padx=(0, 2))
                tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=9, bd=0).pack(side="left", padx=(0, 10), ipady=2)

        sf = tk.LabelFrame(left, text=" 6. HOST-CONTROLLED REPORT CONTENT ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        sf.pack(fill="x", pady=(0, 6))
        report_items = [
            ("Inputs", "inputs"),
            ("Workflow", "workflow"),
            ("Engine Results", "engine_results"),
            ("Thermodynamics", "thermodynamics"),
            ("Images", "images"),
            ("Timeline", "timeline"),
            ("System Info", "system_info"),
            ("AI Prompt", "ai_prompt"),
        ]
        for label, key in report_items:
            tk.Checkbutton(sf, text=label, variable=self._report_vars[key], bg=_C["panel"], fg=_C["text"], selectcolor="black").pack(side="left", padx=4)

        rf = tk.Frame(left, bg=_C["panel"])
        rf.pack(fill="x", pady=15)
        self.run_preopt = tk.BooleanVar(value=True)
        self.run_xtb = tk.BooleanVar(value=True)
        self.run_crest = tk.BooleanVar(value=True)
        self.run_orca = tk.BooleanVar(value=True)
        for text, var, fg in [("Pre-Opt", self.run_preopt, _C["yellow"]), ("Run xTB", self.run_xtb, "white"), ("Run CREST", self.run_crest, "white"), ("Run ORCA DFT", self.run_orca, _C["accent"])]:
            tk.Checkbutton(rf, text=text, variable=var, bg=_C["panel"], fg=fg, selectcolor="black").pack(side="left", padx=5)
        btn_f = tk.Frame(left, bg=_C["panel"])
        btn_f.pack(fill="x", pady=5)
        tk.Button(btn_f, text="LOAD LOCAL ENGINE (.tar.xz / .zip)", command=self._load_local, bg="#d29922", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(2, 0))
        tk.Button(btn_f, text="ANALYZE FOLDER", command=self._analyze_existing_folder, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        tk.Button(btn_f, text="ANALYZE FILES (.out/.xyz)", command=self._analyze_existing_files, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        tk.Button(btn_f, text="RESUME STOPPED JOB", command=self._resume_existing_job, bg="#238636", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        self.go_btn = tk.Button(left, text="START BATCH PIPELINE", command=self._start, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 12, "bold"), pady=10)
        self.go_btn.pack(fill="x", pady=10)

        right = tk.LabelFrame(main, text=" LIVE PIPELINE TERMINAL ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"))
        self.term = tk.Text(right, bg="black", fg=_C["green"], font=("Consolas", 10), state="disabled")
        self.term.pack(fill="both", expand=True, padx=5, pady=5)
        main.add(left_wrapper, minsize=560, stretch="always")
        main.add(right, minsize=460, stretch="always")
        self._build_progress_monitor(parent)

    def _build_progress_monitor(self, parent):
        frame = tk.LabelFrame(parent, text=" HIGH-LEVEL JOB PROGRESS, PERCENT COMPLETE, AND ETA ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=10, pady=8)
        frame.pack(fill="x", padx=10, pady=(0, 10))
        top = tk.Frame(frame, bg=_C["panel"])
        top.pack(fill="x")
        self.iak_progress_stage_lbl = tk.Label(top, text="Waiting for job", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 10, "bold"), anchor="w")
        self.iak_progress_stage_lbl.pack(side="left", fill="x", expand=True)
        self.iak_progress_eta_lbl = tk.Label(top, text="ETA: --:--:--", bg=_C["panel"], fg=_C["muted"], font=("Consolas", 10, "bold"), width=18)
        self.iak_progress_eta_lbl.pack(side="right", padx=6)
        self.iak_progress_percent_lbl = tk.Label(top, text="0.0%", bg=_C["panel"], fg=_C["green"], font=("Consolas", 11, "bold"), width=8)
        self.iak_progress_percent_lbl.pack(side="right", padx=6)
        self.iak_progress_bar = ttk.Progressbar(frame, orient="horizontal", mode="determinate", maximum=100)
        self.iak_progress_bar.pack(fill="x", pady=(6, 8))
        cols = ("stage", "status", "percent", "eta")
        self.iak_progress_tree = ttk.Treeview(frame, columns=cols, show="headings", height=4)
        for col, text, width in [("stage", "Pipeline Stage", 220), ("status", "Status", 110), ("percent", "Complete", 90), ("eta", "ETA", 120)]:
            self.iak_progress_tree.heading(col, text=text)
            self.iak_progress_tree.column(col, width=width, anchor="center")
        self.iak_progress_tree.pack(fill="x")
        self._progress_items = {}
        self._reset_progress_ui()

    def _reset_progress_ui(self):
        if not hasattr(self, "iak_progress_tree"):
            return
        for row in self.iak_progress_tree.get_children():
            self.iak_progress_tree.delete(row)
        self._progress_items = {}
        for stage in ["Validation", "Sampling/filtering", "xTB", "CREST", "ORCA", "Reports"]:
            item = self.iak_progress_tree.insert("", "end", values=(stage, "Waiting", "0.0%", "--:--:--"))
            self._progress_items[stage] = item
        self.iak_progress_bar["value"] = 0
        self.iak_progress_stage_lbl.config(text="Waiting for job")
        self.iak_progress_percent_lbl.config(text="0.0%")
        self.iak_progress_eta_lbl.config(text="ETA: --:--:--")

    def _progress_cb(self, payload):
        self.root.after(0, lambda p=dict(payload): self._apply_progress_payload(p))

    def _normalize_stage(self, stage):
        text = (stage or "").lower()
        if "validation" in text:
            return "Validation"
        if "sample" in text or "filter" in text or "generat" in text:
            return "Sampling/filtering"
        if "xtb" in text:
            return "xTB"
        if "crest" in text:
            return "CREST"
        if "orca" in text:
            return "ORCA"
        if "report" in text or "complete" in text:
            return "Reports"
        return stage or "Pipeline"

    def _apply_progress_payload(self, payload):
        percent = max(0.0, min(100.0, float(payload.get("percent", 0.0))))
        elapsed = float(payload.get("elapsed_seconds", 0.0))
        eta = "complete"
        if 0.0 < percent < 100.0:
            eta = _fmt_duration(elapsed * (100.0 - percent) / percent)
        elif percent <= 0.0:
            eta = "estimating"
        stage = self._normalize_stage(payload.get("stage", "Pipeline"))
        status = payload.get("status", "running").title()
        message = payload.get("message") or stage
        job = payload.get("job", "")
        self.iak_progress_bar["value"] = percent
        self.iak_progress_percent_lbl.config(text=f"{percent:5.1f}%")
        self.iak_progress_eta_lbl.config(text=f"ETA: {eta}")
        self.iak_progress_stage_lbl.config(text=f"Ratio {job} | {stage}: {message}" if job else f"{stage}: {message}")
        item = self._progress_items.get(stage)
        if not item:
            item = self.iak_progress_tree.insert("", "end", values=(stage, "Waiting", "0.0%", "--:--:--"))
            self._progress_items[stage] = item
        self.iak_progress_tree.item(item, values=(stage, status, f"{percent:5.1f}%", eta))
        self.iak_progress_tree.see(item)

    def _get_report_options(self):
        return {key: bool(var.get()) for key, var in self._report_vars.items()}

    def _build_pes_tab(self, parent):
        left = tk.Frame(parent, bg=_C["bg"])
        left.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        right = tk.Frame(parent, bg=_C["panel"], width=600)
        right.pack(side="right", fill="both", expand=False, padx=10, pady=10)
        
        # --- Left Panel: Settings ---
        lbl_cfg = tk.LabelFrame(left, text=" 1. PES & TS CONFIGURATION ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        lbl_cfg.pack(fill="x", pady=5)
        
        # Scan Mode
        f_mode = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_mode.pack(fill="x", pady=4)
        tk.Label(f_mode, text="Scan Mode:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Radiobutton(f_mode, text="Coordinate Grid (1D/2D)", variable=self._vars_pes["scan_mode"], value="coord", bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left")
        tk.Radiobutton(f_mode, text="Reactant → Product Path", variable=self._vars_pes["scan_mode"], value="path", bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left")

        # Scan Type (distance / angle / dihedral)
        f_stype = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_stype.pack(fill="x", pady=4)
        tk.Label(f_stype, text="Scan Type:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        for val, lbl in [("distance", "Bond Distance"), ("angle", "Bond Angle"), ("dihedral", "Dihedral")]:
            tk.Radiobutton(f_stype, text=lbl, variable=self._vars_pes["scan_type"], value=val,
                           bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left", padx=4)

        # Angle / Dihedral extra-atom row (shown always; labelled clearly)
        f_extra = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_extra.pack(fill="x", pady=2)
        tk.Label(f_extra, text="Extra atoms (angle/dih):", bg=_C["panel"], fg=_C["muted"],
                 width=20, anchor="w", font=("Segoe UI", 8, "italic")).pack(side="left")
        tk.Label(f_extra, text="A3:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(4, 2))
        tk.Entry(f_extra, textvariable=self._vars_pes["ang_a3"], bg=_C["entry"],
                 fg=_C["text"], width=4).pack(side="left")
        tk.Label(f_extra, text="A4 (dih):", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(f_extra, textvariable=self._vars_pes["dih_a4"], bg=_C["entry"],
                 fg=_C["text"], width=4).pack(side="left")

        # Reactant XYZ
        f_react = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_react.pack(fill="x", pady=4)
        tk.Label(f_react, text="Reactant XYZ:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Entry(f_react, textvariable=self._vars_pes["reactant"], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
        tk.Button(f_react, text="...", command=lambda: self._vars_pes["reactant"].set(filedialog.askopenfilename()), bg=_C["accent"]).pack(side="left")
        
        # Product XYZ (For Path Mode)
        f_prod = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_prod.pack(fill="x", pady=4)
        tk.Label(f_prod, text="Product XYZ (Path Mode):", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Entry(f_prod, textvariable=self._vars_pes["product"], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
        tk.Button(f_prod, text="...", command=lambda: self._vars_pes["product"].set(filedialog.askopenfilename()), bg=_C["accent"]).pack(side="left")
        
        # Engine
        f_eng = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_eng.pack(fill="x", pady=4)
        tk.Label(f_eng, text="Engine:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        ttk.Combobox(f_eng, textvariable=self._vars_pes["engine"], values=["xtb", "orca", "goat"], state="readonly", width=10).pack(side="left", padx=5)
        
        # Coord 1
        lbl_c1 = tk.LabelFrame(left, text=" Coordinate 1 (Required) ", fg=_C["green"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=10, pady=5)
        lbl_c1.pack(fill="x", pady=5)
        f_c1_a = tk.Frame(lbl_c1, bg=_C["panel"])
        f_c1_a.pack(fill="x", pady=2)
        tk.Label(f_c1_a, text="Atom 1 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_a, textvariable=self._vars_pes["c1_a1"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_a, text="Atom 2 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_a, textvariable=self._vars_pes["c1_a2"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        f_c1_d = tk.Frame(lbl_c1, bg=_C["panel"])
        f_c1_d.pack(fill="x", pady=2)
        tk.Label(f_c1_d, text="Start Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_start"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_d, text="End Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_end"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_d, text="Steps:", bg=_C["panel"], fg=_C["text"], width=10).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_steps"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        # Coord 2
        lbl_c2 = tk.LabelFrame(left, text=" Coordinate 2 (For 3D Plot) ", fg=_C["yellow"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=10, pady=5)
        lbl_c2.pack(fill="x", pady=5)
        tk.Checkbutton(lbl_c2, text="Enable 2D Grid Scan", variable=self._vars_pes["use_c2"], bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)
        f_c2_a = tk.Frame(lbl_c2, bg=_C["panel"])
        f_c2_a.pack(fill="x", pady=2)
        tk.Label(f_c2_a, text="Atom 1 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_a, textvariable=self._vars_pes["c2_a1"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_a, text="Atom 2 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_a, textvariable=self._vars_pes["c2_a2"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        f_c2_d = tk.Frame(lbl_c2, bg=_C["panel"])
        f_c2_d.pack(fill="x", pady=2)
        tk.Label(f_c2_d, text="Start Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_start"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_d, text="End Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_end"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_d, text="Steps:", bg=_C["panel"], fg=_C["text"], width=10).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_steps"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        # TS Options
        lbl_ts = tk.LabelFrame(left, text=" 2. TRANSITION STATE REFINEMENT ", fg=_C["red"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        lbl_ts.pack(fill="x", pady=5)
        tk.Checkbutton(lbl_ts, text="Find Saddle Point & Run TS Optimization (OptTS + Freq)", variable=self._vars_pes["run_ts"], bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)
        tk.Checkbutton(lbl_ts, text="Predict TS via spline saddle-point detection (after scan)", variable=self._vars_pes["predict_ts_spline"], bg=_C["panel"], fg=_C["yellow"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)

        # Convenience buttons for extended scan types
        ext_row = tk.Frame(left, bg=_C["bg"])
        ext_row.pack(fill="x", pady=4)
        tk.Button(ext_row, text=" ▶ Run Angle Scan ", command=self._start_angle_scan,
                  bg="#17a2b8", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" ▶ Run Dihedral Scan ", command=self._start_dihedral_scan,
                  bg="#6f42c1", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" ▶ ORCA 2D PES ", command=self._start_orca_2d_pes,
                  bg="#e05252", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" Barrier Analysis… ", command=self._open_barrier_analysis_dialog,
                  bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 10), padx=10, pady=4).pack(side="left", padx=4)
        
        # Run Button
        self.btn_run_pes = tk.Button(left, text="START PES & TS SEARCH", command=self._start_pes, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 14, "bold"), pady=10)
        self.btn_run_pes.pack(fill="x", pady=15)
        
        # --- Right Panel: Terminal ---
        tk.Label(right, text=" PES/TS TERMINAL LOG ", bg=_C["panel"], fg=_C["text"], font=("Consolas", 10, "bold")).pack(pady=5)
        self.pes_term = tk.Text(right, bg=_C["entry"], fg="#00ff00", font=("Consolas", 9), state="disabled", wrap="word")
        self.pes_term.pack(fill="both", expand=True, padx=5, pady=5)

    def _build_results_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        tk.Button(top, text=" REFRESH ", command=self._refresh_results, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" ANALYZE FOLDER ", command=self._analyze_existing_folder, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" ANALYZE FILES (.out/.xyz) ", command=self._analyze_existing_files, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" AVOGADRO ", command=self._open_in_avogadro, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" EXPORT ", command=self._export_file, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Label(top, text="Double-click XYZ for interactive model viewer; hover for quick preview.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 10, "italic")).pack(side="right", padx=20)
        container = tk.Frame(parent, bg=_C["bg"])
        container.pack(fill="both", expand=True, padx=10, pady=10)
        for i in range(6):
            container.columnconfigure(i, weight=1)
        container.rowconfigure(0, weight=1)
        self.listboxes = []
        self.folders = ["01_Inputs_and_Clusters", "02_xTB_Results", "03_CREST_Results", "04_ORCA_Refinement", "05_Top_Models_Comparison", "06_File_Analysis_Images"]

        def make_listbox(col, title, fg_color=_C["green"]):
            f = tk.LabelFrame(container, text=title, bg=_C["panel"], fg=_C["accent"], font=("Segoe UI", 9, "bold"))
            f.grid(row=0, column=col, sticky="nsew", padx=2, pady=5)
            lb = tk.Listbox(f, bg=_C["entry"], fg=fg_color, font=("Consolas", 9), selectbackground=_C["accent"], exportselection=False)
            lb.pack(side="left", fill="both", expand=True, padx=2, pady=5)
            sb = ttk.Scrollbar(f, orient="vertical", command=lb.yview)
            sb.pack(side="right", fill="y")
            lb.config(yscrollcommand=sb.set)
            lb.bind("<Double-Button-1>", lambda e, l=lb, c=col: self._open_file(l, c))
            lb.bind("<Motion>", lambda e, l=lb, c=col: self._on_hover(e, l, c))
            lb.bind("<Leave>", lambda e: self._hide_preview())
            self.listboxes.append(lb)

        make_listbox(0, " 1. Clusters ")
        make_listbox(1, " 2. xTB Opt ")
        make_listbox(2, " 3. CREST ")
        make_listbox(3, " 4. ORCA DFT ")
        make_listbox(4, " 5. TOP 3 COMPARE ", fg_color=_C["yellow"])
        make_listbox(5, " 6. 3D IMAGES ", fg_color=_C["accent"])

    def _build_graph_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        r1 = tk.Frame(top, bg=_C["panel"])
        r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Series 1 Dir:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=12, anchor="w").pack(side="left", padx=(10, 0))
        tk.Entry(r1, textvariable=self._vars_graph["dir1"], bg=_C["entry"], fg=_C["text"], width=25, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Button(r1, text="...", command=lambda: self._vars_graph["dir1"].set(filedialog.askdirectory()), bg=_C["accent"], fg=_C["text"], bd=0, padx=5).pack(side="left")
        tk.Label(r1, text="Legend 1:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        tk.Entry(r1, textvariable=self._vars_graph["name1"], bg=_C["entry"], fg=_C["text"], width=15, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Label(r1, text="Series 2 Dir:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=12, anchor="w").pack(side="left", padx=(25, 0))
        tk.Entry(r1, textvariable=self._vars_graph["dir2"], bg=_C["entry"], fg=_C["text"], width=25, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Button(r1, text="...", command=lambda: self._vars_graph["dir2"].set(filedialog.askdirectory()), bg=_C["accent"], fg=_C["text"], bd=0, padx=5).pack(side="left")
        tk.Label(r1, text="Legend 2:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        tk.Entry(r1, textvariable=self._vars_graph["name2"], bg=_C["entry"], fg=_C["text"], width=15, bd=0).pack(side="left", padx=5, ipady=3)

        r2 = tk.Frame(top, bg=_C["panel"])
        r2.pack(fill="x", pady=(10, 2))
        tk.Label(r2, text="Custom X-Axis Labels:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=18, anchor="w").pack(side="left", padx=(10, 0))
        tk.Entry(r2, textvariable=self._vars_graph["x_labels"], bg=_C["entry"], fg=_C["text"], width=30, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Checkbutton(r2, text="Add Blank Space for 3D Models", variable=self._vars_graph["top_space"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black", font=("Segoe UI", 9, "bold")).pack(side="left", padx=10)

        r4 = tk.Frame(top, bg=_C["panel"])
        r4.pack(fill="x", pady=(10, 2))
        tk.Label(r4, text="Connection Line:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["conn_style"], values=["Smooth (Bezier)", "Straight", "Wavy", "Zigzag", "Curled (Arc)"], width=15, state="readonly").pack(side="left", padx=5)
        tk.Label(r4, text="Delta Arrow Style:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["delta_arrow"], values=["Straight", "Wavy", "Zigzag", "Curled (Arc)", "No Arrow"], width=12, state="readonly").pack(side="left", padx=5)
        tk.Label(r4, text="Label Box:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["label_box"], values=["Rounded Box", "Square Box", "No Box"], width=12, state="readonly").pack(side="left", padx=5)

        r3 = tk.Frame(top, bg=_C["panel"])
        r3.pack(fill="x", pady=(15, 2))
        tk.Label(r3, text="Energy Source:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(r3, textvariable=self._vars_graph["method"], values=["ORCA", "CREST", "xTB"], width=10, state="readonly").pack(side="left", padx=5)
        tk.Label(r3, text="Metric:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r3, textvariable=self._vars_graph["metric"], values=["Total Energy (ΔE)", "Gibbs Free Energy (ΔG)"], width=20, state="readonly").pack(side="left", padx=5)
        tk.Button(r3, text=" Plot Publication Energy Profile ", command=self._plot_reaction_profile, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=15).pack(side="left", padx=(20, 10))
        tk.Button(r3, text=" Plot CREST vs ORCA Method Acc. ", command=self._plot_methods, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=15).pack(side="left", padx=10)
        tk.Button(r3, text=" Plot All Optimized ", command=self._plot_all_optimized, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Button(r3, text=" Plot Top Conformers ", command=self._plot_top_conformers, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Label(r3, text="Top N:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(8, 2))
        tk.Entry(r3, textvariable=self._vars_graph["conformer_top_n"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Button(r3, text=" Stacked xTB/CREST/ORCA ", command=self._plot_stacked_energy, bg="#c0392b", fg="white", font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Button(r3, text=" Copy to Clipboard ", command=lambda: self._copy_to_clipboard(self.fig), bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="right", padx=20)
        tk.Button(r3, text=" Download High-Res Graph ", command=self._export_high_res_graph, bg=_C["yellow"], fg="black", font=("Segoe UI", 10, "bold"), padx=15).pack(side="right", padx=10)
        self._build_visual_controls(top)

        self.fig = Figure(figsize=(12, 7), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax2 = None
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        self.graph_toolbar = NavigationToolbar2Tk(self.canvas, parent, pack_toolbar=False)
        self.graph_toolbar.update()
        self.graph_toolbar.pack(fill="x", padx=10, pady=(0, 6))

    def _build_visual_controls(self, top):
        row = tk.Frame(top, bg=_C["panel"])
        row.pack(fill="x", pady=(8, 2))
        tk.Label(row, text="JACS visual colors:", bg=_C["panel"], fg=_C["yellow"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 6))
        for label, key in [("Series 1", "series1_color"), ("Series 2", "series2_color"), ("ORCA", "orca_color"), ("CREST", "crest_color"), ("BG", "graph_bg"), ("Axis", "axis_color"), ("Grid", "grid_color")]:
            self._color_button(row, label, key)
        row2 = tk.Frame(top, bg=_C["panel"])
        row2.pack(fill="x", pady=(4, 2))
        tk.Label(row2, text="Model:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(row2, textvariable=self._vars_graph["model_style"], values=["Ball-and-stick", "CPK", "Wireframe", "Licorice"], width=14, state="readonly").pack(side="left", padx=3)
        for label, key in [("C", "atom_C"), ("H", "atom_H"), ("N", "atom_N"), ("O", "atom_O"), ("F", "atom_F"), ("S", "atom_S"), ("Bond", "bond_color"), ("Model BG", "model_bg")]:
            self._color_button(row2, label, key, width=5)
        row3 = tk.Frame(top, bg=_C["panel"])
        row3.pack(fill="x", pady=(4, 2))
        tk.Label(row3, text="3D bonds:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(
            row3,
            textvariable=self._vars_graph["bond_mode"],
            values=["Covalent radii", "Distance cutoff", "Hydrogen bonds", "All close contacts"],
            width=16,
            state="readonly",
        ).pack(side="left", padx=4)
        tk.Label(row3, text="Cutoff A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(row3, textvariable=self._vars_graph["bond_cutoff"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Label(row3, text="Tol A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(row3, textvariable=self._vars_graph["bond_tolerance"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Checkbutton(row3, text="Distances", variable=self._vars_graph["show_bond_distances"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=8)
        tk.Checkbutton(row3, text="Atom labels", variable=self._vars_graph["show_atom_labels"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        tk.Checkbutton(row3, text="Axes", variable=self._vars_graph["show_3d_axes"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        for label, key in [("Elev", "model_elev"), ("Azim", "model_azim"), ("DPI", "image_dpi")]:
            tk.Label(row3, text=f"{label}:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
            tk.Entry(row3, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        row4 = tk.Frame(top, bg=_C["panel"])
        row4.pack(fill="x", pady=(4, 2))
        tk.Label(row4, text="Crop axes:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        for label, key in [("X min", "crop_xmin"), ("X max", "crop_xmax"), ("Y min", "crop_ymin"), ("Y max", "crop_ymax")]:
            tk.Label(row4, text=label, bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(5, 2))
            tk.Entry(row4, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=7, bd=0).pack(side="left", ipady=2)
        tk.Button(row4, text="Apply Crop", command=self._apply_graph_crop, bg=_C["accent"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)
        tk.Button(row4, text="Reset View", command=self._reset_graph_view, bg=_C["dim"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=4)
        tk.Button(row4, text="Pan", command=lambda: self.graph_toolbar.pan(), bg=_C["panel"], fg=_C["text"], relief="groove").pack(side="left", padx=4)
        tk.Button(row4, text="Zoom", command=lambda: self.graph_toolbar.zoom(), bg=_C["panel"], fg=_C["text"], relief="groove").pack(side="left", padx=4)

    def _color_button(self, parent, label, key, width=8):
        frame = tk.Frame(parent, bg=_C["panel"])
        frame.pack(side="left", padx=3)
        tk.Label(frame, text=label, bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 2))
        btn = tk.Button(frame, text="", width=width, bg=self._vars_graph[key].get(), relief="flat", command=lambda k=key: self._pick_color(k))
        btn.pack(side="left")
        self._color_buttons[key] = btn

    def _pick_color(self, key):
        picked = colorchooser.askcolor(color=self._vars_graph[key].get(), parent=self.root)[1]
        if picked:
            self._vars_graph[key].set(picked)
            if key in self._color_buttons:
                self._color_buttons[key].config(bg=picked)
            if hasattr(self, "canvas"):
                self._apply_custom_visual_theme()
                self.canvas.draw_idle()

    def _build_table_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        tk.Button(top, text=" Refresh from Graph Dirs ", command=self._refresh_thermo_table, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" Export CSV ", command=self._export_thermo_csv, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Label(top, text="Scans the Series 1 & 2 directories from the Graph tab to tabulate all energies.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 10, "italic")).pack(side="left", padx=20)
        cols = ("Series", "Ratio", "Method", "Electronic (Eh)", "Gibbs (Eh)", "Rel. Energy (kcal/mol)")
        style = ttk.Style()
        style.configure("Custom.Treeview", font=("Consolas", 10), rowheight=25)
        style.configure("Custom.Treeview.Heading", font=("Segoe UI", 10, "bold"))
        self.thermo_tree = ttk.Treeview(parent, columns=cols, show="headings", style="Custom.Treeview")
        for col in cols:
            self.thermo_tree.heading(col, text=col)
            self.thermo_tree.column(col, width=150, anchor="center")
        scroll = ttk.Scrollbar(parent, orient="vertical", command=self.thermo_tree.yview)
        self.thermo_tree.configure(yscrollcommand=scroll.set)
        self.thermo_tree.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scroll.pack(side="right", fill="y", pady=10)

    def _extract_all_thermo(self, base_dir, method_col):
        data = []
        if not base_dir or not os.path.isdir(base_dir):
            return []
        for root, dirs, files in os.walk(base_dir):
            if "Energy_Comparison.csv" in files:
                csv_path = os.path.join(root, "Energy_Comparison.csv")
                parent_folder = os.path.basename(os.path.dirname(root))
                match = re.search(r"(\d+)[_:]+(\d+)", parent_folder)
                if match:
                    ratio_str = f"{match.group(1)}:{match.group(2)}"
                    sort_key = int(match.group(1)) + int(match.group(2))
                else:
                    ratio_str = parent_folder
                    sort_key = 999
                try:
                    with open(csv_path, "r", encoding="utf-8") as f:
                        for line in f.readlines()[1:]:
                            parts = line.strip().split(",")
                            if len(parts) >= 4 and parts[0] == method_col:
                                data.append({"ratio": ratio_str, "ele": parts[2].strip(), "gibbs": parts[3].strip(), "sort": sort_key})
                except Exception as e:
                    print(f"Error parsing {csv_path}: {e}")
        data.sort(key=lambda x: x["sort"])
        return data

    def _refresh_thermo_table(self):
        for row in self.thermo_tree.get_children():
            self.thermo_tree.delete(row)
        for d, name in [(self._vars_graph["dir1"].get(), self._vars_graph["name1"].get().strip() or "Series 1"), (self._vars_graph["dir2"].get(), self._vars_graph["name2"].get().strip() or "Series 2")]:
            if not d:
                continue
            data = self._extract_all_thermo(d, self._vars_graph["method"].get())
            if not data:
                continue
            base_e, is_gibbs = None, False
            for item in data:
                if item["gibbs"] not in ("N/A", "0.000000"):
                    base_e = float(item["gibbs"])
                    is_gibbs = True
                    break
                if item["ele"] not in ("N/A", "0.000000"):
                    base_e = float(item["ele"])
                    break
            for item in data:
                rel_e = "N/A"
                if base_e is not None:
                    val = float(item["gibbs"]) if is_gibbs and item["gibbs"] != "N/A" else float(item["ele"])
                    rel_e = f"{(val - base_e) * EH2KCAL:.2f}"
                self.thermo_tree.insert("", "end", values=(name, item["ratio"], self._vars_graph["method"].get(), item["ele"], item["gibbs"], rel_e))

    def _export_thermo_csv(self):
        dest = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], title="Export Thermodynamic Data")
        if dest:
            with open(dest, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Series", "Ratio", "Method", "Electronic (Eh)", "Gibbs (Eh)", "Rel. Energy (kcal/mol)"])
                for row_id in self.thermo_tree.get_children():
                    writer.writerow(self.thermo_tree.item(row_id)["values"])
            messagebox.showinfo("Success", f"Data exported to {dest}")

    def _extract_dir_energies(self, base_dir, method_col, metric_type):
        data = {}
        if not base_dir or not os.path.isdir(base_dir):
            return []
        col_idx = 3 if "Gibbs" in metric_type else 2
        for root, dirs, files in os.walk(base_dir):
            if "Energy_Comparison.csv" in files:
                csv_path = os.path.join(root, "Energy_Comparison.csv")
                parent_folder = os.path.basename(os.path.dirname(root))
                match = re.search(r"(\d+)[_:]+(\d+)", parent_folder)
                if match:
                    ratio_str = f"{match.group(1)}:{match.group(2)}"
                    sort_key = int(match.group(1)) + int(match.group(2))
                else:
                    ratio_str = parent_folder
                    sort_key = 999
                try:
                    with open(csv_path, "r", encoding="utf-8") as f:
                        for line in f.readlines()[1:]:
                            parts = line.strip().split(",")
                            if len(parts) > col_idx and parts[0] == method_col:
                                val_str = parts[col_idx].strip()
                                if val_str not in ("N/A", "0.000000"):
                                    data[ratio_str] = {"energy": float(val_str), "sort": sort_key}
                except Exception as e:
                    print(f"Error parsing {csv_path}: {e}")
        return [(k, v["energy"]) for k, v in sorted(data.items(), key=lambda x: x[1]["sort"])]

    def _apply_thesis_theme(self):
        self.ax.clear()
        if self.ax2 is not None:
            self.ax2.remove()
            self.ax2 = None
        bg = self._vars_graph["graph_bg"].get()
        axis_c = self._vars_graph["axis_color"].get()
        self.ax.set_facecolor(bg)
        self.fig.patch.set_facecolor(bg)
        self.ax.tick_params(colors=axis_c, labelsize=11)
        self.ax.xaxis.label.set_color(axis_c)
        self.ax.yaxis.label.set_color(axis_c)
        self.ax.title.set_color(axis_c)
        for spine in self.ax.spines.values():
            spine.set_edgecolor(axis_c)
            spine.set_linewidth(1.5)

    def _make_bbox(self, style, edge_c="#333", alpha=0.85, lw=0.7):
        if style == "No Box":
            return None
        bs = "round,pad=0.25" if style == "Rounded Box" else "square,pad=0.25"
        return dict(boxstyle=bs, facecolor=self._vars_graph["graph_bg"].get(), edgecolor=edge_c, alpha=alpha, linewidth=lw)

    def _plot_reaction_profile(self):
        dir1, dir2 = self._vars_graph["dir1"].get(), self._vars_graph["dir2"].get()
        name1 = self._vars_graph["name1"].get().strip() or "Series 1"
        name2 = self._vars_graph["name2"].get().strip() or "Series 2"
        method = self._vars_graph["method"].get()
        metric = self._vars_graph["metric"].get()
        custom_x = [l.strip() for l in self._vars_graph["x_labels"].get().split(",") if l.strip()]
        conn_style = self._vars_graph["conn_style"].get()
        arrow_style = self._vars_graph["delta_arrow"].get()
        lbl_box_style = self._vars_graph["label_box"].get()
        if method in ["CREST", "xTB"] and "Gibbs" in metric:
            messagebox.showwarning("Metric Auto-Corrected", f"{method} does not compute Gibbs Free Energy. Switching to Total Electronic Energy.")
            self._vars_graph["metric"].set("Total Energy (ΔE)")
            metric = "Total Energy (ΔE)"
        self._apply_thesis_theme()
        data1 = self._extract_dir_energies(dir1, method, metric) if dir1 else []
        data2 = self._extract_dir_energies(dir2, method, metric) if dir2 else []
        if not data1 and not data2:
            messagebox.showerror("Error", "No valid data found.")
            return
        all_labels = []
        for d in [data1, data2]:
            for lbl, _ in d:
                if lbl not in all_labels:
                    all_labels.append(lbl)

        def sort_ratio(lbl):
            try:
                a, b = map(int, lbl.replace("_", ":").split(":"))
                return a + b
            except Exception:
                return 999

        all_labels.sort(key=sort_ratio)
        final_labels = custom_x if custom_x and len(custom_x) >= len(all_labels) else all_labels
        label_to_x = {lbl: i for i, lbl in enumerate(all_labels)}
        all_energies = []
        for d in [data1, data2]:
            if d:
                base_e = d[0][1]
                all_energies.extend([(e - base_e) * EH2KCAL for _, e in d])
        y_span = max(all_energies) - min(all_energies) if all_energies else 1.0
        if y_span == 0:
            y_span = 1.0
        y_pad = y_span * 0.05

        def plot_series(data, color, label, is_series_one):
            if not data:
                return
            base_e = data[0][1]
            rel_energies = [(e - base_e) * EH2KCAL for _, e in data]
            x_positions = [label_to_x[lbl] for lbl, _ in data]
            for i in range(len(data)):
                x_pos, y_val = x_positions[i], rel_energies[i]
                self.ax.hlines(y_val, x_pos - 0.35, x_pos + 0.35, color=color, lw=5, label=label if i == 0 else "")
                val_pad = y_pad if is_series_one else -y_pad
                va_align = "bottom" if is_series_one else "top"
                txt_kw = dict(ha="center", va=va_align, color=color, fontweight="bold", fontsize=11, zorder=9)
                bbox = self._make_bbox(lbl_box_style, edge_c=color, lw=1.5)
                if bbox:
                    txt_kw["bbox"] = bbox
                t = self.ax.text(x_pos, y_val + val_pad, f"{y_val:.1f}", **txt_kw)
                try:
                    t.set_draggable(True)
                except Exception:
                    pass
                if i > 0:
                    prev_x, prev_y = x_positions[i - 1], rel_energies[i - 1]
                    start_x, start_y = prev_x + 0.35, prev_y
                    end_x, end_y = x_pos - 0.35, y_val
                    kw_line = dict(color=color, alpha=0.60, lw=2.5, zorder=3)
                    if conn_style == "Straight":
                        self.ax.plot([start_x, end_x], [start_y, end_y], **kw_line)
                    elif conn_style in ("Smooth (Bezier)", "Smooth"):
                        xs = np.linspace(start_x, end_x, 60)
                        ts = (xs - start_x) / max(end_x - start_x, 1e-9)
                        self.ax.plot(xs, start_y + (end_y - start_y) * (3 * ts**2 - 2 * ts**3), **kw_line)
                    elif conn_style == "Wavy":
                        _draw_wavy(self.ax, start_x, start_y, end_x, end_y, n_waves=6, amp_frac=0.04, **kw_line)
                    elif conn_style == "Zigzag":
                        _draw_zigzag(self.ax, start_x, start_y, end_x, end_y, n_zigs=8, amp_frac=0.04, **kw_line)
                    elif conn_style == "Curled (Arc)":
                        _draw_curled(self.ax, start_x, start_y, end_x, end_y, rad=0.30, **kw_line)
                    delta = y_val - prev_y
                    mid_x, mid_y = (start_x + end_x) / 2, (start_y + end_y) / 2
                    if arrow_style != "No Arrow":
                        _draw_fancy_arrow(self.ax, mid_x, mid_y + (y_pad if is_series_one else -y_pad) * 0.8, mid_x, mid_y, style=arrow_style, color=color, lw=1.5, alpha=0.8, zorder=11)
                    d_kw = dict(ha="center", va="center", color=color, fontsize=10, fontweight="bold", zorder=12)
                    d_bbox = self._make_bbox(lbl_box_style, edge_c=color, alpha=0.95, lw=1.5)
                    if d_bbox:
                        d_kw["bbox"] = d_bbox
                    t_del = self.ax.text(mid_x, mid_y + (y_pad if is_series_one else -y_pad) * 0.8, f"$\\Delta$={delta:.1f}", **d_kw)
                    try:
                        t_del.set_draggable(True)
                    except Exception:
                        pass

        plot_series(data1, self._vars_graph["series1_color"].get(), name1, True)
        plot_series(data2, self._vars_graph["series2_color"].get(), name2, False)
        self.ax.set_xticks(range(len(all_labels)))
        self.ax.set_xticklabels(final_labels[: len(all_labels)], fontweight="bold", fontsize=12)
        self.ax.set_xlim(left=-0.75, right=len(all_labels) - 0.25)
        if self._vars_graph["top_space"].get():
            y_min, y_max = self.ax.get_ylim()
            self.ax.set_ylim(y_min - y_span * 0.1, y_max + y_span * 0.5)
        self.ax2 = self.ax.twinx()
        y1_min, y1_max = self.ax.get_ylim()
        self.ax2.set_ylim(y1_min * KCAL2KJ, y1_max * KCAL2KJ)
        self.ax2.set_ylabel("Relative Energy (kJ/mol)", fontweight="bold", fontsize=14, color=self._vars_graph["axis_color"].get())
        self.ax2.tick_params(colors=self._vars_graph["axis_color"].get(), labelsize=11)
        self.ax2.spines["right"].set_linewidth(1.5)
        symb = "ΔG" if "Gibbs" in metric else "ΔE"
        self.ax.set_ylabel(f"Relative Energy {symb} (kcal/mol)", fontweight="bold", fontsize=14)
        self.ax.set_title(f"Reaction Energy Profile Diagram ({symb})", fontweight="bold", fontsize=18, pad=20)
        self.ax.grid(axis="y", linestyle="-", alpha=0.25, color=self._vars_graph["grid_color"].get())
        self.ax.legend(loc="lower left" if self._vars_graph["top_space"].get() else "best", framealpha=0.95, fontsize=12, edgecolor=self._vars_graph["axis_color"].get())
        watermark = f"Level of Theory: {method}"
        if method == "ORCA":
            watermark += f" ({self._vars['orca_method'].get()})"
        self.ax.text(0.99, 0.02, watermark, ha="right", va="bottom", color=self._vars_graph["watermark_color"].get(), fontsize=10, transform=self.ax.transAxes, style="italic")
        self.fig.tight_layout()
        self.canvas.draw()

    def _plot_methods(self):
        dir1 = self._vars_graph["dir1"].get()
        name1 = self._vars_graph["name1"].get().strip() or "Series"
        metric = self._vars_graph["metric"].get()
        custom_x = [l.strip() for l in self._vars_graph["x_labels"].get().split(",") if l.strip()]
        if "Gibbs" in metric:
            messagebox.showwarning("Metric Auto-Corrected", "CREST vs ORCA comparison uses Total Energy.")
            self._vars_graph["metric"].set("Total Energy (ΔE)")
            metric = "Total Energy (ΔE)"
        if not dir1:
            messagebox.showerror("Error", "Please specify Series 1 Directory.")
            return
        crest_data = self._extract_dir_energies(dir1, "CREST", metric)
        orca_data = self._extract_dir_energies(dir1, "ORCA", metric)
        self._apply_thesis_theme()
        plotted_any = False
        all_labels = []
        if crest_data:
            plotted_any = True
            all_labels = [l for l, _ in crest_data]
            x_c = np.arange(len(all_labels))
            base_c = crest_data[0][1]
            y_c = [(e - base_c) * EH2KCAL for _, e in crest_data]
            self.ax.plot(x_c, y_c, marker="o", markersize=10, linestyle="--", linewidth=2.5, color=self._vars_graph["crest_color"].get(), label="CREST Trend")
        if orca_data:
            plotted_any = True
            all_labels = [l for l, _ in orca_data]
            x_o = np.arange(len(all_labels))
            base_o = orca_data[0][1]
            y_o = [(e - base_o) * EH2KCAL for _, e in orca_data]
            self.ax.plot(x_o, y_o, marker="s", markersize=10, linestyle="-", linewidth=3.5, color=self._vars_graph["orca_color"].get(), label="ORCA DFT Trend")
        if not plotted_any:
            messagebox.showerror("Error", "No valid data found.")
            return
        final_labels = custom_x if custom_x and len(custom_x) >= len(all_labels) else all_labels
        self.ax.set_xticks(np.arange(len(all_labels)))
        self.ax.set_xticklabels(final_labels[: len(all_labels)], fontweight="bold", fontsize=12)
        if self._vars_graph["top_space"].get():
            y_min, y_max = self.ax.get_ylim()
            self.ax.set_ylim(y_min, y_max + ((y_max - y_min) * 0.5))
        self.ax.set_ylabel("Relative Energy ΔE (kcal/mol)", fontsize=14, fontweight="bold", color=self._vars_graph["axis_color"].get())
        self.ax.set_title(f"Method Accuracy Comparison: {name1}", fontsize=18, fontweight="bold", color=self._vars_graph["axis_color"].get(), pad=20)
        self.ax.legend(loc="best", framealpha=0.95, fontsize=12, edgecolor=self._vars_graph["axis_color"].get())
        self.ax.grid(True, alpha=0.3, color=self._vars_graph["grid_color"].get(), linestyle="-")
        self.ax.text(0.99, 0.02, f"Level of Theory (DFT): {self._vars['orca_method'].get()}", ha="right", va="bottom", color=self._vars_graph["watermark_color"].get(), fontsize=10, transform=self.ax.transAxes, style="italic")
        self.fig.tight_layout()
        self.canvas.draw()

    def _collect_plot_records(self, base_dir, method_filter="ALL", metric="Total Energy (ΔE)", top_n=0):
        if not base_dir or not os.path.isdir(base_dir):
            return []
        job_dirs = self._find_iak_job_dirs(base_dir)
        if not job_dirs:
            job_dirs = [base_dir]
        records = []
        method_filter = method_filter.upper()
        for job_dir in job_dirs:
            job_label = os.path.basename(job_dir.rstrip("\\/")) or "job"
            job_records = self._collect_existing_job_records(job_dir)
            for method, method_records in job_records.items():
                if method_filter != "ALL" and method.upper() != method_filter:
                    continue
                for rec in method_records:
                    energy = rec.get("gibbs") if ("Gibbs" in metric and method == "ORCA" and rec.get("gibbs")) else rec.get("energy")
                    if energy is None:
                        continue
                    records.append({
                        "method": method,
                        "job": job_label,
                        "source": rec.get("source", ""),
                        "energy": float(energy),
                        "label": f"{job_label}:{rec.get('source','')}",
                    })
            if method_filter in ("ALL", "CREST"):
                crest_dir = os.path.join(job_dir, "03_CREST_Results")
                if os.path.isdir(crest_dir):
                    for conf_path in Path(crest_dir).glob("crest_conformers_*.xyz"):
                        for idx, mol in enumerate(read_multi_xyz(str(conf_path))):
                            if mol.energy_eh:
                                records.append({
                                    "method": "CREST",
                                    "job": job_label,
                                    "source": f"{conf_path.stem}_conf_{idx}",
                                    "energy": float(mol.energy_eh),
                                    "label": f"{job_label}:{conf_path.stem}_{idx}",
                                })
        if top_n and top_n > 0:
            limited = []
            for method in ["xTB", "CREST", "ORCA"]:
                group = [r for r in records if r["method"] == method]
                group.sort(key=lambda item: item["energy"])
                limited.extend(group[:top_n])
            records = limited
        return records

    def _plot_records_by_method(self, records, title):
        if not records:
            messagebox.showerror("No Data", "No optimized/conformer energy records were found for plotting.")
            return
        self._apply_thesis_theme()
        colors = {"xTB": self._vars_graph["series1_color"].get(), "CREST": self._vars_graph["crest_color"].get(), "ORCA": self._vars_graph["orca_color"].get()}
        x_labels = []
        x_pos = 0
        for method in ["xTB", "CREST", "ORCA"]:
            group = [r for r in records if r["method"] == method]
            if not group:
                continue
            group.sort(key=lambda item: item["energy"])
            base = group[0]["energy"]
            xs, ys = [], []
            for rec in group:
                xs.append(x_pos)
                ys.append((rec["energy"] - base) * EH2KCAL)
                x_labels.append(rec["label"])
                x_pos += 1
            self.ax.plot(xs, ys, marker="o", linewidth=2.2, markersize=7, color=colors.get(method, "#333333"), label=f"{method} relative")
        self.ax.set_xticks(range(len(x_labels)))
        self.ax.set_xticklabels(x_labels, rotation=60, ha="right", fontsize=8)
        self.ax.set_ylabel("Relative Energy (kcal/mol)", fontweight="bold", fontsize=13)
        self.ax.set_title(title, fontweight="bold", fontsize=16, pad=16)
        self.ax.grid(axis="y", linestyle="-", alpha=0.25, color=self._vars_graph["grid_color"].get())
        self.ax.legend(loc="best", framealpha=0.95, fontsize=10)
        self.fig.tight_layout()
        self.canvas.draw()

    def _plot_all_optimized(self):
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        records = self._collect_plot_records(base_dir, method_filter="ALL", metric=self._vars_graph["metric"].get(), top_n=0)
        self._plot_records_by_method(records, "All Optimized Structures: xTB vs CREST vs ORCA")

    def _plot_top_conformers(self):
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        try:
            top_n = max(1, int(self._vars_graph["conformer_top_n"].get()))
        except Exception:
            top_n = 10
        method = self._vars_graph["method"].get()
        records = self._collect_plot_records(base_dir, method_filter=method, metric=self._vars_graph["metric"].get(), top_n=top_n)
        self._plot_records_by_method(records, f"Top {top_n} {method} Conformers / Optimized Structures")

    def _plot_stacked_energy(self):
        """Plot a stacked bar chart comparing xTB, CREST, and ORCA energies for each conformer."""
        if not MATPLOTLIB_AVAILABLE:
            messagebox.showerror("Plot Error", "matplotlib is not available.")
            return
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        if not base_dir or not os.path.isdir(base_dir):
            messagebox.showwarning("No Directory", "Set a valid output directory in Graph Settings.")
            return
        records_xtb   = self._collect_plot_records(base_dir, method_filter="xTB",  metric="energy", top_n=0)
        records_crest = self._collect_plot_records(base_dir, method_filter="CREST", metric="energy", top_n=0)
        records_orca  = self._collect_plot_records(base_dir, method_filter="ORCA",  metric="energy", top_n=0)
        if not any([records_xtb, records_crest, records_orca]):
            messagebox.showinfo("No Data", "No xTB/CREST/ORCA energy data found in the selected directory.")
            return
        self.ax.clear()
        if getattr(self, "ax2", None):
            self.ax2.clear()
        def _energies(recs):
            return [r.get("energy", 0.0) if isinstance(r, dict) else getattr(r, "energy", 0.0) for r in recs]
        labels = [f"C{i+1}" for i in range(max(len(records_xtb), len(records_crest), len(records_orca)))]
        import numpy as np
        x = np.arange(len(labels))
        w = 0.25
        e_xtb   = _energies(records_xtb)   + [0.0] * (len(labels) - len(records_xtb))
        e_crest = _energies(records_crest) + [0.0] * (len(labels) - len(records_crest))
        e_orca  = _energies(records_orca)  + [0.0] * (len(labels) - len(records_orca))
        # Normalize relative to minimum
        base = min(v for v in e_xtb + e_crest + e_orca if v != 0.0) if any(e_xtb + e_crest + e_orca) else 0.0
        e_xtb   = [(v - base) * 627.509 for v in e_xtb]
        e_crest = [(v - base) * 627.509 for v in e_crest]
        e_orca  = [(v - base) * 627.509 for v in e_orca]
        ax = self.ax
        ax.bar(x - w, e_xtb,   w, label="xTB",   color="#2196F3", alpha=0.85)
        ax.bar(x,     e_crest, w, label="CREST",  color="#4CAF50", alpha=0.85)
        ax.bar(x + w, e_orca,  w, label="ORCA",   color="#FF5722", alpha=0.85)
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_xlabel("Conformer"); ax.set_ylabel("Rel. Energy (kcal/mol)")
        ax.set_title("Stacked Method Comparison: xTB / CREST / ORCA")
        ax.legend()
        ax.grid(axis="y", alpha=0.3)
        if hasattr(self, "canvas"):
            self.canvas.draw()


        if not hasattr(self, "ax"):
            return
        bg = self._vars_graph["graph_bg"].get()
        axis_c = self._vars_graph["axis_color"].get()
        grid_c = self._vars_graph["grid_color"].get()
        self.fig.patch.set_facecolor(bg)
        for axis in [self.ax] + ([self.ax2] if getattr(self, "ax2", None) else []):
            axis.set_facecolor(bg)
            axis.tick_params(colors=axis_c)
            axis.xaxis.label.set_color(axis_c)
            axis.yaxis.label.set_color(axis_c)
            axis.title.set_color(axis_c)
            for spine in axis.spines.values():
                spine.set_edgecolor(axis_c)
            for gridline in axis.get_xgridlines() + axis.get_ygridlines():
                gridline.set_color(grid_c)
                gridline.set_alpha(0.35)

    def _parse_crop(self, value):
        value = (value or "").strip()
        return None if not value else float(value)

    def _apply_graph_crop(self):
        try:
            xmin = self._parse_crop(self._vars_graph["crop_xmin"].get())
            xmax = self._parse_crop(self._vars_graph["crop_xmax"].get())
            ymin = self._parse_crop(self._vars_graph["crop_ymin"].get())
            ymax = self._parse_crop(self._vars_graph["crop_ymax"].get())
        except Exception:
            return messagebox.showerror("Crop Error", "Crop values must be numeric or blank.")
        if xmin is not None or xmax is not None:
            current = self.ax.get_xlim()
            self.ax.set_xlim(xmin if xmin is not None else current[0], xmax if xmax is not None else current[1])
        if ymin is not None or ymax is not None:
            current = self.ax.get_ylim()
            self.ax.set_ylim(ymin if ymin is not None else current[0], ymax if ymax is not None else current[1])
            if self.ax2 is not None:
                yl = self.ax.get_ylim()
                self.ax2.set_ylim(yl[0] * KCAL2KJ, yl[1] * KCAL2KJ)
        self._apply_custom_visual_theme()
        self.canvas.draw_idle()

    def _reset_graph_view(self):
        self.ax.relim()
        self.ax.autoscale_view()
        if self.ax2 is not None:
            yl = self.ax.get_ylim()
            self.ax2.set_ylim(yl[0] * KCAL2KJ, yl[1] * KCAL2KJ)
        for key in ["crop_xmin", "crop_xmax", "crop_ymin", "crop_ymax"]:
            self._vars_graph[key].set("")
        self._apply_custom_visual_theme()
        self.canvas.draw_idle()

    def _copy_to_clipboard(self, figure):
        import tempfile

        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
                tmp_path = f.name
            figure.savefig(tmp_path, dpi=300, bbox_inches="tight")
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms;"
                "Add-Type -AssemblyName System.Drawing;"
                f"$img = [System.Drawing.Image]::FromFile('{tmp_path}');"
                "[System.Windows.Forms.Clipboard]::SetImage($img);"
                "$img.Dispose();"
            )
            result = subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], capture_output=True, timeout=10)
            if result.returncode == 0:
                messagebox.showinfo("Clipboard", "Plot copied to Windows Clipboard.")
            else:
                messagebox.showerror("Clipboard Error", result.stderr.decode(errors="replace"))
        except Exception as e:
            messagebox.showerror("Clipboard Error", str(e))
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass

    def _export_high_res_graph(self):
        dest = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Image", "*.png"), ("PDF Document", "*.pdf"), ("JPEG Image", "*.jpg"), ("SVG Vector", "*.svg")], title="Export High-Res Graph")
        if dest:
            self.fig.savefig(dest, dpi=600, bbox_inches="tight")
            messagebox.showinfo("Export Successful", f"High-resolution publication graph saved to:\n{dest}")

    def _get_selected_filepath(self):
        for col, lb in enumerate(self.listboxes):
            sel = lb.curselection()
            if sel:
                fname = lb.get(sel[0])
                if fname.startswith("("):
                    return None
                return os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        return None

    def _open_file(self, listbox, col):
        sel = listbox.curselection()
        if not sel:
            return
        fname = listbox.get(sel[0])
        if fname.startswith("("):
            return
        path = os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        if not os.path.exists(path):
            return messagebox.showerror("Missing File", f"File not found:\n{path}")
        if path.lower().endswith(".xyz") and MATPLOTLIB_AVAILABLE:
            return self._open_model_viewer(path)
        try:
            if sys.platform == "win32":
                os.startfile(path)
            else:
                webbrowser.open(Path(path).as_uri())
        except Exception as exc:
            messagebox.showerror("Open Error", str(exc))

    def _open_in_avogadro(self):
        path = self._get_selected_filepath()
        if not path:
            return messagebox.showwarning("Select File", "Please select a file first.")
        cmd = None
        if shutil.which("avogadro"):
            cmd = ["avogadro", path]
        elif shutil.which("avogadro2"):
            cmd = ["avogadro2", path]
        elif sys.platform == "win32":
            cps = [
                r"C:\Program Files\Avogadro\bin\avogadro.exe",
                r"C:\Program Files (x86)\Avogadro\bin\avogadro.exe",
                r"C:\Program Files\Avogadro\avogadro.exe",
                r"C:\Program Files (x86)\Avogadro\avogadro.exe",
                r"C:\Program Files\Avogadro2\bin\avogadro2.exe",
                r"C:\Program Files\Avogadro2\avogadro2.exe",
            ]
            for cp in cps:
                if os.path.exists(cp):
                    cmd = [cp, path]
                    break
        if not cmd:
            return messagebox.showerror("Not Found", "Avogadro not found in standard paths.")
        try:
            subprocess.Popen(cmd)
        except Exception as e:
            messagebox.showerror("Error", f"Launch failed: {e}")

    def _export_file(self):
        path = self._get_selected_filepath()
        if not path:
            return messagebox.showwarning("Select File", "Please select a file first.")
        dest = filedialog.asksaveasfilename(defaultextension=Path(path).suffix, initialfile=os.path.basename(path), title="Export")
        if dest:
            shutil.copy2(path, dest)

    def _on_hover(self, event, listbox, col):
        idx = listbox.nearest(event.y)
        bbox = listbox.bbox(idx)
        if not bbox or not (bbox[1] <= event.y <= bbox[1] + bbox[3]):
            return self._hide_preview()
        fname = listbox.get(idx)
        if fname.startswith("("):
            return self._hide_preview()
        filepath = os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        if not os.path.exists(filepath) or not fname.endswith(".xyz"):
            return
        if self.preview_file == filepath and self.preview_tw is not None:
            return
        self._show_preview(event.x_root, event.y_root, filepath)

    def _hide_preview(self):
        if self.preview_tw:
            self.preview_tw.destroy()
            self.preview_tw = None
        self.preview_file = None

    def _read_xyz_atoms(self, filepath):
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        n = int(lines[0].strip())
        return [(p[0], float(p[1]), float(p[2]), float(p[3])) for l in lines[2 : 2 + n] for p in [l.split()] if len(p) >= 4]

    def _model_projection(self, atoms):
        coords = np.array([[a[1], a[2], a[3]] for a in atoms], dtype=float)
        coords -= np.mean(coords, axis=0)
        rx = np.array([[1, 0, 0], [0, math.cos(0.35), -math.sin(0.35)], [0, math.sin(0.35), math.cos(0.35)]])
        ry = np.array([[math.cos(0.61), 0, math.sin(0.61)], [0, 1, 0], [-math.sin(0.61), 0, math.cos(0.61)]])
        return coords @ rx @ ry

    def _atom_color(self, symbol):
        if symbol == "Cl":
            key = "atom_Cl"
        elif symbol in {"H", "C", "N", "O", "F", "S"}:
            key = f"atom_{symbol}"
        else:
            key = "atom_other"
        return self._vars_graph[key].get()

    def _covalent_radius(self, symbol):
        radii = {
            "H": 0.31,
            "B": 0.85,
            "C": 0.76,
            "N": 0.71,
            "O": 0.66,
            "F": 0.57,
            "P": 1.07,
            "S": 1.05,
            "Cl": 1.02,
            "Br": 1.20,
            "I": 1.39,
            "Si": 1.11,
            "Na": 1.66,
            "K": 2.03,
            "Mg": 1.41,
            "Ca": 1.76,
            "Fe": 1.24,
            "Cu": 1.32,
            "Zn": 1.22,
        }
        return radii.get(symbol, 0.80)

    def _vdw_radius(self, symbol):
        radii = {
            "H": 1.20,
            "C": 1.70,
            "N": 1.55,
            "O": 1.52,
            "F": 1.47,
            "P": 1.80,
            "S": 1.80,
            "Cl": 1.75,
            "Br": 1.85,
            "I": 1.98,
        }
        return radii.get(symbol, 1.65)

    def _float_var(self, key, fallback):
        try:
            return float(self._vars_graph[key].get())
        except Exception:
            return fallback

    def _detect_bonds(self, atoms, coords):
        mode = self._vars_graph["bond_mode"].get()
        cutoff = self._float_var("bond_cutoff", 1.85)
        tolerance = self._float_var("bond_tolerance", 0.45)
        bonds = []
        for i in range(len(atoms)):
            for j in range(i + 1, len(atoms)):
                dist = float(np.linalg.norm(coords[i] - coords[j]))
                sym_i, sym_j = atoms[i][0], atoms[j][0]
                include = False
                kind = "bond"
                if mode == "Distance cutoff":
                    include = dist <= cutoff
                elif mode == "Hydrogen bonds":
                    pair = {sym_i, sym_j}
                    include = "H" in pair and bool(pair.intersection({"O", "N", "F", "S"})) and 1.3 <= dist <= cutoff
                    kind = "hbond"
                elif mode == "All close contacts":
                    include = dist <= cutoff
                    kind = "contact"
                else:
                    include = dist <= self._covalent_radius(sym_i) + self._covalent_radius(sym_j) + tolerance
                if include and dist > 0.25:
                    bonds.append((i, j, dist, kind))
        return bonds

    def _set_3d_equal_axes(self, axis, coords):
        mins = coords.min(axis=0)
        maxs = coords.max(axis=0)
        centers = (mins + maxs) / 2.0
        radius = max(float(np.max(maxs - mins)) / 2.0, 1.0)
        pad = radius * 0.22
        radius += pad
        axis.set_xlim(centers[0] - radius, centers[0] + radius)
        axis.set_ylim(centers[1] - radius, centers[1] + radius)
        axis.set_zlim(centers[2] - radius, centers[2] + radius)
        try:
            axis.set_box_aspect((1, 1, 1))
        except Exception:
            pass

    def _render_xyz_model(self, axis, filepath):
        axis.clear()
        axis.set_facecolor(self._vars_graph["model_bg"].get())
        axis.figure.patch.set_facecolor(self._vars_graph["model_bg"].get())
        atoms = self._read_xyz_atoms(filepath)
        coords = np.array([[a[1], a[2], a[3]] for a in atoms], dtype=float)
        coords -= np.mean(coords, axis=0)
        style = self._vars_graph["model_style"].get()
        bond_color = self._vars_graph["bond_color"].get()
        bond_lw = {"Wireframe": 1.1, "Ball-and-stick": 2.6, "Licorice": 6.0, "CPK": 0.8}.get(style, 2.6)
        atom_scale = {"Wireframe": 18, "Ball-and-stick": 180, "Licorice": 90, "CPK": 520}.get(style, 180)
        bonds = self._detect_bonds(atoms, coords)
        if style != "CPK":
            for i, j, dist, kind in bonds:
                linestyle = "--" if kind in {"hbond", "contact"} else "-"
                alpha = 0.55 if kind in {"hbond", "contact"} else 0.95
                axis.plot(
                    [coords[i, 0], coords[j, 0]],
                    [coords[i, 1], coords[j, 1]],
                    [coords[i, 2], coords[j, 2]],
                    color=bond_color,
                    linewidth=bond_lw,
                    linestyle=linestyle,
                    solid_capstyle="round",
                    alpha=alpha,
                    zorder=1,
                )
                if self._vars_graph["show_bond_distances"].get():
                    mid = (coords[i] + coords[j]) / 2.0
                    axis.text(
                        mid[0],
                        mid[1],
                        mid[2],
                        f"{dist:.2f} A",
                        color=self._vars_graph["axis_color"].get(),
                        fontsize=7,
                        ha="center",
                        va="center",
                    )
        for idx in range(len(atoms)):
            symbol = atoms[idx][0]
            base = self._vdw_radius(symbol) if style == "CPK" else self._covalent_radius(symbol) + 0.30
            size = atom_scale * (base**2)
            if style == "Wireframe":
                size *= 0.35
            elif style == "CPK":
                size *= 0.75
            elif style == "Licorice":
                size *= 0.55
            axis.scatter(
                coords[idx, 0],
                coords[idx, 1],
                coords[idx, 2],
                s=size,
                color=self._atom_color(symbol),
                edgecolors="#111827",
                linewidths=0.65,
                depthshade=True,
                zorder=3,
            )
            if self._vars_graph["show_atom_labels"].get():
                axis.text(
                    coords[idx, 0],
                    coords[idx, 1],
                    coords[idx, 2],
                    f"{symbol}{idx + 1}",
                    color=self._vars_graph["axis_color"].get(),
                    fontsize=8,
                )
        self._set_3d_equal_axes(axis, coords)
        axis.view_init(elev=self._float_var("model_elev", 18.0), azim=self._float_var("model_azim", 38.0))
        if self._vars_graph["show_3d_axes"].get():
            axis.set_xlabel("X (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.set_ylabel("Y (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.set_zlabel("Z (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.tick_params(colors=self._vars_graph["axis_color"].get(), labelsize=7)
        else:
            axis.set_axis_off()
        for pane in [axis.xaxis.pane, axis.yaxis.pane, axis.zaxis.pane]:
            pane.set_facecolor(self._vars_graph["model_bg"].get())
            pane.set_edgecolor("#d0d7de")

    def _show_preview(self, x, y, filepath):
        self._hide_preview()
        self.preview_file = filepath
        tw = tk.Toplevel(self.root)
        self.preview_tw = tw
        tw.wm_overrideredirect(True)
        tw.geometry(f"+{x + 15}+{y + 15}")
        cv = tk.Canvas(tw, width=270, height=270, bg=self._vars_graph["model_bg"].get(), highlightthickness=2, highlightbackground=_C["accent"])
        cv.pack()
        try:
            atoms = self._read_xyz_atoms(filepath)
            coords = self._model_projection(atoms)
            xy, z = coords[:, :2], coords[:, 2]
            span = max(float(np.max(np.abs(xy))), 1.0)
            xy = xy * (105.0 / span) + 135.0
            distances = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)
            style = self._vars_graph["model_style"].get()
            bond_width = {"Wireframe": 1, "Ball-and-stick": 3, "Licorice": 6, "CPK": 1}.get(style, 3)
            if style != "CPK":
                for i in range(len(atoms)):
                    for j in range(i + 1, len(atoms)):
                        if 0.4 < distances[i, j] < 1.85:
                            cv.create_line(xy[i, 0], xy[i, 1], xy[j, 0], xy[j, 1], fill=self._vars_graph["bond_color"].get(), width=bond_width)
            for idx in sorted(range(len(atoms)), key=lambda i: z[i]):
                symbol = atoms[idx][0]
                radius = 4 if symbol == "H" else 8
                if style == "CPK":
                    radius = 11 if symbol == "H" else 18
                elif style == "Wireframe":
                    radius = 3
                elif style == "Licorice":
                    radius = 5 if symbol == "H" else 7
                cv.create_oval(xy[idx, 0] - radius, xy[idx, 1] - radius, xy[idx, 0] + radius, xy[idx, 1] + radius, fill=self._atom_color(symbol), outline="#111827")
        except Exception:
            cv.create_text(135, 135, text="Preview unavailable", fill="white")

    def _open_model_viewer(self, filepath):
        win = tk.Toplevel(self.root)
        win.title(f"IAK Model Viewer - {os.path.basename(filepath)}")
        win.geometry("900x720")
        win.configure(bg=_C["bg"])
        controls = tk.Frame(win, bg=_C["panel"])
        controls.pack(fill="x", padx=8, pady=8)
        tk.Label(controls, text="Model style:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(5, 4))
        ttk.Combobox(controls, textvariable=self._vars_graph["model_style"], values=["Ball-and-stick", "CPK", "Wireframe", "Licorice"], width=15, state="readonly").pack(side="left", padx=4)
        tk.Label(controls, text="Bonds:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 4))
        ttk.Combobox(
            controls,
            textvariable=self._vars_graph["bond_mode"],
            values=["Covalent radii", "Distance cutoff", "Hydrogen bonds", "All close contacts"],
            width=16,
            state="readonly",
        ).pack(side="left", padx=4)
        tk.Label(controls, text="Cutoff A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(controls, textvariable=self._vars_graph["bond_cutoff"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Label(controls, text="Tol A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(controls, textvariable=self._vars_graph["bond_tolerance"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Checkbutton(controls, text="Distances", variable=self._vars_graph["show_bond_distances"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=8)
        tk.Checkbutton(controls, text="Atom labels", variable=self._vars_graph["show_atom_labels"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        tk.Checkbutton(controls, text="Axes", variable=self._vars_graph["show_3d_axes"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        for label, key in [("Elev", "model_elev"), ("Azim", "model_azim")]:
            tk.Label(controls, text=f"{label}:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
            tk.Entry(controls, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        fig = Figure(figsize=(7, 6), dpi=110)
        ax = fig.add_subplot(111, projection="3d")
        canvas = FigureCanvasTkAgg(fig, master=win)
        toolbar = NavigationToolbar2Tk(canvas, win, pack_toolbar=False)

        def redraw():
            self._render_xyz_model(ax, filepath)
            canvas.draw_idle()

        tk.Button(controls, text="Redraw", command=redraw, bg=_C["accent"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)
        tk.Button(controls, text="Export Image", command=lambda: self._export_model_figure(fig), bg=_C["green"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=4)
        tk.Label(controls, text="Drag to rotate; use toolbar pan/zoom to inspect and crop.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(side="left", padx=12)
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=(0, 8))
        toolbar.update()
        toolbar.pack(fill="x", padx=8, pady=(0, 8))
        redraw()

    def _export_model_figure(self, fig):
        dest = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Image", "*.png"), ("PDF Document", "*.pdf"), ("SVG Vector", "*.svg"), ("JPEG Image", "*.jpg")], title="Export Model Image")
        if dest:
            image_dpi = int(self._float_var("image_dpi", 600))
            image_dpi = max(72, min(image_dpi, 1200))
            fig.savefig(dest, dpi=image_dpi, bbox_inches="tight")
            messagebox.showinfo("Export Successful", f"Model image saved to:\n{dest}")

    def _refresh_results(self):
        out_dir = os.path.abspath(self._vars["out"].get().strip(" \"'"))
        for col, lb in enumerate(self.listboxes):
            lb.delete(0, tk.END)
            path = os.path.join(out_dir, self.folders[col])
            if os.path.exists(path):
                files = sorted([f for f in os.listdir(path) if f.lower().endswith((".xyz", ".json", ".csv", ".md", ".png", ".jpg", ".jpeg", ".svg", ".pdf"))])
                for f in files:
                    lb.insert(tk.END, f)
                if not files:
                    lb.insert(tk.END, "(Empty)")

    def _is_iak_job_dir(self, folder):
        if not os.path.isdir(folder):
            return False
        markers = [
            "01_Inputs_and_Clusters",
            "02_xTB_Results",
            "03_CREST_Results",
            "04_ORCA_Refinement",
            "05_Top_Models_Comparison",
            "state.json",
        ]
        return any(os.path.exists(os.path.join(folder, marker)) for marker in markers)

    def _find_iak_job_dirs(self, folder):
        folder = os.path.abspath(folder)
        if self._is_iak_job_dir(folder):
            return [folder]
        jobs = []
        for root, dirs, files in os.walk(folder):
            if self._is_iak_job_dir(root):
                jobs.append(root)
                dirs[:] = []
        return sorted(set(jobs))

    def _resolve_existing_path(self, job_dir, path_value):
        if not path_value:
            return None
        path_value = str(path_value)
        if os.path.exists(path_value):
            return path_value
        basename = os.path.basename(path_value)
        if not basename:
            return None
        for root, _, files in os.walk(job_dir):
            if basename in files:
                return os.path.join(root, basename)
        return None

    def _xyz_comment_energy(self, path):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
            if len(lines) < 2:
                return None
            return float(lines[1].split()[0])
        except Exception:
            return None

    def _parse_orca_out(self, out_path):
        energy, gibbs, imag, success = None, None, 0, False
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                content = handle.read()
            for line in content.splitlines():
                if "FINAL SINGLE POINT ENERGY" in line:
                    try:
                        energy = float(line.split()[-1])
                    except Exception:
                        pass
                elif "Final Gibbs free energy" in line:
                    try:
                        gibbs = float(line.split()[-2])
                    except Exception:
                        pass
                elif "*** imaginary mode ***" in line:
                    imag += 1
                elif "ORCA TERMINATED NORMALLY" in line:
                    success = True
            xyz_path = None
            folder = os.path.dirname(out_path)
            stem = Path(out_path).stem
            candidates = [
                os.path.join(folder, f"{stem}_trj.xyz"),
                os.path.join(folder, f"{stem}.xyz"),
            ]
            candidates.extend(str(p) for p in Path(folder).glob("*_trj.xyz"))
            candidates.extend(str(p) for p in Path(folder).glob("*.xyz"))
            for candidate in candidates:
                if os.path.exists(candidate):
                    xyz_path = candidate
                    break
            if xyz_path is None:
                extracted = os.path.join(folder, f"{stem}_final_from_out.xyz")
                if self._extract_orca_final_xyz(out_path, extracted):
                    xyz_path = extracted
            if energy is None:
                success = False
            return {
                "status": "success" if success and energy is not None else "failed",
                "energy": energy,
                "gibbs": gibbs or 0.0,
                "imag": imag,
                "path": xyz_path,
                "out_path": out_path,
            }
        except Exception:
            return {"status": "failed", "energy": None, "gibbs": 0.0, "imag": 0, "path": None, "out_path": out_path}

    def _extract_orca_final_xyz(self, out_path, dest_xyz):
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
            blocks = []
            idx = 0
            while idx < len(lines):
                line = lines[idx]
                upper = line.upper()
                if "CARTESIAN COORDINATES" in upper and ("ANGSTROEM" in upper or "ANGSTROM" in upper):
                    idx += 1
                    block = []
                    while idx < len(lines):
                        raw = lines[idx].strip()
                        idx += 1
                        if not raw:
                            if block:
                                break
                            continue
                        if set(raw) <= {"-"}:
                            continue
                        parts = raw.split()
                        if len(parts) >= 4 and re.match(r"^[A-Z][a-z]?$", parts[0]):
                            try:
                                block.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                                continue
                            except Exception:
                                pass
                        if block:
                            break
                    if block:
                        blocks.append(block)
                else:
                    idx += 1
            if not blocks:
                return None
            atoms = blocks[-1]
            os.makedirs(os.path.dirname(dest_xyz), exist_ok=True)
            with open(dest_xyz, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(f"{len(atoms)}\nExtracted final coordinates from {os.path.basename(out_path)}\n")
                for sym, x, y, z in atoms:
                    handle.write(f"{sym:<4} {x:15.6f} {y:15.6f} {z:15.6f}\n")
            return dest_xyz
        except Exception:
            return None

    def _parse_orca_thermo(self, out_path):
        data = {
            "final_single_point_energy_eh": None,
            "zero_point_energy_eh": None,
            "total_thermal_energy_eh": None,
            "total_enthalpy_eh": None,
            "final_entropy_term_eh": None,
            "final_gibbs_free_energy_eh": None,
            "temperature_k": None,
            "pressure_atm": None,
            "imaginary_frequencies": 0,
            "normal_termination": False,
        }
        labels = {
            "FINAL SINGLE POINT ENERGY": "final_single_point_energy_eh",
            "Zero point energy": "zero_point_energy_eh",
            "Total thermal energy": "total_thermal_energy_eh",
            "Total Enthalpy": "total_enthalpy_eh",
            "Final entropy term": "final_entropy_term_eh",
            "Final Gibbs free energy": "final_gibbs_free_energy_eh",
        }
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    stripped = line.strip()
                    for label, key in labels.items():
                        if label.lower() in stripped.lower():
                            floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                            if floats:
                                data[key] = float(floats[-1])
                    if "*** imaginary mode ***" in stripped:
                        data["imaginary_frequencies"] += 1
                    if "ORCA TERMINATED NORMALLY" in stripped:
                        data["normal_termination"] = True
                    if "Temperature" in stripped and "K" in stripped:
                        floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                        if floats:
                            data["temperature_k"] = float(floats[-1])
                    if "Pressure" in stripped and ("atm" in stripped.lower() or "ATM" in stripped):
                        floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                        if floats:
                            data["pressure_atm"] = float(floats[-1])
        except Exception:
            pass
        return data

    def _copy_unique_result(self, src, dest):
        if not src or not os.path.exists(src):
            return None
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.abspath(src) == os.path.abspath(dest):
            return dest
        shutil.copy2(src, dest)
        return dest

    def _collect_existing_job_records(self, job_dir):
        state_path = os.path.join(job_dir, "state.json")
        state = {"xtb": {}, "crest": {}, "orca": {}}
        if os.path.exists(state_path):
            try:
                with open(state_path, "r", encoding="utf-8") as handle:
                    state.update(json.load(handle))
            except Exception:
                pass

        records = {"xTB": [], "CREST": [], "ORCA": []}

        for key, value in state.get("xtb", {}).items():
            if value.get("status") == "success" and value.get("energy") is not None:
                path = self._resolve_existing_path(job_dir, value.get("path"))
                records["xTB"].append({"source": key, "energy": float(value["energy"]), "gibbs": None, "imag": None, "path": path})

        xtb_dir = os.path.join(job_dir, "02_xTB_Results")
        if not records["xTB"] and os.path.isdir(xtb_dir):
            for path in Path(xtb_dir).rglob("*.xyz"):
                energy = self._xyz_comment_energy(str(path))
                if energy is not None:
                    records["xTB"].append({"source": path.stem, "energy": energy, "gibbs": None, "imag": None, "path": str(path)})

        for key, value in state.get("crest", {}).items():
            if value.get("status") == "success":
                path = self._resolve_existing_path(job_dir, value.get("best_path") or value.get("path"))
                if path:
                    mols = read_multi_xyz(path)
                    energy = mols[0].energy_eh if mols else self._xyz_comment_energy(path)
                    if energy is not None:
                        records["CREST"].append({"source": key, "energy": float(energy), "gibbs": None, "imag": None, "path": path})

        crest_dir = os.path.join(job_dir, "03_CREST_Results")
        if os.path.isdir(crest_dir):
            for path in list(Path(crest_dir).glob("crest_best_*.xyz")) + list(Path(crest_dir).glob("crest_conformers_*.xyz")):
                mols = read_multi_xyz(str(path))
                energy = mols[0].energy_eh if mols else self._xyz_comment_energy(str(path))
                if energy is not None:
                    records["CREST"].append({"source": path.stem, "energy": float(energy), "gibbs": None, "imag": None, "path": str(path)})

        for key, value in state.get("orca", {}).items():
            if value.get("status") == "success" and value.get("energy") is not None:
                path = self._resolve_existing_path(job_dir, value.get("best_path") or value.get("path"))
                records["ORCA"].append({
                    "source": key,
                    "energy": float(value["energy"]),
                    "gibbs": float(value.get("gibbs", 0.0) or 0.0),
                    "imag": int(value.get("imag", 0) or 0),
                    "path": path,
                })

        orca_dir = os.path.join(job_dir, "04_ORCA_Refinement")
        if os.path.isdir(orca_dir):
            for out_path in Path(orca_dir).rglob("*.out"):
                parsed = self._parse_orca_out(str(out_path))
                if parsed["status"] == "success" and parsed["energy"] is not None:
                    records["ORCA"].append({
                        "source": out_path.stem,
                        "energy": float(parsed["energy"]),
                        "gibbs": float(parsed.get("gibbs", 0.0) or 0.0),
                        "imag": int(parsed.get("imag", 0) or 0),
                        "path": parsed.get("path"),
                    })
        return records

    def _write_existing_analysis_outputs(self, job_dir):
        comp_dir = os.path.join(job_dir, "05_Top_Models_Comparison")
        logs_dir = os.path.join(job_dir, "logs")
        os.makedirs(comp_dir, exist_ok=True)
        os.makedirs(logs_dir, exist_ok=True)
        records = self._collect_existing_job_records(job_dir)
        rows = []

        xtb_best = min(records["xTB"], key=lambda item: item["energy"], default=None)
        if xtb_best:
            self._copy_unique_result(xtb_best.get("path"), os.path.join(comp_dir, "1_BEST_xTB.xyz"))
            rows.append(["xTB", xtb_best["source"], f"{xtb_best['energy']:.6f}", "N/A", "N/A"])

        crest_best = min(records["CREST"], key=lambda item: item["energy"], default=None)
        if crest_best:
            self._copy_unique_result(crest_best.get("path"), os.path.join(comp_dir, "2_BEST_CREST.xyz"))
            rows.append(["CREST", crest_best["source"], f"{crest_best['energy']:.6f}", "N/A", "N/A"])

        orca_candidates = records["ORCA"]
        true_minima = [item for item in orca_candidates if item.get("imag", 0) == 0]
        rank_pool = true_minima or orca_candidates
        orca_best = min(rank_pool, key=lambda item: item["gibbs"] if item.get("gibbs", 0.0) else item["energy"], default=None)
        if orca_best:
            self._copy_unique_result(orca_best.get("path"), os.path.join(comp_dir, "3_BEST_ORCA.xyz"))
            rows.append(["ORCA", orca_best["source"], f"{orca_best['energy']:.6f}", f"{orca_best.get('gibbs', 0.0):.6f}", "N/A"])

        csv_path = os.path.join(comp_dir, "Energy_Comparison.csv")
        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Level_of_Theory", "Source_ID", "Total_Energy_Eh", "Gibbs_Free_Energy_Eh", "Binding_Energy_kcal_mol"])
            writer.writerows(rows)

        report_path = os.path.join(comp_dir, "Existing_Folder_Analysis_Report.md")
        with open(report_path, "w", encoding="utf-8") as handle:
            handle.write(f"# Existing Folder Analysis\n\n")
            handle.write(f"- **Analyzed folder:** `{job_dir}`\n")
            handle.write(f"- **Analysis time:** {_now()}\n")
            handle.write(f"- **xTB records found:** {len(records['xTB'])}\n")
            handle.write(f"- **CREST records found:** {len(records['CREST'])}\n")
            handle.write(f"- **ORCA records found:** {len(records['ORCA'])}\n")
            handle.write(f"- **ORCA true minima (0 imaginary frequencies):** {len(true_minima)}\n\n")
            handle.write("## Best Extracted Models\n\n")
            handle.write("| Method | Source | Energy (Eh) | Gibbs (Eh) | Notes |\n")
            handle.write("|---|---|---:|---:|---|\n")
            if xtb_best:
                handle.write(f"| xTB | {xtb_best['source']} | {xtb_best['energy']:.6f} | N/A | Best available xTB record |\n")
            if crest_best:
                handle.write(f"| CREST | {crest_best['source']} | {crest_best['energy']:.6f} | N/A | Best available CREST record |\n")
            if orca_best:
                handle.write(f"| ORCA | {orca_best['source']} | {orca_best['energy']:.6f} | {orca_best.get('gibbs', 0.0):.6f} | Ranked by Gibbs when available |\n")
            if not rows:
                handle.write("| N/A | N/A | N/A | N/A | No parseable energy records were found |\n")

        with open(os.path.join(logs_dir, "Existing_Folder_Analysis.json"), "w", encoding="utf-8") as handle:
            json.dump({"folder": job_dir, "time": _now(), "records": records}, handle, indent=2)
        file_analysis = self._generate_file_level_analysis(job_dir)
        return {"job_dir": job_dir, "rows": len(rows), "report": report_path, "csv": csv_path, "file_analysis": file_analysis}

    def _count_xyz_atoms(self, xyz_path):
        try:
            with open(xyz_path, "r", encoding="utf-8", errors="replace") as handle:
                return int(handle.readline().strip())
        except Exception:
            return None

    def _unique_analysis_path(self, folder, stem, suffix, used_names):
        clean_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem).strip("_") or "analysis"
        candidate = f"{clean_stem}{suffix}"
        idx = 1
        while candidate.lower() in used_names or os.path.exists(os.path.join(folder, candidate)):
            candidate = f"{clean_stem}_{idx}{suffix}"
            idx += 1
        used_names.add(candidate.lower())
        return os.path.join(folder, candidate)

    def _generate_structure_image(self, xyz_path, image_path):
        if not MATPLOTLIB_AVAILABLE or not xyz_path or not os.path.exists(xyz_path):
            return None
        try:
            image_dpi = int(self._float_var("image_dpi", 300))
            image_dpi = max(72, min(image_dpi, 1200))
            fig = Figure(figsize=(5.6, 5.2), dpi=min(image_dpi, 220))
            ax = fig.add_subplot(111, projection="3d")
            self._render_xyz_model(ax, xyz_path)
            ax.set_title(os.path.basename(xyz_path), fontsize=8, color=self._vars_graph["axis_color"].get())
            fig.savefig(image_path, dpi=image_dpi, bbox_inches="tight")
            return image_path
        except Exception:
            return None

    def _analysis_value(self, value):
        if value is None or value == "":
            return "N/A"
        if isinstance(value, float):
            return f"{value:.8f}"
        return str(value)

    def _relative_report_path(self, target, report_dir):
        try:
            return os.path.relpath(target, report_dir).replace("\\", "/")
        except Exception:
            return target.replace("\\", "/")

    def _analyze_xyz_file_record(self, xyz_path, images_dir, image_names):
        energy = self._xyz_comment_energy(xyz_path)
        image_path = self._unique_analysis_path(images_dir, Path(xyz_path).stem, ".png", image_names)
        generated_image = self._generate_structure_image(xyz_path, image_path)
        return {
            "source_file": xyz_path,
            "file_type": "XYZ",
            "status": "parsed",
            "atoms": self._count_xyz_atoms(xyz_path),
            "xyz_path": xyz_path,
            "image_path": generated_image,
            "final_single_point_energy_eh": energy,
            "zero_point_energy_eh": None,
            "total_thermal_energy_eh": None,
            "total_enthalpy_eh": None,
            "final_entropy_term_eh": None,
            "final_gibbs_free_energy_eh": None,
            "temperature_k": None,
            "pressure_atm": None,
            "imaginary_frequencies": None,
            "normal_termination": None,
            "notes": "Energy read from XYZ comment line." if energy is not None else "Structure image generated; no thermodynamic data present in XYZ.",
        }

    def _analyze_orca_out_record(self, out_path, images_dir, image_names):
        thermo = self._parse_orca_thermo(out_path)
        parsed = self._parse_orca_out(out_path)
        xyz_path = parsed.get("path")
        image_path = None
        if xyz_path and os.path.exists(xyz_path):
            image_path = self._unique_analysis_path(images_dir, Path(out_path).stem, ".png", image_names)
            image_path = self._generate_structure_image(xyz_path, image_path)
        status = "parsed" if thermo.get("final_single_point_energy_eh") is not None or xyz_path else "partial"
        notes = []
        if thermo.get("final_gibbs_free_energy_eh") is not None:
            notes.append("Thermodynamic Gibbs energy found.")
        if thermo.get("total_enthalpy_eh") is not None:
            notes.append("Thermodynamic enthalpy found.")
        if image_path:
            notes.append("Molecular image generated from final/output coordinates.")
        elif not xyz_path:
            notes.append("No final Cartesian coordinate block or matching XYZ was found.")
        return {
            "source_file": out_path,
            "file_type": "ORCA OUT",
            "status": status,
            "atoms": self._count_xyz_atoms(xyz_path) if xyz_path else None,
            "xyz_path": xyz_path,
            "image_path": image_path,
            "final_single_point_energy_eh": thermo.get("final_single_point_energy_eh") if thermo.get("final_single_point_energy_eh") is not None else parsed.get("energy"),
            "zero_point_energy_eh": thermo.get("zero_point_energy_eh"),
            "total_thermal_energy_eh": thermo.get("total_thermal_energy_eh"),
            "total_enthalpy_eh": thermo.get("total_enthalpy_eh"),
            "final_entropy_term_eh": thermo.get("final_entropy_term_eh"),
            "final_gibbs_free_energy_eh": thermo.get("final_gibbs_free_energy_eh") if thermo.get("final_gibbs_free_energy_eh") is not None else parsed.get("gibbs"),
            "temperature_k": thermo.get("temperature_k"),
            "pressure_atm": thermo.get("pressure_atm"),
            "imaginary_frequencies": thermo.get("imaginary_frequencies"),
            "normal_termination": thermo.get("normal_termination"),
            "notes": " ".join(notes) if notes else "ORCA output parsed.",
        }

    def _generate_file_level_analysis(self, analysis_dir):
        comp_dir = os.path.join(analysis_dir, "05_Top_Models_Comparison")
        logs_dir = os.path.join(analysis_dir, "logs")
        images_dir = os.path.join(analysis_dir, "06_File_Analysis_Images")
        opts = self._get_report_options() if hasattr(self, "_get_report_options") else {}
        include_thermo = opts.get("thermodynamics", True)
        include_images = opts.get("images", True)
        os.makedirs(comp_dir, exist_ok=True)
        os.makedirs(logs_dir, exist_ok=True)
        os.makedirs(images_dir, exist_ok=True)

        source_files = []
        for path in Path(analysis_dir).rglob("*"):
            if not path.is_file():
                continue
            lower_path = str(path).lower()
            if "06_file_analysis_images" in lower_path or "__pycache__" in lower_path:
                continue
            if path.name.lower().endswith("_final_from_out.xyz"):
                continue
            if path.suffix.lower() in (".out", ".xyz"):
                source_files.append(str(path))
        source_files = sorted(set(source_files))

        image_names = set()
        rows = []
        for file_path in source_files:
            if file_path.lower().endswith(".out"):
                rows.append(self._analyze_orca_out_record(file_path, images_dir, image_names))
            elif file_path.lower().endswith(".xyz"):
                rows.append(self._analyze_xyz_file_record(file_path, images_dir, image_names))

        csv_path = os.path.join(logs_dir, "File_Analysis_Summary.csv")
        fields = [
            "source_file",
            "file_type",
            "status",
            "atoms",
            "xyz_path",
            "notes",
        ]
        thermo_fields = [
            "final_single_point_energy_eh",
            "zero_point_energy_eh",
            "total_thermal_energy_eh",
            "total_enthalpy_eh",
            "final_entropy_term_eh",
            "final_gibbs_free_energy_eh",
            "temperature_k",
            "pressure_atm",
            "imaginary_frequencies",
            "normal_termination",
        ]
        if include_thermo:
            fields[4:4] = thermo_fields
        if include_images:
            fields.insert(-1, "image_path")
        else:
            for row in rows:
                row["image_path"] = ""
        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key, "") for key in fields})

        report_path = os.path.join(comp_dir, "File_Analysis_Report.md")
        with open(report_path, "w", encoding="utf-8") as handle:
            handle.write("# File-Level Structure and Thermodynamic Analysis\n\n")
            handle.write(f"- **Analyzed folder:** `{analysis_dir}`\n")
            handle.write(f"- **Analysis time:** {_now()}\n")
            handle.write(f"- **Files analyzed:** {len(rows)}\n")
            if include_images:
                handle.write(f"- **Images generated:** {sum(1 for row in rows if row.get('image_path'))}\n")
            if include_thermo:
                handle.write(f"- **Thermodynamic ORCA records:** {sum(1 for row in rows if row.get('final_gibbs_free_energy_eh') not in (None, 0.0) or row.get('total_enthalpy_eh') is not None)}\n")
            handle.write("\n")
            handle.write("## Summary Table\n\n")
            if include_thermo:
                handle.write("| File | Type | Atoms | E(eh) | H(eh) | G(eh) | ZPE(eh) | Imag | Normal | Notes |\n")
                handle.write("|---|---|---:|---:|---:|---:|---:|---:|---|---|\n")
            else:
                handle.write("| File | Type | Atoms | Notes |\n")
                handle.write("|---|---|---:|---|\n")
            for row in rows:
                if include_thermo:
                    handle.write(
                        f"| {os.path.basename(row['source_file'])} | {row['file_type']} | {self._analysis_value(row.get('atoms'))} | "
                        f"{self._analysis_value(row.get('final_single_point_energy_eh'))} | "
                        f"{self._analysis_value(row.get('total_enthalpy_eh'))} | "
                        f"{self._analysis_value(row.get('final_gibbs_free_energy_eh'))} | "
                        f"{self._analysis_value(row.get('zero_point_energy_eh'))} | "
                        f"{self._analysis_value(row.get('imaginary_frequencies'))} | "
                        f"{self._analysis_value(row.get('normal_termination'))} | {row.get('notes','')} |\n"
                    )
                else:
                    handle.write(f"| {os.path.basename(row['source_file'])} | {row['file_type']} | {self._analysis_value(row.get('atoms'))} | {row.get('notes','')} |\n")
            if rows and include_images:
                handle.write("\n## Generated Molecular Images\n\n")
                for row in rows:
                    if row.get("image_path"):
                        rel_image = self._relative_report_path(row["image_path"], comp_dir)
                        handle.write(f"### {os.path.basename(row['source_file'])}\n\n")
                        handle.write(f"![{os.path.basename(row['source_file'])}]({rel_image})\n\n")
            else:
                handle.write("\nNo `.out` or `.xyz` files were found for file-level analysis.\n")

        return {"csv": csv_path, "report": report_path, "images_dir": images_dir, "file_count": len(rows)}

    def _copy_loose_file(self, src, dest_dir, used_names):
        os.makedirs(dest_dir, exist_ok=True)
        name = os.path.basename(src)
        stem, suffix = os.path.splitext(name)
        candidate = name
        idx = 1
        while candidate.lower() in used_names or os.path.exists(os.path.join(dest_dir, candidate)):
            candidate = f"{stem}_{idx}{suffix}"
            idx += 1
        used_names.add(candidate.lower())
        dest = os.path.join(dest_dir, candidate)
        shutil.copy2(src, dest)
        return dest

    def _prepare_selected_files_analysis_dir(self, files, analysis_name="IAK_selected_files_analysis"):
        parents = [os.path.dirname(os.path.abspath(path)) for path in files]
        try:
            base_dir = os.path.commonpath(parents)
            if not os.path.isdir(base_dir):
                base_dir = parents[0]
        except Exception:
            base_dir = parents[0]
        analysis_dir = os.path.join(base_dir, analysis_name)
        inputs_dir = os.path.join(analysis_dir, "01_Inputs_and_Clusters")
        orca_dir = os.path.join(analysis_dir, "04_ORCA_Refinement")
        os.makedirs(inputs_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "02_xTB_Results"), exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "03_CREST_Results"), exist_ok=True)
        os.makedirs(orca_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "05_Top_Models_Comparison"), exist_ok=True)
        used = set()
        copied_xyz, copied_out = 0, 0
        for src in files:
            lower = src.lower()
            if lower.endswith(".xyz"):
                self._copy_loose_file(src, inputs_dir, used)
                copied_xyz += 1
            elif lower.endswith(".out"):
                self._copy_loose_file(src, orca_dir, used)
                copied_out += 1
        return analysis_dir, copied_xyz, copied_out

    def _create_loose_folder_analysis(self, folder):
        analysis_dir = os.path.join(folder, "IAK_existing_analysis")
        inputs_dir = os.path.join(analysis_dir, "01_Inputs_and_Clusters")
        orca_dir = os.path.join(analysis_dir, "04_ORCA_Refinement")
        os.makedirs(inputs_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "02_xTB_Results"), exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "03_CREST_Results"), exist_ok=True)
        os.makedirs(orca_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "05_Top_Models_Comparison"), exist_ok=True)
        used = set()
        copied_xyz, copied_out = 0, 0
        for root, dirs, files in os.walk(folder):
            if os.path.abspath(root).startswith(os.path.abspath(analysis_dir)):
                continue
            for name in files:
                src = os.path.join(root, name)
                lower = name.lower()
                if lower.endswith(".xyz") and copied_xyz < 300:
                    self._copy_loose_file(src, inputs_dir, used)
                    copied_xyz += 1
                elif lower.endswith(".out") and copied_out < 300:
                    self._copy_loose_file(src, orca_dir, used)
                    copied_out += 1
                elif lower == "energy_comparison.csv":
                    self._copy_loose_file(src, os.path.join(analysis_dir, "05_Top_Models_Comparison"), used)
        return analysis_dir

    def _analyze_existing_folder(self):
        folder = filedialog.askdirectory(title="Select existing IAK result folder or folder containing XYZ/ORCA files")
        if not folder:
            return
        folder = os.path.abspath(folder)
        self._reset_progress_ui()
        self._apply_progress_payload({"stage": "Validation", "percent": 5.0, "status": "running", "message": "Scanning existing folder.", "elapsed_seconds": 0.0})
        self._append_text(f"\n[Existing Analysis] Scanning folder: {folder}\n")
        try:
            job_dirs = self._find_iak_job_dirs(folder)
            if not job_dirs:
                self._append_text("[Existing Analysis] No IAK folder structure found. Creating loose-file analysis folder...\n")
                job_dirs = [self._create_loose_folder_analysis(folder)]

            results = []
            total = max(len(job_dirs), 1)
            started = time.time()
            for idx, job_dir in enumerate(job_dirs, start=1):
                percent = 10.0 + 80.0 * ((idx - 1) / total)
                self._apply_progress_payload({
                    "stage": "Reports",
                    "percent": percent,
                    "status": "running",
                    "message": f"Analyzing existing job {idx}/{total}.",
                    "elapsed_seconds": time.time() - started,
                })
                results.append(self._write_existing_analysis_outputs(job_dir))

            first_job = results[0]["job_dir"]
            self._vars["out"].set(first_job)
            if MATPLOTLIB_AVAILABLE:
                self._vars_graph["dir1"].set(folder if len(results) > 1 else first_job)
                self._vars_graph["name1"].set(os.path.basename(folder.rstrip("\\/")) or "Existing Data")
                if hasattr(self, "thermo_tree"):
                    self._refresh_thermo_table()
            self._refresh_results()
            self.nb.select(self.tab_res)
            self._apply_progress_payload({
                "stage": "Complete",
                "percent": 100.0,
                "status": "completed",
                "message": f"Analyzed {len(results)} existing folder(s).",
                "elapsed_seconds": time.time() - started,
            })
            self._append_text(f"[Existing Analysis] Complete. Loaded results from: {first_job}\n")
            messagebox.showinfo(
                "Existing Folder Analysis Complete",
                f"Analyzed {len(results)} folder(s).\n\nLoaded first result folder:\n{first_job}\n\nReports and Energy_Comparison.csv files were generated where possible.",
            )
        except Exception as exc:
            self._append_text(f"[Existing Analysis Error] {exc}\n")
            self._apply_progress_payload({"stage": "Failed", "percent": 100.0, "status": "failed", "message": str(exc), "elapsed_seconds": 0.0})
            messagebox.showerror("Existing Folder Analysis Error", str(exc))

    def _analyze_existing_files(self):
        files = filedialog.askopenfilenames(
            title="Select existing ORCA .out and/or XYZ files",
            filetypes=[
                ("ORCA output and XYZ", "*.out *.xyz"),
                ("ORCA output", "*.out"),
                ("XYZ structures", "*.xyz"),
                ("All files", "*.*"),
            ],
        )
        files = [os.path.abspath(path) for path in files if path.lower().endswith((".out", ".xyz"))]
        if not files:
            return
        self._reset_progress_ui()
        started = time.time()
        self._apply_progress_payload({
            "stage": "Validation",
            "percent": 5.0,
            "status": "running",
            "message": f"Preparing {len(files)} selected file(s).",
            "elapsed_seconds": 0.0,
        })
        try:
            analysis_dir, copied_xyz, copied_out = self._prepare_selected_files_analysis_dir(files)
            self._append_text(
                f"\n[Existing File Analysis] Selected {len(files)} file(s): "
                f"{copied_xyz} XYZ and {copied_out} ORCA OUT copied into {analysis_dir}\n"
            )
            self._apply_progress_payload({
                "stage": "Reports",
                "percent": 55.0,
                "status": "running",
                "message": "Parsing selected files and writing analysis outputs.",
                "elapsed_seconds": time.time() - started,
            })
            result = self._write_existing_analysis_outputs(analysis_dir)
            self._vars["out"].set(analysis_dir)
            if MATPLOTLIB_AVAILABLE:
                self._vars_graph["dir1"].set(analysis_dir)
                self._vars_graph["name1"].set("Selected Files")
                if hasattr(self, "thermo_tree"):
                    self._refresh_thermo_table()
            self._refresh_results()
            self.nb.select(self.tab_res)
            self._apply_progress_payload({
                "stage": "Complete",
                "percent": 100.0,
                "status": "completed",
                "message": "Selected file analysis complete.",
                "elapsed_seconds": time.time() - started,
            })
            messagebox.showinfo(
                "Existing File Analysis Complete",
                "Selected files were analyzed.\n\n"
                f"Analysis folder:\n{analysis_dir}\n\n"
                f"XYZ files: {copied_xyz}\nORCA .out files: {copied_out}\n"
                f"Energy rows parsed: {result['rows']}",
            )
        except Exception as exc:
            self._append_text(f"[Existing File Analysis Error] {exc}\n")
            self._apply_progress_payload({
                "stage": "Failed",
                "percent": 100.0,
                "status": "failed",
                "message": str(exc),
                "elapsed_seconds": time.time() - started,
            })
            messagebox.showerror("Existing File Analysis Error", str(exc))

    def _resume_existing_job(self):
        folder = filedialog.askdirectory(title="Select stopped/failed IAK job folder or parent folder")
        if not folder:
            return
        folder = os.path.abspath(folder)
        job_dirs = self._find_iak_job_dirs(folder)
        if not job_dirs:
            return messagebox.showerror("Resume Job", "No IAK job folder was found in the selected location.")
        job_dir = job_dirs[0]
        inputs_dir = os.path.join(job_dir, "01_Inputs_and_Clusters")
        anchor = os.path.join(inputs_dir, "raw_input_anchor.xyz")
        guest = os.path.join(inputs_dir, "raw_input_guest.xyz")
        if not os.path.exists(anchor):
            candidates = list(Path(inputs_dir).glob("*.xyz")) if os.path.isdir(inputs_dir) else []
            anchor = str(candidates[0]) if candidates else ""
        if anchor and os.path.exists(anchor):
            self._vars["a"].set(anchor)
        if os.path.exists(guest):
            self._vars["b"].set(guest)
        else:
            self._vars["b"].set("")
        folder_name = os.path.basename(job_dir.rstrip("\\/"))
        match = re.search(r"(\d+)[_:](\d+)$", folder_name)
        if match:
            self._vars["ratio"].set(f"{match.group(1)}:{match.group(2)}")
        self._vars["out"].set(job_dir)
        self._refresh_results()
        self.nb.select(self.tab_main)
        self._append_text(
            f"\n[Resume] Loaded existing job folder:\n{job_dir}\n"
            "Press START BATCH PIPELINE to continue. Successful stages in state.json will be skipped automatically.\n"
        )
        messagebox.showinfo(
            "Resume Ready",
            "Existing job loaded.\n\nPress START BATCH PIPELINE to continue from the saved state.\nAlready successful xTB/CREST/ORCA jobs will be skipped.",
        )

    def _update_guest_count_label(self):
        n = len(self._guest_list)
        color = _C["green"] if n > 0 else _C["muted"]
        self._guest_count_lbl.config(
            text=f"{n} guest(s) queued" if n != 1 else "1 guest queued",
            fg=color)

    def _start(self):
        v = {}
        for k, var in self._vars.items():
            val = var.get().strip(" \"'")
            if k in ["a", "b"] and val:
                val = os.path.abspath(val)
            v[k] = val
        inject_embedded_engines()
        self._update_installation_labels()
        if not os.path.isfile(v["a"]):
            self._append_text(f"\n[Error] Anchor XYZ file not found or invalid path: {v['a']}\n")
            return messagebox.showerror("Error", f"Anchor XYZ file not found:\n{v['a']}")

        # Resolve effective guest list: multi-guest panel takes priority over legacy field
        effective_guests = [p for p in self._guest_list if os.path.isfile(p)]
        if not effective_guests and v["b"] and os.path.isfile(v["b"]):
            effective_guests = [v["b"]]

        if not effective_guests:
            if "0" not in v["ratio"]:
                ans = messagebox.askyesno("Single Molecule Mode",
                    "No Guest (B) file found in queue or legacy field.\n"
                    "Run as single isolated molecule (Ratio 1:0)?")
                if ans:
                    v["ratio"] = "1:0"
                else:
                    return
        v["_guests"] = effective_guests  # pass resolved list to worker
        self._reset_progress_ui()
        self.go_btn.config(state="disabled", text="RUNNING BATCH QUEUE...")
        self.nb.select(0)
        g_count = len(effective_guests)
        self._append_text(
            f"\n[System] Initialization complete. "
            f"{g_count} guest molecule(s) queued. "
            f"Booting Batch Pipeline Thread...\n")
        self.start_time = time.time()
        self.is_running = True
        threading.Thread(target=self._worker, args=(v,), daemon=True).start()

    def _worker(self, v):
        try:
            mode_name = v.get("mode", "balanced").lower()
            base_mode = RunMode.BALANCED if mode_name == "custom" else RunMode[mode_name.upper()]
            config = Config.from_mode(base_mode)
            config.preopt_inputs = self.run_preopt.get()
            try:
                config.cores = int(v.get("cores", 4))
                config.maxcore = int(v.get("maxcore", 2000))
                config.charge = int(v.get("charge", 0))
                config.multiplicity = int(v.get("mult", 1))
                config.n_generate = int(v.get("n_generate", config.n_generate))
                config.n_keep_scored = int(v.get("n_keep_scored", config.n_keep_scored))
                config.n_keep_clustered = int(v.get("n_keep_clustered", config.n_keep_clustered))
                config.n_run_xtb = int(v.get("n_run_xtb", config.n_run_xtb))
                config.n_run_crest = int(v.get("n_run_crest", config.n_run_crest))
                config.random_seed = int(v.get("random_seed", config.random_seed))
                config.max_placement_attempts = int(v.get("max_placement_attempts", config.max_placement_attempts))
                config.rmsd_cutoff = float(v.get("rmsd_cutoff", config.rmsd_cutoff))
                config.xtb_ewin_kcal = float(v.get("xtb_ewin_kcal", config.xtb_ewin_kcal))
                config.crest_ewin_kcal = float(v.get("crest_ewin_kcal", config.crest_ewin_kcal))
            except ValueError:
                raise RuntimeError("Host-controlled numerical inputs must be valid numbers.")
            if config.n_generate < 1 or config.n_keep_scored < 1 or config.n_keep_clustered < 1:
                raise RuntimeError("Generate/keep counts must be at least 1.")
            if config.n_run_xtb < 0 or config.n_run_crest < 0:
                raise RuntimeError("xTB/CREST run counts cannot be negative.")
            if config.max_placement_attempts < 1:
                raise RuntimeError("Placement attempts must be at least 1.")
            config.xtb_method = v.get("xtb_method", config.xtb_method).strip() or "--gfn2"
            config.crest_method = v.get("crest_method", config.crest_method).strip() or "--gfn2"
            config.orca_method = v.get("orca_method", "B97-3c Opt Freq")
            config.report_options = self._get_report_options()
            reaction_type = normalize_reaction_type(v.get("reaction_type", "Non-covalent"))
            try:
                if v.get("e_a"):
                    config.energy_a = float(v.get("e_a"))
                if v.get("e_b"):
                    config.energy_b = float(v.get("e_b"))
            except ValueError:
                raise RuntimeError("Monomer Energies must be valid decimals. Leave empty if not calculating Binding Energy.")
            ratio_pairs = []
            for r in v["ratio"].split(","):
                r = r.strip()
                if not r:
                    continue
                if ":" in r:
                    parts = tuple(int(p) for p in r.split(":"))
                    ratio_pairs.append(parts)
                else:
                    ratio_pairs.append((1, int(r)))
            if not ratio_pairs:
                raise RuntimeError("Please provide at least one valid ratio (e.g., 1:0, 1:1).")

            # Resolve guest files: multi-guest list (may be empty → single-molecule mode)
            guest_paths = v.get("_guests") or ([] if not v.get("b") else [v["b"]])
            if not guest_paths:
                guest_paths = [None]  # sentinel → single-molecule

            base_out_dir = v["out"].rstrip("/\\ ")
            # Simple, unambiguous prefix: append "_" to whatever the user typed.
            # Do NOT regex-strip trailing digits — that mangles paths like "CO_H2" or "_1_1_2".
            prefix = base_out_dir + "_"

            total_jobs = len(ratio_pairs)
            job_idx = 0
            for r_tuple in ratio_pairs:
                job_idx += 1
                n_A = r_tuple[0]
                n_guests_list = list(r_tuple[1:]) if len(r_tuple) > 1 else [0]

                # Build ratio_label from the ORIGINAL tuple BEFORE any padding so that
                # "1:1", "1:1:0", "1:1:0:0" each produce a UNIQUE output folder even
                # when n_guests_list gets extended to the same length by the next block.
                ratio_label = "_".join(map(str, r_tuple))

                # Align n_guests_list length with queued guest files (placement counts only)
                if guest_paths != [None]:
                    if len(n_guests_list) > len(guest_paths):
                        self.root.after(0, lambda r=r_tuple, ng=len(n_guests_list), gp=len(guest_paths): self._append_text(
                            f"\n[WARNING] Ratio {r}: {ng} guest component(s) specified but only {gp} guest file(s) queued. Extra ignored.\n"))
                        n_guests_list = n_guests_list[:len(guest_paths)]
                    elif len(n_guests_list) < len(guest_paths):
                        n_guests_list.extend([0] * (len(guest_paths) - len(n_guests_list)))

                # If ratio signifies single molecule (either no guest or 0 copies of all guests)
                is_single = (sum(n_guests_list) == 0)

                try:
                    # Validation inside the per-ratio try so one bad ratio doesn't abort the rest
                    if n_A < 0 or any(x < 0 for x in n_guests_list):
                        raise RuntimeError(f"Negative stoichiometry is not allowed: {r_tuple}")
                    if n_A == 0 and is_single:
                        raise RuntimeError(f"Invalid ratio {r_tuple}: at least one species count must be > 0.")

                    current_out_name = f"{prefix}{ratio_label}"
                    current_out = os.path.abspath(current_out_name)
                    self.root.after(0, lambda o=current_out_name: self._vars["out"].set(o))
                    self.root.after(0, lambda r=r_tuple, o=current_out_name, ji=job_idx, jt=total_jobs:
                        self._append_text(
                            f"\n{'=' * 70}\n"
                            f"[BATCH QUEUE] Job {ji}/{jt} | Ratio {r} | Folder: {o}\n"
                            f"{'=' * 70}\n"))
                    
                    eff_a_path = v["a"] if n_A > 0 else None
                    eff_b_paths = guest_paths if not is_single else []

                    # Validate and auto-correct spin multiplicity based on total electrons.
                    anchor_mol = Molecule.from_xyz(eff_a_path) if eff_a_path and os.path.exists(eff_a_path) else Molecule([])
                    guest_mols = [Molecule.from_xyz(p) for p in eff_b_paths if p and os.path.exists(p)]
                    job_config = dataclasses.replace(config)
                    cm_check = validate_charge_multiplicity(
                        anchor_mol,
                        guest_mols,
                        n_A,
                        n_guests_list,
                        job_config.charge,
                        job_config.multiplicity,
                    )
                    if not cm_check["valid"]:
                        total_electrons = cm_check.get("total_electrons")
                        suggested = int(cm_check.get("suggested_multiplicity", job_config.multiplicity))
                        if total_electrons is not None and total_electrons > 0 and suggested >= 1:
                            old_mult = job_config.multiplicity
                            job_config.multiplicity = suggested
                            self.root.after(
                                0,
                                lambda r=r_tuple, m=cm_check["message"], om=old_mult, sm=suggested: self._append_text(
                                    f"\n[SPIN AUTO-CORRECTION] Ratio {r}: {m} "
                                    f"Using multiplicity {om} -> {sm}.\n"
                                ),
                            )
                        else:
                            raise RuntimeError(f"Ratio {r_tuple}: {cm_check['message']}")
                    else:
                        self.root.after(
                            0,
                            lambda r=r_tuple, te=cm_check.get("total_electrons"): self._append_text(
                                f"[Validation] Ratio {r}: total electrons = {te}; charge/multiplicity validated.\n"
                            ),
                        )
                    
                    pipe = Pipeline(
                        eff_a_path,
                        eff_b_paths,
                        n_guests_list,
                        job_config,
                        current_out,
                        ratio_label=ratio_label,
                        progress_cb=self._progress_cb,
                        reaction_type=reaction_type,
                        n_anchor=n_A,
                    )
                    pipe.run(run_xtb=self.run_xtb.get(), run_crest=self.run_crest.get(),
                             run_orca=self.run_orca.get(), log_cb=self._append_text,
                             status_cb=self._status_cb)
                    self.root.after(0, self._refresh_results)
                except Exception as iter_e:
                    self.root.after(0, lambda e=iter_e, r=r_tuple:
                        self._append_text(
                            f"\n[CRITICAL BATCH ERROR] Ratio {r} aborted: "
                            f"{str(e)}. Proceeding to next job...\n"))
            self.root.after(0, lambda jt=total_jobs: messagebox.showinfo(
                "Batch Complete",
                f"All {jt} job(s) completed!\n\n"
                f"Guests processed: {len(guest_paths) if guest_paths != [None] else 0}\n"
                f"Ratios processed: {len(ratio_pairs)}\n\n"
                "Check the respective folders for Top Models, Energy CSVs, and Job Summary Reports."))
        except Exception as e:
            self.root.after(0, lambda e=e: self._append_text(f"\n[CRITICAL ERROR] Pipeline aborted: {str(e)}\n"))
            self.root.after(0, lambda e=e: messagebox.showerror("Error", str(e)))
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.go_btn.config(state="normal", text="START BATCH PIPELINE"))

    def _pes_log(self, text):
        self.root.after(0, lambda: self.pes_term.config(state="normal"))
        self.root.after(0, lambda: self.pes_term.insert("end", text + "\n"))
        self.root.after(0, lambda: self.pes_term.see("end"))
        self.root.after(0, lambda: self.pes_term.config(state="disabled"))

    def _start_pes(self):
        v = {k: var.get() for k, var in self._vars_pes.items()}
        if not v["reactant"] or not os.path.exists(v["reactant"]):
            return messagebox.showerror("Error", "Valid Reactant XYZ is required for PES Scan.")
        self.btn_run_pes.config(state="disabled", text="RUNNING PES/TS...")
        self._pes_log("="*60)
        self._pes_log(" INITIALIZING PES & TS SEARCH PIPELINE ")
        self._pes_log("="*60)
        threading.Thread(target=self._worker_pes, args=(v,), daemon=True).start()

    def _worker_pes(self, v):
        try:
            # 1. Parse Input Geometry
            react_path = os.path.abspath(v["reactant"])
            react_name = os.path.splitext(os.path.basename(react_path))[0]
            work_dir = os.path.abspath(f"PES_{react_name}_{int(time.time())}")
            os.makedirs(work_dir, exist_ok=True)
            shutil.copy2(react_path, os.path.join(work_dir, "reactant.xyz"))
            reaction_type = normalize_reaction_type(self._vars.get("reaction_type").get() if "reaction_type" in self._vars else "Non-covalent")

            charge = _safe_int(self._vars.get("charge").get() if "charge" in self._vars else 0)
            multiplicity = _safe_int(self._vars.get("mult").get() if "mult" in self._vars else 1)
            if charge is None:
                raise RuntimeError("System charge must be an integer for PES/TS calculations.")
            if multiplicity is None or multiplicity < 1:
                raise RuntimeError("Multiplicity must be a positive integer for PES/TS calculations.")

            reactant_mol = Molecule.from_xyz(react_path)
            pes_cm_check = validate_charge_multiplicity(reactant_mol, [], 1, [], charge, multiplicity)
            if not pes_cm_check["valid"]:
                total_electrons = pes_cm_check.get("total_electrons")
                suggested = int(pes_cm_check.get("suggested_multiplicity", multiplicity))
                if total_electrons is not None and total_electrons > 0 and suggested >= 1:
                    self._pes_log(
                        f"[SPIN AUTO-CORRECTION] {pes_cm_check['message']} "
                        f"Using multiplicity {multiplicity} -> {suggested}."
                    )
                    multiplicity = suggested
                else:
                    raise RuntimeError(pes_cm_check["message"])
            else:
                self._pes_log(f"[Validation] Total electrons = {pes_cm_check.get('total_electrons')}; charge/multiplicity validated.")
            
            scan_mode = v.get("scan_mode", "coord")
            engine = v["engine"]
            
            if scan_mode == "path":
                if not v["product"] or not os.path.exists(v["product"]):
                    raise RuntimeError("Product XYZ is required for Reactant -> Product Path Interpolation.")
                prod_path = os.path.abspath(v["product"])
                shutil.copy2(prod_path, os.path.join(work_dir, "product.xyz"))
                product_mol = Molecule.from_xyz(prod_path)
                balanced, balance_message = validate_reactant_product_atom_balance(reactant_mol, product_mol, reaction_type)
                if not balanced:
                    raise RuntimeError(balance_message)
                self._pes_log(f"[Validation] {balance_message}")
                
                self._pes_log(f"Working Directory: {work_dir}")
                self._pes_log(f"Engine: {engine.upper()}")
                self._pes_log(f"Mode: Reactant -> Product Path Interpolation ({reaction_type})")
                
                if engine == "xtb":
                    self._run_xtb_path(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_neb(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_neb(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                else:
                    raise RuntimeError(f"Engine {engine} not supported for Path Interpolation.")
            else:
                try:
                    c1_a1, c1_a2 = int(v["c1_a1"]), int(v["c1_a2"])
                    c1_s, c1_e, c1_steps = float(v["c1_start"]), float(v["c1_end"]), int(v["c1_steps"])
                except ValueError:
                    raise RuntimeError("Invalid values for Coordinate 1. Must be numerical.")
                
                use_c2 = int(v["use_c2"]) == 1
                if use_c2:
                    try:
                        c2_a1, c2_a2 = int(v["c2_a1"]), int(v["c2_a2"])
                        c2_s, c2_e, c2_steps = float(v["c2_start"]), float(v["c2_end"]), int(v["c2_steps"])
                    except ValueError:
                        raise RuntimeError("Invalid values for Coordinate 2. Must be numerical.")
                else:
                    c2_a1=c2_a2=c2_s=c2_e=c2_steps=None
                
                self._pes_log(f"Working Directory: {work_dir}")
                self._pes_log(f"Engine: {engine.upper()}")
                self._pes_log("Mode: Coordinate Grid Scan")
                
                if engine == "xtb":
                    self._run_xtb_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                else:
                    raise RuntimeError(f"Engine {engine} not supported for PES.")
                
            # 4. Extract TS Guess and Run OptTS if checked
            run_ts = int(v["run_ts"]) == 1
            if run_ts:
                self._pes_log("\n--- Proceeding to Transition State Refinement ---")
                ts_guess_path = os.path.join(work_dir, "ts_guess.xyz")
                if not os.path.exists(ts_guess_path):
                    raise RuntimeError("Saddle point (ts_guess.xyz) not found from PES scan. Cannot run TS Opt.")
                if engine == "xtb":
                    self._run_xtb_ts(work_dir, ts_guess_path, charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_ts(work_dir, ts_guess_path, charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_ts(work_dir, ts_guess_path, charge, multiplicity)
                    
            self._pes_log("\n[SUCCESS] PES/TS Workflow Completed!")
            self.root.after(0, lambda: messagebox.showinfo("PES/TS Complete", f"Workflow finished.\nOutputs saved in:\n{work_dir}"))
        except Exception as e:
            _emsg = str(e)
            self._pes_log(f"\n[ERROR] PES Pipeline failed: {_emsg}")
            self.root.after(0, lambda m=_emsg: messagebox.showerror("PES Error", m))
        finally:
            self.root.after(0, lambda: self.btn_run_pes.config(state="normal", text="START PES & TS SEARCH"))

    def _run_xtb_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        scan_inp = os.path.join(work_dir, "scan.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  {c1_a1} {c1_a2} : {c1_s}, {c1_e}, {c1_steps}\n")
            if use_c2:
                f.write(f"  {c2_a1} {c2_a2} : {c2_s}, {c2_e}, {c2_steps}\n")
            f.write("$end\n")
        self._pes_log("Running xTB relaxed scan... (This may take a while)")
        
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
             raise RuntimeError("xTB not found on path.")
             
        cmd = f"\"{xtb_exe}\" {mol_file} --opt --input scan.inp"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_pes.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
            
        self._pes_log("xTB Scan finished. Parsing xtbscan.log...")
        scan_log = os.path.join(work_dir, "xtbscan.log")
        if not os.path.exists(scan_log):
             raise RuntimeError("xtbscan.log not found. The xTB scan failed.")
             
        energies = []
        geoms = []
        with open(scan_log, "r") as f:
             lines = f.readlines()
        
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 if "energy:" in lines[i+1]:
                     en = float(re.search(r"energy:\s*([-0-9.]+)", lines[i+1]).group(1))
                 else:
                     en = 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No step energies found in xtbscan.log.")
             
        self._pes_log(f"Extracted {len(energies)} points from scan.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy point found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        if use_c2 and MATPLOTLIB_AVAILABLE:
            self._generate_3d_pes_plot(work_dir, c1_steps, c2_steps, energies)

    def _run_orca_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        self._pes_log("Running ORCA relaxed scan... (This may take a very long time)")
        mol = Molecule.from_xyz(os.path.join(work_dir, mol_file))
        inp_path = os.path.join(work_dir, "orca_pes.inp")
        
        # NOTE: ORCA atom indices are 0-based for scanning!
        with open(inp_path, "w") as f:
            f.write("! B97-3c Opt\n")
            f.write("%geom Scan\n")
            f.write(f"  B {c1_a1-1} {c1_a2-1} = {c1_s}, {c1_e}, {c1_steps}\n")
            if use_c2:
                f.write(f"  B {c2_a1-1} {c2_a2-1} = {c2_s}, {c2_e}, {c2_steps}\n")
            f.write("end end\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_pes.inp > orca_pes.out"
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_pes.out")
        if not os.path.exists(out_path):
             raise RuntimeError("orca_pes.out not found. The ORCA scan failed.")
             
        trj_path = os.path.join(work_dir, "orca_pes.trj")
        if not os.path.exists(trj_path):
             self._pes_log("Warning: orca_pes.trj not found. Attempting to parse ORCA output for TS guess manually.")
             # Very basic fallback
             return

        # Parse orca.trj
        energies = []
        geoms = []
        with open(trj_path, "r") as f:
             lines = f.readlines()
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 en_match = re.search(r"[-0-9.]+", lines[i+1])
                 en = float(en_match.group(0)) if en_match else 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No step energies found in orca_pes.trj.")
             
        self._pes_log(f"Extracted {len(energies)} points from ORCA scan.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy point found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        if use_c2 and MATPLOTLIB_AVAILABLE:
            self._generate_3d_pes_plot(work_dir, c1_steps, c2_steps, energies)

    def _run_xtb_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log("Running xTB Transition State Optimization (--opt ts)...")
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        ts_mol = os.path.basename(ts_guess_path)
        cmd = f"\"{xtb_exe}\" {ts_mol} --opt ts --hess"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_ts.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
        
        imag_freqs = []
        for line in p.stdout.splitlines():
            if re.match(r"^\s*\d+\s+-\d+\.\d+", line):
                parts = line.split()
                if len(parts) >= 2 and float(parts[1]) < 0:
                     imag_freqs.append(float(parts[1]))
                     
        self._pes_log(f"xTB TS Output: Found {len(imag_freqs)} imaginary frequencies.")
        if len(imag_freqs) == 1:
             self._pes_log(f"SUCCESS: True TS confirmed! Imaginary mode: {imag_freqs[0]} cm-1")
        else:
             self._pes_log(f"WARNING: Found {len(imag_freqs)} imaginary modes. This might not be a valid TS.")

    def _run_orca_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log("Generating ORCA OptTS input...")
        mol = Molecule.from_xyz(ts_guess_path)
        inp_path = os.path.join(work_dir, "orca_ts.inp")
        with open(inp_path, "w") as f:
            f.write("! B97-3c OptTS Freq\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_ts.inp > orca_ts.out"
        self._pes_log("Running ORCA OptTS... (this may take a long time)")
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_ts.out")
        if not os.path.exists(out_path):
            raise RuntimeError("ORCA TS output not found.")
            
        with open(out_path, "r") as f:
            content = f.read()
            
        imag_freqs = re.findall(r"^\s*\d+:\s+-\d+\.\d+\s+cm\*\*-1", content, re.MULTILINE)
        self._pes_log(f"ORCA TS Output: Found {len(imag_freqs)} imaginary frequencies.")
        if len(imag_freqs) == 1:
             self._pes_log(f"SUCCESS: True TS confirmed! Imaginary mode: {imag_freqs[0].strip()}")
        else:
             self._pes_log(f"WARNING: Found {len(imag_freqs)} imaginary modes. This might not be a valid TS.")

    def _run_goat_neb(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log(f"Generating GOAT NEB-TS input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_neb.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"NEB\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    reactant: \"{reactant_file}\"\n    product: \"{product_file}\"\n")
            f.write(f"    charge: {charge}\n    multiplicity: {multiplicity}\n")
        self._pes_log("Running Chemrefine GOAT NEB...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    def _run_goat_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        self._pes_log(f"Generating GOAT PES input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_pes.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"PES\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    geometry: \"{mol_file}\"\n")
            f.write(f"    scan:\n      - atoms: [{c1_a1}, {c1_a2}]\n        start: {c1_s}\n        end: {c1_e}\n        steps: {c1_steps}\n")
            if use_c2:
                f.write(f"      - atoms: [{c2_a1}, {c2_a2}]\n        start: {c2_s}\n        end: {c2_e}\n        steps: {c2_steps}\n")
        self._pes_log("Running Chemrefine GOAT PES...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    def _run_goat_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log(f"Generating GOAT TS Refinement input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_ts.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"OPT+TS\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    geometry: \"{os.path.basename(ts_guess_path)}\"\n")
        self._pes_log("Running Chemrefine GOAT TS Optimization...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    # =========================================================================
    # TRANSITION STATE PREDICTION METHODS
    # =========================================================================

    def _predict_ts_from_scan(self, energies: list, coords: list, work_dir: str) -> dict:
        """Predict TS location from a 1-D PES scan using cubic-spline interpolation.

        Parameters
        ----------
        energies : list of float
            Raw energies (Hartree) at each scan step.
        coords   : list of float
            Corresponding coordinate values (Å or degrees).
        work_dir : str
            Directory to write the spline-predicted PES plot and report.

        Returns
        -------
        dict with keys:
            ts_coord   – predicted TS coordinate value
            ts_energy  – spline energy at TS (Eh)
            ts_index   – raw-data index closest to TS
            barrier_fwd – forward  barrier ΔE‡ in kcal/mol
            barrier_rev – reverse barrier ΔE‡ in kcal/mol
            delta_e    – reaction energy ΔErxn in kcal/mol
        """
        import numpy as np
        EH2KCAL = 627.5094740631

        n = len(energies)
        if n < 4:
            self._pes_log("[TS-Predict] Need at least 4 scan points for spline interpolation.")
            return {}

        x = np.array(coords, dtype=float)
        y = np.array(energies, dtype=float)

        # Cubic spline via numpy (no scipy required)
        try:
            from scipy.interpolate import CubicSpline
            cs = CubicSpline(x, y)
            x_fine = np.linspace(x[0], x[-1], 2000)
            y_fine = cs(x_fine)
            y_deriv = cs(x_fine, 1)   # first derivative
        except ImportError:
            # Fallback: parabolic fit around raw maximum
            self._pes_log("[TS-Predict] scipy not available — using raw-data maximum as TS guess.")
            max_idx = int(np.argmax(y))
            result = {
                "ts_coord": float(x[max_idx]),
                "ts_energy": float(y[max_idx]),
                "ts_index": max_idx,
                "barrier_fwd": float((y[max_idx] - y[0]) * EH2KCAL),
                "barrier_rev": float((y[max_idx] - y[-1]) * EH2KCAL),
                "delta_e": float((y[-1] - y[0]) * EH2KCAL),
            }
            self._pes_log(
                f"[TS-Predict] Raw-max TS at coord={result['ts_coord']:.4f}, "
                f"ΔE‡(fwd)={result['barrier_fwd']:.2f} kcal/mol"
            )
            return result

        # Find sign-change of derivative → saddle point
        sign_changes = np.where(np.diff(np.sign(y_deriv)))[0]
        # Keep only local maxima (deriv goes + → -)
        max_idxs = [i for i in sign_changes if y_deriv[i] > 0]

        if not max_idxs:
            # No saddle found by derivative; fall back to global max
            max_idxs = [int(np.argmax(y_fine))]

        # Pick the highest saddle
        saddle_i = max_idxs[int(np.argmax([y_fine[i] for i in max_idxs]))]
        ts_coord = float(x_fine[saddle_i])
        ts_energy = float(y_fine[saddle_i])
        ts_index = int(np.argmin(np.abs(x - ts_coord)))

        e_react = float(y[0])
        e_prod = float(y[-1])
        barrier_fwd = (ts_energy - e_react) * EH2KCAL
        barrier_rev = (ts_energy - e_prod) * EH2KCAL
        delta_e = (e_prod - e_react) * EH2KCAL

        result = {
            "ts_coord": ts_coord,
            "ts_energy": ts_energy,
            "ts_index": ts_index,
            "barrier_fwd": barrier_fwd,
            "barrier_rev": barrier_rev,
            "delta_e": delta_e,
        }

        self._pes_log(
            f"[TS-Predict] Spline saddle-point: coord={ts_coord:.4f}, "
            f"E(TS)={ts_energy:.6f} Eh\n"
            f"  ΔE‡(fwd) = {barrier_fwd:.2f} kcal/mol\n"
            f"  ΔE‡(rev) = {barrier_rev:.2f} kcal/mol\n"
            f"  ΔErxn    = {delta_e:.2f} kcal/mol"
        )

        # Write text report
        report_path = os.path.join(work_dir, "ts_prediction_report.txt")
        with open(report_path, "w") as f:
            f.write("IAK Transition State Prediction Report\n")
            f.write("=" * 45 + "\n\n")
            f.write(f"Method: Cubic-spline saddle-point detection\n")
            f.write(f"Scan points used: {n}\n\n")
            f.write(f"Predicted TS coordinate : {ts_coord:.6f}\n")
            f.write(f"Predicted TS energy     : {ts_energy:.6f} Eh\n")
            f.write(f"Nearest scan step index : {ts_index} (0-based)\n\n")
            f.write(f"Forward  barrier ΔE‡    : {barrier_fwd:.4f} kcal/mol\n")
            f.write(f"Reverse  barrier ΔE‡    : {barrier_rev:.4f} kcal/mol\n")
            f.write(f"Reaction energy ΔErxn   : {delta_e:.4f} kcal/mol\n\n")
            f.write("All saddle-point candidates (spline maxima):\n")
            for si in max_idxs:
                f.write(f"  coord={x_fine[si]:.4f}  E={y_fine[si]:.6f} Eh\n")
        self._pes_log(f"[TS-Predict] Report saved → {report_path}")

        # Spline plot
        if MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(x, (y - y[0]) * EH2KCAL, "o", color="#388bfd",
                        label="Scan points", zorder=3)
                ax.plot(x_fine, (y_fine - y[0]) * EH2KCAL, "-",
                        color="#17a2b8", lw=2, label="Cubic spline")
                ax.axvline(ts_coord, color="#e05252", ls="--", lw=1.5,
                           label=f"TS guess ({ts_coord:.3f})")
                ax.scatter([ts_coord], [(ts_energy - y[0]) * EH2KCAL],
                           s=120, color="#e05252", zorder=5)
                ax.set_xlabel("Scan Coordinate")
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("PES Scan — TS Prediction (Spline)")
                ax.legend()
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                plot_path = os.path.join(work_dir, "ts_prediction_spline.png")
                plt.savefig(plot_path, dpi=200)
                plt.close(fig)
                self._pes_log(f"[TS-Predict] Spline plot saved → {plot_path}")
            except Exception as exc:
                self._pes_log(f"[TS-Predict] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _ts_barrier_analysis(
        self,
        e_reactant: float,
        e_ts: float,
        e_product: float,
        label_r: str = "Reactant",
        label_ts: str = "TS",
        label_p: str = "Product",
        work_dir: str = "",
    ) -> dict:
        """Compute thermochemical quantities from three-point energies (Eh).

        Returns a dict:  barrier_fwd, barrier_rev, delta_e (all kcal/mol),
        plus Evans–Polanyi coefficient alpha and a text summary.
        Optionally writes an energy-level diagram PNG to work_dir.
        """
        EH2KCAL = 627.5094740631
        barrier_fwd = (e_ts - e_reactant) * EH2KCAL
        barrier_rev = (e_ts - e_product) * EH2KCAL
        delta_e = (e_product - e_reactant) * EH2KCAL
        # Evans–Polanyi α = ΔE‡(fwd) / (ΔE‡(fwd) + ΔE‡(rev))
        denom = barrier_fwd + barrier_rev
        alpha = barrier_fwd / denom if denom != 0 else float("nan")

        summary = (
            f"  {label_r} → [{label_ts}]‡ → {label_p}\n"
            f"  ΔE‡(fwd) = {barrier_fwd:+.3f} kcal/mol\n"
            f"  ΔE‡(rev) = {barrier_rev:+.3f} kcal/mol\n"
            f"  ΔErxn    = {delta_e:+.3f} kcal/mol\n"
            f"  Evans–Polanyi α = {alpha:.3f}"
        )
        self._pes_log("[Barrier Analysis]\n" + summary)

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 4))
                rel = [0.0, barrier_fwd, delta_e]
                x_pos = [0, 1, 2]
                labels = [label_r, label_ts, label_p]
                colors = ["#388bfd", "#e05252", "#22c55e"]
                for xi, yi, lbl, col in zip(x_pos, rel, labels, colors):
                    ax.hlines(yi, xi - 0.2, xi + 0.2, colors=col, lw=3)
                    ax.text(xi, yi + 0.5, f"{lbl}\n{yi:+.2f}", ha="center",
                            va="bottom", fontsize=9, color=col)
                # Bezier-like connection
                for i in range(len(x_pos) - 1):
                    ax.annotate(
                        "",
                        xy=(x_pos[i + 1] - 0.2, rel[i + 1]),
                        xytext=(x_pos[i] + 0.2, rel[i]),
                        arrowprops=dict(arrowstyle="-", color="#888", lw=1.2,
                                        connectionstyle="arc3,rad=-0.3"),
                    )
                ax.set_xticks([])
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("Energy Level Diagram")
                ax.grid(axis="y", alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "energy_level_diagram.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[Barrier Analysis] Energy diagram saved → {out}")
            except Exception as exc:
                self._pes_log(f"[Barrier Analysis] Plot error: {exc}")

        return {
            "barrier_fwd": barrier_fwd,
            "barrier_rev": barrier_rev,
            "delta_e": delta_e,
            "alpha": alpha,
            "summary": summary,
        }

    # -------------------------------------------------------------------------

    def _interpolate_path_idpp(
        self,
        reactant_xyz: str,
        product_xyz: str,
        n_images: int,
        work_dir: str,
    ) -> list:
        """Generate NEB initial path images via IDPP (Image Dependent Pair Potential)
        linear interpolation with pair-distance correction.

        Returns a list of XYZ-block strings (one per image including endpoints).
        Also writes image_NNN.xyz files to work_dir.
        """
        def _read_xyz(path):
            with open(path) as f:
                lines = f.readlines()
            n = int(lines[0])
            atoms, coords = [], []
            for l in lines[2 : 2 + n]:
                parts = l.split()
                atoms.append(parts[0])
                coords.append([float(parts[1]), float(parts[2]), float(parts[3])])
            return atoms, np.array(coords)

        self._pes_log(f"[IDPP] Generating {n_images} interpolated images …")
        atoms, r_coords = _read_xyz(reactant_xyz)
        _, p_coords = _read_xyz(product_xyz)

        if len(atoms) != len(_):
            raise RuntimeError("Reactant and product have different atom counts.")

        n_atoms = len(atoms)
        images = []
        all_blocks = []

        for k in range(n_images + 2):  # includes endpoints
            t = k / (n_images + 1)
            # Linear interpolation
            coords_k = (1 - t) * r_coords + t * p_coords

            # IDPP correction: repulsion term to prevent atom clashes
            if 0 < k <= n_images:
                for _ in range(5):  # 5 micro-iterations
                    grad = np.zeros_like(coords_k)
                    for i in range(n_atoms):
                        for j in range(i + 1, n_atoms):
                            rij = coords_k[i] - coords_k[j]
                            dist = np.linalg.norm(rij) + 1e-10
                            # Target interpolated distance
                            d_r = np.linalg.norm(r_coords[i] - r_coords[j])
                            d_p = np.linalg.norm(p_coords[i] - p_coords[j])
                            d_target = (1 - t) * d_r + t * d_p + 1e-10
                            f_ij = 2.0 * (dist - d_target) / (d_target ** 4) * (rij / dist)
                            grad[i] += f_ij
                            grad[j] -= f_ij
                    coords_k -= 0.01 * grad

            images.append(coords_k.copy())

            # Build XYZ block
            block = f"{n_atoms}\nImage {k} (IDPP)\n"
            for sym, (x, y, z) in zip(atoms, coords_k):
                block += f"{sym:4s}  {x:12.6f}  {y:12.6f}  {z:12.6f}\n"
            all_blocks.append(block)

            out_xyz = os.path.join(work_dir, f"image_{k:03d}.xyz")
            with open(out_xyz, "w") as f:
                f.write(block)

        self._pes_log(f"[IDPP] Wrote {n_images + 2} images (incl. endpoints) to {work_dir}")
        return all_blocks

    # -------------------------------------------------------------------------

    def _run_orca_ts_with_hessian(
        self, work_dir: str, ts_guess_path: str, charge: int, mult: int,
        method: str = "B97-3c", cores: int = 4,
    ):
        """ORCA OptTS using a pre-computed numerical Hessian as initial Hessian.

        Workflow:
          1. Run a single-point + frequency calculation to obtain the Hessian.
          2. Feed that Hessian into OptTS via InHessName keyword.
          3. Confirm TS: exactly one imaginary frequency.
        """
        self._pes_log("[ORCA-OptTS+Hess] Step 1: Computing numerical Hessian …")
        mol = Molecule.from_xyz(ts_guess_path)
        basename = os.path.splitext(os.path.basename(ts_guess_path))[0]

        # --- Step 1: Hessian calc ---
        hess_inp = os.path.join(work_dir, f"{basename}_hess.inp")
        with open(hess_inp, "w") as f:
            f.write(f"! {method} NumFreq\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        p1 = subprocess.run(
            f"orca {basename}_hess.inp > {basename}_hess.out",
            shell=True, cwd=work_dir, capture_output=False,
        )
        hess_file = os.path.join(work_dir, f"{basename}_hess.hess")
        if not os.path.exists(hess_file):
            self._pes_log("[ORCA-OptTS+Hess] Hessian file not found — falling back to standard OptTS.")
            self._run_orca_ts(work_dir, ts_guess_path, charge, mult)
            return

        self._pes_log("[ORCA-OptTS+Hess] Step 2: Running OptTS with initial Hessian …")
        ts_inp = os.path.join(work_dir, f"{basename}_optts.inp")
        with open(ts_inp, "w") as f:
            f.write(f"! {method} OptTS Freq\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write("%geom\n")
            f.write(f'  InHessName "{basename}_hess.hess"\n')
            f.write("  Calc_Hess false\n")
            f.write("end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        subprocess.run(
            f"orca {basename}_optts.inp > {basename}_optts.out",
            shell=True, cwd=work_dir,
        )
        out_path = os.path.join(work_dir, f"{basename}_optts.out")
        result = self._parse_orca_ts_result(out_path, work_dir)
        self._report_ts_result(result)

    # -------------------------------------------------------------------------

    def _parse_orca_ts_result(self, out_path: str, work_dir: str) -> dict:
        """Parse an ORCA output file to extract TS energy, imaginary frequencies,
        and the optimised TS geometry (written as ts_confirmed.xyz).

        Returns dict: energy_eh, imag_freqs (list[float]), n_imag, converged, ts_xyz_path
        """
        result = {
            "energy_eh": None,
            "imag_freqs": [],
            "n_imag": 0,
            "converged": False,
            "ts_xyz_path": None,
        }
        if not os.path.exists(out_path):
            self._pes_log(f"[ParseORCA-TS] Output not found: {out_path}")
            return result

        with open(out_path, "r", errors="replace") as f:
            content = f.read()
            lines = content.splitlines()

        # Convergence
        result["converged"] = "HURRAY" in content or "THE OPTIMIZATION HAS CONVERGED" in content

        # Final energy
        for line in reversed(lines):
            m = re.search(r"FINAL SINGLE POINT ENERGY\s+([-\d.]+)", line)
            if m:
                result["energy_eh"] = float(m.group(1))
                break

        # Imaginary frequencies (negative values in freq block)
        imag = []
        in_freq = False
        for line in lines:
            if "VIBRATIONAL FREQUENCIES" in line:
                in_freq = True
            if in_freq:
                m = re.match(r"\s*\d+:\s+(-\d+\.\d+)\s+cm\*\*-1", line)
                if m:
                    imag.append(float(m.group(1)))
            if in_freq and line.strip() == "" and imag:
                break  # end of freq block
        result["imag_freqs"] = imag
        result["n_imag"] = len(imag)

        # Extract final optimised geometry
        geom_lines = []
        in_geom = False
        for i, line in enumerate(lines):
            if "CARTESIAN COORDINATES (ANGSTROEM)" in line:
                in_geom = True
                geom_lines = []
                continue
            if in_geom:
                if line.strip() == "" and geom_lines:
                    break
                if re.match(r"\s*[A-Za-z]", line):
                    geom_lines.append(line.strip())

        if geom_lines:
            ts_xyz_path = os.path.join(work_dir, "ts_confirmed.xyz")
            with open(ts_xyz_path, "w") as f:
                f.write(f"{len(geom_lines)}\n")
                f.write(
                    f"TS E={result['energy_eh']} Eh  "
                    f"nimag={result['n_imag']}\n"
                )
                for gl in geom_lines:
                    parts = gl.split()
                    f.write(
                        f"{parts[0]:<4}  "
                        f"{float(parts[1]):15.8f}  "
                        f"{float(parts[2]):15.8f}  "
                        f"{float(parts[3]):15.8f}\n"
                    )
            result["ts_xyz_path"] = ts_xyz_path

        return result

    # -------------------------------------------------------------------------

    def _parse_xtb_ts_result(self, log_path: str, work_dir: str) -> dict:
        """Parse an xTB output/log to extract TS energy and imaginary frequencies.

        Returns dict: energy_eh, imag_freqs, n_imag, converged.
        """
        result = {"energy_eh": None, "imag_freqs": [], "n_imag": 0, "converged": False}
        if not os.path.exists(log_path):
            return result

        with open(log_path, "r", errors="replace") as f:
            lines = f.readlines()

        imag = []
        for line in lines:
            # xTB freq output: "     1     -243.34  (i)" or similar
            m = re.search(r"(-\d+\.\d+)\s+\(i\)", line)
            if m:
                imag.append(float(m.group(1)))
            # Also catch plain negative freq columns
            m2 = re.match(r"^\s*\d+\s+(-\d+\.\d+)\s+cm", line)
            if m2:
                imag.append(float(m2.group(1)))
            # Total energy
            m3 = re.search(r"TOTAL ENERGY\s+([-\d.]+)\s+Eh", line)
            if m3:
                result["energy_eh"] = float(m3.group(1))
            # Convergence
            if "GEOMETRY OPTIMIZATION CONVERGED" in line or "converged" in line.lower():
                result["converged"] = True

        result["imag_freqs"] = list(dict.fromkeys(imag))  # deduplicate
        result["n_imag"] = len(result["imag_freqs"])
        return result

    # -------------------------------------------------------------------------

    def _run_orca_irc(
        self, work_dir: str, ts_xyz_path: str, charge: int, mult: int,
        method: str = "B97-3c", direction: str = "both", cores: int = 4,
    ):
        """Run an Intrinsic Reaction Coordinate (IRC) calculation from a TS geometry.

        direction: 'forward', 'backward', or 'both' (runs two separate ORCA jobs).
        Output: IRC_forward.trj and/or IRC_backward.trj + summary plot.
        """
        if not os.path.exists(ts_xyz_path):
            self._pes_log(f"[IRC] TS file not found: {ts_xyz_path}")
            return

        mol = Molecule.from_xyz(ts_xyz_path)
        dirs = (
            ["forward", "backward"] if direction == "both"
            else [direction]
        )

        energies_by_dir: dict = {}

        for d in dirs:
            self._pes_log(f"[IRC] Running IRC {d} from TS …")
            inp_name = f"irc_{d}.inp"
            out_name = f"irc_{d}.out"
            inp_path = os.path.join(work_dir, inp_name)
            with open(inp_path, "w") as f:
                f.write(f"! {method} IRC\n")
                f.write(f"%pal nprocs {cores} end\n")
                f.write(f"%irc\n")
                f.write(f"  Direction {d.capitalize()}\n")
                f.write(f"  MaxIter 80\n")
                f.write(f"  StepSize 0.1\n")
                f.write("end\n")
                f.write(f"* xyz {charge} {mult}\n")
                for a in mol.atoms:
                    f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
                f.write("*\n")

            subprocess.run(
                f"orca {inp_name} > {out_name}",
                shell=True, cwd=work_dir,
            )

            # Parse IRC energies from trajectory
            trj = os.path.join(work_dir, f"irc_{d}.trj")
            if not os.path.exists(trj):
                # ORCA may name it differently
                alts = [
                    os.path.join(work_dir, f"irc_{d}_IRC_Full_trj.xyz"),
                    os.path.join(work_dir, "IRC_Full_trj.xyz"),
                ]
                for a in alts:
                    if os.path.exists(a):
                        trj = a
                        break

            ens = []
            if os.path.exists(trj):
                with open(trj) as f:
                    lines = f.readlines()
                i = 0
                while i < len(lines):
                    try:
                        nat = int(lines[i].strip())
                        m = re.search(r"([-\d.]+)", lines[i + 1])
                        ens.append(float(m.group(1)) if m else 0.0)
                        i += 2 + nat
                    except Exception:
                        i += 1
                energies_by_dir[d] = ens
                self._pes_log(f"[IRC-{d}] {len(ens)} points parsed.")
            else:
                self._pes_log(f"[IRC-{d}] Trajectory file not found — ORCA may have failed.")

        # Plot combined IRC
        if energies_by_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                EH2KCAL = 627.5094740631
                fig, ax = plt.subplots(figsize=(8, 5))
                offset = 0
                color_map = {"forward": "#388bfd", "backward": "#e05252"}
                for d, ens in energies_by_dir.items():
                    y = np.array(ens)
                    y_rel = (y - y[0]) * EH2KCAL
                    x_irc = np.arange(len(y)) * (1 if d == "forward" else -1) + offset
                    ax.plot(x_irc, y_rel, "-o", ms=3, lw=1.5,
                            color=color_map.get(d, "gray"), label=f"IRC {d}")
                ax.axhline(0, color="#888", ls="--", lw=0.8)
                ax.set_xlabel("IRC Step")
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("Intrinsic Reaction Coordinate (IRC)")
                ax.legend()
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out_plot = os.path.join(work_dir, "IRC_plot.png")
                plt.savefig(out_plot, dpi=200)
                plt.close(fig)
                self._pes_log(f"[IRC] Plot saved → {out_plot}")
            except Exception as exc:
                self._pes_log(f"[IRC] Plot error: {exc}")

    # -------------------------------------------------------------------------

    def _run_xtb_irc(
        self, work_dir: str, ts_xyz_path: str, charge: int, mult: int,
    ):
        """Approximate IRC using xTB --path from TS toward reactant and product.

        xTB does not have a native IRC command; this method runs two path
        calculations: one with the TS as start, one as end, effectively
        tracing both sides of the reaction coordinate under GFN2-xTB.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            self._pes_log("[xTB-IRC] xTB not found on PATH.")
            return

        reactant_path = os.path.join(work_dir, "reactant.xyz")
        product_path = os.path.join(work_dir, "product.xyz")

        for target, label in [(reactant_path, "backward"), (product_path, "forward")]:
            if not os.path.exists(target):
                self._pes_log(f"[xTB-IRC] {label} target file not found: {target}")
                continue
            self._pes_log(f"[xTB-IRC] Path {label}: TS → {label} endpoint …")
            ts_base = os.path.basename(ts_xyz_path)
            cmd = f'"{xtb_exe}" {ts_base} --path {os.path.basename(target)}'
            if charge:
                cmd += f" --chrg {charge}"
            if mult != 1:
                cmd += f" --uhf {mult - 1}"

            irc_dir = os.path.join(work_dir, f"xtb_irc_{label}")
            os.makedirs(irc_dir, exist_ok=True)
            import shutil as _shutil
            _shutil.copy2(ts_xyz_path, irc_dir)
            _shutil.copy2(target, irc_dir)

            p = subprocess.run(cmd, shell=True, cwd=irc_dir,
                               capture_output=True, text=True)
            log_out = os.path.join(irc_dir, f"xtb_irc_{label}.log")
            with open(log_out, "w") as f:
                f.write(p.stdout + p.stderr)
            self._pes_log(f"[xTB-IRC] {label} done — log: {log_out}")

    # -------------------------------------------------------------------------

    def _validate_ts_geometry(
        self,
        ts_xyz_path: str,
        reactant_xyz_path: str,
        product_xyz_path: str,
        bond_cutoff: float = 1.85,
    ) -> dict:
        """Validate that a TS geometry makes chemical sense by checking:
        (a) It has bonds that are breaking/forming relative to reactant and product.
        (b) The imaginary-mode displacement correlates with those bond changes.

        Uses a simple distance-threshold bond matrix (no force field needed).
        Returns a dict with keys: bonds_breaking, bonds_forming, is_valid, notes.
        """
        def _bond_matrix(xyz_path, cutoff):
            mat = {}
            if not os.path.exists(xyz_path):
                return mat
            with open(xyz_path) as f:
                lines = f.readlines()
            n = int(lines[0])
            atoms, coords = [], []
            for l in lines[2:2 + n]:
                p = l.split()
                atoms.append(p[0])
                coords.append([float(p[1]), float(p[2]), float(p[3])])
            for i in range(n):
                for j in range(i + 1, n):
                    d = sum((coords[i][k] - coords[j][k]) ** 2 for k in range(3)) ** 0.5
                    if d < cutoff:
                        mat[(i, j)] = round(d, 4)
            return mat

        r_bonds = _bond_matrix(reactant_xyz_path, bond_cutoff)
        p_bonds = _bond_matrix(product_xyz_path, bond_cutoff)
        ts_bonds = _bond_matrix(ts_xyz_path, bond_cutoff)

        r_set = set(r_bonds)
        p_set = set(p_bonds)
        ts_set = set(ts_bonds)

        # Bonds present in reactant but absent in product → breaking
        breaking = r_set - p_set
        # Bonds present in product but absent in reactant → forming
        forming = p_set - r_set

        # Check TS has partial character for these bonds
        ts_breaking_present = breaking & ts_set
        ts_forming_present = forming & ts_set

        notes = []
        if not breaking and not forming:
            notes.append("No bond changes detected between reactant and product.")
        if ts_breaking_present:
            notes.append(
                f"TS retains {len(ts_breaking_present)}/{len(breaking)} breaking bond(s) — expected for early TS."
            )
        if ts_forming_present:
            notes.append(
                f"TS already has {len(ts_forming_present)}/{len(forming)} forming bond(s) — late TS character."
            )

        is_valid = bool(breaking or forming)

        result = {
            "bonds_breaking": sorted(breaking),
            "bonds_forming": sorted(forming),
            "ts_breaking_present": sorted(ts_breaking_present),
            "ts_forming_present": sorted(ts_forming_present),
            "is_valid": is_valid,
            "notes": notes,
        }

        self._pes_log("[TS-Validate] Bond-change analysis:")
        self._pes_log(f"  Bonds breaking (R→P): {sorted(breaking)}")
        self._pes_log(f"  Bonds forming  (R→P): {sorted(forming)}")
        for note in notes:
            self._pes_log(f"  {note}")
        if is_valid:
            self._pes_log("[TS-Validate] TS geometry is consistent with expected bond changes.")
        else:
            self._pes_log("[TS-Validate] WARNING: No bond changes detected — check atom numbering.")

        return result

    # -------------------------------------------------------------------------

    def _report_ts_result(self, result: dict):
        """Log a human-readable summary of a parsed TS result dict."""
        if result.get("energy_eh") is not None:
            self._pes_log(f"[TS Result] Energy       : {result['energy_eh']:.6f} Eh")
        self._pes_log(f"[TS Result] Converged    : {result.get('converged', 'unknown')}")
        n = result.get("n_imag", 0)
        freqs = result.get("imag_freqs", [])
        if n == 1:
            self._pes_log(
                f"[TS Result] ✓ TRUE TS confirmed — 1 imaginary freq: {freqs[0]:.1f} cm⁻¹"
            )
        elif n == 0:
            self._pes_log(
                "[TS Result] ✗ No imaginary frequencies — geometry converged to a MINIMUM, not a TS."
            )
        else:
            self._pes_log(
                f"[TS Result] ✗ {n} imaginary frequencies found: {freqs} cm⁻¹ — higher-order saddle point."
            )
        if result.get("ts_xyz_path"):
            self._pes_log(f"[TS Result] Geometry saved → {result['ts_xyz_path']}")

    # =========================================================================
    # END TRANSITION STATE PREDICTION METHODS
    # =========================================================================

    def _run_xtb_path(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log("Running xTB Reactant -> Product Path Interpolation (--path)...")
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
             raise RuntimeError("xTB not found on path.")
             
        cmd = f"\"{xtb_exe}\" {reactant_file} --path {product_file}"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        cmd = f"ulimit -s unlimited && export OMP_STACKSIZE=1G && {cmd}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_path.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
            
        self._pes_log("xTB Path Interpolation finished. Parsing xtbpath.xyz...")
        path_log = os.path.join(work_dir, "xtbpath.xyz")
        if not os.path.exists(path_log):
             raise RuntimeError("xtbpath.xyz not found. The xTB path interpolation failed.")
             
        # Extract highest energy point (or just take point #5 if arbitrary)
        # xTB NEB logs energy in the comment line of each frame in xtbpath.xyz
        energies = []
        geoms = []
        with open(path_log, "r") as f:
             lines = f.readlines()
        
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 en_match = re.search(r"energy:\s*([-0-9.]+)", lines[i+1].lower())
                 en = float(en_match.group(1)) if en_match else 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No structures parsed from xtbpath.xyz.")
             
        self._pes_log(f"Extracted {len(energies)} frames from path.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy frame found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        # Optional: Generate a simple 1D plot
        if MATPLOTLIB_AVAILABLE:
            self._generate_1d_pes_plot(work_dir, energies)

    def _run_orca_neb(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log("Running ORCA NEB-TS Interpolation... (This will take a very long time)")
        mol_react = Molecule.from_xyz(os.path.join(work_dir, reactant_file))
        inp_path = os.path.join(work_dir, "orca_neb.inp")
        
        with open(inp_path, "w") as f:
            f.write("! B97-3c OptTS NEB-TS\n")
            f.write(f"%neb NEB_End_XYZFile \"{product_file}\" end\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol_react.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_neb.inp > orca_neb.out"
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_neb.out")
        if not os.path.exists(out_path):
             raise RuntimeError("orca_neb.out not found. The ORCA NEB failed.")
             
        # ORCA NEB-TS automatically performs the TS optimization and outputs it
        # We can extract the final geometry as ts_guess.xyz
        # For simplicity, if ORCA finishes properly, we just look for orca_neb.xyz
        final_xyz = os.path.join(work_dir, "orca_neb.xyz")
        if os.path.exists(final_xyz):
             shutil.copy2(final_xyz, os.path.join(work_dir, "ts_guess.xyz"))
             self._pes_log("Found final ORCA NEB-TS geometry. Saved as ts_guess.xyz")
        else:
             self._pes_log("Warning: orca_neb.xyz not found. Cannot set ts_guess.xyz.")

    def _generate_1d_pes_plot(self, work_dir, energies):
        try:
            import matplotlib.pyplot as plt
            fig = plt.figure(figsize=(8,6))
            plt.plot(range(1, len(energies)+1), energies, marker='o', linestyle='-', color='b')
            plt.title("Reactant -> Product Interpolation Path")
            plt.xlabel("Interpolation Step")
            plt.ylabel("Energy (Eh)")
            plt.grid(True)
            plot_path = os.path.join(work_dir, "Path_1D_Plot.png")
            plt.savefig(plot_path, dpi=300)
            plt.close()
            self._pes_log(f"1D Path Plot saved to {plot_path}")
        except Exception as e:
            self._pes_log(f"Failed to generate 1D plot: {str(e)}")

    def _generate_3d_pes_plot(self, work_dir, c1_steps, c2_steps, energies):
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D
            
            N = len(energies)
            # Adjust dimensions depending on inclusive/exclusive steps. Usually step count = N intervals -> N+1 points.
            # But let's just attempt a safe reshape.
            # Try to infer dims if c1_steps and c2_steps don't match exactly
            import math
            possible_cols = [int(c1_steps), int(c1_steps)+1, int(c2_steps), int(c2_steps)+1]
            cols = None
            for c in possible_cols:
                if c > 0 and N % c == 0:
                    cols = c
                    break
                    
            if cols is None:
                self._pes_log(f"Warning: Cannot reshape energy array ({N} points) for a 3D plot smoothly. Plot skipped.")
                return
                
            rows = N // cols
            Z = np.array(energies).reshape(rows, cols)
            X, Y = np.meshgrid(range(cols), range(rows))
            
            fig = plt.figure(figsize=(8,6))
            ax = fig.add_subplot(111, projection='3d')
            surf = ax.plot_surface(X, Y, Z, cmap='viridis')
            fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
            ax.set_title("2D Relaxed Scan PES")
            ax.set_xlabel("Coord 1 (Steps)")
            ax.set_ylabel("Coord 2 (Steps)")
            ax.set_zlabel("Energy (Eh)")
            
            plot_path = os.path.join(work_dir, "PES_3D_Plot.png")
            plt.savefig(plot_path, dpi=300)
            plt.close()
            self._pes_log(f"3D PES Plot saved to {plot_path}")
        except Exception as e:
            self._pes_log(f"Failed to generate 3D plot: {str(e)}")

    # =========================================================================
    # EXTENDED PES METHODS — Multi-dimensional scans, angular, umbrella, FES
    # =========================================================================

    def _run_xtb_angle_scan(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int, a3: int,
        angle_start: float, angle_end: float, n_steps: int,
        charge: int, mult: int,
    ):
        """Relaxed bond-angle scan using xTB ($scan block with 3-atom angle).

        Writes xtbscan_angle.log and ts_guess_angle.xyz (highest-energy frame).
        Also produces a 1-D plot.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        scan_inp = os.path.join(work_dir, "scan_angle.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  angle: {a1}, {a2}, {a3}, {angle_start}, {angle_end}, {n_steps}\n")
            f.write("$end\n")

        self._pes_log(
            f"[Angle Scan] xTB angle {a1}-{a2}-{a3}: "
            f"{angle_start}° → {angle_end}° in {n_steps} steps …"
        )
        cmd = f'"{xtb_exe}" {mol_file} --opt --input scan_angle.inp'
        if charge:
            cmd += f" --chrg {charge}"
        if mult != 1:
            cmd += f" --uhf {mult - 1}"

        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        log_path = os.path.join(work_dir, "xtb_angle_scan.log")
        with open(log_path, "w") as f:
            f.write(p.stdout + p.stderr)

        scan_log = os.path.join(work_dir, "xtbscan.log")
        energies, geoms = self._parse_xyz_trajectory(scan_log)
        if not energies:
            raise RuntimeError("No energies in xtbscan.log (angle scan).")

        self._pes_log(f"[Angle Scan] {len(energies)} points. Max-E frame → ts_guess_angle.xyz")
        max_i = int(np.argmax(energies))
        with open(os.path.join(work_dir, "ts_guess_angle.xyz"), "w") as f:
            f.write(geoms[max_i])

        angles = np.linspace(angle_start, angle_end, len(energies))
        self._plot_1d_pes(
            work_dir, angles, energies,
            xlabel="Bond Angle (°)",
            title=f"Angle Scan {a1}-{a2}-{a3}",
            filename="angle_scan_pes.png",
        )

    # -------------------------------------------------------------------------

    def _run_xtb_dihedral_scan(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int, a3: int, a4: int,
        dih_start: float, dih_end: float, n_steps: int,
        charge: int, mult: int,
    ):
        """Relaxed dihedral (torsion) scan using xTB (4-atom $scan block).

        Writes xtb_dihedral_scan.log, ts_guess_dihedral.xyz, dihedral_scan_pes.png.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        scan_inp = os.path.join(work_dir, "scan_dih.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  dihedral: {a1}, {a2}, {a3}, {a4}, {dih_start}, {dih_end}, {n_steps}\n")
            f.write("$end\n")

        self._pes_log(
            f"[Dihedral Scan] xTB dihedral {a1}-{a2}-{a3}-{a4}: "
            f"{dih_start}° → {dih_end}° in {n_steps} steps …"
        )
        cmd = f'"{xtb_exe}" {mol_file} --opt --input scan_dih.inp'
        if charge:
            cmd += f" --chrg {charge}"
        if mult != 1:
            cmd += f" --uhf {mult - 1}"

        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_dihedral_scan.log"), "w") as f:
            f.write(p.stdout + p.stderr)

        energies, geoms = self._parse_xyz_trajectory(os.path.join(work_dir, "xtbscan.log"))
        if not energies:
            raise RuntimeError("No energies in xtbscan.log (dihedral scan).")

        max_i = int(np.argmax(energies))
        with open(os.path.join(work_dir, "ts_guess_dihedral.xyz"), "w") as f:
            f.write(geoms[max_i])

        dihedrals = np.linspace(dih_start, dih_end, len(energies))
        self._plot_1d_pes(
            work_dir, dihedrals, energies,
            xlabel="Dihedral Angle (°)",
            title=f"Dihedral Scan {a1}-{a2}-{a3}-{a4}",
            filename="dihedral_scan_pes.png",
        )
        self._pes_log(f"[Dihedral Scan] Done. Max-E step: {max_i + 1}")

    # -------------------------------------------------------------------------

    def _run_orca_2d_pes(
        self,
        work_dir: str,
        mol_file: str,
        c1_a1: int, c1_a2: int, c1_start: float, c1_end: float, c1_steps: int,
        c2_a1: int, c2_a2: int, c2_start: float, c2_end: float, c2_steps: int,
        charge: int, mult: int,
        method: str = "B97-3c",
        cores: int = 4,
    ):
        """Full 2-D relaxed PES scan in ORCA (nested B-scan blocks).

        Generates a filled-contour plot (FES-style) in kcal/mol relative units
        and writes PES_2D_contour.png + PES_2D_data.csv.
        """
        self._pes_log(
            f"[ORCA 2D-PES] Scanning "
            f"B({c1_a1-1},{c1_a2-1}) {c1_start}→{c1_end} × "
            f"B({c2_a1-1},{c2_a2-1}) {c2_start}→{c2_end} with {method} …"
        )
        mol = Molecule.from_xyz(os.path.join(work_dir, mol_file))
        inp_path = os.path.join(work_dir, "orca_2d_pes.inp")
        with open(inp_path, "w") as f:
            f.write(f"! {method} Opt\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write("%geom Scan\n")
            f.write(f"  B {c1_a1-1} {c1_a2-1} = {c1_start}, {c1_end}, {c1_steps}\n")
            f.write(f"  B {c2_a1-1} {c2_a2-1} = {c2_start}, {c2_end}, {c2_steps}\n")
            f.write("end end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        subprocess.run(
            "orca orca_2d_pes.inp > orca_2d_pes.out",
            shell=True, cwd=work_dir,
        )

        trj = os.path.join(work_dir, "orca_2d_pes.trj")
        energies, _ = self._parse_xyz_trajectory(trj)
        if not energies:
            self._pes_log("[ORCA 2D-PES] No trajectory energies found.")
            return

        n_total = len(energies)
        self._pes_log(f"[ORCA 2D-PES] Parsed {n_total} points.")
        self._generate_2d_contour_pes(
            work_dir, energies, c1_steps, c2_steps,
            c1_start, c1_end, c2_start, c2_end,
            xlabel=f"Bond {c1_a1}-{c1_a2} (Å)",
            ylabel=f"Bond {c2_a1}-{c2_a2} (Å)",
        )

    # -------------------------------------------------------------------------

    def _generate_2d_contour_pes(
        self,
        work_dir: str,
        energies: list,
        c1_steps: int, c2_steps: int,
        c1_start: float, c1_end: float,
        c2_start: float, c2_end: float,
        xlabel: str = "Coord 1",
        ylabel: str = "Coord 2",
        filename: str = "PES_2D_contour.png",
    ):
        """Render a filled-contour 2-D PES map in kcal/mol and export CSV."""
        if not MATPLOTLIB_AVAILABLE:
            self._pes_log("[2D-Contour] matplotlib not available — skipping plot.")
            return
        import matplotlib.pyplot as plt
        EH2KCAL = 627.5094740631

        y = np.array(energies, dtype=float)
        # Infer grid shape
        for cols in [c1_steps, c1_steps + 1, c2_steps, c2_steps + 1]:
            if cols > 0 and len(y) % cols == 0:
                rows = len(y) // cols
                break
        else:
            self._pes_log(f"[2D-Contour] Cannot reshape {len(y)} points into grid.")
            return

        Z = (y - y.min()).reshape(rows, cols) * EH2KCAL
        X = np.linspace(c1_start, c1_end, cols)
        Y_ax = np.linspace(c2_start, c2_end, rows)
        XX, YY = np.meshgrid(X, Y_ax)

        fig, ax = plt.subplots(figsize=(7, 6))
        levels = np.linspace(0, Z.max(), 30)
        cf = ax.contourf(XX, YY, Z, levels=levels, cmap="RdYlGn_r")
        ax.contour(XX, YY, Z, levels=levels[::3], colors="k", linewidths=0.5, alpha=0.5)
        cbar = fig.colorbar(cf, ax=ax)
        cbar.set_label("Relative Energy (kcal/mol)")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title("2-D Relaxed PES (Contour)")
        fig.tight_layout()
        out = os.path.join(work_dir, filename)
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[2D-Contour] Plot saved → {out}")

        # CSV export
        csv_path = os.path.join(work_dir, "PES_2D_data.csv")
        with open(csv_path, "w") as f:
            f.write(f"{xlabel},{ylabel},E_rel_kcalmol\n")
            for ri in range(rows):
                for ci in range(cols):
                    f.write(f"{XX[ri,ci]:.4f},{YY[ri,ci]:.4f},{Z[ri,ci]:.4f}\n")
        self._pes_log(f"[2D-Contour] Data CSV saved → {csv_path}")

    # -------------------------------------------------------------------------

    def _plot_1d_pes(
        self,
        work_dir: str,
        x_vals,
        energies: list,
        xlabel: str = "Coordinate",
        ylabel: str = "Energy (Eh)",
        title: str = "PES Scan",
        filename: str = "pes_1d.png",
        relative_kcal: bool = True,
    ):
        """Generic 1-D PES plotter. Converts to kcal/mol relative if requested."""
        if not MATPLOTLIB_AVAILABLE:
            return
        import matplotlib.pyplot as plt
        EH2KCAL = 627.5094740631

        x = np.asarray(x_vals, dtype=float)
        y = np.asarray(energies, dtype=float)
        if relative_kcal:
            y = (y - y[0]) * EH2KCAL
            ylabel = "Relative Energy (kcal/mol)"

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(x, y, "-o", color="#388bfd", ms=4, lw=2)
        ax.fill_between(x, y, alpha=0.12, color="#388bfd")
        ax.axhline(0, color="#888", ls="--", lw=0.8)

        # Mark max
        max_i = int(np.argmax(y))
        ax.scatter([x[max_i]], [y[max_i]], color="#e05252", s=100, zorder=5,
                   label=f"Max ({y[max_i]:.2f})")
        ax.annotate(
            f"{y[max_i]:.2f}",
            (x[max_i], y[max_i]),
            textcoords="offset points", xytext=(6, 6),
            fontsize=8, color="#e05252",
        )

        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        out = os.path.join(work_dir, filename)
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[PES Plot] Saved → {out}")

    # -------------------------------------------------------------------------

    def _parse_xyz_trajectory(self, trj_path: str):
        """Parse a multi-frame XYZ trajectory (xtbscan.log, ORCA .trj, etc.).

        Returns (energies: list[float], geom_blocks: list[str]).
        Energy is read from the comment line: first float found.
        """
        energies, geoms = [], []
        if not os.path.exists(trj_path):
            return energies, geoms
        with open(trj_path, "r", errors="replace") as f:
            lines = f.readlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue
            try:
                n_at = int(line)
                comment = lines[i + 1] if i + 1 < len(lines) else ""
                m = re.search(r"energy:\s*([-\d.]+)", comment, re.IGNORECASE)
                if not m:
                    m = re.search(r"([-\d.]+)", comment)
                en = float(m.group(1)) if m else 0.0
                energies.append(en)
                geoms.append("".join(lines[i : i + 2 + n_at]))
                i += 2 + n_at
            except Exception:
                i += 1
        return energies, geoms

    # =========================================================================
    # FREE ENERGY SURFACE (FES) METHODS
    # =========================================================================

    def _compute_fes_from_populations(
        self,
        populations: list,
        coords: list,
        temperature: float = 298.15,
        work_dir: str = "",
        xlabel: str = "Coordinate",
        filename: str = "FES_1D.png",
    ) -> dict:
        """Compute 1-D Free Energy Surface from histogram populations via
        Boltzmann inversion: F(ξ) = -kT ln P(ξ) + const.

        Parameters
        ----------
        populations : list of float
            Population counts or probabilities at each bin.
        coords      : list of float
            Bin centre coordinate values.
        temperature : float
            Temperature in Kelvin (default 298.15 K).
        work_dir    : str
            Directory to save plot/report (optional).

        Returns
        -------
        dict: fes (kcal/mol array), coords, min_coord, min_fes, barriers
        """
        KB_KCAL = 0.001987204  # kcal mol⁻¹ K⁻¹
        kT = KB_KCAL * temperature

        p = np.array(populations, dtype=float)
        x = np.array(coords, dtype=float)

        # Avoid log(0)
        p = np.where(p <= 0, np.nan, p)
        fes = -kT * np.log(p / np.nanmax(p))
        fes -= np.nanmin(fes)  # shift minimum to 0

        # Locate minima and barriers
        valid = ~np.isnan(fes)
        fes_v = fes[valid]
        x_v = x[valid]
        min_idx = int(np.argmin(fes_v))
        max_idx = int(np.argmax(fes_v))

        result = {
            "fes": fes,
            "coords": x,
            "min_coord": float(x_v[min_idx]),
            "min_fes": float(fes_v[min_idx]),
            "max_coord": float(x_v[max_idx]),
            "max_fes": float(fes_v[max_idx]),
            "barrier": float(fes_v[max_idx] - fes_v[min_idx]),
            "temperature": temperature,
        }

        self._pes_log(
            f"[FES] T={temperature} K | "
            f"kT={kT:.4f} kcal/mol\n"
            f"  Global minimum: ξ={result['min_coord']:.4f}, F=0.00 kcal/mol\n"
            f"  Barrier peak  : ξ={result['max_coord']:.4f}, "
            f"F={result['barrier']:.3f} kcal/mol"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(x_v, fes_v, "-", color="#388bfd", lw=2, label=f"FES  T={temperature} K")
                ax.fill_between(x_v, fes_v, alpha=0.15, color="#388bfd")
                ax.scatter([result["min_coord"]], [0], color="#22c55e", s=100, zorder=5,
                           label=f"Min ({result['min_coord']:.3f})")
                ax.scatter([result["max_coord"]], [result["barrier"]], color="#e05252",
                           s=100, zorder=5, label=f"Barrier ({result['barrier']:.2f} kcal/mol)")
                ax.set_xlabel(xlabel)
                ax.set_ylabel("Free Energy (kcal/mol)")
                ax.set_title(f"Free Energy Surface  (T = {temperature} K)")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, filename)
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[FES] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _compute_fes_2d_from_populations(
        self,
        hist2d,
        x_edges,
        y_edges,
        temperature: float = 298.15,
        work_dir: str = "",
        xlabel: str = "CV1",
        ylabel: str = "CV2",
        filename: str = "FES_2D.png",
    ) -> dict:
        """Compute 2-D Free Energy Surface from a 2-D histogram via Boltzmann
        inversion.  Returns FES array in kcal/mol.

        Parameters
        ----------
        hist2d   : 2-D array-like, shape (ny, nx), population counts or weights.
        x_edges  : bin edges for CV1 (length nx+1).
        y_edges  : bin edges for CV2 (length ny+1).
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        H = np.asarray(hist2d, dtype=float)
        H = np.where(H <= 0, np.nan, H)
        F = -kT * np.log(H / np.nanmax(H))
        F -= np.nanmin(F)

        x_centers = 0.5 * (np.asarray(x_edges[:-1]) + np.asarray(x_edges[1:]))
        y_centers = 0.5 * (np.asarray(y_edges[:-1]) + np.asarray(y_edges[1:]))
        XX, YY = np.meshgrid(x_centers, y_centers)

        min_pos = np.unravel_index(np.nanargmin(F), F.shape)
        max_pos = np.unravel_index(np.nanargmax(F), F.shape)

        result = {
            "fes_2d": F,
            "x_centers": x_centers,
            "y_centers": y_centers,
            "min_coords": (float(XX[min_pos]), float(YY[min_pos])),
            "max_coords": (float(XX[max_pos]), float(YY[max_pos])),
            "barrier": float(np.nanmax(F)),
            "temperature": temperature,
        }

        self._pes_log(
            f"[2D-FES] T={temperature} K  barrier={result['barrier']:.3f} kcal/mol\n"
            f"  Min at CV1={result['min_coords'][0]:.3f}, CV2={result['min_coords'][1]:.3f}\n"
            f"  Max at CV1={result['max_coords'][0]:.3f}, CV2={result['max_coords'][1]:.3f}"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 6))
                F_plot = np.where(np.isnan(F), np.nanmax(F), F)
                levels = np.linspace(0, np.nanmax(F), 25)
                cf = ax.contourf(XX, YY, F_plot, levels=levels, cmap="RdYlGn_r")
                ax.contour(XX, YY, F_plot, levels=levels[::4], colors="k",
                           linewidths=0.5, alpha=0.6)
                cbar = fig.colorbar(cf, ax=ax)
                cbar.set_label("Free Energy (kcal/mol)")
                ax.scatter(*result["min_coords"], color="#22c55e", s=120, zorder=5,
                           label="Min", marker="*")
                ax.scatter(*result["max_coords"], color="#e05252", s=120, zorder=5,
                           label="Max", marker="^")
                ax.set_xlabel(xlabel)
                ax.set_ylabel(ylabel)
                ax.set_title(f"2-D Free Energy Surface  (T = {temperature} K)")
                ax.legend(fontsize=8)
                fig.tight_layout()
                out = os.path.join(work_dir, filename)
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[2D-FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[2D-FES] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _run_umbrella_sampling_setup(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int,
        window_centers: list,
        spring_k: float = 50.0,
        charge: int = 0, mult: int = 1,
        n_steps: int = 5000,
        method: str = "gfn2",
    ) -> str:
        """Set up xTB umbrella sampling windows using a harmonic bias potential.

        For each window centre ξ₀ the method writes an xTB constraint file and
        runs a short MD.  Outputs are saved under work_dir/us_window_NNN/.
        WHAM analysis is delegated to _run_wham_analysis.

        Returns path to a summary file listing all window output dirs.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        self._pes_log(
            f"[US] Setting up {len(window_centers)} umbrella windows\n"
            f"  Atoms {a1}-{a2}, k={spring_k} kcal/mol/Å², n_steps={n_steps}"
        )
        summary_lines = []
        mol_src = os.path.join(work_dir, mol_file)

        for idx, xi in enumerate(window_centers):
            w_dir = os.path.join(work_dir, f"us_window_{idx:03d}")
            os.makedirs(w_dir, exist_ok=True)
            import shutil as _sh
            _sh.copy2(mol_src, w_dir)

            # xTB constraint input (harmonic spring on distance)
            cstr_path = os.path.join(w_dir, "xtb_us.inp")
            with open(cstr_path, "w") as f:
                f.write("$constrain\n")
                f.write(f"  force constant={spring_k:.4f}\n")
                f.write(f"  distance: {a1}, {a2}, {xi:.4f}\n")
                f.write("$end\n")
                f.write("$md\n")
                f.write(f"  time={n_steps * 0.5e-3:.2f}  # ps\n")
                f.write("  step=0.5\n")
                f.write(f"  temp=298.15\n")
                f.write("$end\n")

            cmd = f'"{xtb_exe}" {mol_file} --md --input xtb_us.inp'
            if charge:
                cmd += f" --chrg {charge}"
            if mult != 1:
                cmd += f" --uhf {mult - 1}"
            if method.lower() != "gfn2":
                cmd += f" --{method.lower()}"

            self._pes_log(f"[US] Window {idx:03d}  ξ₀={xi:.3f} Å — running MD …")
            p = subprocess.run(cmd, shell=True, cwd=w_dir,
                               capture_output=True, text=True)
            with open(os.path.join(w_dir, "xtb_us.log"), "w") as f:
                f.write(p.stdout + p.stderr)
            summary_lines.append(f"{idx}\t{xi:.4f}\t{w_dir}\n")

        summary_path = os.path.join(work_dir, "us_windows_summary.txt")
        with open(summary_path, "w") as f:
            f.write("window\txi0\tdir\n")
            f.writelines(summary_lines)
        self._pes_log(f"[US] All windows done. Summary → {summary_path}")
        return summary_path

    # -------------------------------------------------------------------------

    def _run_wham_analysis(
        self,
        summary_path: str,
        a1: int, a2: int,
        temperature: float = 298.15,
        n_bins: int = 50,
        tol: float = 1e-6,
        max_iter: int = 10000,
    ) -> dict:
        """Pure-Python WHAM (Weighted Histogram Analysis Method) to reconstruct
        the 1-D PMF (Potential of Mean Force) from umbrella-sampling windows.

        Reads the xTB MD trajectory (xtb.trj) from each window directory listed
        in the summary file, extracts the reaction coordinate (atom pair distance
        a1-a2), builds windowed histograms, and iterates WHAM equations to
        convergence.

        Returns dict: pmf (kcal/mol), bin_centers, barrier_fwd, barrier_rev.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature
        BETA = 1.0 / kT

        if not os.path.exists(summary_path):
            self._pes_log("[WHAM] Summary file not found.")
            return {}

        # --- Read window metadata ---
        windows = []
        with open(summary_path) as f:
            next(f)  # header
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 3:
                    windows.append({"xi0": float(parts[1]), "dir": parts[2]})

        if not windows:
            self._pes_log("[WHAM] No windows found in summary.")
            return {}

        self._pes_log(f"[WHAM] {len(windows)} windows loaded. Extracting distances …")

        def _extract_distances(w_dir):
            """Read xtb.trj and compute atom-pair distances (a1, a2)."""
            trj = os.path.join(w_dir, "xtb.trj")
            if not os.path.exists(trj):
                return []
            dists = []
            with open(trj, errors="replace") as f:
                lines = f.readlines()
            i = 0
            while i < len(lines):
                try:
                    n_at = int(lines[i].strip())
                    coords = []
                    for l in lines[i + 2 : i + 2 + n_at]:
                        p = l.split()
                        coords.append([float(p[1]), float(p[2]), float(p[3])])
                    if len(coords) >= max(a1, a2):
                        v = [coords[a1 - 1][k] - coords[a2 - 1][k] for k in range(3)]
                        dists.append(sum(x**2 for x in v) ** 0.5)
                    i += 2 + n_at
                except Exception:
                    i += 1
            return dists

        all_xi = [_extract_distances(w["dir"]) for w in windows]
        all_flat = [x for wl in all_xi for x in wl]
        if not all_flat:
            self._pes_log("[WHAM] No distance data extracted from trajectories.")
            return {}

        xi_min, xi_max = min(all_flat), max(all_flat)
        bin_edges = np.linspace(xi_min, xi_max, n_bins + 1)
        bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])

        # Build per-window histograms
        hists = []
        for wl in all_xi:
            h, _ = np.histogram(wl, bins=bin_edges)
            hists.append(h.astype(float))

        N_w = np.array([sum(wl) for wl in all_xi], dtype=float)
        xi0_arr = np.array([w["xi0"] for w in windows])
        # Spring constants (kcal/mol/Å² — hard-coded; could be read from summary)
        spring_k_arr = np.full(len(windows), 50.0)

        # --- WHAM iterations ---
        F_k = np.zeros(len(windows))  # window free energies (natural units: kT)
        for iteration in range(max_iter):
            # Denominator: Σ_k N_k exp(F_k - β U_k(ξ))
            denom = np.zeros(n_bins)
            for k, (xi0, spring_k) in enumerate(zip(xi0_arr, spring_k_arr)):
                bias = 0.5 * spring_k * (bin_centers - xi0) ** 2  # kcal/mol
                denom += N_w[k] * np.exp(F_k[k] - BETA * bias)

            # Numerator: total histogram
            H_total = sum(hists)
            rho = np.where(denom > 0, H_total / denom, 0.0)

            # Update F_k
            F_k_new = np.zeros(len(windows))
            for k, (xi0, spring_k) in enumerate(zip(xi0_arr, spring_k_arr)):
                bias = 0.5 * spring_k * (bin_centers - xi0) ** 2
                F_k_new[k] = -np.log(np.dot(rho, np.exp(-BETA * bias)) + 1e-300)

            F_k_new -= F_k_new[0]  # anchor to first window
            if np.max(np.abs(F_k_new - F_k)) < tol:
                self._pes_log(f"[WHAM] Converged in {iteration + 1} iterations.")
                break
            F_k = F_k_new

        # PMF = -kT ln ρ(ξ)
        pmf = np.where(rho > 0, -kT * np.log(rho), np.nan)
        pmf -= np.nanmin(pmf)

        valid = ~np.isnan(pmf)
        max_i = int(np.argmax(pmf[valid]))
        min_i = int(np.argmin(pmf[valid]))
        barrier_fwd = float(np.nanmax(pmf))

        self._pes_log(
            f"[WHAM] PMF barrier = {barrier_fwd:.3f} kcal/mol  "
            f"at ξ={bin_centers[np.nanargmax(pmf)]:.4f} Å"
        )

        # Write CSV
        work_dir = os.path.dirname(summary_path)
        csv_path = os.path.join(work_dir, "WHAM_PMF.csv")
        with open(csv_path, "w") as f:
            f.write("xi_Angstrom,PMF_kcalmol\n")
            for xi, pval in zip(bin_centers, pmf):
                f.write(f"{xi:.5f},{pval:.5f}\n")
        self._pes_log(f"[WHAM] PMF CSV saved → {csv_path}")

        # Plot
        if MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(bin_centers[valid], pmf[valid], "-o", ms=3,
                        color="#388bfd", lw=2, label="PMF (WHAM)")
                ax.fill_between(bin_centers[valid], pmf[valid], alpha=0.12,
                                color="#388bfd")
                ax.set_xlabel(f"Distance atoms {a1}-{a2} (Å)")
                ax.set_ylabel("PMF (kcal/mol)")
                ax.set_title(f"WHAM Potential of Mean Force  (T={temperature} K)")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "WHAM_PMF.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[WHAM] PMF plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[WHAM] Plot error: {exc}")

        return {
            "pmf": pmf,
            "bin_centers": bin_centers,
            "barrier_fwd": barrier_fwd,
            "F_windows": F_k * kT,
        }

    # =========================================================================
    # PERTURBATION THEORY METHODS (FEP / LRA / BAR)
    # =========================================================================

    def _compute_fep(
        self,
        energies_0: list,
        energies_1: list,
        temperature: float = 298.15,
        direction: str = "forward",
        work_dir: str = "",
    ) -> dict:
        """Free Energy Perturbation (FEP) — Zwanzig exponential average.

        ΔA = -kT ln < exp(-ΔU/kT) >₀   (forward, Zwanzig 1954)
        ΔA = +kT ln < exp(+ΔU/kT) >₁   (backward)

        Parameters
        ----------
        energies_0 : potential energies sampled at state 0 (kcal/mol).
        energies_1 : potential energies sampled at state 1 (kcal/mol) —
                     must correspond 1-to-1 with energies_0 (same configs).
        direction  : 'forward', 'backward', or 'both'.

        Returns
        -------
        dict: delta_A_fwd, delta_A_bwd, delta_A_bar (BAR estimate),
              overlap, convergence info.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        u0 = np.array(energies_0, dtype=float)
        u1 = np.array(energies_1, dtype=float)
        dU = u1 - u0   # ΔU = U₁ - U₀

        # --- Forward FEP (Zwanzig) ---
        dU_shifted = dU - dU.max()  # numerical stability
        delta_A_fwd = -kT * (np.log(np.mean(np.exp(-dU_shifted / kT))) + dU.max() / kT)

        # --- Backward FEP ---
        dU_b_shifted = -dU - (-dU).max()
        delta_A_bwd = kT * (np.log(np.mean(np.exp(-dU_b_shifted / kT))) + (-dU).max() / kT)

        # --- Simple BAR (Bennett Acceptance Ratio) estimate ---
        # Full iterative BAR would require root-finding; here use the average of fwd/bwd
        delta_A_bar = 0.5 * (delta_A_fwd - delta_A_bwd)

        # --- Phase-space overlap (Bhattacharyya coefficient approximation) ---
        n_bins = max(20, len(u0) // 10)
        all_vals = np.concatenate([dU, -dU])
        bins = np.linspace(all_vals.min(), all_vals.max(), n_bins + 1)
        h0, _ = np.histogram(dU, bins=bins, density=True)
        h1, _ = np.histogram(-dU, bins=bins, density=True)
        db = bins[1] - bins[0]
        overlap = float(np.sum(np.sqrt(h0 * h1)) * db)

        result = {
            "delta_A_fwd": delta_A_fwd,
            "delta_A_bwd": delta_A_bwd,
            "delta_A_bar": delta_A_bar,
            "overlap": overlap,
            "temperature": temperature,
            "n_samples": len(u0),
        }

        self._pes_log(
            f"[FEP]  T={temperature} K  n={len(u0)} samples\n"
            f"  ΔA (forward  FEP) = {delta_A_fwd:+.4f} kcal/mol\n"
            f"  ΔA (backward FEP) = {delta_A_bwd:+.4f} kcal/mol\n"
            f"  ΔA (BAR est.)     = {delta_A_bar:+.4f} kcal/mol\n"
            f"  Phase-space overlap (Bhattacharyya) = {overlap:.4f}"
        )
        if overlap < 0.05:
            self._pes_log(
                "[FEP] WARNING: Very low overlap (<0.05). "
                "FEP estimate unreliable — consider shorter λ spacing."
            )

        if work_dir and MATPLOTLIB_AVAILABLE:
            self._plot_fep_distribution(work_dir, dU, temperature, result)

        return result

    # -------------------------------------------------------------------------

    def _compute_ti(
        self,
        dU_dl_by_lambda: list,
        lambda_vals: list,
        temperature: float = 298.15,
        work_dir: str = "",
    ) -> dict:
        """Thermodynamic Integration (TI) — integrate ⟨∂U/∂λ⟩_λ over λ.

        Parameters
        ----------
        dU_dl_by_lambda : list of lists / arrays.
            Each element is a list of ∂U/∂λ samples at the corresponding λ.
        lambda_vals : list of float
            λ values in [0, 1] for each window.

        Returns
        -------
        dict: delta_A_ti, lambdas, mean_dUdl, se_dUdl, integrand_plot path.
        """
        lambdas = np.array(lambda_vals, dtype=float)
        means = np.array([np.mean(w) for w in dU_dl_by_lambda], dtype=float)
        stds = np.array([np.std(w, ddof=1) / max(len(w) ** 0.5, 1)
                         for w in dU_dl_by_lambda], dtype=float)

        # Trapezoidal integration
        delta_A = float(np.trapz(means, lambdas))

        result = {
            "delta_A_ti": delta_A,
            "lambdas": lambdas,
            "mean_dUdl": means,
            "se_dUdl": stds,
            "temperature": temperature,
        }

        self._pes_log(
            f"[TI]  λ from {lambdas[0]:.3f} to {lambdas[-1]:.3f}  "
            f"({len(lambdas)} windows)\n"
            f"  ΔA (TI trapz) = {delta_A:+.4f} kcal/mol"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 4))
                ax.plot(lambdas, means, "-o", color="#388bfd", lw=2, ms=5,
                        label="⟨∂U/∂λ⟩")
                ax.fill_between(lambdas, means - stds, means + stds,
                                alpha=0.25, color="#388bfd", label="±1 SE")
                ax.fill_between(lambdas, 0, means, alpha=0.12, color="#17a2b8")
                ax.axhline(0, color="#888", ls="--", lw=0.8)
                ax.set_xlabel("λ")
                ax.set_ylabel("⟨∂U/∂λ⟩ (kcal/mol)")
                ax.set_title(f"Thermodynamic Integration  ΔA = {delta_A:+.4f} kcal/mol")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "TI_integrand.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[TI] Integrand plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[TI] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _compute_lra(
        self,
        dU_state0: list,
        dU_state1: list,
        temperature: float = 298.15,
    ) -> dict:
        """Linear Response Approximation (LRA) free energy estimate.

        ΔA_LRA = ½ (⟨ΔU⟩₀ + ⟨ΔU⟩₁)

        where ΔU = U₁ - U₀ sampled at states 0 and 1 respectively.
        Also computes the reorganisation energy:
            λ_reorg = ½ (⟨ΔU⟩₀ - ⟨ΔU⟩₁)

        Returns dict: delta_A_lra, lambda_reorg, mean_dU_0, mean_dU_1.
        """
        u0 = np.asarray(dU_state0, dtype=float)
        u1 = np.asarray(dU_state1, dtype=float)

        mean0 = float(np.mean(u0))
        mean1 = float(np.mean(u1))
        delta_A_lra = 0.5 * (mean0 + mean1)
        lambda_reorg = 0.5 * (mean0 - mean1)

        result = {
            "delta_A_lra": delta_A_lra,
            "lambda_reorg": lambda_reorg,
            "mean_dU_0": mean0,
            "mean_dU_1": mean1,
            "temperature": temperature,
        }

        self._pes_log(
            f"[LRA]  T={temperature} K\n"
            f"  ⟨ΔU⟩₀ = {mean0:+.4f} kcal/mol\n"
            f"  ⟨ΔU⟩₁ = {mean1:+.4f} kcal/mol\n"
            f"  ΔA_LRA       = {delta_A_lra:+.4f} kcal/mol\n"
            f"  λ_reorg      = {lambda_reorg:+.4f} kcal/mol"
        )
        return result

    # -------------------------------------------------------------------------

    def _compute_bar(
        self,
        energies_0: list,
        energies_1: list,
        temperature: float = 298.15,
        max_iter: int = 1000,
        tol: float = 1e-8,
    ) -> dict:
        """Bennett Acceptance Ratio (BAR) — iterative solution for ΔA.

        Solves  Σᵢ f(U₁ᵢ - U₀ᵢ - C) = Σⱼ f(U₀ⱼ - U₁ⱼ + C)
        where f(x) = 1/(1 + exp(x/kT))  (Fermi function).

        Parameters
        ----------
        energies_0 : ΔU = U₁-U₀ values sampled at state 0 (kcal/mol).
        energies_1 : ΔU = U₁-U₀ values sampled at state 1 (kcal/mol).

        Returns dict: delta_A_bar, n_iter, converged.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        u_fwd = np.asarray(energies_0, dtype=float)  # ΔU at state 0
        u_bwd = -np.asarray(energies_1, dtype=float)  # -ΔU at state 1

        n0, n1 = len(u_fwd), len(u_bwd)
        C = 0.0  # initial guess for ΔA (kT units)

        def _fermi(x):
            return np.where(x > 500, 0.0, 1.0 / (1.0 + np.exp(np.clip(x, -500, 500))))

        converged = False
        for it in range(max_iter):
            lhs = np.mean(_fermi((u_fwd - C) / kT))
            rhs = np.mean(_fermi((u_bwd + C) / kT))
            # Newton step
            C_new = C + kT * np.log(n0 * lhs / (n1 * rhs + 1e-300))
            if abs(C_new - C) < tol:
                converged = True
                C = C_new
                break
            C = C_new

        delta_A = float(C + kT * np.log(float(n1) / float(n0)))

        result = {
            "delta_A_bar": delta_A,
            "n_iter": it + 1,
            "converged": converged,
            "temperature": temperature,
        }

        self._pes_log(
            f"[BAR]  T={temperature} K  n0={n0} n1={n1}\n"
            f"  ΔA (BAR) = {delta_A:+.4f} kcal/mol  "
            f"({'converged' if converged else 'not converged'} in {it+1} iters)"
        )
        return result

    # -------------------------------------------------------------------------

    def _plot_fep_distribution(
        self,
        work_dir: str,
        dU: np.ndarray,
        temperature: float,
        fep_result: dict,
    ):
        """Plot forward/backward ΔU distributions and FEP convergence diagnostics."""
        if not MATPLOTLIB_AVAILABLE:
            return
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        # Left: histogram of ΔU
        ax = axes[0]
        ax.hist(dU, bins=40, color="#388bfd", alpha=0.7, density=True,
                label="ΔU = U₁-U₀ (state 0 samples)")
        ax.hist(-dU, bins=40, color="#e05252", alpha=0.5, density=True,
                label="-ΔU (state 1 samples)")
        ax.set_xlabel("ΔU (kcal/mol)")
        ax.set_ylabel("Density")
        ax.set_title("FEP Overlap Distribution")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.text(
            0.05, 0.95,
            f"Overlap = {fep_result['overlap']:.3f}",
            transform=ax.transAxes, va="top", fontsize=9,
            bbox=dict(boxstyle="round", fc="white", alpha=0.7),
        )

        # Right: block average of ΔA_fwd
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature
        ax2 = axes[1]
        n = len(dU)
        block_sizes = np.unique(np.round(np.linspace(10, n, 40)).astype(int))
        block_dA = []
        for bs in block_sizes:
            chunk = dU[:bs]
            shifted = chunk - chunk.max()
            block_dA.append(
                -kT * (np.log(np.mean(np.exp(-shifted / kT))) + chunk.max() / kT)
            )
        ax2.plot(block_sizes, block_dA, "-o", ms=3, color="#388bfd", lw=1.5)
        ax2.axhline(fep_result["delta_A_fwd"], color="#e05252", ls="--", lw=1.2,
                    label=f"ΔA_fwd = {fep_result['delta_A_fwd']:+.3f}")
        ax2.axhline(fep_result["delta_A_bar"], color="#22c55e", ls=":", lw=1.2,
                    label=f"ΔA_BAR = {fep_result['delta_A_bar']:+.3f}")
        ax2.set_xlabel("Block size (samples)")
        ax2.set_ylabel("ΔA (kcal/mol)")
        ax2.set_title("FEP Block-Average Convergence")
        ax2.legend(fontsize=8)
        ax2.grid(True, alpha=0.3)

        fig.tight_layout()
        out = os.path.join(work_dir, "FEP_diagnostics.png")
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[FEP] Diagnostics plot saved → {out}")

    # -------------------------------------------------------------------------

    def _compute_alchemical_lambda_schedule(
        self,
        n_windows: int,
        schedule: str = "linear",
        softcore_alpha: float = 0.5,
    ) -> list:
        """Generate λ values for alchemical FEP/TI calculations.

        schedule options:
          'linear'    – uniform spacing in [0,1]
          'gauss-leg' – Gaussian-Legendre quadrature points (optimal for TI)
          'softcore'  – clustered near endpoints for better overlap
        """
        if schedule == "gauss-leg":
            try:
                from numpy.polynomial.legendre import leggauss
                pts, wts = leggauss(n_windows)
                lambdas = list(0.5 * (pts + 1))
            except Exception:
                lambdas = list(np.linspace(0, 1, n_windows))
        elif schedule == "softcore":
            # More windows near 0 and 1 for soft-core perturbations
            x = np.linspace(0, np.pi, n_windows)
            lambdas = list(0.5 * (1 - np.cos(x)))
        else:
            lambdas = list(np.linspace(0, 1, n_windows))

        self._pes_log(
            f"[Alchemical] λ schedule '{schedule}', {n_windows} windows:\n"
            f"  {[round(l, 4) for l in lambdas]}"
        )
        return lambdas

    # -------------------------------------------------------------------------

    def _fes_from_metadynamics_hills(
        self,
        hills_file: str,
        cv_range: tuple,
        n_bins: int = 100,
        temperature: float = 298.15,
        work_dir: str = "",
        cv_label: str = "CV (Å)",
        gamma: float = None,
    ) -> dict:
        """Reconstruct 1-D FES from a PLUMED-style HILLS file (well-tempered
        or standard metadynamics).

        The HILLS file format assumed (space-separated):
          time  CV  sigma  height  biasfactor

        FES is approximated by summing Gaussian hills (negative sum).
        Well-tempered bias: height is rescaled by exp factor.

        Parameters
        ----------
        hills_file : path to HILLS file.
        cv_range   : (cv_min, cv_max) tuple in Å.
        gamma      : well-tempered bias factor (γ). None → standard metadynamics.

        Returns dict: fes (kcal/mol), cv_grid, min_cv, barrier.
        """
        if not os.path.exists(hills_file):
            self._pes_log(f"[MetaD-FES] HILLS file not found: {hills_file}")
            return {}

        self._pes_log(f"[MetaD-FES] Reading HILLS from {hills_file} …")
        hills = []
        with open(hills_file, errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    try:
                        hills.append({
                            "time": float(parts[0]),
                            "cv": float(parts[1]),
                            "sigma": float(parts[2]),
                            "height": float(parts[3]),
                            "biasfactor": float(parts[4]) if len(parts) > 4 else 1.0,
                        })
                    except ValueError:
                        continue

        self._pes_log(f"[MetaD-FES] {len(hills)} Gaussian hills read.")
        cv_grid = np.linspace(cv_range[0], cv_range[1], n_bins)
        V_bias = np.zeros(n_bins)

        for h in hills:
            gauss = h["height"] * np.exp(
                -0.5 * ((cv_grid - h["cv"]) / h["sigma"]) ** 2
            )
            if gamma is not None and gamma > 1:
                # Well-tempered scaling factor
                KB_KCAL = 0.001987204
                kT = KB_KCAL * temperature
                gauss *= (gamma - 1) / gamma
            V_bias += gauss

        # FES = -V_bias (up to a constant)
        fes = -V_bias
        fes -= fes.min()

        min_i = int(np.argmin(fes))
        max_i = int(np.argmax(fes))
        barrier = float(fes[max_i] - fes[min_i])

        result = {
            "fes": fes,
            "cv_grid": cv_grid,
            "min_cv": float(cv_grid[min_i]),
            "max_cv": float(cv_grid[max_i]),
            "barrier": barrier,
            "n_hills": len(hills),
        }

        self._pes_log(
            f"[MetaD-FES] Barrier = {barrier:.3f} kcal/mol  "
            f"Min at CV={result['min_cv']:.4f}"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(cv_grid, fes, "-", color="#388bfd", lw=2,
                        label="MetaD FES")
                ax.fill_between(cv_grid, fes, alpha=0.15, color="#388bfd")
                ax.scatter([cv_grid[min_i]], [0], color="#22c55e", s=120,
                           zorder=5, label="Min")
                ax.scatter([cv_grid[max_i]], [barrier], color="#e05252",
                           s=120, zorder=5,
                           label=f"Barrier {barrier:.2f} kcal/mol")
                ax.set_xlabel(cv_label)
                ax.set_ylabel("Free Energy (kcal/mol)")
                ax.set_title(
                    f"Metadynamics FES  "
                    f"({'well-tempered γ='+str(gamma) if gamma else 'standard'})"
                )
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "MetaD_FES.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[MetaD-FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[MetaD-FES] Plot error: {exc}")

        return result

    # =========================================================================
    # END EXTENDED PES / FES / PERTURBATION METHODS
    # =========================================================================

    # =========================================================================
    # FES & PERTURBATION TAB + PES SCAN LAUNCHERS
    # =========================================================================

    def _start_angle_scan(self):
        """Launch angle scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("Angle Scan", "Set Reactant XYZ first.")
        out_dir = os.path.join(os.path.dirname(mol), "pes_angle_scan")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            a1, a2, a3 = int(v["c1_a1"].get()), int(v["c1_a2"].get()), int(v["ang_a3"].get())
            a_start, a_end, n_steps = float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get())
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Angle Scan", f"Invalid parameter: {exc}")
        self._pes_log(f"[Angle Scan] Launching: atoms {a1}-{a2}-{a3}, {a_start}°→{a_end}° ({n_steps} steps)")
        threading.Thread(
            target=lambda: self._run_xtb_angle_scan(out_dir, mol_base, a1, a2, a3, a_start, a_end, n_steps, charge, mult),
            daemon=True,
        ).start()

    def _start_dihedral_scan(self):
        """Launch dihedral scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("Dihedral Scan", "Set Reactant XYZ first.")
        out_dir = os.path.join(os.path.dirname(mol), "pes_dihedral_scan")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            a1, a2 = int(v["c1_a1"].get()), int(v["c1_a2"].get())
            a3, a4 = int(v["ang_a3"].get()), int(v["dih_a4"].get())
            d_start, d_end, n_steps = float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get())
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Dihedral Scan", f"Invalid parameter: {exc}")
        self._pes_log(f"[Dihedral Scan] atoms {a1}-{a2}-{a3}-{a4}, {d_start}°→{d_end}°")
        threading.Thread(
            target=lambda: self._run_xtb_dihedral_scan(out_dir, mol_base, a1, a2, a3, a4, d_start, d_end, n_steps, charge, mult),
            daemon=True,
        ).start()

    def _start_orca_2d_pes(self):
        """Launch ORCA 2-D PES scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("ORCA 2D PES", "Set Reactant XYZ first.")
        if not v["use_c2"].get():
            return messagebox.showerror("ORCA 2D PES", "Enable 'Coordinate 2' first.")
        out_dir = os.path.join(os.path.dirname(mol), "orca_2d_pes")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            c1 = (int(v["c1_a1"].get()), int(v["c1_a2"].get()),
                  float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get()))
            c2 = (int(v["c2_a1"].get()), int(v["c2_a2"].get()),
                  float(v["c2_start"].get()), float(v["c2_end"].get()), int(v["c2_steps"].get()))
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
            cores = int(self._vars["cores"].get())
        except ValueError as exc:
            return messagebox.showerror("ORCA 2D PES", f"Invalid parameter: {exc}")
        self._pes_log("[ORCA 2D PES] Launching …")
        threading.Thread(
            target=lambda: self._run_orca_2d_pes(
                out_dir, mol_base, *c1, *c2, charge, mult, cores=cores),
            daemon=True,
        ).start()

    def _open_barrier_analysis_dialog(self):
        """Simple dialog to enter 3 energies (R / TS / P in Eh) and get barriers."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Barrier Analysis")
        dlg.configure(bg=_C["panel"])
        dlg.geometry("400x260")
        dlg.grab_set()
        dlg.transient(self.root)
        tk.Label(dlg, text="Enter energies in Hartree (Eh):", bg=_C["panel"],
                 fg=_C["accent"], font=("Segoe UI", 11, "bold")).pack(pady=(14, 6))
        vars_dlg = {}
        for lbl, key, default in [
            ("Reactant E (Eh):", "e_r", "-10.000000"),
            ("TS       E (Eh):", "e_ts", "-9.980000"),
            ("Product  E (Eh):", "e_p", "-9.990000"),
            ("Temperature (K):", "temp", "298.15"),
        ]:
            row = tk.Frame(dlg, bg=_C["panel"])
            row.pack(fill="x", padx=20, pady=3)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"],
                     width=22, anchor="w").pack(side="left")
            v = tk.StringVar(value=default)
            vars_dlg[key] = v
            tk.Entry(row, textvariable=v, bg=_C["entry"], fg=_C["text"],
                     bd=0, width=16).pack(side="left", padx=4)

        def _run():
            try:
                e_r = float(vars_dlg["e_r"].get())
                e_ts = float(vars_dlg["e_ts"].get())
                e_p = float(vars_dlg["e_p"].get())
                temp = float(vars_dlg["temp"].get())
            except ValueError:
                return messagebox.showerror("Barrier", "Enter valid numbers.", parent=dlg)
            out = self._vars_pes["reactant"].get()
            work_dir = os.path.dirname(out) if out else ""
            self._ts_barrier_analysis(e_r, e_ts, e_p, work_dir=work_dir)
            dlg.destroy()

        tk.Button(dlg, text="Compute Barriers", command=_run,
                  bg=_C["green"], fg="black",
                  font=("Segoe UI", 11, "bold"), pady=6).pack(pady=12)

    # -------------------------------------------------------------------------

    def _build_fes_tab(self, parent):
        """Free Energy Surface & Perturbation Theory tab."""
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        # ── Sub-tab 1: Umbrella Sampling / WHAM ──────────────────────────────
        tab_us = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_us, text=" Umbrella / WHAM ")

        us_top = tk.Frame(tab_us, bg=_C["bg"])
        us_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(us_top, text="Umbrella Sampling & WHAM PMF",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        pane_us = tk.Frame(us_top, bg=_C["panel"])
        pane_us.pack(fill="x", pady=6)

        def _lrow(parent, label, key, browse=False, btype="file"):
            row = tk.Frame(parent, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=28, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if browse:
                def _b(k=key, bt=btype):
                    fp = (filedialog.askopenfilename() if bt == "file"
                          else filedialog.askdirectory())
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white",
                          command=_b).pack(side="left")

        _lrow(pane_us, "Molecule XYZ:", "us_mol", browse=True)
        for label, key in [("Atom 1 Index:", "us_a1"), ("Atom 2 Index:", "us_a2"),
                            ("Window centres (comma-sep Å):", "us_centers"),
                            ("Spring k (kcal/mol/Å²):", "us_spring_k"),
                            ("MD steps per window:", "us_steps"),
                            ("Temperature (K):", "temperature"),
                            ("N bins (WHAM):", "n_bins"),
                            ("US summary file (for WHAM):", "us_summary"),
                            ("Output folder:", "fes_out")]:
            _lrow(pane_us, label, key,
                  browse=(key in ("us_summary", "fes_out")),
                  btype=("file" if key == "us_summary" else "dir"))

        btn_us = tk.Frame(us_top, bg=_C["bg"])
        btn_us.pack(fill="x", pady=6)
        tk.Button(btn_us, text=" ▶ Setup US Windows ",
                  command=self._launch_umbrella_setup,
                  bg=_C["green"], fg="black",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(side="left", padx=4)
        tk.Button(btn_us, text=" ▶ Run WHAM Analysis ",
                  command=self._launch_wham,
                  bg="#17a2b8", fg="white",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(side="left", padx=4)

        # ── Sub-tab 2: Metadynamics FES ───────────────────────────────────────
        tab_meta = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_meta, text=" MetaD FES ")

        meta_top = tk.Frame(tab_meta, bg=_C["bg"])
        meta_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(meta_top, text="Metadynamics Free Energy Surface (HILLS → FES)",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        pane_meta = tk.Frame(meta_top, bg=_C["panel"])
        pane_meta.pack(fill="x", pady=6)

        for label, key, brs in [
            ("HILLS file (PLUMED):", "hills_file", True),
            ("CV min:", "hills_cv_min", False),
            ("CV max:", "hills_cv_max", False),
            ("CV axis label:", "hills_cv_label", False),
            ("Well-tempered γ (blank=standard):", "hills_gamma", False),
            ("N bins:", "n_bins", False),
            ("Temperature (K):", "temperature", False),
            ("Output folder:", "fes_out", True),
        ]:
            row = tk.Frame(pane_meta, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=34, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if brs:
                def _b(k=key):
                    fp = filedialog.askopenfilename() if k == "hills_file" else filedialog.askdirectory()
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white", command=_b).pack(side="left")

        tk.Button(meta_top, text=" ▶ Reconstruct FES from HILLS ",
                  command=self._launch_metad_fes,
                  bg="#6f42c1", fg="white",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(anchor="w", pady=8)

        # ── Sub-tab 3: FEP / TI / LRA / BAR ─────────────────────────────────
        tab_fep = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_fep, text=" FEP / TI / BAR ")

        fep_top = tk.Frame(tab_fep, bg=_C["bg"])
        fep_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(fep_top, text="Free Energy Perturbation (FEP)  ·  TI  ·  BAR  ·  LRA",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        info = (
            "Load two CSV files each containing one column of energies (kcal/mol).\n"
            "  • File 0 = ΔU = U₁–U₀ values sampled at state 0  (forward FEP)\n"
            "  • File 1 = ΔU = U₁–U₀ values sampled at state 1  (backward FEP / BAR)\n"
            "TI: provide ∂U/∂λ CSV files per λ window (one value per row per window, comma-separated header = lambda values)."
        )
        tk.Label(fep_top, text=info, bg=_C["bg"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic"), justify="left", wraplength=700).pack(anchor="w", pady=4)

        pane_fep = tk.Frame(fep_top, bg=_C["panel"])
        pane_fep.pack(fill="x", pady=6)

        for label, key in [
            ("Energy file 0 (state 0 samples CSV):", "fep_file0"),
            ("Energy file 1 (state 1 samples CSV):", "fep_file1"),
            ("Temperature (K):", "temperature"),
            ("Output folder:", "fes_out"),
            ("λ schedule (linear/gauss-leg/softcore):", "lambda_schedule"),
            ("N λ windows:", "n_lambda"),
        ]:
            row = tk.Frame(pane_fep, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=38, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if key in ("fep_file0", "fep_file1"):
                def _b(k=key):
                    fp = filedialog.askopenfilename(
                        filetypes=[("CSV", "*.csv"), ("Text", "*.txt"), ("All", "*")])
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white", command=_b).pack(side="left")

        btn_fep = tk.Frame(fep_top, bg=_C["bg"])
        btn_fep.pack(fill="x", pady=8)
        for label, cmd, col in [
            (" ▶ Run FEP (Zwanzig) ", self._launch_fep, "#e05252"),
            (" ▶ Run BAR (iterative) ", self._launch_bar, "#388bfd"),
            (" ▶ Run LRA ", self._launch_lra, "#22c55e"),
            (" λ Schedule Preview ", self._launch_lambda_preview, _C["panel"]),
        ]:
            tk.Button(btn_fep, text=label, command=cmd,
                      bg=col, fg=("white" if col != _C["panel"] else _C["text"]),
                      font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)

        # ── Shared terminal log ───────────────────────────────────────────────
        for tab, name in [(tab_us, "us"), (tab_meta, "meta"), (tab_fep, "fep")]:
            log_f = tk.Frame(tab, bg=_C["bg"])
            log_f.pack(fill="both", expand=True, padx=8, pady=(4, 6))
            tk.Label(log_f, text="Log:", bg=_C["bg"], fg=_C["muted"],
                     font=("Segoe UI", 8, "italic")).pack(anchor="w")
            term = tk.Text(log_f, bg="#0c0c0c", fg="#d4d4d4",
                           font=("Consolas", 9), wrap="none",
                           state="disabled", height=10)
            term.pack(fill="both", expand=True)
            sb = tk.Scrollbar(log_f, orient="vertical", command=term.yview)
            sb.pack(side="right", fill="y")
            term.config(yscrollcommand=sb.set)
            setattr(self, f"_fes_term_{name}", term)

    # ── FES tab launcher helpers ──────────────────────────────────────────────

    def _fes_log(self, msg: str, tab: str = "us"):
        """Thread-safe log to the FES sub-tab terminal."""
        term = getattr(self, f"_fes_term_{tab}", None)
        if term is None:
            self._pes_log(msg)
            return
        def _do():
            term.config(state="normal")
            term.insert("end", msg + "\n")
            term.see("end")
            term.config(state="disabled")
        self.root.after(0, _do)

    def _launch_umbrella_setup(self):
        import threading
        v = self._vars_fes
        mol = v["us_mol"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("US", "Set molecule XYZ first.")
        out = v["fes_out"].get().strip() or os.path.join(os.path.dirname(mol), "umbrella_sampling")
        os.makedirs(out, exist_ok=True)
        import shutil as _sh; _sh.copy2(mol, out)
        mol_base = os.path.basename(mol)
        try:
            a1, a2 = int(v["us_a1"].get()), int(v["us_a2"].get())
            centers = [float(x.strip()) for x in v["us_centers"].get().split(",")]
            spring_k = float(v["us_spring_k"].get())
            n_steps = int(v["us_steps"].get())
            temp = float(v["temperature"].get())
            charge = int(self._vars["charge"].get())
            mult = int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("US", str(exc))
        self._fes_log(f"[US] Setting up {len(centers)} windows …", "us")
        def _worker():
            try:
                summary = self._run_umbrella_sampling_setup(
                    out, mol_base, a1, a2, centers, spring_k, charge, mult, n_steps)
                self._vars_fes["us_summary"].set(summary)
                self._fes_log(f"[US] Done. Summary: {summary}", "us")
            except Exception as exc:
                self._fes_log(f"[US] ERROR: {exc}", "us")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_wham(self):
        import threading
        v = self._vars_fes
        summary = v["us_summary"].get().strip()
        if not summary or not os.path.isfile(summary):
            return messagebox.showerror("WHAM", "Provide the US summary file (us_windows_summary.txt).")
        try:
            a1, a2 = int(v["us_a1"].get()), int(v["us_a2"].get())
            temp = float(v["temperature"].get())
            n_bins = int(v["n_bins"].get())
        except ValueError as exc:
            return messagebox.showerror("WHAM", str(exc))
        self._fes_log("[WHAM] Starting …", "us")
        threading.Thread(
            target=lambda: self._run_wham_analysis(summary, a1, a2, temp, n_bins),
            daemon=True,
        ).start()

    def _launch_metad_fes(self):
        import threading
        v = self._vars_fes
        hills = v["hills_file"].get().strip()
        if not hills or not os.path.isfile(hills):
            return messagebox.showerror("MetaD FES", "Select a HILLS file.")
        out = v["fes_out"].get().strip() or os.path.dirname(hills)
        try:
            cv_min = float(v["hills_cv_min"].get())
            cv_max = float(v["hills_cv_max"].get())
            temp = float(v["temperature"].get())
            n_bins = int(v["n_bins"].get())
            gamma_s = v["hills_gamma"].get().strip()
            gamma = float(gamma_s) if gamma_s else None
            cv_label = v["hills_cv_label"].get() or "CV"
        except ValueError as exc:
            return messagebox.showerror("MetaD FES", str(exc))
        self._fes_log("[MetaD FES] Reconstructing …", "meta")
        threading.Thread(
            target=lambda: self._fes_from_metadynamics_hills(
                hills, (cv_min, cv_max), n_bins, temp, out, cv_label, gamma),
            daemon=True,
        ).start()

    def _load_energy_csv(self, path: str) -> list:
        """Read a single-column CSV/TXT of energy values (kcal/mol). Returns list of floats."""
        vals = []
        with open(path, errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    vals.append(float(line.split(",")[0]))
                except ValueError:
                    continue
        return vals

    def _launch_fep(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("FEP", "Load both energy CSV files.")
        out = v["fes_out"].get().strip() or os.path.dirname(f0)
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("FEP", str(exc))
        self._fes_log("[FEP] Loading data …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                self._fes_log(f"[FEP] n0={len(u0)} n1={len(u1)}", "fep")
                result = self._compute_fep(u0, u1, temp, work_dir=out)
            except Exception as exc:
                self._fes_log(f"[FEP] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_bar(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("BAR", "Load both energy CSV files.")
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("BAR", str(exc))
        self._fes_log("[BAR] Running …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                result = self._compute_bar(u0, u1, temp)
                self._fes_log(
                    f"[BAR] ΔA = {result['delta_A_bar']:+.4f} kcal/mol  "
                    f"({'converged' if result['converged'] else 'not converged'}  "
                    f"in {result['n_iter']} iterations)", "fep")
            except Exception as exc:
                self._fes_log(f"[BAR] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_lra(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("LRA", "Load both energy CSV files.")
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("LRA", str(exc))
        self._fes_log("[LRA] Computing …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                result = self._compute_lra(u0, u1, temp)
                self._fes_log(
                    f"[LRA] ΔA_LRA = {result['delta_A_lra']:+.4f}  "
                    f"λ_reorg = {result['lambda_reorg']:+.4f} kcal/mol", "fep")
            except Exception as exc:
                self._fes_log(f"[LRA] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_lambda_preview(self):
        """Show a small plot of the chosen λ schedule."""
        try:
            n = int(self._vars_fes["n_lambda"].get())
            schedule = self._vars_fes["lambda_schedule"].get().strip() or "linear"
        except ValueError:
            return messagebox.showerror("λ Schedule", "Enter a valid N λ windows.")
        lambdas = self._compute_alchemical_lambda_schedule(n, schedule)
        if not MATPLOTLIB_AVAILABLE:
            self._fes_log(f"[λ] Schedule ({schedule}, {n}): {lambdas}", "fep")
            return
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.plot(range(n), lambdas, "o-", color="#388bfd")
        ax.set_xlabel("Window index")
        ax.set_ylabel("λ")
        ax.set_title(f"λ schedule: {schedule}  (N={n})")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        plt.show()

    # =========================================================================
    # NEW TAB BUILDERS — NEB/TS, Reaction Library, PES Tutorial
    # =========================================================================

    def _build_neb_tab(self, parent):
        """Dedicated NEB / TS-Search tab."""
        top = tk.Frame(parent, bg=_C["bg"])
        top.pack(fill="both", expand=True, padx=10, pady=8)

        tk.Label(top, text="NEB / Transition State Search",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))

        pane = tk.Frame(top, bg=_C["panel"], bd=1, relief="flat")
        pane.pack(fill="x", pady=4)

        def _browse_neb(key):
            fp = filedialog.askopenfilename(title=f"Select {key.title()} XYZ",
                                            filetypes=[("XYZ", "*.xyz"), ("All", "*")])
            if fp:
                self._vars_neb[key].set(fp)

        for key, label in [("reactant", "Reactant (start) XYZ:"),
                            ("product",  "Product  (end)   XYZ:")]:
            row = tk.Frame(pane, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=24, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_neb[key], bg=_C["entry"],
                     fg=_C["text"], bd=0, font=("Consolas", 9)).pack(side="left", fill="x", expand=True, padx=4)
            tk.Button(row, text="...", bg=_C["accent"], fg="white",
                      command=lambda k=key: _browse_neb(k)).pack(side="left")

        # Parameter row
        params = tk.Frame(pane, bg=_C["panel"])
        params.pack(fill="x", padx=8, pady=4)
        for label, key, width in [
            ("Engine:",     "engine",        10),
            ("Images:",     "images",         5),
            ("Spring k:",   "spring_k",       7),
            ("Charge:",     "charge",          5),
            ("Multiplicity:", "mult",          5),
            ("Max Iter:",   "max_iter",        6),
        ]:
            tk.Label(params, text=label, bg=_C["panel"], fg=_C["text"],
                     font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
            if key == "engine":
                ttk.Combobox(params, textvariable=self._vars_neb[key],
                             values=["xtb", "orca"], width=width,
                             state="readonly").pack(side="left", padx=(0, 6))
            else:
                tk.Entry(params, textvariable=self._vars_neb[key], width=width,
                         bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", padx=(0, 6))

        chk_row = tk.Frame(pane, bg=_C["panel"])
        chk_row.pack(fill="x", padx=8, pady=(2, 6))
        tk.Checkbutton(chk_row, text="Run TS refinement after NEB",
                       variable=self._vars_neb["run_ts_refine"],
                       bg=_C["panel"], fg=_C["text"], selectcolor=_C["entry"],
                       font=("Segoe UI", 9)).pack(side="left", padx=4)
        tk.Checkbutton(chk_row, text="Compute Hessian at TS",
                       variable=self._vars_neb["ts_hess"],
                       bg=_C["panel"], fg=_C["text"], selectcolor=_C["entry"],
                       font=("Segoe UI", 9)).pack(side="left", padx=4)

        # Action buttons
        btn_row = tk.Frame(top, bg=_C["bg"])
        btn_row.pack(fill="x", pady=6)
        tk.Button(btn_row, text=" ▶  Run NEB ", command=self._start_neb,
                  bg=_C["green"], fg="black", font=("Segoe UI", 11, "bold"),
                  padx=20, pady=4).pack(side="left", padx=4)
        tk.Button(btn_row, text=" ✗  Stop ", command=self._stop_neb,
                  bg=_C["red"], fg="white", font=("Segoe UI", 11, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)
        tk.Button(btn_row, text=" Open Output Folder ",
                  command=self._open_neb_output_folder,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 10),
                  padx=10, pady=4).pack(side="left", padx=4)

        # Terminal log widget
        log_frame = tk.Frame(top, bg=_C["bg"])
        log_frame.pack(fill="both", expand=True, pady=(4, 0))
        tk.Label(log_frame, text="NEB Log:", bg=_C["bg"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._neb_term = tk.Text(log_frame, bg="#0c0c0c", fg="#d4d4d4",
                                  font=("Consolas", 9), wrap="none",
                                  state="disabled", height=20)
        self._neb_term.pack(fill="both", expand=True)
        nsb = tk.Scrollbar(log_frame, orient="vertical", command=self._neb_term.yview)
        nsb.pack(side="right", fill="y")
        self._neb_term.config(yscrollcommand=nsb.set)

    def _neb_log(self, msg: str):
        """Append message to NEB terminal log (thread-safe)."""
        def _do():
            self._neb_term.config(state="normal")
            self._neb_term.insert("end", msg + "\n")
            self._neb_term.see("end")
            self._neb_term.config(state="disabled")
        self.root.after(0, _do)

    def _stop_neb(self):
        """Signal the NEB worker to stop by setting is_running=False."""
        self.is_running = False
        self._neb_log("[NEB] Stop requested — current step will finish then exit.")

    def _open_neb_output_folder(self):
        """Open the NEB output folder in Explorer."""
        reactant = self._vars_neb["reactant"].get().strip()
        folder = os.path.join(os.path.dirname(reactant), "neb_run") if reactant else ""
        if not folder or not os.path.isdir(folder):
            folder = self._vars["out"].get().strip()
        if folder and os.path.isdir(folder):
            os.startfile(folder)
        else:
            messagebox.showinfo("Open Folder", "Output folder not found yet — run NEB first.")

    def _start_neb(self):
        """Launch NEB/TS worker thread."""
        v = {k: (var.get() if not isinstance(var, tk.BooleanVar) else var.get())
             for k, var in self._vars_neb.items()}
        if not v["reactant"] or not os.path.isfile(v["reactant"]):
            return messagebox.showerror("NEB", "Reactant XYZ file missing or invalid.")
        if not v["product"] or not os.path.isfile(v["product"]):
            return messagebox.showerror("NEB", "Product XYZ file missing or invalid.")
        self._neb_log(f"[NEB] Starting NEB with engine={v['engine']}, images={v['images']}")
        threading.Thread(target=self._worker_neb, args=(v,), daemon=True).start()

    def _worker_neb(self, v: dict):
        """Background worker — calls existing NEB/path engine."""
        import traceback
        out_dir = os.path.join(os.path.dirname(v["reactant"]), "neb_run")
        os.makedirs(out_dir, exist_ok=True)
        try:
            engine = v["engine"].lower()
            if engine == "orca":
                self._neb_log("[NEB] Running ORCA NEB-CI …")
                result = self._run_orca_neb(
                    reactant_xyz=v["reactant"],
                    product_xyz=v["product"],
                    out_dir=out_dir,
                    images=int(v["images"]),
                    charge=int(v["charge"]),
                    mult=int(v["mult"]),
                )
            else:
                self._neb_log("[NEB] Running xTB path (NEB-like) …")
                result = self._run_xtb_path(
                    reactant_xyz=v["reactant"],
                    product_xyz=v["product"],
                    out_dir=out_dir,
                    images=int(v["images"]),
                    charge=int(v["charge"]),
                    mult=int(v["mult"]),
                )
            if isinstance(result, dict):
                self._neb_log(f"[NEB] Done. Status: {result.get('status', 'unknown')}")
                if result.get("ts_energy"):
                    self._neb_log(f"[NEB] TS Energy: {result['ts_energy']:.6f} Eh")
            else:
                self._neb_log(f"[NEB] Done. Output: {result}")
        except Exception:
            self._neb_log(f"[NEB] ERROR:\n{traceback.format_exc()}")

    # -------------------------------------------------------------------------

    def _build_reaction_library_tab(self, parent):
        """Reaction Library browser tab."""
        tk.Label(parent, text="Reaction Library — Curated Presets",
                 bg=_C["bg"], fg=_C["green"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=10, pady=(8, 4))

        pane = tk.Frame(parent, bg=_C["bg"])
        pane.pack(fill="both", expand=True, padx=10, pady=4)

        # Left: treeview
        left = tk.Frame(pane, bg=_C["panel"], width=280)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="Reactions", bg=_C["panel"], fg=_C["accent"],
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=6, pady=4)

        tv = ttk.Treeview(left, columns=("type",), show="tree headings",
                          selectmode="browse")
        tv.heading("#0", text="Name")
        tv.heading("type", text="Type")
        tv.column("#0", width=190)
        tv.column("type", width=110, stretch=False)
        tv.pack(fill="both", expand=True, padx=4, pady=4)
        tsb = tk.Scrollbar(left, orient="vertical", command=tv.yview)
        tsb.pack(side="right", fill="y")
        tv.config(yscrollcommand=tsb.set)

        categories: dict[str, list] = {}
        for name, info in REACTION_LIBRARY.items():
            cat = info.get("type", "Other")
            categories.setdefault(cat, []).append(name)

        cat_nodes: dict[str, str] = {}
        for cat, names in sorted(categories.items()):
            node = tv.insert("", "end", text=f"  {cat}", values=("",), open=True,
                             tags=("cat",))
            cat_nodes[cat] = node
            for n in names:
                tv.insert(node, "end", text=n, iid=n,
                          values=(REACTION_LIBRARY[n].get("type", ""),))

        tv.tag_configure("cat", foreground="#e0b040")

        # Right: detail panel
        right = tk.Frame(pane, bg=_C["panel"])
        right.pack(side="left", fill="both", expand=True)

        detail_title = tk.Label(right, text="Select a reaction →", bg=_C["panel"],
                                fg=_C["accent"], font=("Segoe UI", 11, "bold"),
                                wraplength=500, justify="left")
        detail_title.pack(anchor="w", padx=10, pady=(8, 2))

        detail_txt = tk.Text(right, bg=_C["entry"], fg=_C["text"],
                             font=("Consolas", 9), wrap="word", height=12,
                             bd=0, state="disabled")
        detail_txt.pack(fill="both", expand=True, padx=10, pady=4)

        apply_row = tk.Frame(right, bg=_C["panel"])
        apply_row.pack(fill="x", padx=10, pady=6)
        self._rxn_lib_selected: str = ""

        def _on_select(_evt):
            iid = tv.focus()
            if not iid or iid not in REACTION_LIBRARY:
                return
            self._rxn_lib_selected = iid
            info = REACTION_LIBRARY[iid]
            detail_title.config(text=iid)
            dist = info.get("distance", ("?", "?"))
            body = (
                f"Type         : {info.get('type', 'N/A')}\n"
                f"Distance (Å) : {dist[0]:.1f} – {dist[1]:.1f}\n"
                f"Anchor role  : {info.get('anchor_role', 'N/A')}\n"
                f"Guest role   : {info.get('guest_role', 'N/A')}\n\n"
                f"Description  :\n  {info.get('description', '')}\n\n"
                f"Reference    :\n  {info.get('ref', 'N/A')}\n"
            )
            detail_txt.config(state="normal")
            detail_txt.delete("1.0", "end")
            detail_txt.insert("end", body)
            detail_txt.config(state="disabled")

        tv.bind("<<TreeviewSelect>>", _on_select)

        def _apply_to_pipeline():
            if not self._rxn_lib_selected:
                return
            info = REACTION_LIBRARY[self._rxn_lib_selected]
            rtype = info.get("type", "Non-covalent")
            # Map library type to pipeline combo values
            match = rtype if rtype in REACTION_TYPE_CHOICES else "Non-covalent"
            self._vars["reaction_type"].set(match)
            self._append_text(
                f"\n[Reaction Library] Applied: {self._rxn_lib_selected}\n"
                f"  Reaction type set to: {match}\n"
                f"  Typical distance: {info.get('distance', ('?','?'))[0]:.1f}–{info.get('distance',('?','?'))[1]:.1f} Å\n"
            )
            self.nb.select(self.tab_main)

        def _apply_to_neb():
            if not self._rxn_lib_selected:
                return
            self._append_text(f"\n[Reaction Library → NEB] Switched to NEB tab for: {self._rxn_lib_selected}\n")
            self.nb.select(self.tab_neb)

        tk.Button(apply_row, text="Apply to Pipeline Tab", command=_apply_to_pipeline,
                  bg=_C["green"], fg="black", font=("Segoe UI", 10, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)
        tk.Button(apply_row, text="Apply to NEB Tab", command=_apply_to_neb,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 10, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)

        # Search bar
        search_row = tk.Frame(right, bg=_C["panel"])
        search_row.pack(fill="x", padx=10, pady=(0, 6))
        tk.Label(search_row, text="Search:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9)).pack(side="left")
        search_var = tk.StringVar()
        tk.Entry(search_row, textvariable=search_var, bg=_C["entry"], fg=_C["text"],
                 bd=0, font=("Segoe UI", 9), width=28).pack(side="left", padx=6)

        def _search(_evt=None):
            q = search_var.get().lower()
            tv.selection_remove(*tv.selection())
            for iid in REACTION_LIBRARY:
                try:
                    if q in iid.lower() or q in REACTION_LIBRARY[iid].get("type", "").lower():
                        tv.focus(iid)
                        tv.selection_set(iid)
                        tv.see(iid)
                        _on_select(None)
                        break
                except Exception:
                    pass

        search_var.trace_add("write", lambda *_: _search())

    # =========================================================================
    # PREBIOTIC CHEMISTRY MODULE
    # =========================================================================

    # ── Backend computation helpers ───────────────────────────────────────────

    def _prebiotic_match_conditions(
        self,
        rxn_data: dict,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
    ) -> dict:
        """Score how well user conditions match a prebiotic reaction entry.

        Returns dict with keys:
          score       (0–100, higher = better match)
          T_match     (True/False/partial)
          pH_match
          P_match
          atm_match   fraction of required gases present
          mineral_match fraction of catalysts present
          warnings    list of text warnings
          suggestions list of optimisation suggestions
        """
        warnings = []
        suggestions = []
        score = 0.0

        # Temperature
        t_range = rxn_data.get("T_K", (None, None, None))
        t_min, t_max, t_opt = (t_range + (None,))[:3] if len(t_range) >= 2 else (None, None, None)
        t_match = "unknown"
        if t_min is not None and t_max is not None:
            if t_min <= T_K <= t_max:
                t_match = True
                score += 30
                if t_opt is not None:
                    deviation = abs(T_K - t_opt) / max(t_max - t_min, 1)
                    score += max(0, 10 * (1 - deviation))
            else:
                t_match = False
                if T_K < t_min:
                    warnings.append(f"Temperature {T_K} K is below minimum {t_min} K.")
                    suggestions.append(f"Raise temperature to at least {t_min} K ({t_min - 273:.0f} °C).")
                else:
                    warnings.append(f"Temperature {T_K} K exceeds maximum {t_max} K.")
                    suggestions.append(f"Lower temperature below {t_max} K ({t_max - 273:.0f} °C).")
        else:
            t_match = "n/a"
            score += 15

        # pH
        ph_range = rxn_data.get("pH", (None, None, None))
        ph_min, ph_max = ph_range[0], ph_range[1]
        ph_match = "unknown"
        if ph_min is not None and ph_max is not None:
            if ph_min <= pH <= ph_max:
                ph_match = True
                score += 25
                if len(ph_range) >= 3 and ph_range[2] is not None:
                    dev = abs(pH - ph_range[2]) / max(ph_max - ph_min, 0.1)
                    score += max(0, 10 * (1 - dev))
            else:
                ph_match = False
                if pH < ph_min:
                    warnings.append(f"pH {pH:.1f} is too acidic (need ≥ {ph_min}).")
                    suggestions.append(f"Raise pH toward {ph_range[2] or ph_min} (add NH3, Na2CO3).")
                else:
                    warnings.append(f"pH {pH:.1f} is too basic (need ≤ {ph_max}).")
                    suggestions.append(f"Lower pH toward {ph_range[2] or ph_max} (add CO2, HCl).")
        else:
            ph_match = "n/a"
            score += 12

        # Pressure
        p_range = rxn_data.get("P_atm") or (None, None)
        p_min, p_max = p_range[0], p_range[1]
        p_match = "unknown"
        if p_min is not None and p_max is not None:
            if p_min <= P_atm <= p_max:
                p_match = True
                score += 10
            else:
                p_match = False
                if P_atm < p_min:
                    warnings.append(f"Pressure {P_atm:.1f} atm below minimum {p_min} atm.")
                    suggestions.append(f"Increase pressure to ≥ {p_min} atm (hydrothermal/deep sea).")
                else:
                    warnings.append(f"Pressure {P_atm:.1f} atm above maximum {p_max} atm.")
        else:
            p_match = "n/a"
            score += 5

        # Atmosphere
        required_atm = [a.lower() for a in (rxn_data.get("atmosphere") or [])]
        provided_atm = [a.strip().lower() for a in user_atm]
        atm_found = sum(1 for a in required_atm if any(a in p for p in provided_atm))
        atm_match = atm_found / len(required_atm) if required_atm else 1.0
        score += 15 * atm_match
        for a in required_atm:
            if not any(a in p for p in provided_atm):
                warnings.append(f"Required atmospheric component missing: {a.upper()}")
                suggestions.append(f"Add {a.upper()} to reaction atmosphere.")

        # Minerals
        required_min = [m.lower() for m in (rxn_data.get("minerals") or [])]
        provided_min = [m.strip().lower() for m in user_minerals]
        min_found = sum(1 for m in required_min if any(m.split("(")[0].strip() in p for p in provided_min))
        mineral_match = min_found / len(required_min) if required_min else 1.0
        score += 10 * mineral_match
        for m in required_min:
            if not any(m.split("(")[0].strip() in p for p in provided_min):
                suggestions.append(f"Consider adding mineral catalyst: {m}")

        score = min(100.0, score)
        return {
            "score": round(score, 1),
            "T_match": t_match,
            "pH_match": ph_match,
            "P_match": p_match,
            "atm_match": round(atm_match * 100),
            "mineral_match": round(mineral_match * 100),
            "warnings": warnings,
            "suggestions": suggestions,
        }

    def _prebiotic_filter_reactions(
        self,
        category: str = "All",
        env_keyword: str = "All",
        query: str = "",
    ) -> list:
        """Return list of (rxn_name, rxn_data) matching the filters."""
        results = []
        q = query.strip().lower()
        for name, data in PREBIOTIC_DB.items():
            if category != "All" and data.get("category", "") != category:
                continue
            if env_keyword != "All":
                env_list = " ".join(data.get("env", [])).lower()
                if env_keyword.lower() not in env_list:
                    continue
            if q:
                blob = (
                    name + " " +
                    data.get("category", "") + " " +
                    " ".join(data.get("products", [])) + " " +
                    " ".join(str(v) for v in data.get("reactants", {}).keys()) + " " +
                    data.get("pathway", "") + " " +
                    " ".join(data.get("env", []))
                ).lower()
                if q not in blob:
                    continue
            results.append((name, data))
        return results

    def _prebiotic_generate_report(
        self,
        rxn_name: str,
        rxn_data: dict,
        match: dict,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
        output_dir: str,
    ) -> str:
        """Write a detailed plain-text elucidation report; return file path."""
        lines = [
            "=" * 72,
            "  PREBIOTIC REACTION CONDITION ELUCIDATION REPORT",
            f"  IAK Pipeline v11.2  |  Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            "=" * 72,
            "",
            f"REACTION  : {rxn_name}",
            f"CATEGORY  : {rxn_data.get('category', 'N/A')}",
            f"MATCH SCORE: {match['score']:.1f} / 100",
            "",
            "─" * 72,
            "USER CONDITIONS",
            "─" * 72,
            f"  Temperature : {T_K} K  ({T_K - 273.15:.1f} °C)",
            f"  pH          : {pH}",
            f"  Pressure    : {P_atm} atm",
            f"  Atmosphere  : {', '.join(user_atm) or 'not specified'}",
            f"  Minerals    : {', '.join(user_minerals) or 'none'}",
            "",
            "─" * 72,
            "OPTIMAL / REPORTED CONDITIONS",
            "─" * 72,
        ]
        t_range = rxn_data.get("T_K", ())
        if len(t_range) == 3:
            lines.append(f"  Temperature : {t_range[0]}–{t_range[1]} K  (optimal {t_range[2]} K)")
        ph_range = rxn_data.get("pH", ())
        if len(ph_range) >= 2 and ph_range[0] is not None:
            lines.append(f"  pH          : {ph_range[0]}–{ph_range[1]}")
        p_range = rxn_data.get("P_atm") or ()
        if len(p_range) == 2 and p_range[0] is not None:
            lines.append(f"  Pressure    : {p_range[0]}–{p_range[1]} atm")
        lines += [
            f"  Atmosphere  : {', '.join(rxn_data.get('atmosphere', [])) or 'none required'}",
            f"  Minerals    : {', '.join(rxn_data.get('minerals', [])) or 'none required'}",
            f"  Environment : {', '.join(rxn_data.get('env', []))}",
            "",
            "─" * 72,
            "REACTION DETAILS",
            "─" * 72,
            "  Reactants:",
        ]
        for mol, role in (rxn_data.get("reactants") or {}).items():
            lines.append(f"    • {mol}  [{role}]")
        lines.append("  Products:")
        for p in rxn_data.get("products", []):
            lines.append(f"    • {p}")
        dg = rxn_data.get("energy_kJ")
        if dg is not None:
            sign = "endergonic (+)" if dg > 0 else "exergonic (−)"
            lines.append(f"  ΔG° (STP)   : {dg:+.1f} kJ/mol  [{sign}]")
        lines += [
            "",
            f"  Mechanism   : {rxn_data.get('pathway', 'N/A')}",
            "",
            "─" * 72,
            "CONDITION MATCH ANALYSIS",
            "─" * 72,
            f"  Temperature match : {match['T_match']}",
            f"  pH match          : {match['pH_match']}",
            f"  Pressure match    : {match['P_match']}",
            f"  Atmosphere match  : {match['atm_match']}%",
            f"  Mineral match     : {match['mineral_match']}%",
        ]
        if match["warnings"]:
            lines += ["", "  WARNINGS:"]
            for w in match["warnings"]:
                lines.append(f"    ⚠  {w}")
        if match["suggestions"]:
            lines += ["", "  SUGGESTIONS:"]
            for s in match["suggestions"]:
                lines.append(f"    →  {s}")
        lines += [
            "",
            "─" * 72,
            "FEASIBILITY NOTES",
            "─" * 72,
            "  " + rxn_data.get("feasibility_notes", "").replace("\n", "\n  "),
            "",
            "─" * 72,
            "KEY REFERENCES",
            "─" * 72,
        ]
        for ref in rxn_data.get("refs", []):
            lines.append(f"  [{ref}]")
        lines += ["", "=" * 72, "END OF REPORT", "=" * 72, ""]
        report_text = "\n".join(lines)

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_", rxn_name)[:60]
        report_path = os.path.join(output_dir, f"prebiotic_{safe_name}.txt")
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_text)
        return report_path

    def _prebiotic_plot_condition_radar(
        self,
        rxn_name: str,
        match: dict,
        output_dir: str,
    ) -> str:
        """Draw a radar (spider) chart showing the condition match; save PNG."""
        if not MATPLOTLIB_AVAILABLE:
            return ""
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        labels = ["Temperature", "pH", "Pressure", "Atmosphere", "Minerals"]

        def _bool_to_score(v):
            if v is True:
                return 100
            if v is False:
                return 0
            return 50  # partial / n/a

        values = [
            _bool_to_score(match["T_match"]),
            _bool_to_score(match["pH_match"]),
            _bool_to_score(match["P_match"]),
            match["atm_match"],
            match["mineral_match"],
        ]

        N = len(labels)
        angles = [n / float(N) * 2 * math.pi for n in range(N)]
        angles += angles[:1]
        vals_plot = values + values[:1]

        fig, ax = plt.subplots(figsize=(5, 5), subplot_kw=dict(polar=True))
        fig.patch.set_facecolor(_C["panel"])
        ax.set_facecolor(_C["panel"])
        ax.plot(angles, vals_plot, "o-", linewidth=2, color=_C["green"])
        ax.fill(angles, vals_plot, alpha=0.25, color=_C["green"])
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=9, color=_C["text"])
        ax.set_ylim(0, 100)
        ax.set_yticks([25, 50, 75, 100])
        ax.set_yticklabels(["25", "50", "75", "100"], fontsize=7, color=_C["muted"])
        ax.set_title(f"Condition Match\n{rxn_name[:45]}", fontsize=10, pad=14,
                     color=_C["text"], fontweight="bold")
        score_patch = mpatches.Patch(color=_C["green"],
                                     label=f"Overall score: {match['score']:.0f}/100")
        ax.legend(handles=[score_patch], loc="upper right",
                  bbox_to_anchor=(1.3, 1.1), fontsize=9)
        fig.tight_layout()

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_", rxn_name)[:50]
        out_path = os.path.join(output_dir, f"prebiotic_radar_{safe_name}.png")
        fig.savefig(out_path, dpi=120, bbox_inches="tight",
                    facecolor=_C["panel"])
        plt.close(fig)
        return out_path

    def _prebiotic_plot_energy_diagram(
        self,
        rxn_data: dict,
        output_dir: str,
    ) -> str:
        """Draw a simple reaction energy diagram for the prebiotic reaction."""
        if not MATPLOTLIB_AVAILABLE:
            return ""
        import matplotlib.pyplot as plt

        dg = rxn_data.get("energy_kJ")
        if dg is None:
            return ""

        reactants = list((rxn_data.get("reactants") or {}).keys())
        products = rxn_data.get("products", ["Products"])
        r_label = " + ".join(str(r) for r in reactants[:2]) or "Reactants"
        p_label = " + ".join(str(p) for p in products[:2]) or "Products"

        fig, ax = plt.subplots(figsize=(6, 4))
        fig.patch.set_facecolor(_C["panel"])
        ax.set_facecolor(_C["panel"])

        e_r, e_ts, e_p = 0.0, max(dg + 15, 15), dg
        for x, y, lbl, col in [
            (0.1, e_r, r_label, _C["accent"]),
            (0.5, e_ts, "Transition State†", _C["red"]),
            (0.9, e_p, p_label, _C["green"]),
        ]:
            ax.plot([x - 0.05, x + 0.05], [y, y], linewidth=3, color=col)
            ax.text(x, y + 2, lbl[:28], ha="center", va="bottom",
                    fontsize=8, color=col, fontweight="bold")

        ax.plot([0.15, 0.45], [e_r, e_ts], "k--", lw=1, alpha=0.5)
        ax.plot([0.55, 0.85], [e_ts, e_p], "k--", lw=1, alpha=0.5)

        ax.annotate("", xy=(0.5, e_ts), xytext=(0.5, e_r),
                    arrowprops=dict(arrowstyle="<->", color=_C["red"], lw=1.5))
        ax.text(0.52, (e_ts + e_r) / 2, f"+{e_ts:.0f} kJ/mol", fontsize=8,
                color=_C["red"], va="center")
        ax.annotate("", xy=(0.9, e_p), xytext=(0.9, e_r),
                    arrowprops=dict(arrowstyle="<->", color=_C["green"], lw=1.5))
        ax.text(0.92, (e_p + e_r) / 2, f"{dg:+.0f} kJ/mol", fontsize=8,
                color=_C["green"], va="center")

        ax.set_ylabel("Relative Energy (kJ/mol)", color=_C["text"])
        ax.set_xlim(0, 1.05)
        ax.set_xticks([])
        ax.set_title(f"Prebiotic Reaction Energy Profile", fontsize=10,
                     color=_C["text"], fontweight="bold")
        ax.spines[["top", "right", "bottom"]].set_visible(False)
        ax.tick_params(colors=_C["muted"])
        ax.yaxis.label.set_color(_C["muted"])
        fig.tight_layout()

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_",
                           rxn_data.get("category", "rxn"))[:40]
        out_path = os.path.join(output_dir, f"prebiotic_energy_{safe_name}.png")
        fig.savefig(out_path, dpi=120, bbox_inches="tight",
                    facecolor=_C["panel"])
        plt.close(fig)
        return out_path

    def _prebiotic_run_xtb_thermo(
        self,
        mol_file: str,
        T_K: float,
        charge: int,
        mult: int,
        output_dir: str,
        method: str = "--gfn2",
        solvent: str = "",
    ) -> dict:
        """Run xTB opt + Hessian at the given temperature; return thermo dict."""
        if not is_tool_available("xtb"):
            return {"error": "xTB not found on PATH."}
        from platform import system as _sys
        xtb = "xtb.exe" if _sys() == "Windows" else "xtb"
        os.makedirs(output_dir, exist_ok=True)
        solvent_flag = f"--alpb {solvent}" if solvent else ""
        cmd = (
            f'"{xtb}" "{mol_file}" {method} --opt --hess --temp {T_K}'
            f' --chrg {charge} --uhf {mult - 1}'
            f' {solvent_flag} > xtb_prebiotic.log 2>&1'
        )
        subprocess.run(cmd, shell=True, cwd=output_dir)
        log = os.path.join(output_dir, "xtb_prebiotic.log")
        result = {"log": log, "T_K": T_K, "charge": charge, "mult": mult}
        if os.path.isfile(log):
            text = open(log, errors="replace").read()
            for pattern, key in [
                (r"TOTAL FREE ENERGY\s*=\s*([-\d.]+)", "G_Eh"),
                (r"TOTAL ENTHALPY\s*=\s*([-\d.]+)", "H_Eh"),
                (r"ZERO POINT ENERGY\s*=\s*([-\d.]+)", "ZPE_Eh"),
                (r"G\(RRHO\)\s*=\s*([-\d.]+)", "G_RRHO_Eh"),
                (r"(-?\d+\.\d+) Eh\s+TOTAL ENERGY", "E_Eh"),
            ]:
                m = re.search(pattern, text)
                if m:
                    result[key] = float(m.group(1))
        return result

    def _prebiotic_rank_all(
        self,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
        category: str = "All",
    ) -> list:
        """Score every reaction in PREBIOTIC_DB against the user conditions;
        return sorted list of (score, name, match_dict)."""
        results = []
        for name, data in PREBIOTIC_DB.items():
            if category != "All" and data.get("category") != category:
                continue
            match = self._prebiotic_match_conditions(
                data, T_K, pH, P_atm, user_atm, user_minerals)
            results.append((match["score"], name, match, data))
        results.sort(key=lambda x: -x[0])
        return results

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_prebiotic_tab(self, parent):
        """Prebiotic Reaction Condition Elucidation — multi-module notebook."""
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True, padx=4, pady=4)

        # ── Sub-tabs ──────────────────────────────────────────────────────────
        tab_db    = tk.Frame(nb, bg=_C["bg"])
        tab_rxn   = tk.Frame(nb, bg=_C["bg"])
        tab_xtb   = tk.Frame(nb, bg=_C["bg"])
        tab_crest = tk.Frame(nb, bg=_C["bg"])
        tab_orca  = tk.Frame(nb, bg=_C["bg"])
        tab_tut   = tk.Frame(nb, bg=_C["bg"])

        nb.add(tab_db,    text="  📚 Reaction Library  ")
        nb.add(tab_rxn,   text="  🧪 Custom Reactants  ")
        nb.add(tab_xtb,   text="  ⚡ xTB Module  ")
        nb.add(tab_crest, text="  🔄 CREST Module  ")
        nb.add(tab_orca,  text="  🎯 ORCA Module  ")
        nb.add(tab_tut,   text="  📖 Tutorials  ")

        self._build_prebiotic_db_subtab(tab_db)
        self._build_prebiotic_rxn_subtab(tab_rxn)
        self._build_prebiotic_xtb_subtab(tab_xtb)
        self._build_prebiotic_crest_subtab(tab_crest)
        self._build_prebiotic_orca_subtab(tab_orca)
        self._build_prebiotic_tutorial_subtab(tab_tut)

    # ── Shared helpers ────────────────────────────────────────────────────────

    def _prebiotic_output_dir(self) -> str:
        d = self._vars_prebiotic["output_dir"].get().strip()
        if not d:
            d = os.path.join(os.getcwd(), "prebiotic_output")
        return d

    def _prebio_file_row(self, parent, label, key, *, filetypes=None, directory=False):
        """Helper: labelled file-browse row."""
        row = tk.Frame(parent, bg=_C["panel"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                 width=18, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row, textvariable=self._vars_prebiotic[key],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)
        def _browse():
            if directory:
                v = filedialog.askdirectory()
            else:
                v = filedialog.askopenfilename(
                    filetypes=filetypes or [("XYZ", "*.xyz"), ("All", "*")])
            if v:
                self._vars_prebiotic[key].set(v)
        tk.Button(row, text="…", command=_browse,
                  bg=_C["accent"], fg="white", bd=0, width=3).pack(side="left")

    def _prebio_entry_row(self, parent, label, key, width=14, tooltip=None):
        row = tk.Frame(parent, bg=_C["panel"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                 width=22, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row, textvariable=self._vars_prebiotic[key],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=width).pack(side="left", padx=4)
        if tooltip:
            tk.Label(row, text=tooltip, bg=_C["panel"], fg=_C["muted"],
                     font=("Segoe UI", 8, "italic")).pack(side="left")

    def _prebio_log_widget(self, parent, height=14):
        """Return a disabled Text + scrollbar packed into parent."""
        f = tk.Frame(parent, bg=_C["panel"])
        f.pack(fill="both", expand=True, padx=4, pady=4)
        t = tk.Text(f, bg="#0c0c0c", fg="#d4d4d4",
                    font=("Consolas", 9), wrap="word",
                    state="disabled", height=height)
        t.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(f, orient="vertical", command=t.yview)
        sb.pack(side="right", fill="y")
        t.config(yscrollcommand=sb.set)
        for tag, fg_col in [("header", _C["accent"]), ("good", "#22c55e"),
                             ("warn", "#f59e0b"), ("bad", _C["red"]),
                             ("muted", _C["muted"])]:
            t.tag_config(tag, foreground=fg_col,
                         font=("Consolas", 10, "bold") if tag == "header" else None)
        return t

    def _prebio_write(self, widget, text, clear=False):
        """Thread-safe write to a log Text widget."""
        def _do():
            widget.config(state="normal")
            if clear:
                widget.delete("1.0", "end")
            widget.insert("end", text + "\n")
            widget.see("end")
            widget.config(state="disabled")
        self.root.after(0, _do)

    # ── Tab 1 : Reaction Library (DB) ─────────────────────────────────────────

    def _build_prebiotic_db_subtab(self, parent):
        paned = tk.PanedWindow(parent, orient=tk.HORIZONTAL,
                               sashwidth=5, bg=_C["border"])
        paned.pack(fill="both", expand=True, padx=6, pady=6)

        left = tk.Frame(paned, bg=_C["bg"], width=360)
        paned.add(left, minsize=320)

        # ── Conditions ────────────────────────────────────────────────────────
        cond_f = tk.LabelFrame(left, text=" Primitive Earth Conditions ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        cond_f.pack(fill="x", padx=6, pady=4)
        self._prebio_entry_row(cond_f, "Temperature (K):", "T_K",
                               tooltip="298 … 600")
        self._prebio_entry_row(cond_f, "pH:", "pH", tooltip="0 … 14")
        self._prebio_entry_row(cond_f, "Pressure (atm):", "P_atm", tooltip="1 … 500")
        self._prebio_entry_row(cond_f, "Atmosphere (csv):", "atmosphere",
                               tooltip="e.g. N2, CO2, H2, CH4")
        self._prebio_entry_row(cond_f, "Minerals (csv):", "minerals",
                               tooltip="e.g. Montmorillonite, FeS")

        # ── Presets ───────────────────────────────────────────────────────────
        preset_f = tk.LabelFrame(left, text=" Environment Presets ",
                                 bg=_C["panel"], fg=_C["yellow"],
                                 font=("Segoe UI", 9, "bold"), padx=8, pady=4)
        preset_f.pack(fill="x", padx=6, pady=3)
        presets = {
            "Miller-Urey flask": dict(T_K="298", pH="7.0", P_atm="1.0",
                                      atmosphere="H2, NH3, CH4, H2O", minerals=""),
            "Alkaline vent":     dict(T_K="373", pH="11.0", P_atm="50",
                                      atmosphere="H2, CO2",
                                      minerals="FeS, Greigite, Serpentine"),
            "Ice eutectic":      dict(T_K="253", pH="9.0", P_atm="1.0",
                                      atmosphere="HCN, NH3, CO2", minerals=""),
            "Tidal flat":        dict(T_K="333", pH="8.0", P_atm="1.0",
                                      atmosphere="N2, CO2, H2O, NH3",
                                      minerals="Montmorillonite, Hydroxyapatite"),
            "Volcanic fumarole": dict(T_K="573", pH="2.5", P_atm="3.0",
                                      atmosphere="SO2, HCl, H2O, CO2",
                                      minerals="Apatite, Fe3O4"),
            "Soda lake":         dict(T_K="298", pH="10.0", P_atm="1.0",
                                      atmosphere="CO2, N2, H2O",
                                      minerals="Na2CO3, Borate minerals"),
        }
        rows = [tk.Frame(preset_f, bg=_C["panel"]) for _ in range(2)]
        for r in rows:
            r.pack(fill="x", pady=1)
        for i, (nm, vals) in enumerate(presets.items()):
            def _ap(v=vals):
                for k2, v2 in v.items():
                    self._vars_prebiotic[k2].set(v2)
            tk.Button(rows[i // 3], text=nm[:20],
                      command=_ap, bg=_C["dim"], fg=_C["text"],
                      font=("Segoe UI", 8), padx=3, pady=2,
                      relief="flat", cursor="hand2").pack(
                          side="left", padx=2, expand=True, fill="x")

        # ── Filters ───────────────────────────────────────────────────────────
        filt_f = tk.LabelFrame(left, text=" Filter / Search ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=8, pady=4)
        filt_f.pack(fill="x", padx=6, pady=3)
        cats = ["All"] + sorted(set(
            d.get("category", "Other") for d in PREBIOTIC_DB.values()))
        envs = ["All", "Hydrothermal vent", "Ice eutectic", "Mineral surface",
                "Tidal pool", "Alkaline lake", "Volcanic", "Aqueous solution"]
        for lbl, key, vals in [
            ("Category:", "filter_category", cats),
            ("Environment:", "filter_env", envs),
        ]:
            r = tk.Frame(filt_f, bg=_C["panel"])
            r.pack(fill="x", pady=1)
            tk.Label(r, text=lbl, bg=_C["panel"], fg=_C["text"],
                     width=13, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            ttk.Combobox(r, textvariable=self._vars_prebiotic[key],
                         values=vals, state="readonly", width=22).pack(
                             side="left", padx=4)
        sr = tk.Frame(filt_f, bg=_C["panel"])
        sr.pack(fill="x", pady=1)
        tk.Label(sr, text="Search:", bg=_C["panel"], fg=_C["text"],
                 width=13, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(sr, textvariable=self._vars_prebiotic["search_query"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=24).pack(
                     side="left", padx=4)

        # ── Buttons ───────────────────────────────────────────────────────────
        bf = tk.Frame(left, bg=_C["bg"])
        bf.pack(fill="x", padx=6, pady=6)
        tk.Button(bf, text="⟳ Refresh",
                  command=self._prebiotic_refresh_list,
                  bg=_C["accent"], fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)
        tk.Button(bf, text="★ Rank by Conditions",
                  command=self._prebiotic_rank_and_show,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)
        tk.Button(bf, text="▶ Elucidate Selected",
                  command=self._prebiotic_elucidate_selected,
                  bg="#6f42c1", fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)

        # ── Right: list + detail ───────────────────────────────────────────────
        right = tk.Frame(paned, bg=_C["bg"])
        paned.add(right, minsize=420)

        list_f = tk.LabelFrame(right, text=" Prebiotic Reactions ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        list_f.pack(fill="both", expand=True, padx=6, pady=(6, 2))
        lbf = tk.Frame(list_f, bg=_C["panel"])
        lbf.pack(fill="both", expand=True)
        self._prebiotic_listbox = tk.Listbox(
            lbf, bg=_C["entry"], fg=_C["text"],
            font=("Consolas", 9), selectbackground=_C["accent"],
            selectforeground="white", activestyle="none",
            exportselection=False)
        self._prebiotic_listbox.pack(side="left", fill="both", expand=True)
        lb_sb = ttk.Scrollbar(lbf, orient="vertical",
                              command=self._prebiotic_listbox.yview)
        lb_sb.pack(side="right", fill="y")
        self._prebiotic_listbox.config(yscrollcommand=lb_sb.set)
        self._prebiotic_listbox.bind("<<ListboxSelect>>",
                                     self._prebiotic_on_select)

        det_f = tk.LabelFrame(right, text=" Reaction Details & Condition Analysis ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        det_f.pack(fill="both", expand=True, padx=6, pady=(2, 6))
        self._prebiotic_detail = self._prebio_log_widget(det_f, height=16)

        # ── Output dir ────────────────────────────────────────────────────────
        odf = tk.Frame(left, bg=_C["bg"])
        odf.pack(fill="x", padx=6, pady=2)
        self._prebio_file_row(odf, "Output dir:", "output_dir", directory=True)
        tk.Checkbutton(left, text="Export full text report (.txt)",
                       variable=self._vars_prebiotic["export_report"],
                       bg=_C["bg"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", padx=6)

        self._prebiotic_refresh_list()

    # ── Tab 2 : Custom Reactants & Bond-breaking / forming ───────────────────

    def _build_prebiotic_rxn_subtab(self, parent):
        """Define your own reactants, specify bonds to break/form, run PES scan."""
        header = tk.LabelFrame(parent,
                               text=" User-Defined Reaction Pathway ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Specify reactant/product SMILES or names, choose which bonds "
                      "break or form,\nthen drive the reaction coordinate with an xTB "
                      "constrained bond scan.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        # Reactant / product ──────────────────────────────────────────────────
        mol_lf = tk.LabelFrame(left_f, text=" Molecules ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)

        self._prebio_file_row(mol_lf, "Reactant XYZ:", "mol_file")
        self._prebio_file_row(mol_lf, "Product XYZ:", "product_file")

        row_rct = tk.Frame(mol_lf, bg=_C["panel"])
        row_rct.pack(fill="x", pady=2)
        tk.Label(row_rct, text="Reactant names/SMILES:", bg=_C["panel"],
                 fg=_C["text"], width=22, anchor="w",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row_rct, textvariable=self._vars_prebiotic["user_reactants"],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)

        row_prd = tk.Frame(mol_lf, bg=_C["panel"])
        row_prd.pack(fill="x", pady=2)
        tk.Label(row_prd, text="Product names/SMILES:", bg=_C["panel"],
                 fg=_C["text"], width=22, anchor="w",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row_prd, textvariable=self._vars_prebiotic["user_products"],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)

        chrg_row = tk.Frame(mol_lf, bg=_C["panel"])
        chrg_row.pack(fill="x", pady=2)
        tk.Label(chrg_row, text="Charge:", bg=_C["panel"],
                 fg=_C["text"], font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(chrg_row, textvariable=self._vars_prebiotic["charge"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=5).pack(
                     side="left", padx=4)
        tk.Label(chrg_row, text="Mult:", bg=_C["panel"],
                 fg=_C["text"], font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
        tk.Entry(chrg_row, textvariable=self._vars_prebiotic["mult"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=5).pack(side="left")

        # Bond breaking / forming ─────────────────────────────────────────────
        bond_lf = tk.LabelFrame(left_f,
                                text=" Bond Breaking & Forming ",
                                bg=_C["panel"], fg=_C["yellow"],
                                font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Use 1-based atom indices from the XYZ.\n"
                      "Multiple pairs: comma-separated, e.g.  1-2, 3-4",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Bonds to BREAK:", "bond_break",
                               tooltip="e.g. 1-2, 3-4")
        self._prebio_entry_row(bond_lf, "Bonds to FORM:", "bond_form",
                               tooltip="e.g. 5-6")

        # Scan parameters ─────────────────────────────────────────────────────
        scan_lf = tk.LabelFrame(left_f,
                                text=" Constrained Bond-Scan (xTB) ",
                                bg=_C["panel"], fg=_C["accent"],
                                font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        scan_lf.pack(fill="x", pady=4)
        tk.Label(scan_lf,
                 text="Drive atom pair distance from start → end Å",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(scan_lf, "Atom 1 (idx):", "scan_dist_A1")
        self._prebio_entry_row(scan_lf, "Atom 2 (idx):", "scan_dist_A2")
        self._prebio_entry_row(scan_lf, "Start distance (Å):", "scan_start")
        self._prebio_entry_row(scan_lf, "End distance (Å):", "scan_end")
        self._prebio_entry_row(scan_lf, "Steps:", "scan_steps")
        self._prebio_entry_row(scan_lf, "xTB method:", "xtb_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(scan_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / none")
        self._prebio_file_row(scan_lf, "Output dir:", "output_dir", directory=True)

        btn_f = tk.Frame(left_f, bg=_C["bg"])
        btn_f.pack(fill="x", pady=4)
        tk.Button(btn_f, text="▶ Run Bond Scan",
                  command=self._prebiotic_run_bond_scan,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=10, pady=4).pack(
                      side="left", padx=2)
        tk.Button(btn_f, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=10, pady=4).pack(
                      side="left", padx=2)

        # Log + plot area ─────────────────────────────────────────────────────
        log_lf = tk.LabelFrame(right_f, text=" Bond-Scan Log ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_rxn_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 3 : xTB Module ────────────────────────────────────────────────────

    def _build_prebiotic_xtb_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" xTB Thermochemistry at Prebiotic Conditions ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Optimise + compute Hessian with GFN2-xTB (or GFN-FF / GFN1) at the "
                      "chosen temperature.\nParses G, H, ZPE and plots the energy profile.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Molecule ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Molecule XYZ:", "mol_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        xtb_lf = tk.LabelFrame(left_f, text=" xTB Settings ",
                               bg=_C["panel"], fg=_C["yellow"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        xtb_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(xtb_lf, "Method:", "xtb_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(xtb_lf, "Temperature (K):", "T_K")
        self._prebio_entry_row(xtb_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / methanol / none")
        tk.Checkbutton(xtb_lf, text="Run xTB thermo (--hess --temp)",
                       variable=self._vars_prebiotic["run_xtb_thermo"],
                       bg=_C["panel"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", pady=2)

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run xTB Thermo",
                  command=self._prebiotic_run_xtb_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" xTB Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_xtb_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 4 : CREST Module ──────────────────────────────────────────────────

    def _build_prebiotic_crest_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" CREST Conformer / Reactive Sampling ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="CREST explores the conformational space at prebiotic temperature "
                      "using iMTD-GC.\nUse --T or --cinp for reactive sampling across bond "
                      "rearrangements.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Input ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Molecule XYZ:", "mol_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        crest_lf = tk.LabelFrame(left_f, text=" CREST Settings ",
                                 bg=_C["panel"], fg=_C["yellow"],
                                 font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        crest_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(crest_lf, "Method:", "crest_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(crest_lf, "Temperature (K):", "crest_T",
                               tooltip="MD temperature for iMTD-GC")
        self._prebio_entry_row(crest_lf, "Energy window (kcal):", "crest_ewin",
                               tooltip="default 6 kcal/mol above minimum")
        self._prebio_entry_row(crest_lf, "Keep top-N conformers:", "crest_keep_n",
                               tooltip="written to crest_conformers_top.xyz")
        self._prebio_entry_row(crest_lf, "Atmosphere (csv):", "atmosphere",
                               tooltip="informational only; see solvent below")
        self._prebio_entry_row(crest_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / none")

        bond_lf = tk.LabelFrame(left_f,
                                text=" Reactive Constraint (optional) ",
                                bg=_C["panel"], fg=_C["muted"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=4)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Force a bond to break/form during CREST sampling\n"
                      "via a constrained input file (--cinp).",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Constrain bond (A1-A2):", "bond_break",
                               tooltip="e.g. 1-2")

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run CREST",
                  command=self._prebiotic_run_crest_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)
        tk.Button(bf, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" CREST Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_crest_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 5 : ORCA Module ───────────────────────────────────────────────────

    def _build_prebiotic_orca_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" ORCA High-Level Optimisation / TS Search / NEB ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Run ORCA Opt, Freq, OptTS, or NEB-TS using DFT/composite methods.\n"
                      "Bond-breaking/forming is modelled by providing reactant+product "
                      "geometries for NEB interpolation.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Input Structures ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Reactant XYZ:", "mol_file")
        self._prebio_file_row(mol_lf, "Product XYZ (NEB):", "product_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        orca_lf = tk.LabelFrame(left_f, text=" ORCA Settings ",
                                bg=_C["panel"], fg=_C["yellow"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        orca_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(orca_lf, "Method:", "orca_method",
                               tooltip="B97-3c / PBE0 / DLPNO-CCSD(T)")
        self._prebio_entry_row(orca_lf, "Basis set:", "orca_basis",
                               tooltip="def2-mTZVP / def2-SVP / leave blank for B97-3c")
        self._prebio_entry_row(orca_lf, "Keywords:", "orca_keywords",
                               tooltip="Opt Freq / OptTS / NEB-TS / SP")
        self._prebio_entry_row(orca_lf, "nProc:", "orca_nproc")
        self._prebio_entry_row(orca_lf, "MaxCore (MB):", "orca_maxcore")
        tk.Checkbutton(orca_lf, text="Use NEB-TS (reactant + product needed)",
                       variable=self._vars_prebiotic["orca_neb"],
                       bg=_C["panel"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", pady=2)

        bond_lf = tk.LabelFrame(left_f,
                                text=" Bond Making / Breaking Hint ",
                                bg=_C["panel"], fg=_C["muted"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=4)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Optional: add %geom Modify_Internal constraints\n"
                      "to the ORCA input to steer the optimisation.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Break bond (A1-A2):", "bond_break",
                               tooltip="adds ModRedundant {B a1 a2 D}")
        self._prebio_entry_row(bond_lf, "Form bond (A1-A2):", "bond_form",
                               tooltip="adds ModRedundant {B a1 a2 A}")

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run ORCA",
                  command=self._prebiotic_run_orca_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)
        tk.Button(bf, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" ORCA Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_orca_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 6 : Tutorials ─────────────────────────────────────────────────────

    def _build_prebiotic_tutorial_subtab(self, parent):
        nb2 = ttk.Notebook(parent)
        nb2.pack(fill="both", expand=True, padx=4, pady=4)

        sections = {
            "📚 Reaction Library": _PREBIOTIC_TUT_DB,
            "🧪 Custom Reactants": _PREBIOTIC_TUT_RXN,
            "⚡ xTB Module": _PREBIOTIC_TUT_XTB,
            "🔄 CREST Module": _PREBIOTIC_TUT_CREST,
            "🎯 ORCA Module": _PREBIOTIC_TUT_ORCA,
        }
        for title, text in sections.items():
            tf = tk.Frame(nb2, bg=_C["bg"])
            nb2.add(tf, text=f"  {title}  ")
            t = tk.Text(tf, bg="#0c0c0c", fg="#d4d4d4",
                        font=("Consolas", 9), wrap="word",
                        state="normal", padx=10, pady=10)
            sb = ttk.Scrollbar(tf, orient="vertical", command=t.yview)
            sb.pack(side="right", fill="y")
            t.pack(side="left", fill="both", expand=True)
            t.config(yscrollcommand=sb.set)
            # Style tags
            t.tag_config("h1", foreground=_C["accent"],
                         font=("Segoe UI", 12, "bold"))
            t.tag_config("h2", foreground=_C["green"],
                         font=("Segoe UI", 10, "bold"))
            t.tag_config("code", foreground="#d19a66",
                         font=("Consolas", 9))
            t.tag_config("tip", foreground="#22c55e",
                         font=("Segoe UI", 9, "italic"))
            t.tag_config("warn", foreground="#f59e0b",
                         font=("Segoe UI", 9, "italic"))
            # Render tutorial text with basic markup
            for chunk in text.split("\n"):
                if chunk.startswith("## "):
                    t.insert("end", chunk[3:] + "\n", "h1")
                elif chunk.startswith("### "):
                    t.insert("end", chunk[4:] + "\n", "h2")
                elif chunk.startswith("```"):
                    pass
                elif chunk.startswith("TIP:"):
                    t.insert("end", chunk + "\n", "tip")
                elif chunk.startswith("WARN:"):
                    t.insert("end", chunk + "\n", "warn")
                else:
                    # inline code: text between backticks
                    import re as _re
                    parts = _re.split(r'(`[^`]+`)', chunk)
                    for part in parts:
                        if part.startswith("`") and part.endswith("`"):
                            t.insert("end", part[1:-1], "code")
                        else:
                            t.insert("end", part)
                    t.insert("end", "\n")
            t.config(state="disabled")

    # ── Prebiotic UI callbacks ────────────────────────────────────────────────

    def _prebiotic_log(self, msg: str):
        """Write to the DB-tab detail pane (thread-safe)."""
        def _do():
            self._prebiotic_detail.config(state="normal")
            self._prebiotic_detail.insert("end", msg + "\n")
            self._prebiotic_detail.see("end")
            self._prebiotic_detail.config(state="disabled")
        self.root.after(0, _do)

    def _prebiotic_set_detail(self, text: str):
        self._prebiotic_detail.config(state="normal")
        self._prebiotic_detail.delete("1.0", "end")
        self._prebiotic_detail.insert("end", text)
        self._prebiotic_detail.config(state="disabled")

    def _prebiotic_refresh_list(self):
        category = self._vars_prebiotic["filter_category"].get()
        env = self._vars_prebiotic["filter_env"].get()
        query = self._vars_prebiotic["search_query"].get()
        matches = self._prebiotic_filter_reactions(category, env, query)
        self._prebiotic_listbox.delete(0, "end")
        self._prebiotic_list_data = []
        for name, data in matches:
            cat = data.get("category", "")
            dg = data.get("energy_kJ")
            dg_str = f"{dg:+.0f} kJ" if dg is not None else "??"
            self._prebiotic_listbox.insert(
                "end",
                f"  {name[:46]:<46}  [{cat[:22]}]  ΔG≈{dg_str}")
            self._prebiotic_list_data.append((name, data))

    def _prebiotic_rank_and_show(self):
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
        except ValueError:
            return messagebox.showerror("Prebiotic",
                                        "Enter valid T, pH, P values.")
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        cat = self._vars_prebiotic["filter_category"].get()
        ranked = self._prebiotic_rank_all(T, pH, P, atm, mins, cat)
        self._prebiotic_listbox.delete(0, "end")
        self._prebiotic_list_data = []
        for score, name, match, data in ranked:
            bar = "█" * int(score // 10) + "░" * (10 - int(score // 10))
            self._prebiotic_listbox.insert(
                "end",
                f"  {score:5.1f}/100  {bar}  {name[:40]:<40}"
                f"  [{data.get('category','')[:18]}]")
            self._prebiotic_list_data.append((name, data))
        self._prebiotic_set_detail(
            f"Ranked {len(ranked)} reactions.\n"
            f"  T={T} K  pH={pH}  P={P} atm\n"
            f"  Atmosphere: {', '.join(atm) or '–'}\n"
            f"  Minerals  : {', '.join(mins) or '–'}\n\n"
            "Click a reaction → details.  "
            "▶ Elucidate Selected → full report + plots.")

    def _prebiotic_on_select(self, event=None):
        sel = self._prebiotic_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self._prebiotic_list_data):
            return
        name, data = self._prebiotic_list_data[idx]
        self._vars_prebiotic["selected_rxn"].set(name)
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
        except ValueError:
            T, pH, P = 298.0, 7.0, 1.0
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        match = self._prebiotic_match_conditions(data, T, pH, P, atm, mins)
        lines = [
            f"{'═'*60}",
            f"  {name}",
            f"{'═'*60}",
            f"  Category    : {data.get('category', 'N/A')}",
            f"  Match Score : {match['score']:.1f} / 100",
            f"  Environments: {', '.join(data.get('env', []))}",
            "", "  REACTANTS:",
        ]
        for mol, role in (data.get("reactants") or {}).items():
            lines.append(f"    • {mol}  [{role}]")
        lines.append("  PRODUCTS:")
        for p in data.get("products", []):
            lines.append(f"    • {p}")
        dg = data.get("energy_kJ")
        if dg is not None:
            lines.append(f"  ΔG° ≈ {dg:+.1f} kJ/mol  "
                         f"({'endergonic' if dg > 0 else 'exergonic'})")
        lines += [
            "", f"  PATHWAY: {data.get('pathway', 'N/A')}",
            "", "  CONDITION MATCH:",
            f"    T  : {'✓' if match['T_match'] is True else '✗' if match['T_match'] is False else '—'}",
            f"    pH : {'✓' if match['pH_match'] is True else '✗' if match['pH_match'] is False else '—'}",
            f"    P  : {'✓' if match['P_match'] is True else '✗' if match['P_match'] is False else '—'}",
            f"    Atm: {match['atm_match']}%",
            f"    Min: {match['mineral_match']}%",
        ]
        if match["warnings"]:
            lines += ["", "  WARNINGS:"]
            for w in match["warnings"]:
                lines.append(f"    ⚠  {w}")
        if match["suggestions"]:
            lines += ["", "  SUGGESTIONS:"]
            for s in match["suggestions"]:
                lines.append(f"    →  {s}")
        lines += [
            "", "  FEASIBILITY:",
            "    " + data.get("feasibility_notes", "").replace("\n", "\n    "),
            "", "  REFERENCES:",
        ]
        for ref in data.get("refs", []):
            lines.append(f"    [{ref}]")
        self._prebiotic_set_detail("\n".join(lines))

    def _prebiotic_elucidate_selected(self):
        name = self._vars_prebiotic["selected_rxn"].get().strip()
        if not name or name not in PREBIOTIC_DB:
            return messagebox.showerror(
                "Prebiotic", "Select a reaction from the list first.")
        rxn_data = PREBIOTIC_DB[name]
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Prebiotic", f"Invalid parameter: {exc}")
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        out_base = self._vars_prebiotic["output_dir"].get().strip() or os.path.join(
            os.getcwd(), "prebiotic_output",
            re.sub(r"[^\w]", "_", name)[:40])

        def _worker():
            try:
                self._prebiotic_log(f"\n[Elucidator] {name}")
                match = self._prebiotic_match_conditions(
                    rxn_data, T, pH, P, atm, mins)
                self._prebiotic_log(
                    f"[Elucidator] Match score: {match['score']:.1f}/100")
                if self._vars_prebiotic["export_report"].get():
                    rp = self._prebiotic_generate_report(
                        name, rxn_data, match, T, pH, P, atm, mins, out_base)
                    self._prebiotic_log(f"[Report] Saved: {rp}")
                radar = self._prebiotic_plot_condition_radar(name, match, out_base)
                if radar:
                    self._prebiotic_log(f"[Radar] Saved: {radar}")
                ediag = self._prebiotic_plot_energy_diagram(rxn_data, out_base)
                if ediag:
                    self._prebiotic_log(f"[Energy diagram] Saved: {ediag}")
                if self._vars_prebiotic["run_xtb_thermo"].get() \
                        and mol_file and os.path.isfile(mol_file):
                    self._prebiotic_log(f"[xTB] Running at T={T} K …")
                    thermo = self._prebiotic_run_xtb_thermo(
                        mol_file, T, charge, mult, out_base)
                    if "error" in thermo:
                        self._prebiotic_log(f"[xTB] {thermo['error']}")
                    else:
                        self._prebiotic_log(
                            f"[xTB] G={thermo.get('G_Eh','?')} Eh  "
                            f"H={thermo.get('H_Eh','?')} Eh")
                self._prebiotic_log(f"[Elucidator] Done → {out_base}")
                self.root.after(
                    0, lambda: messagebox.showinfo(
                        "Prebiotic Elucidator",
                        f"Done!  Match score: {match['score']:.0f}/100\n"
                        f"Outputs: {out_base}"))
            except Exception as exc:
                _m = str(exc)
                self._prebiotic_log(f"[Elucidator] ERROR: {_m}")
                self.root.after(
                    0, lambda m=_m: messagebox.showerror("Prebiotic Elucidator", m))

        threading.Thread(target=_worker, daemon=True).start()

    # ── Bond-scan runner ─────────────────────────────────────────────────────

    def _prebiotic_run_bond_scan(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("Bond Scan",
                                        "Select a valid reactant XYZ file.")
        try:
            a1 = int(self._vars_prebiotic["scan_dist_A1"].get())
            a2 = int(self._vars_prebiotic["scan_dist_A2"].get())
            start = float(self._vars_prebiotic["scan_start"].get())
            end = float(self._vars_prebiotic["scan_end"].get())
            steps = int(self._vars_prebiotic["scan_steps"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Bond Scan", f"Invalid value: {exc}")

        method = self._vars_prebiotic["xtb_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        out_dir = self._prebiotic_output_dir()
        bond_break_raw = self._vars_prebiotic["bond_break"].get().strip()
        bond_form_raw = self._vars_prebiotic["bond_form"].get().strip()

        self.is_running = True
        self._prebio_write(self._prebio_rxn_log,
                           f"[Bond Scan] {mol_file}\n"
                           f"  Atoms {a1}-{a2}  {start}→{end} Å  ({steps} steps)\n"
                           f"  Method: {method}  solvent: {solvent or 'none'}\n"
                           f"  Break: {bond_break_raw or '–'}  Form: {bond_form_raw or '–'}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                xtb_exe = "xtb.exe" if _sys() == "Windows" else "xtb"
                os.makedirs(out_dir, exist_ok=True)

                # Build xTB input file with $scan block
                scan_inp = os.path.join(out_dir, "scan_prebio.inp")
                with open(scan_inp, "w") as fh:
                    fh.write("$constrain\n")
                    fh.write(f"  force constant=1.0\n")
                    fh.write(f"  distance: {a1}, {a2}, {start}\n")
                    fh.write("$scan\n")
                    fh.write(f"  1: {start:.3f},{end:.3f},{steps}\n")
                    # Bond-break constraints: add weak repulsion
                    for pair in [p.strip() for p in bond_break_raw.split(",") if p.strip()]:
                        parts2 = pair.replace("-", " ").split()
                        if len(parts2) == 2:
                            fh.write(f"$fix\n  distance: {parts2[0]}, {parts2[1]}, break\n")
                    fh.write("$end\n")

                solvent_flag = f"--alpb {solvent}" if solvent else ""
                cmd = (f'"{xtb_exe}" "{mol_file}" {method} '
                       f'--input "{scan_inp}" --opt '
                       f'--chrg {charge} --uhf {mult - 1} '
                       f'{solvent_flag} > xtb_scan_prebio.log 2>&1')
                self._prebio_write(self._prebio_rxn_log,
                                   f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse xtbscan.log energies
                scan_log = os.path.join(out_dir, "xtbscan.log")
                energies = []
                if os.path.isfile(scan_log):
                    for line in open(scan_log, errors="replace"):
                        m = re.search(r"(-?\d+\.\d{6,})", line)
                        if m:
                            energies.append(float(m.group(1)))
                if not energies:
                    # fallback: grep main log
                    main_log = os.path.join(out_dir, "xtb_scan_prebio.log")
                    if os.path.isfile(main_log):
                        for line in open(main_log, errors="replace"):
                            if "TOTAL ENERGY" in line:
                                m = re.search(r"(-?\d+\.\d+)", line)
                                if m:
                                    energies.append(float(m.group(1)))

                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] {len(energies)} energy points parsed.")

                if energies and MATPLOTLIB_AVAILABLE:
                    import matplotlib.pyplot as plt
                    import numpy as np
                    dists = np.linspace(start, end, len(energies))
                    E_rel = np.array(energies)
                    E_rel = (E_rel - E_rel[0]) * 2625.5  # Eh → kJ/mol
                    fig, ax = plt.subplots(figsize=(6, 4))
                    fig.patch.set_facecolor(_C["panel"])
                    ax.set_facecolor(_C["panel"])
                    ax.plot(dists, E_rel, "o-", color=_C["green"], lw=2)
                    ax.axhline(0, ls="--", color=_C["muted"], lw=0.8)
                    ts_idx = int(np.argmax(E_rel))
                    ax.axvline(dists[ts_idx], ls=":", color=_C["red"], lw=1.5,
                               label=f"TS† ≈ {dists[ts_idx]:.2f} Å")
                    ax.set_xlabel(f"d(A{a1}–A{a2}) / Å",
                                  color=_C["muted"])
                    ax.set_ylabel("ΔE / kJ mol⁻¹",
                                  color=_C["muted"])
                    ax.set_title("Prebiotic Bond-Scan PES",
                                 color=_C["text"], fontweight="bold")
                    ax.legend(facecolor=_C["panel"], labelcolor=_C["text"])
                    ax.tick_params(colors=_C["muted"])
                    for sp in ax.spines.values():
                        sp.set_color(_C["border"])
                    fig.tight_layout()
                    png = os.path.join(out_dir, "prebio_bond_scan.png")
                    fig.savefig(png, dpi=120, bbox_inches="tight",
                                facecolor=_C["panel"])
                    plt.close(fig)
                    self._prebio_write(self._prebio_rxn_log,
                                       f"[Plot] Saved: {png}")
                    ts_e = E_rel[ts_idx]
                    self._prebio_write(self._prebio_rxn_log,
                                       f"[Bond Scan] TS† ≈ {dists[ts_idx]:.2f} Å, "
                                       f"ΔE‡ ≈ {ts_e:.1f} kJ/mol")
                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── xTB module runner ─────────────────────────────────────────────────────

    def _prebiotic_run_xtb_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("xTB Module",
                                        "Select a valid molecule XYZ file.")
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("xTB Module", str(exc))

        out_dir = self._prebiotic_output_dir()
        method = self._vars_prebiotic["xtb_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        self._prebio_write(self._prebio_xtb_log,
                           f"[xTB] {mol_file}\n  Method:{method}  T={T}K  "
                           f"solvent:{solvent or 'none'}",
                           clear=True)

        def _worker():
            try:
                thermo = self._prebiotic_run_xtb_thermo(
                    mol_file, T, charge, mult, out_dir,
                    method=method, solvent=solvent)
                if "error" in thermo:
                    self._prebio_write(self._prebio_xtb_log,
                                       f"[xTB] {thermo['error']}")
                    return
                self._prebio_write(self._prebio_xtb_log, "[xTB] Parsed thermochemistry:")
                for k2, v2 in thermo.items():
                    if k2 not in ("log", "T_K", "charge", "mult"):
                        self._prebio_write(self._prebio_xtb_log,
                                           f"  {k2:15s} = {v2}")
                self._prebio_write(self._prebio_xtb_log,
                                   f"[xTB] Log: {thermo.get('log','')}")
                self._prebio_write(self._prebio_xtb_log, "[xTB] Done.")
            except Exception as exc:
                self._prebio_write(self._prebio_xtb_log,
                                   f"[xTB] ERROR: {exc}")

        threading.Thread(target=_worker, daemon=True).start()

    # ── CREST module runner ───────────────────────────────────────────────────

    def _prebiotic_run_crest_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("CREST Module",
                                        "Select a valid molecule XYZ file.")
        try:
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
            T_crest = float(self._vars_prebiotic["crest_T"].get())
            ewin = float(self._vars_prebiotic["crest_ewin"].get())
            keep_n = int(self._vars_prebiotic["crest_keep_n"].get())
        except ValueError as exc:
            return messagebox.showerror("CREST Module", str(exc))

        method = self._vars_prebiotic["crest_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        bond_constrain = self._vars_prebiotic["bond_break"].get().strip()
        out_dir = self._prebiotic_output_dir()
        self.is_running = True
        self._prebio_write(self._prebio_crest_log,
                           f"[CREST] {mol_file}\n  Method:{method}  T={T_crest}K  "
                           f"ewin={ewin}  keep={keep_n}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                crest_exe = "crest.exe" if _sys() == "Windows" else "crest"
                os.makedirs(out_dir, exist_ok=True)
                solvent_flag = f"--alpb {solvent}" if solvent else ""
                cinp_flag = ""
                if bond_constrain:
                    # Write --cinp file for reactive constraint
                    cinp_path = os.path.join(out_dir, "crest_prebio.inp")
                    pairs = [p.strip() for p in bond_constrain.split(",") if p.strip()]
                    with open(cinp_path, "w") as fh:
                        fh.write("$constrain\n  force constant=0.5\n")
                        for pair in pairs:
                            idxs = pair.replace("-", " ").split()
                            if len(idxs) == 2:
                                fh.write(f"  distance: {idxs[0]}, {idxs[1]}, auto\n")
                        fh.write("$end\n")
                    cinp_flag = f'--cinp "{cinp_path}"'

                cmd = (f'"{crest_exe}" "{mol_file}" {method} '
                       f'--T {T_crest:.0f} --ewin {ewin:.1f} '
                       f'--chrg {charge} --uhf {mult - 1} '
                       f'{solvent_flag} {cinp_flag} '
                       f'> crest_prebio.log 2>&1')
                self._prebio_write(self._prebio_crest_log, f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse ensemble
                ensemble = os.path.join(out_dir, "crest_conformers.xyz")
                n_conf = 0
                if os.path.isfile(ensemble):
                    with open(ensemble, errors="replace") as ef:
                        lines_e = ef.readlines()
                    # count frames
                    i2 = 0
                    conf_energies = []
                    while i2 < len(lines_e):
                        try:
                            nat = int(lines_e[i2].strip())
                            comment = lines_e[i2 + 1].strip() if i2 + 1 < len(lines_e) else ""
                            energy_m = re.search(r"(-?\d+\.\d+)", comment)
                            if energy_m:
                                conf_energies.append(float(energy_m.group(1)))
                            n_conf += 1
                            i2 += nat + 2
                        except (ValueError, IndexError):
                            break

                    self._prebio_write(self._prebio_crest_log,
                                       f"[CREST] {n_conf} conformers found.")

                    # Keep top-N
                    if keep_n > 0 and n_conf > 0:
                        top_path = os.path.join(out_dir, "crest_conformers_top.xyz")
                        with open(ensemble, errors="replace") as ef:
                            raw = ef.read()
                        frames = []
                        i2 = 0
                        src_lines = raw.splitlines(True)
                        while i2 < len(src_lines):
                            try:
                                nat = int(src_lines[i2].strip())
                                frame = "".join(src_lines[i2:i2 + nat + 2])
                                frames.append(frame)
                                i2 += nat + 2
                            except (ValueError, IndexError):
                                break
                        with open(top_path, "w") as fh:
                            fh.write("".join(frames[:keep_n]))
                        self._prebio_write(self._prebio_crest_log,
                                           f"[CREST] Top-{keep_n} saved: {top_path}")

                    # Energy plot
                    if conf_energies and MATPLOTLIB_AVAILABLE:
                        import matplotlib.pyplot as plt
                        import numpy as np
                        E_rel = np.array(conf_energies)
                        E_rel = (E_rel - E_rel[0]) * 2625.5
                        fig, ax = plt.subplots(figsize=(6, 3))
                        fig.patch.set_facecolor(_C["panel"])
                        ax.set_facecolor(_C["panel"])
                        ax.bar(range(1, len(E_rel) + 1), E_rel,
                               color=_C["accent"], edgecolor=_C["border"])
                        ax.set_xlabel("Conformer #", color=_C["muted"])
                        ax.set_ylabel("ΔE / kJ mol⁻¹", color=_C["muted"])
                        ax.set_title("CREST Conformer Energies",
                                     color=_C["text"], fontweight="bold")
                        ax.tick_params(colors=_C["muted"])
                        fig.tight_layout()
                        png = os.path.join(out_dir, "crest_energies.png")
                        fig.savefig(png, dpi=120, bbox_inches="tight",
                                    facecolor=_C["panel"])
                        plt.close(fig)
                        self._prebio_write(self._prebio_crest_log,
                                           f"[Plot] Saved: {png}")
                else:
                    self._prebio_write(self._prebio_crest_log,
                                       "[CREST] crest_conformers.xyz not found. "
                                       "Check crest_prebio.log.")
                self._prebio_write(self._prebio_crest_log,
                                   f"[CREST] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_crest_log,
                                   f"[CREST] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── ORCA module runner ────────────────────────────────────────────────────

    def _prebiotic_run_orca_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("ORCA Module",
                                        "Select a valid reactant XYZ file.")
        try:
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
            nproc = int(self._vars_prebiotic["orca_nproc"].get())
            maxcore = int(self._vars_prebiotic["orca_maxcore"].get())
        except ValueError as exc:
            return messagebox.showerror("ORCA Module", str(exc))

        method = self._vars_prebiotic["orca_method"].get().strip() or "B97-3c"
        basis = self._vars_prebiotic["orca_basis"].get().strip()
        keywords = self._vars_prebiotic["orca_keywords"].get().strip() or "Opt Freq"
        use_neb = self._vars_prebiotic["orca_neb"].get()
        product_file = self._vars_prebiotic["product_file"].get().strip()
        bond_break_raw = self._vars_prebiotic["bond_break"].get().strip()
        bond_form_raw = self._vars_prebiotic["bond_form"].get().strip()
        out_dir = self._prebiotic_output_dir()
        self.is_running = True
        self._prebio_write(self._prebio_orca_log,
                           f"[ORCA] {mol_file}\n"
                           f"  Method: {method}  Basis: {basis or 'built-in'}\n"
                           f"  Keywords: {keywords}  NEB: {use_neb}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                orca_exe = "orca.exe" if _sys() == "Windows" else "orca"
                os.makedirs(out_dir, exist_ok=True)

                # Read reactant coords
                with open(mol_file, errors="replace") as f2:
                    xyz_lines = f2.readlines()
                # Strip first 2 lines for coord block
                coord_block = "".join(xyz_lines[2:]).strip()

                inp_path = os.path.join(out_dir, "orca_prebio.inp")

                if use_neb and product_file and os.path.isfile(product_file):
                    # NEB-TS input
                    kw_line = (f"! {method} {basis} NEB-TS FREQ"
                               if "NEB" not in keywords.upper()
                               else f"! {method} {basis} {keywords}")
                    with open(inp_path, "w") as fh:
                        fh.write(f"{kw_line}\n")
                        fh.write(f"%pal nprocs {nproc} end\n")
                        fh.write(f"%maxcore {maxcore}\n")
                        fh.write("%neb\n")
                        fh.write(f'  product "{product_file}"\n')
                        fh.write("  nimages 8\n")
                        fh.write("end\n")
                        fh.write(f"* xyz {charge} {mult}\n")
                        fh.write(coord_block + "\n*\n")
                else:
                    kw_line = f"! {method} {basis} {keywords}".strip()
                    with open(inp_path, "w") as fh:
                        fh.write(f"{kw_line}\n")
                        fh.write(f"%pal nprocs {nproc} end\n")
                        fh.write(f"%maxcore {maxcore}\n")
                        # Bond-break/form via Modify_Internal
                        break_pairs = [p.strip() for p in
                                       bond_break_raw.split(",") if p.strip()]
                        form_pairs = [p.strip() for p in
                                      bond_form_raw.split(",") if p.strip()]
                        if break_pairs or form_pairs:
                            fh.write("%geom\n  Modify_Internal\n")
                            for pair in break_pairs:
                                idxs = pair.replace("-", " ").split()
                                if len(idxs) == 2:
                                    # 0-based for ORCA
                                    i1 = int(idxs[0]) - 1
                                    i2b = int(idxs[1]) - 1
                                    fh.write(f"    {{B {i1} {i2b} D}}\n")
                            for pair in form_pairs:
                                idxs = pair.replace("-", " ").split()
                                if len(idxs) == 2:
                                    i1 = int(idxs[0]) - 1
                                    i2b = int(idxs[1]) - 1
                                    fh.write(f"    {{B {i1} {i2b} A}}\n")
                            fh.write("  end\nend\n")
                        fh.write(f"* xyz {charge} {mult}\n")
                        fh.write(coord_block + "\n*\n")

                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] Input: {inp_path}")
                cmd = f'"{orca_exe}" "{inp_path}" > orca_prebio.log 2>&1'
                self._prebio_write(self._prebio_orca_log, f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse results from ORCA log
                orca_log = os.path.join(out_dir, "orca_prebio.log")
                if os.path.isfile(orca_log):
                    text = open(orca_log, errors="replace").read()
                    for pattern, label in [
                        (r"FINAL SINGLE POINT ENERGY\s+([-\d.]+)", "Final SCF Energy (Eh)"),
                        (r"Total enthalpy\s*:\s*([-\d.]+)", "Enthalpy (Eh)"),
                        (r"Total Gibbs free energy\s*:\s*([-\d.]+)", "G (Eh)"),
                        (r"Zero point energy\s*:\s*([-\d.]+)", "ZPE (Eh)"),
                        (r"Imaginary frequency:\s*([-\d.]+)", "Imaginary freq (cm⁻¹)"),
                    ]:
                        m = re.search(pattern, text)
                        if m:
                            self._prebio_write(self._prebio_orca_log,
                                               f"  {label:35s} = {m.group(1)}")
                    # NEB barrier
                    m_ts = re.search(
                        r"NEB-TS.*?barrier\s*=\s*([\d.]+)\s*kcal", text, re.DOTALL)
                    if m_ts:
                        self._prebio_write(self._prebio_orca_log,
                                           f"  NEB-TS barrier = {m_ts.group(1)} kcal/mol")
                    # Frequencies
                    freqs = re.findall(r":\s+([-\d.]+)\s+cm\*\*-1", text)
                    if freqs:
                        self._prebio_write(self._prebio_orca_log,
                                           f"  Frequencies (cm⁻¹): "
                                           f"{', '.join(freqs[:8])} …")
                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── Extended xTB thermo (now accepts method/solvent kwargs) ──────────────

    # -------------------------------------------------------------------------

    def _build_pes_tutorial_tab(self, parent):
        """Step-by-step PES tutorial + 3D surface help."""
        tk.Label(parent, text="PES Tutorial & 3D Surface Guide",
                 bg=_C["bg"], fg=_C["green"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=10, pady=(8, 4))

        # Notebook inside tutorial
        tnb = ttk.Notebook(parent)
        tnb.pack(fill="both", expand=True, padx=10, pady=4)

        # ── helper ────────────────────────────────────────────────────────────
        def _make_text_tab(notebook, tab_title, content):
            frame = tk.Frame(notebook, bg=_C["bg"])
            notebook.add(frame, text=tab_title)
            txt = tk.Text(frame, bg=_C["panel"], fg=_C["text"],
                          font=("Consolas", 9), wrap="word",
                          padx=12, pady=8, state="normal", relief="flat")
            sb = tk.Scrollbar(frame, orient="vertical", command=txt.yview)
            sb.pack(side="right", fill="y")
            txt.pack(fill="both", expand=True)
            txt.config(yscrollcommand=sb.set)
            txt.tag_configure("h1", font=("Segoe UI", 12, "bold"),
                              foreground=_C["green"])
            txt.tag_configure("h2", font=("Segoe UI", 10, "bold"),
                              foreground=_C["yellow"])
            txt.tag_configure("code", font=("Consolas", 9),
                              foreground=_C.get("cyan", "#00CED1"),
                              background=_C["entry"])
            txt.tag_configure("tip", foreground=_C.get("blue", "#87CEEB"))
            txt.tag_configure("warn", foreground=_C.get("red", "#FF6B6B"))
            for line in content.split("\n"):
                if line.startswith("## "):
                    txt.insert("end", line[3:] + "\n", "h1")
                elif line.startswith("### "):
                    txt.insert("end", line[4:] + "\n", "h2")
                elif line.startswith("`") and line.endswith("`"):
                    txt.insert("end", line[1:-1] + "\n", "code")
                elif line.startswith("TIP:"):
                    txt.insert("end", line + "\n", "tip")
                elif line.startswith("WARN:"):
                    txt.insert("end", line + "\n", "warn")
                else:
                    txt.insert("end", line + "\n")
            txt.config(state="disabled")

        # ── Tab 1 : Step-by-Step Guide ────────────────────────────────────────
        GUIDE = """\
══════════════════════════════════════════════════════════════════════
 IAK PES TUTORIAL — How to Run a Potential Energy Surface Scan
══════════════════════════════════════════════════════════════════════

## STEP 1 — Prepare your XYZ file

• Use a pre-optimised structure (e.g. from xTB Opt or CREST best conformer).
• Make sure atom indices start from 1 (IAK uses 1-based atom numbering).
• Place both molecules in the same XYZ file (multi-molecule complex) OR
  use the Anchor + Guest workflow to auto-assemble a complex first.

### Example — minimal XYZ header
`5`
`water dimer`
`O  0.000  0.000  0.119`
`H  0.000  0.756 -0.476`
`H  0.000 -0.756 -0.476`
`O  0.000  0.000  3.000`
`H  0.000  0.756  2.405`

## STEP 2 — Choose scan coordinate

• Bond scan        : two atom indices  (e.g. 1 and 4)
• Angle scan       : three atom indices (e.g. 1 2 3)
• Dihedral scan    : four atom indices  (e.g. 1 2 3 4)

TIP: Use a visualiser (Avogadro / MOLDEN) to check atom numbering before entering indices.

## STEP 3 — Set scan range

• Start distance   : typically 1.0 – 1.5 Å (equilibrium)
• End distance     : typically 3.0 – 5.0 Å (dissociation)
• Steps            : 10–30 points gives a smooth curve without too much CPU time

## STEP 4 — Launch the scan

Click  ▶ Run PES Scan  in the "PES Coordinate Scan" tab.
The progress log will show each point:  Point 1/20 … energy = -X.XXX Eh

## STEP 5 — Interpret the PES plot

• The lowest point is the equilibrium geometry.
• The highest point on the reaction pathway is the transition state (TS†).
• The barrier height  ΔE‡  is reported in kcal/mol and kJ/mol.

WARN: A monotonically rising curve means dissociation, not a barrier — check if you scanned the right bond.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " Step-by-Step Guide ", GUIDE)

        # ── Tab 2 : xTB Input Format ──────────────────────────────────────────
        XTB_FMT = """\
## xTB Constraint / Scan Input Format (IAK auto-generates this)

IAK writes a  xtb_scan.inp  file in your output directory.  Here is
what it looks like for a bond scan between atoms 1 and 4:

`$constrain`
`  force constant=0.5`
`  distance: 1, 4, auto`
`$scan`
`  mode=sequential`
`  distance: 1, 4, 1.0, 3.5, 20`
`$end`

### Angle scan example (atoms 1, 2, 3)
`$constrain`
`  force constant=0.5`
`  angle: 1, 2, 3, auto`
`$scan`
`  mode=sequential`
`  angle: 1, 2, 3, 80.0, 180.0, 20`
`$end`

### xTB command IAK runs
`xtb molecule.xyz --input xtb_scan.inp --gfn2 --chrg 0 --uhf 0`

TIP: Add --alpb water  in xTB Settings to include implicit solvation.
TIP: GFN-FF is much faster for large systems (>100 atoms) but less accurate.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " xTB Input Format ", XTB_FMT)

        # ── Tab 3 : 3D Surface Guide ──────────────────────────────────────────
        SURF3D = """\
## 3D PES Surface — How to Generate a 2D Scan Grid

To obtain a 3D surface you must vary TWO coordinates simultaneously.
Run two sequential scans OR use the grid mode (if enabled).

### Workflow
1. Run a coarse scan  (10×10 grid)  to locate the approximate TS region.
2. Refine with a fine  scan  (20×20 grid)  around the TS.
3. The surface is plotted as a heatmap + 3D wireframe.

### Interpreting the 3D surface
• Valleys    = stable intermediates or reactants / products
• Saddle point = transition state
• Ridge       = reaction path connecting two valleys through the TS

### Example — two-coordinate scan (bond A-B and bond C-D)
`$scan`
`  mode=sequential`
`  distance: 1, 2, 1.0, 3.0, 10`
`  distance: 3, 4, 1.0, 3.0, 10`
`$end`

TIP: Use  --opt  after the scan to relax each constrained point for a
     more accurate surface.

WARN: 3D scans scale as N² — a 20-step scan = 400 single-point calculations.
      Plan accordingly or use GFN-FF for speed.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " 3D Surface Guide ", SURF3D)

        # ── Tab 4 : Troubleshooting ───────────────────────────────────────────
        TROUBLESHOOT = """\
## Common PES Scan Problems & Fixes

### xtb not found
WARN: Make sure xTB is installed and on your PATH.
TIP:  In Settings → Paths, set the full path to the xtb executable.

### Scan produces NaN energies
• The geometry may have clashed.  Reduce the step size or increase the
  force constant in the constrain block.
• Try  --opt  to relax each step geometry.

### Monotonically increasing curve (no barrier)
• You may have scanned the wrong pair of atoms.
• Check indices (1-based) in a molecular viewer.

### Imaginary frequency at wrong point
• Run  xtb --hess  at the apparent TS to confirm.
• The true TS has exactly one negative frequency along the reaction coordinate.

### Memory / time errors
• Reduce molecule size or use GFN-FF (--gfnff) instead of GFN2-xTB.
• Split large systems into smaller fragments.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " Troubleshooting ", TROUBLESHOOT)

# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    app = IAKApp()
    app.mainloop()


# ---------------------------------------------------------------------------
# Matplotlib drawing helpers
# ---------------------------------------------------------------------------
def _draw_wavy(ax, x1, y1, x2, y2, n_waves=5, amp_frac=0.06, **kw):
    t = np.linspace(0, 1, 300)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    amp = amp_frac * length
    wave = amp * np.sin(n_waves * 2 * np.pi * t)
    ax.plot(x1 + t * dx + wave * px, y1 + t * dy + wave * py, **kw)


def _draw_zigzag(ax, x1, y1, x2, y2, n_zigs=7, amp_frac=0.05, **kw):
    n = n_zigs * 2 + 1
    t = np.linspace(0, 1, n)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    amp = amp_frac * length
    displace = np.array([amp * ((-1) ** i) if i % 2 == 1 else 0 for i in range(n)])
    ax.plot(x1 + t * dx + displace * px, y1 + t * dy + displace * py, **kw)


def _draw_curled(ax, x1, y1, x2, y2, rad=0.35, **kw):
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    px, py = -dy / length, dx / length
    cp = (mx + rad * length * px, my + rad * length * py)
    path = mpath.Path(
        [(x1, y1), cp, (x2, y2)],
        [mpath.Path.MOVETO, mpath.Path.CURVE3, mpath.Path.CURVE3],
    )
    lw = kw.pop("lw", kw.pop("linewidth", 1.0))
    color = kw.pop("color", "k")
    alpha = kw.pop("alpha", 1.0)
    ls = kw.pop("ls", kw.pop("linestyle", "-"))
    zorder = kw.pop("zorder", 3)
    ax.add_patch(
        mpatches.PathPatch(
            path,
            fill=False,
            edgecolor=color,
            linewidth=lw,
            alpha=alpha,
            linestyle=ls,
            zorder=zorder,
        )
    )


def _draw_fancy_arrow(
    ax,
    x1,
    y1,
    x2,
    y2,
    style="Straight",
    color="k",
    lw=1.0,
    alpha=0.75,
    zorder=10,
    head_size=0.012,
):
    kw = dict(color=color, lw=lw, alpha=alpha, zorder=zorder)
    dx, dy = x2 - x1, y2 - y1
    length = max(np.hypot(dx, dy), 1e-9)
    ux, uy = dx / length, dy / length
    gap = head_size * length
    bx2, by2 = x2 - gap * ux, y2 - gap * uy

    if style == "Wavy":
        _draw_wavy(ax, x1, y1, bx2, by2, n_waves=5, amp_frac=0.06, **kw)
    elif style == "Zigzag":
        _draw_zigzag(ax, x1, y1, bx2, by2, n_zigs=6, amp_frac=0.05, **kw)
    elif style in ("Curled (Arc)", "Curled"):
        _draw_curled(ax, x1, y1, bx2, by2, rad=0.30, **kw)
    elif style in ("Smooth (Bezier)", "Smooth"):
        xs = np.linspace(x1, bx2, 60)
        ts = (xs - x1) / max(bx2 - x1, 1e-9)
        ax.plot(xs, y1 + (by2 - y1) * (3 * ts**2 - 2 * ts**3), **kw)
    else:
        ax.plot([x1, bx2], [y1, by2], **kw)

    ax.annotate(
        "",
        xy=(x2, y2),
        xytext=(bx2, by2),
        arrowprops=dict(arrowstyle="->", color=color, lw=lw, alpha=alpha, mutation_scale=10 * lw),
        zorder=zorder + 1,
    )


# =============================================================================
# LOGGING INFRASTRUCTURE
# =============================================================================


# ---------------------------------------------------------------------------
# Main application class
# ---------------------------------------------------------------------------
class IAKApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("IAK v11.2 The Job-Report and Visual Analytics Edition")
        self.root.geometry("1500x1040")
        self.root.configure(bg=_C["bg"])
        self._q = queue.Queue()
        self._vars = {k: tk.StringVar(value=v) for k, v in {"a": "", "b": "", "ratio": "1:0, 1:1, 1:2", "mode": "balanced", "out": "run", "reaction_type": "Non-covalent"}.items()}
        self._vars_pes = {
            "scan_mode": tk.StringVar(value="coord"),
            "scan_type": tk.StringVar(value="distance"),  # distance | angle | dihedral
            "reactant": tk.StringVar(value=""),
            "product": tk.StringVar(value=""),
            "engine": tk.StringVar(value="xtb"),
            "c1_a1": tk.StringVar(value="1"), "c1_a2": tk.StringVar(value="2"),
            "c1_start": tk.StringVar(value="1.0"), "c1_end": tk.StringVar(value="2.5"), "c1_steps": tk.StringVar(value="10"),
            "use_c2": tk.BooleanVar(value=False),
            "c2_a1": tk.StringVar(value="3"), "c2_a2": tk.StringVar(value="4"),
            "c2_start": tk.StringVar(value="1.5"), "c2_end": tk.StringVar(value="3.0"), "c2_steps": tk.StringVar(value="10"),
            "run_ts": tk.BooleanVar(value=True),
            "predict_ts_spline": tk.BooleanVar(value=True),
            # Angle scan extras
            "ang_a3": tk.StringVar(value="3"),
            # Dihedral scan extras
            "dih_a3": tk.StringVar(value="3"), "dih_a4": tk.StringVar(value="4"),
        }
        # FES / Perturbation variables
        self._vars_fes = {
            "temperature": tk.StringVar(value="298.15"),
            "n_bins": tk.StringVar(value="50"),
            # Umbrella sampling
            "us_mol": tk.StringVar(value=""),
            "us_a1": tk.StringVar(value="1"), "us_a2": tk.StringVar(value="2"),
            "us_centers": tk.StringVar(value="1.0,1.2,1.4,1.6,1.8,2.0"),
            "us_spring_k": tk.StringVar(value="50.0"),
            "us_steps": tk.StringVar(value="5000"),
            "us_summary": tk.StringVar(value=""),
            # HILLS / metadynamics
            "hills_file": tk.StringVar(value=""),
            "hills_cv_min": tk.StringVar(value="1.0"),
            "hills_cv_max": tk.StringVar(value="4.0"),
            "hills_gamma": tk.StringVar(value=""),
            "hills_cv_label": tk.StringVar(value="Distance (Å)"),
            # FEP / TI
            "fep_file0": tk.StringVar(value=""),
            "fep_file1": tk.StringVar(value=""),
            "n_lambda": tk.StringVar(value="11"),
            "lambda_schedule": tk.StringVar(value="linear"),
            # Output dir
            "fes_out": tk.StringVar(value=""),
        }
        # NEB/TS-dedicated variables
        self._vars_neb = {
            "reactant": tk.StringVar(value=""),
            "product": tk.StringVar(value=""),
            "engine": tk.StringVar(value="xtb"),
            "images": tk.StringVar(value="8"),
            "spring_k": tk.StringVar(value="0.01"),
            "run_ts_refine": tk.BooleanVar(value=True),
            "ts_hess": tk.BooleanVar(value=True),
            "charge": tk.StringVar(value="0"),
            "mult": tk.StringVar(value="1"),
            "max_iter": tk.StringVar(value="500"),
        }
        # Prebiotic elucidation module variables
        self._vars_prebiotic = {
            # ── Environment conditions ──────────────────────────────────────
            "search_query":    tk.StringVar(value=""),
            "filter_env":      tk.StringVar(value="All"),
            "filter_category": tk.StringVar(value="All"),
            "T_K":             tk.StringVar(value="298"),
            "pH":              tk.StringVar(value="7.0"),
            "P_atm":           tk.StringVar(value="1.0"),
            "atmosphere":      tk.StringVar(value="N2, CO2, H2O"),
            "minerals":        tk.StringVar(value=""),
            # ── User-defined reactants & bonds ───────────────────────────────
            "user_reactants":  tk.StringVar(value=""),      # csv SMILES or names
            "user_products":   tk.StringVar(value=""),      # csv SMILES or names
            "bond_break":      tk.StringVar(value=""),      # "A1-A2,A3-A4" (1-based atom pairs)
            "bond_form":       tk.StringVar(value=""),      # "A1-A2" pairs to form
            "scan_dist_A1":    tk.StringVar(value="1"),
            "scan_dist_A2":    tk.StringVar(value="2"),
            "scan_start":      tk.StringVar(value="1.0"),
            "scan_end":        tk.StringVar(value="3.5"),
            "scan_steps":      tk.StringVar(value="20"),
            # ── Molecule & charge ────────────────────────────────────────────
            "charge":          tk.StringVar(value="0"),
            "mult":            tk.StringVar(value="1"),
            "mol_file":        tk.StringVar(value=""),
            "product_file":    tk.StringVar(value=""),      # for NEB/CREST product
            "output_dir":      tk.StringVar(value=""),
            # ── xTB settings ─────────────────────────────────────────────────
            "run_xtb_thermo":  tk.BooleanVar(value=True),
            "xtb_method":      tk.StringVar(value="--gfn2"),
            "xtb_solvent":     tk.StringVar(value=""),
            # ── CREST settings ───────────────────────────────────────────────
            "run_crest":       tk.BooleanVar(value=False),
            "crest_method":    tk.StringVar(value="--gfn2"),
            "crest_T":         tk.StringVar(value="298.15"),
            "crest_ewin":      tk.StringVar(value="6.0"),
            "crest_keep_n":    tk.StringVar(value="10"),
            # ── ORCA settings ────────────────────────────────────────────────
            "run_orca":        tk.BooleanVar(value=False),
            "orca_method":     tk.StringVar(value="B97-3c"),
            "orca_basis":      tk.StringVar(value="def2-mTZVP"),
            "orca_keywords":   tk.StringVar(value="Opt Freq"),
            "orca_neb":        tk.BooleanVar(value=False),
            "orca_nproc":      tk.StringVar(value="4"),
            "orca_maxcore":    tk.StringVar(value="2000"),
            # ── Report ───────────────────────────────────────────────────────
            "export_report":   tk.BooleanVar(value=True),
            "selected_rxn":    tk.StringVar(value=""),
        }
        self._guest_list: list[str] = []  # Multi-guest B paths
        for k, v in {
            "cores": "4",
            "maxcore": "2000",
            "charge": "0",
            "mult": "1",
            "xtb_method": "--gfn2",
            "crest_method": "--gfn2",
            "orca_method": "B97-3c Opt Freq",
            "exec_env": "Local (Subprocess)",
            "goat_model": "uma-s-1",
            "n_generate": "200",
            "n_keep_scored": "50",
            "n_keep_clustered": "40",
            "n_run_xtb": "20",
            "n_run_crest": "5",
            "rmsd_cutoff": "0.5",
            "xtb_ewin_kcal": "5.0",
            "crest_ewin_kcal": "3.0",
            "random_seed": "42",
            "max_placement_attempts": "50",
            "e_a": "",
            "e_b": "",
        }.items():
            self._vars[k] = tk.StringVar(value=v)
        self._vars_graph = {
            "dir1": tk.StringVar(value=""),
            "name1": tk.StringVar(value="Series 1"),
            "dir2": tk.StringVar(value=""),
            "name2": tk.StringVar(value="Series 2"),
            "method": tk.StringVar(value="ORCA"),
            "metric": tk.StringVar(value="Gibbs Free Energy (ΔG)"),
            "x_labels": tk.StringVar(value=""),
            "top_space": tk.BooleanVar(value=False),
            "conn_style": tk.StringVar(value="Smooth (Bezier)"),
            "delta_arrow": tk.StringVar(value="Straight"),
            "label_box": tk.StringVar(value="Rounded Box"),
            "series1_color": tk.StringVar(value="#17a2b8"),
            "series2_color": tk.StringVar(value="#ffc107"),
            "crest_color": tk.StringVar(value="#6c757d"),
            "orca_color": tk.StringVar(value="#388bfd"),
            "graph_bg": tk.StringVar(value="#ffffff"),
            "axis_color": tk.StringVar(value="#000000"),
            "grid_color": tk.StringVar(value="#b8b8b8"),
            "watermark_color": tk.StringVar(value="#6e6e6e"),
            "crop_xmin": tk.StringVar(value=""),
            "crop_xmax": tk.StringVar(value=""),
            "crop_ymin": tk.StringVar(value=""),
            "crop_ymax": tk.StringVar(value=""),
            "model_style": tk.StringVar(value="Ball-and-stick"),
            "model_bg": tk.StringVar(value="#ffffff"),
            "bond_color": tk.StringVar(value="#6b7280"),
            "atom_H": tk.StringVar(value="#f8fafc"),
            "atom_C": tk.StringVar(value="#4b5563"),
            "atom_N": tk.StringVar(value="#2563eb"),
            "atom_O": tk.StringVar(value="#dc2626"),
            "atom_F": tk.StringVar(value="#22c55e"),
            "atom_S": tk.StringVar(value="#facc15"),
            "atom_Cl": tk.StringVar(value="#16a34a"),
            "atom_other": tk.StringVar(value="#f97316"),
            "bond_mode": tk.StringVar(value="Covalent radii"),
            "bond_cutoff": tk.StringVar(value="1.85"),
            "bond_tolerance": tk.StringVar(value="0.45"),
            "show_bond_distances": tk.BooleanVar(value=False),
            "show_atom_labels": tk.BooleanVar(value=False),
            "show_3d_axes": tk.BooleanVar(value=True),
            "model_elev": tk.StringVar(value="18"),
            "model_azim": tk.StringVar(value="38"),
            "image_dpi": tk.StringVar(value="300"),
            "conformer_top_n": tk.StringVar(value="10"),
        }
        self._report_vars = {
            "inputs": tk.BooleanVar(value=True),
            "workflow": tk.BooleanVar(value=True),
            "engine_results": tk.BooleanVar(value=True),
            "thermodynamics": tk.BooleanVar(value=True),
            "images": tk.BooleanVar(value=True),
            "timeline": tk.BooleanVar(value=True),
            "system_info": tk.BooleanVar(value=True),
            "ai_prompt": tk.BooleanVar(value=True),
        }
        self.active_xtb, self.active_crest, self.active_orca = 0, 0, 0
        self.preview_tw = None
        self.preview_file = None
        self.is_running = False
        self.start_time = 0
        self._color_buttons = {}
        self._build_ui()
        setup_logging(gui_queue=self._q)
        self.root.after(100, self._poll_log)
        self.root.after(800, self._show_capabilities_popup)

    def mainloop(self):
        self.root.mainloop()

    def _show_capabilities_popup(self):
        self.cap_w = tk.Toplevel(self.root)
        self.cap_w.title("IAK Workflow Capabilities")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 360
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 270
        self.cap_w.geometry(f"720x520+{x}+{y}")
        self.cap_w.configure(bg=_C["panel"])
        self.cap_w.grab_set()
        self.cap_w.transient(self.root)
        tk.Label(self.cap_w, text="IAK v11.2 Workflow Capabilities", font=("Segoe UI", 16, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 10))
        caps = [
            "1. Intelligent H-bond logic docking for supramolecular assembly.",
            "2. Single Molecule Mode for isolated anchor runs.",
            "3. RMSD-based duplicate filtering and steric screening.",
            "4. xTB, CREST, and self-healing ORCA refinement pipeline.",
            "5. Per-job summary reports with input correctness checks.",
            "6. Live percent-complete and ETA progress monitor.",
            "7. JACS-grade graphing with custom colors, pan, zoom, and crop.",
            "8. Chemcraft-like molecular image styles and atom/bond color control.",
        ]
        for cap in caps:
            tk.Label(self.cap_w, text=cap, font=("Segoe UI", 11), bg=_C["panel"], fg=_C["text"], justify="left", anchor="w").pack(fill="x", padx=40, pady=8)

        def next_step():
            self.cap_w.destroy()
            self.root.after(100, self._show_guidelines_popup)

        tk.Button(self.cap_w, text="Next: Usage Guidelines", command=next_step, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=25).pack(pady=25)

    def _show_guidelines_popup(self):
        self.guide_w = tk.Toplevel(self.root)
        self.guide_w.title("IAK Usage Guidelines")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 360
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 300
        self.guide_w.geometry(f"720x600+{x}+{y}")
        self.guide_w.configure(bg=_C["panel"])
        self.guide_w.grab_set()
        self.guide_w.transient(self.root)
        tk.Label(self.guide_w, text="How to Use IAK", font=("Segoe UI", 16, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 5))
        guide_text = (
            "1. Select your Anchor (A) and Guest (B) .xyz files. Leave B empty for single molecule.\n"
            "2. Define Ratios such as 1:0, 1:1, 1:4. Use commas for batch queue.\n"
            "3. Set hardware resources and charge/multiplicity.\n"
            "4. Run the pipeline. Job reports are written into each ratio folder.\n"
            "5. Use Trend Analysis & Graphs for custom JACS-style plots and model images."
        )
        tk.Label(self.guide_w, text=guide_text, font=("Segoe UI", 11), bg=_C["panel"], fg=_C["text"], justify="left").pack(padx=40, pady=10)
        tk.Label(self.guide_w, text="Manual Engine Downloads:", font=("Segoe UI", 12, "bold"), bg=_C["panel"], fg=_C["yellow"]).pack(pady=(10, 5))

        def make_link(parent, text, url):
            lbl = tk.Label(parent, text=text, font=("Segoe UI", 10, "underline"), bg=_C["panel"], fg=_C["accent"], cursor="hand2")
            lbl.pack(pady=2)
            lbl.bind("<Button-1>", lambda e: webbrowser.open_new(url))

        make_link(self.guide_w, "xTB Releases (grimme-lab)", "https://github.com/grimme-lab/xtb/releases")
        make_link(self.guide_w, "CREST Releases (grimme-lab)", "https://github.com/grimme-lab/crest/releases")
        make_link(self.guide_w, "ORCA Forum", "https://orcaforum.kofo.mpg.de")
        tk.Label(self.guide_w, text="'Where molecules become meaning, and computation becomes discovery — inspired by Dr. Imran A. Khan,\nbrought to life by his team Asif Raza and Huma Basheer,\ncreating a platform where chemistry meets intelligence, innovation, and scientific excellence.'", font=("Segoe UI", 10, "bold", "italic"), bg=_C["panel"], fg="green", justify="center").pack(pady=30)
        tk.Button(self.guide_w, text="Enter Workspace", command=lambda: (self.guide_w.destroy(), self.root.after(100, self._show_startup_check)), bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=20).pack(pady=10)

    def _show_startup_check(self):
        self.sw = tk.Toplevel(self.root)
        self.sw.title("System Verification")
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 225
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 150
        self.sw.geometry(f"450x300+{x}+{y}")
        self.sw.configure(bg=_C["panel"])
        self.sw.grab_set()
        self.sw.transient(self.root)
        tk.Label(self.sw, text="Checking Computational Engines...", font=("Segoe UI", 14, "bold"), bg=_C["panel"], fg=_C["accent"]).pack(pady=(20, 10))
        self.check_vars = {}
        self.check_btns = {}
        frame = tk.Frame(self.sw, bg=_C["panel"])
        frame.pack(fill="both", expand=True, padx=30)
        for engine in ["xTB", "CREST", "ORCA"]:
            row = tk.Frame(frame, bg=_C["panel"])
            row.pack(fill="x", pady=8)
            tk.Label(row, text=f"{engine}:", font=("Segoe UI", 11, "bold"), width=8, anchor="w", bg=_C["panel"], fg=_C["text"]).pack(side="left")
            status_lbl = tk.Label(row, text="Checking...", font=("Segoe UI", 11, "italic"), width=15, anchor="w", bg=_C["panel"], fg=_C["muted"])
            status_lbl.pack(side="left")
            btn = tk.Button(row, text="Add Manually", command=lambda e=engine: self._load_local_from_startup(e), bg=_C["yellow"], fg="black", font=("Segoe UI", 9, "bold"), relief="flat", cursor="hand2")
            btn.pack(side="right")
            btn.pack_forget()
            self.check_vars[engine] = status_lbl
            self.check_btns[engine] = btn
        self.sw_continue = tk.Button(self.sw, text="Continue to IAK", command=self.sw.destroy, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 11, "bold"), relief="flat", cursor="hand2", width=20)
        self.sw_continue.pack(pady=20)
        self.sw_continue.pack_forget()
        threading.Thread(target=self._perform_startup_checks, daemon=True).start()

    def _perform_startup_checks(self):
        time.sleep(0.5)
        all_ready = True
        for engine in ["xTB", "CREST", "ORCA"]:
            is_avail = is_tool_available(engine.lower())
            if not is_avail:
                all_ready = False
            self.root.after(0, lambda e=engine, a=is_avail: self._update_startup_ui(e, a))
            time.sleep(0.4)
        self.root.after(0, lambda: self._finalize_startup_ui(all_ready))

    def _update_startup_ui(self, engine, is_avail):
        if not hasattr(self, "sw") or not self.sw.winfo_exists():
            return
        lbl, btn = self.check_vars.get(engine), self.check_btns.get(engine)
        if is_avail:
            lbl.config(text="Running", fg=_C["green"], font=("Segoe UI", 11, "bold"))
            btn.pack_forget()
        else:
            lbl.config(text="Missing", fg=_C["red"], font=("Segoe UI", 11, "bold"))
            btn.pack(side="right")

    def _finalize_startup_ui(self, all_ready):
        if not hasattr(self, "sw") or not self.sw.winfo_exists():
            return
        self.sw_continue.pack(pady=20)
        if all_ready:
            self.sw_continue.config(text="All Engines Ready - Start", bg=_C["green"])

    def _extract_local_worker(self, fp, engine, from_startup=False):
        """Extract a tar.xz / zip archive for a given engine into the tools directory."""
        try:
            dest = Path(fp).parent
            if fp.endswith(".zip"):
                import zipfile
                with zipfile.ZipFile(fp, "r") as z:
                    z.extractall(dest)
            else:
                import tarfile as _tf
                with _tf.open(fp) as t:
                    t.extractall(dest)
            msg = f"[{engine}] Extracted to {dest}"
            self.root.after(0, lambda m=msg: self._append_text(m + "\n"))
            if from_startup and hasattr(self, "check_vars") and engine in self.check_vars:
                self.root.after(0, lambda: self.check_vars[engine].config(
                    text=f"{engine} ✓ (local)", fg=_C["green"],
                    font=("Segoe UI", 11, "bold")))
        except Exception as exc:
            m = str(exc)
            self.root.after(0, lambda msg=m: self._append_text(f"[Extract ERROR] {msg}\n"))

    def _load_local(self):
        """Open a file dialog to select a local engine archive and extract it."""
        fp = filedialog.askopenfilename(
            title="Select Engine Archive (.tar.xz / .zip)",
            filetypes=[("Archives", "*.tar.xz *.tar.gz *.tgz *.zip"), ("All files", "*.*")]
        )
        if not fp:
            return
        self._append_text(f"[Load Local] Extracting {Path(fp).name} …\n")
        threading.Thread(target=self._extract_local_worker, args=(fp, Path(fp).stem), daemon=True).start()

    def _load_local_from_startup(self, engine):
        fp = filedialog.askopenfilename(parent=self.sw, title=f"Select {engine} Archive", filetypes=[("Archives", "*.tar.xz *.tar.gz *.tgz *.zip")])
        if fp:
            self.check_vars[engine].config(text="Extracting...", fg=_C["yellow"], font=("Segoe UI", 11, "italic"))
            self.check_btns[engine].pack_forget()
            threading.Thread(target=self._extract_local_worker, args=(fp, engine, True), daemon=True).start()

    def _choose_output_base(self):
        current = self._vars["out"].get().strip(" \"'") or "run"
        current_path = Path(current)
        initial_dir = str(current_path.parent) if current_path.parent != Path(".") else os.getcwd()
        parent = filedialog.askdirectory(title="Choose parent folder for IAK output", initialdir=initial_dir)
        if not parent:
            return
        default_name = current_path.name if current_path.name else "run"
        name = simpledialog.askstring(
            "Output Name",
            "Enter the output base name you want:",
            initialvalue=default_name,
            parent=self.root,
        )
        if not name:
            return
        clean_name = re.sub(r'[<>:"/\\\\|?*]+', "_", name.strip())
        if not clean_name:
            clean_name = "run"
        self._vars["out"].set(os.path.join(parent, clean_name))

    def _apply_mode_preset(self):
        mode = self._vars["mode"].get().strip().lower()
        if mode == "custom":
            return
        try:
            cfg = Config.from_mode(RunMode[mode.upper()])
        except Exception:
            cfg = Config.from_mode(RunMode.BALANCED)
        for key in [
            "n_generate",
            "n_keep_scored",
            "n_keep_clustered",
            "n_run_xtb",
            "n_run_crest",
            "rmsd_cutoff",
            "xtb_ewin_kcal",
            "crest_ewin_kcal",
            "random_seed",
            "max_placement_attempts",
            "xtb_method",
            "crest_method",
            "orca_method",
        ]:
            if key in self._vars:
                self._vars[key].set(str(getattr(cfg, key)))

    def _poll_log(self):
        while not self._q.empty():
            self._append_text(self._q.get() + "\n")
        self.root.after(100, self._poll_log)

    def _append_text(self, t):
        self.term.config(state="normal")
        self.term.insert("end", t)
        self.term.see("end")
        self.term.config(state="disabled")

    def _status_cb(self, mode, delta):
        if mode == "xtb":
            self.active_xtb += delta
        elif mode == "crest":
            self.active_crest += delta
        elif mode == "orca":
            self.active_orca += delta
        self.root.after(0, self._update_status_ui)

    def _update_status_ui(self):
        total = self.active_xtb + self.active_crest + self.active_orca
        color = _C["green"] if total > 0 else _C["dim"]
        icon = "ACTIVE" if total > 0 else "IDLE"
        self.live_status_lbl.config(text=f"[{icon}] JOBS: {self.active_xtb} xTB | {self.active_crest} CREST | {self.active_orca} ORCA", fg=color)

    def _update_timer(self):
        if self.is_running:
            elapsed = int(time.time() - self.start_time)
            hrs, mins, secs = elapsed // 3600, (elapsed % 3600) // 60, elapsed % 60
            self.timer_lbl.config(text=f"{hrs:02d}:{mins:02d}:{secs:02d}")
        self.root.after(1000, self._update_timer)

    def _update_installation_labels(self):
        xtb_ok, crest_ok, orca_ok = is_tool_available("xtb"), is_tool_available("crest"), is_tool_available("orca")
        self._xtb_lbl.config(text="xTB: Ready" if xtb_ok else "xTB: Missing", fg=_C["green"] if xtb_ok else _C["red"])
        self._crest_lbl.config(text="CREST: Ready" if crest_ok else "CREST: Missing", fg=_C["green"] if crest_ok else _C["red"])
        self._orca_lbl.config(text="ORCA: Ready" if orca_ok else "ORCA: Missing", fg=_C["green"] if orca_ok else _C["red"])

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook.Tab", padding=[15, 5], font=("Segoe UI", 10, "bold"))
        hdr = tk.Frame(self.root, bg=_C["hdr_bg"], pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="IAK PIPELINE v11.2", font=("Segoe UI", 20, "bold"), fg=_C["accent"], bg=_C["hdr_bg"]).pack(side="left", padx=20)
        stat_f = tk.Frame(hdr, bg=_C["hdr_bg"])
        stat_f.pack(side="left", padx=20)
        self._xtb_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._xtb_lbl.pack(side="left", padx=10)
        self._crest_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._crest_lbl.pack(side="left", padx=10)
        self._orca_lbl = tk.Label(stat_f, font=("Segoe UI", 10, "bold"), bg=_C["hdr_bg"])
        self._orca_lbl.pack(side="left", padx=10)
        self.timer_lbl = tk.Label(hdr, text="00:00:00", font=("Consolas", 12, "bold"), fg=_C["accent"], bg=_C["hdr_bg"])
        self.timer_lbl.pack(side="right", padx=(10, 20))
        self.live_status_lbl = tk.Label(hdr, text="[IDLE] JOBS: 0 xTB | 0 CREST | 0 ORCA", font=("Segoe UI", 10, "bold"), fg=_C["dim"], bg=_C["hdr_bg"])
        self.live_status_lbl.pack(side="right", padx=10)
        self._update_installation_labels()
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=15, pady=15)
        self.tab_main = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_pes = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_neb = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_rxn = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_res = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_graph = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_table = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_fes = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_prebiotic = tk.Frame(self.nb, bg=_C["bg"])
        self.tab_tutorial = tk.Frame(self.nb, bg=_C["bg"])
        self.nb.add(self.tab_main, text=" Workflow Pipeline ")
        self.nb.add(self.tab_pes, text=" PES Coordinate Scan ")
        self.nb.add(self.tab_neb, text=" NEB / TS Search ")
        self.nb.add(self.tab_rxn, text=" Reaction Library ")
        self.nb.add(self.tab_res, text=" Generated Results ")
        if MATPLOTLIB_AVAILABLE:
            self.nb.add(self.tab_graph, text=" Trend Analysis & Graphs ")
            self.nb.add(self.tab_table, text=" Thermodynamic Table ")
        self.nb.add(self.tab_fes, text=" FES & Perturbation ")
        self.nb.add(self.tab_prebiotic, text=" Prebiotic Chemistry ")
        self.nb.add(self.tab_tutorial, text=" PES Tutorial ")
        self._build_pipeline_tab(self.tab_main)
        self._build_pes_tab(self.tab_pes)
        self._build_neb_tab(self.tab_neb)
        self._build_reaction_library_tab(self.tab_rxn)
        self._build_results_tab(self.tab_res)
        if MATPLOTLIB_AVAILABLE:
            self._build_graph_tab(self.tab_graph)
            self._build_table_tab(self.tab_table)
        self._build_fes_tab(self.tab_fes)
        self._build_prebiotic_tab(self.tab_prebiotic)
        self._build_pes_tutorial_tab(self.tab_tutorial)
        self.root.after(1000, self._update_timer)

    def _build_pipeline_tab(self, parent):
        main = tk.PanedWindow(parent, orient=tk.HORIZONTAL, sashwidth=6, sashrelief=tk.RAISED, bg=_C["border"], bd=0)
        main.pack(fill="both", expand=True, padx=10, pady=10)
        left_wrapper = tk.Frame(main, bg=_C["bg"])
        left_canvas = tk.Canvas(left_wrapper, bg=_C["bg"], highlightthickness=0)
        left_scroll = tk.Scrollbar(left_wrapper, orient="vertical", command=left_canvas.yview)
        left = tk.Frame(left_canvas, bg=_C["bg"])
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.pack(side="left", fill="both", expand=True)
        left_scroll.pack(side="right", fill="y")
        canvas_window = left_canvas.create_window((0, 0), window=left, anchor="nw")
        left_canvas.bind("<Configure>", lambda e: left_canvas.itemconfig(canvas_window, width=e.width))
        left.bind("<Configure>", lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))

        wf = tk.LabelFrame(left, text=" 1. WORKFLOW SETUP ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        wf.pack(fill="x", pady=(0, 6))
        tk.Label(wf, text="Tip: Leave Guest list empty and set Ratio to '1:0' for single-molecule runs.",
                 bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 5))

        # ── Anchor (A) ──────────────────────────────────────────────────────────
        for lbl, var in [("Anchor (A) XYZ:", "a")]:
            f = tk.Frame(wf, bg=_C["panel"])
            f.pack(fill="x", pady=2)
            tk.Label(f, text=lbl, bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
            tk.Entry(f, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
            tk.Button(f, text="...", command=lambda v=var: self._vars[v].set(
                filedialog.askopenfilename(filetypes=[("XYZ", "*.xyz"), ("All", "*")])), bg=_C["accent"]).pack(side="left")

        # ── Multi-Guest (B) panel ────────────────────────────────────────────────
        gf = tk.LabelFrame(wf, text=" Guest (B) XYZ Files — Multiple Guests Supported ",
                           fg=_C["green"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=8, pady=6)
        gf.pack(fill="x", pady=(4, 2))

        # Listbox showing queued guests
        lb_frame = tk.Frame(gf, bg=_C["panel"])
        lb_frame.pack(fill="x")
        self._guest_lb = tk.Listbox(lb_frame, bg=_C["entry"], fg=_C["text"], selectmode="extended",
                                    height=4, font=("Consolas", 9), bd=0, highlightthickness=0,
                                    activestyle="dotbox")
        self._guest_lb.pack(side="left", fill="x", expand=True)
        lb_sb = tk.Scrollbar(lb_frame, orient="vertical", command=self._guest_lb.yview)
        lb_sb.pack(side="right", fill="y")
        self._guest_lb.config(yscrollcommand=lb_sb.set)

        # Populate listbox from _guest_list on startup
        def _refresh_guest_lb():
            self._guest_lb.delete(0, "end")
            for p in self._guest_list:
                self._guest_lb.insert("end", os.path.basename(p))
        _refresh_guest_lb()

        # Buttons: Add / Remove / Clear
        btn_row = tk.Frame(gf, bg=_C["panel"])
        btn_row.pack(fill="x", pady=(4, 0))

        def _add_guests():
            paths = filedialog.askopenfilenames(
                title="Select Guest (B) XYZ files",
                filetypes=[("XYZ files", "*.xyz"), ("All files", "*")])
            for p in paths:
                p = os.path.abspath(p)
                if p not in self._guest_list:
                    self._guest_list.append(p)
            # also update legacy _vars["b"] to first guest for backward compat
            if self._guest_list:
                self._vars["b"].set(self._guest_list[0])
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _remove_selected_guests():
            sel = list(self._guest_lb.curselection())
            for idx in reversed(sel):
                self._guest_list.pop(idx)
            if self._guest_list:
                self._vars["b"].set(self._guest_list[0])
            else:
                self._vars["b"].set("")
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _clear_all_guests():
            self._guest_list.clear()
            self._vars["b"].set("")
            _refresh_guest_lb()
            self._update_guest_count_label()

        def _move_up():
            sel = list(self._guest_lb.curselection())
            if not sel or sel[0] == 0:
                return
            for idx in sel:
                self._guest_list[idx-1], self._guest_list[idx] = self._guest_list[idx], self._guest_list[idx-1]
            _refresh_guest_lb()
            for idx in sel:
                self._guest_lb.selection_set(idx-1)

        def _move_down():
            sel = list(self._guest_lb.curselection())
            if not sel or sel[-1] == len(self._guest_list)-1:
                return
            for idx in reversed(sel):
                self._guest_list[idx], self._guest_list[idx+1] = self._guest_list[idx+1], self._guest_list[idx]
            _refresh_guest_lb()
            for idx in sel:
                self._guest_lb.selection_set(idx+1)

        for txt, cmd, col in [
            ("+ Add Guest(s)",  _add_guests,            _C["green"]),
            ("- Remove Sel.",   _remove_selected_guests, _C["red"]),
            ("Clear All",       _clear_all_guests,       _C["dim"]),
            ("▲ Up",            _move_up,                _C["accent"]),
            ("▼ Down",          _move_down,              _C["accent"]),
        ]:
            tk.Button(btn_row, text=txt, command=cmd, bg=col, fg=_C["text"],
                      font=("Segoe UI", 8, "bold"), relief="flat", cursor="hand2",
                      padx=8, pady=2).pack(side="left", padx=2)

        self._guest_count_lbl = tk.Label(btn_row,
            text="0 guest(s) queued", bg=_C["panel"], fg=_C["muted"],
            font=("Segoe UI", 8, "italic"))
        self._guest_count_lbl.pack(side="left", padx=12)

        # ── Adduct Presets & Role Controls ──────────────────────────────────────
        adduct_row = tk.Frame(gf, bg=_C["panel"])
        adduct_row.pack(fill="x", pady=(6, 2))
        tk.Label(adduct_row, text="Adduct Presets:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        def _set_ratio(r, tip=""):
            self._vars["ratio"].set(r)
            if tip:
                self._append_text(f"\n[Adduct Preset] Ratio set to: {r} ({tip})\n")

        for label, ratio, tip in [
            ("1:1 Binary",    "1:1",     "1 anchor + 1 guest"),
            ("1:2 Binary",    "1:1, 1:2","scan 1:1 and 1:2"),
            ("1:1:1 Ternary", "1:1:1",   "1 anchor + guest1 + guest2"),
            ("1:2:1 Ternary", "1:2:1",   "1 anchor + 2×guest1 + 1×guest2"),
            ("2:1:1 Quaternary", "2:1:1","2 anchors + guest1 + guest2"),
            ("Scan 1:0→1:5",  ",".join(f"1:{i}" for i in range(6)), "stoichiometry sweep"),
        ]:
            tk.Button(adduct_row, text=label,
                      command=lambda r=ratio, t=tip: _set_ratio(r, t),
                      bg=_C["panel"], fg=_C["accent"],
                      font=("Segoe UI", 8), relief="groove", padx=6).pack(side="left", padx=2)

        role_row = tk.Frame(gf, bg=_C["panel"])
        role_row.pack(fill="x", pady=(2, 4))
        tk.Label(role_row, text="Role Swap:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        def _swap_roles():
            """Swap anchor A ↔ first guest B so the guest becomes the anchor and vice versa."""
            a_path = self._vars["a"].get().strip(" \"'")
            b_path = self._vars["b"].get().strip(" \"'")
            if not a_path and not self._guest_list:
                return messagebox.showwarning("Role Swap", "No Anchor or Guest files set.")
            b_first = self._guest_list[0] if self._guest_list else b_path
            new_b = a_path
            self._vars["a"].set(b_first)
            self._vars["b"].set(new_b)
            if self._guest_list:
                self._guest_list[0] = new_b if new_b else self._guest_list[0]
                _refresh_guest_lb()
                self._update_guest_count_label()
            self._append_text(f"\n[Role Swap] Anchor ↔ Guest1 swapped.\n  New Anchor: {b_first}\n  New Guest1: {new_b}\n")

        def _add_as_extra_anchor():
            """Promote the first guest to an additional anchor by duplicating the anchor entry."""
            b_path = self._vars["b"].get().strip(" \"'")
            a_path = self._vars["a"].get().strip(" \"'")
            if not b_path and not self._guest_list:
                return messagebox.showwarning("Role", "No Guest file set.")
            guest = self._guest_list[0] if self._guest_list else b_path
            self._append_text(
                f"\n[Multi-Anchor] To model 2 anchors, set Ratio to '2:...' — "
                f"IAK will place {os.path.basename(a_path or 'anchor')} twice.\n"
                f"  Guest kept as: {os.path.basename(guest)}\n"
            )
            self._vars["ratio"].set("2:1")

        tk.Button(role_row, text="⇄ Swap A ↔ B1", command=_swap_roles,
                  bg=_C["yellow"], fg="black", font=("Segoe UI", 8, "bold"),
                  relief="groove", padx=8).pack(side="left", padx=4)
        tk.Button(role_row, text="+ Promote B→2nd Anchor", command=_add_as_extra_anchor,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 8, "bold"),
                  relief="groove", padx=8).pack(side="left", padx=4)
        tk.Label(role_row,
                 text="Tip: Use ratio 2:1 for 2 anchors, 1:1:1 for ternary adduct with 2 guests",
                 bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 7, "italic")).pack(side="left", padx=8)

        # ── Ratios / Output ──────────────────────────────────────────────────────
        for lbl, var in [("Reaction Type:", "reaction_type"), ("Ratios (e.g., 1:0, 1:1, 2:1):", "ratio"), ("Base Output Name:", "out")]:
            f = tk.Frame(wf, bg=_C["panel"])
            f.pack(fill="x", pady=2)
            tk.Label(f, text=lbl, bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
            if var == "reaction_type":
                cb = ttk.Combobox(f, textvariable=self._vars[var], values=REACTION_TYPE_CHOICES, state="readonly")
                cb.pack(side="left", fill="x", expand=True, padx=5)
            else:
                tk.Entry(f, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
            if var == "out":
                tk.Button(f, text="...", command=self._choose_output_base, bg=_C["accent"]).pack(side="left")

        mode_row = tk.Frame(wf, bg=_C["panel"])
        mode_row.pack(fill="x", pady=2)
        tk.Label(mode_row, text="Preset Mode:", bg=_C["panel"], fg=_C["text"], width=26, anchor="w").pack(side="left")
        mode_cb = ttk.Combobox(mode_row, textvariable=self._vars["mode"], values=["fast", "balanced", "thorough", "custom"], width=16, state="readonly")
        mode_cb.pack(side="left", padx=5)
        mode_cb.bind("<<ComboboxSelected>>", lambda _e: self._apply_mode_preset())
        tk.Label(mode_row, text="Custom values below always override the preset.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 8, "italic")).pack(side="left", padx=8)

        cf = tk.LabelFrame(left, text=" 2. CHEMISTRY SETTINGS ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        cf.pack(fill="x", pady=(0, 6))
        for lbl, var, width in [("System Charge:", "charge", 10), ("Multiplicity:", "mult", 10), ("xTB Flags:", "xtb_method", 18), ("CREST Flags:", "crest_method", 18), ("ORCA Method:", "orca_method", 40)]:
            row = tk.Frame(cf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=width, bd=0).pack(side="left", fill="x", expand=var in {"orca_method", "xtb_method", "crest_method"}, padx=5)

        exec_row = tk.Frame(cf, bg=_C["panel"])
        exec_row.pack(fill="x", pady=2)
        tk.Label(exec_row, text="Execution Env:", bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
        ttk.Combobox(exec_row, textvariable=self._vars["exec_env"], values=["Local (Subprocess)", "Docker Container", "SLURM Cluster"], state="readonly", width=18).pack(side="left", padx=5)
        tk.Label(exec_row, text="GOAT/MLIP Model:", bg=_C["panel"], fg=_C["text"], width=15, anchor="w").pack(side="left", padx=(10, 0))
        ttk.Combobox(exec_row, textvariable=self._vars["goat_model"], values=["uma-s-1", "mace", "fairchem", "sevenn", "orb"], state="readonly", width=10).pack(side="left", padx=5)

        tf = tk.LabelFrame(left, text=" 3. THERMODYNAMICS (Optional) ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        tf.pack(fill="x", pady=(0, 6))
        tk.Label(tf, text="Input isolated ORCA energies (Eh) for Binding Affinity.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 5))
        for lbl, var in [("Monomer A Energy:", "e_a"), ("Monomer B Energy:", "e_b")]:
            row = tk.Frame(tf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)

        hf = tk.LabelFrame(left, text=" 4. HARDWARE RESOURCES ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        hf.pack(fill="x", pady=(0, 6))
        for lbl, var, note in [("CPU Cores:", "cores", "(16, 32+ for large systems)"), ("RAM/Core (MB):", "maxcore", "(Total = Cores * RAM)")]:
            row = tk.Frame(hf, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"], width=22, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=10, bd=0).pack(side="left", padx=5)
            tk.Label(row, text=note, bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=10)

        af = tk.LabelFrame(left, text=" 5. HOST-CONTROLLED SAMPLING AND FILTERS ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        af.pack(fill="x", pady=(0, 6))
        host_rows = [
            [("Generate Seeds", "n_generate"), ("Score Keep", "n_keep_scored"), ("Cluster Keep", "n_keep_clustered")],
            [("Run xTB", "n_run_xtb"), ("Run CREST", "n_run_crest"), ("Random Seed", "random_seed")],
            [("RMSD Cutoff", "rmsd_cutoff"), ("xTB Window kcal", "xtb_ewin_kcal"), ("CREST Window kcal", "crest_ewin_kcal")],
            [("Placement Attempts", "max_placement_attempts")],
        ]
        for row_items in host_rows:
            row = tk.Frame(af, bg=_C["panel"])
            row.pack(fill="x", pady=2)
            for lbl, var in row_items:
                tk.Label(row, text=f"{lbl}:", bg=_C["panel"], fg=_C["text"], width=17, anchor="w").pack(side="left", padx=(0, 2))
                tk.Entry(row, textvariable=self._vars[var], bg=_C["entry"], fg=_C["text"], width=9, bd=0).pack(side="left", padx=(0, 10), ipady=2)

        sf = tk.LabelFrame(left, text=" 6. HOST-CONTROLLED REPORT CONTENT ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        sf.pack(fill="x", pady=(0, 6))
        report_items = [
            ("Inputs", "inputs"),
            ("Workflow", "workflow"),
            ("Engine Results", "engine_results"),
            ("Thermodynamics", "thermodynamics"),
            ("Images", "images"),
            ("Timeline", "timeline"),
            ("System Info", "system_info"),
            ("AI Prompt", "ai_prompt"),
        ]
        for label, key in report_items:
            tk.Checkbutton(sf, text=label, variable=self._report_vars[key], bg=_C["panel"], fg=_C["text"], selectcolor="black").pack(side="left", padx=4)

        rf = tk.Frame(left, bg=_C["panel"])
        rf.pack(fill="x", pady=15)
        self.run_preopt = tk.BooleanVar(value=True)
        self.run_xtb = tk.BooleanVar(value=True)
        self.run_crest = tk.BooleanVar(value=True)
        self.run_orca = tk.BooleanVar(value=True)
        for text, var, fg in [("Pre-Opt", self.run_preopt, _C["yellow"]), ("Run xTB", self.run_xtb, "white"), ("Run CREST", self.run_crest, "white"), ("Run ORCA DFT", self.run_orca, _C["accent"])]:
            tk.Checkbutton(rf, text=text, variable=var, bg=_C["panel"], fg=fg, selectcolor="black").pack(side="left", padx=5)
        btn_f = tk.Frame(left, bg=_C["panel"])
        btn_f.pack(fill="x", pady=5)
        tk.Button(btn_f, text="LOAD LOCAL ENGINE (.tar.xz / .zip)", command=self._load_local, bg="#d29922", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(2, 0))
        tk.Button(btn_f, text="ANALYZE FOLDER", command=self._analyze_existing_folder, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        tk.Button(btn_f, text="ANALYZE FILES (.out/.xyz)", command=self._analyze_existing_files, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        tk.Button(btn_f, text="RESUME STOPPED JOB", command=self._resume_existing_job, bg="#238636", fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", fill="x", expand=True, padx=(6, 2))
        self.go_btn = tk.Button(left, text="START BATCH PIPELINE", command=self._start, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 12, "bold"), pady=10)
        self.go_btn.pack(fill="x", pady=10)

        right = tk.LabelFrame(main, text=" LIVE PIPELINE TERMINAL ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"))
        self.term = tk.Text(right, bg="black", fg=_C["green"], font=("Consolas", 10), state="disabled")
        self.term.pack(fill="both", expand=True, padx=5, pady=5)
        main.add(left_wrapper, minsize=560, stretch="always")
        main.add(right, minsize=460, stretch="always")
        self._build_progress_monitor(parent)

    def _build_progress_monitor(self, parent):
        frame = tk.LabelFrame(parent, text=" HIGH-LEVEL JOB PROGRESS, PERCENT COMPLETE, AND ETA ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=10, pady=8)
        frame.pack(fill="x", padx=10, pady=(0, 10))
        top = tk.Frame(frame, bg=_C["panel"])
        top.pack(fill="x")
        self.iak_progress_stage_lbl = tk.Label(top, text="Waiting for job", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 10, "bold"), anchor="w")
        self.iak_progress_stage_lbl.pack(side="left", fill="x", expand=True)
        self.iak_progress_eta_lbl = tk.Label(top, text="ETA: --:--:--", bg=_C["panel"], fg=_C["muted"], font=("Consolas", 10, "bold"), width=18)
        self.iak_progress_eta_lbl.pack(side="right", padx=6)
        self.iak_progress_percent_lbl = tk.Label(top, text="0.0%", bg=_C["panel"], fg=_C["green"], font=("Consolas", 11, "bold"), width=8)
        self.iak_progress_percent_lbl.pack(side="right", padx=6)
        self.iak_progress_bar = ttk.Progressbar(frame, orient="horizontal", mode="determinate", maximum=100)
        self.iak_progress_bar.pack(fill="x", pady=(6, 8))
        cols = ("stage", "status", "percent", "eta")
        self.iak_progress_tree = ttk.Treeview(frame, columns=cols, show="headings", height=4)
        for col, text, width in [("stage", "Pipeline Stage", 220), ("status", "Status", 110), ("percent", "Complete", 90), ("eta", "ETA", 120)]:
            self.iak_progress_tree.heading(col, text=text)
            self.iak_progress_tree.column(col, width=width, anchor="center")
        self.iak_progress_tree.pack(fill="x")
        self._progress_items = {}
        self._reset_progress_ui()

    def _reset_progress_ui(self):
        if not hasattr(self, "iak_progress_tree"):
            return
        for row in self.iak_progress_tree.get_children():
            self.iak_progress_tree.delete(row)
        self._progress_items = {}
        for stage in ["Validation", "Sampling/filtering", "xTB", "CREST", "ORCA", "Reports"]:
            item = self.iak_progress_tree.insert("", "end", values=(stage, "Waiting", "0.0%", "--:--:--"))
            self._progress_items[stage] = item
        self.iak_progress_bar["value"] = 0
        self.iak_progress_stage_lbl.config(text="Waiting for job")
        self.iak_progress_percent_lbl.config(text="0.0%")
        self.iak_progress_eta_lbl.config(text="ETA: --:--:--")

    def _progress_cb(self, payload):
        self.root.after(0, lambda p=dict(payload): self._apply_progress_payload(p))

    def _normalize_stage(self, stage):
        text = (stage or "").lower()
        if "validation" in text:
            return "Validation"
        if "sample" in text or "filter" in text or "generat" in text:
            return "Sampling/filtering"
        if "xtb" in text:
            return "xTB"
        if "crest" in text:
            return "CREST"
        if "orca" in text:
            return "ORCA"
        if "report" in text or "complete" in text:
            return "Reports"
        return stage or "Pipeline"

    def _apply_progress_payload(self, payload):
        percent = max(0.0, min(100.0, float(payload.get("percent", 0.0))))
        elapsed = float(payload.get("elapsed_seconds", 0.0))
        eta = "complete"
        if 0.0 < percent < 100.0:
            eta = _fmt_duration(elapsed * (100.0 - percent) / percent)
        elif percent <= 0.0:
            eta = "estimating"
        stage = self._normalize_stage(payload.get("stage", "Pipeline"))
        status = payload.get("status", "running").title()
        message = payload.get("message") or stage
        job = payload.get("job", "")
        self.iak_progress_bar["value"] = percent
        self.iak_progress_percent_lbl.config(text=f"{percent:5.1f}%")
        self.iak_progress_eta_lbl.config(text=f"ETA: {eta}")
        self.iak_progress_stage_lbl.config(text=f"Ratio {job} | {stage}: {message}" if job else f"{stage}: {message}")
        item = self._progress_items.get(stage)
        if not item:
            item = self.iak_progress_tree.insert("", "end", values=(stage, "Waiting", "0.0%", "--:--:--"))
            self._progress_items[stage] = item
        self.iak_progress_tree.item(item, values=(stage, status, f"{percent:5.1f}%", eta))
        self.iak_progress_tree.see(item)

    def _get_report_options(self):
        return {key: bool(var.get()) for key, var in self._report_vars.items()}

    def _build_pes_tab(self, parent):
        left = tk.Frame(parent, bg=_C["bg"])
        left.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        right = tk.Frame(parent, bg=_C["panel"], width=600)
        right.pack(side="right", fill="both", expand=False, padx=10, pady=10)
        
        # --- Left Panel: Settings ---
        lbl_cfg = tk.LabelFrame(left, text=" 1. PES & TS CONFIGURATION ", fg=_C["accent"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        lbl_cfg.pack(fill="x", pady=5)
        
        # Scan Mode
        f_mode = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_mode.pack(fill="x", pady=4)
        tk.Label(f_mode, text="Scan Mode:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Radiobutton(f_mode, text="Coordinate Grid (1D/2D)", variable=self._vars_pes["scan_mode"], value="coord", bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left")
        tk.Radiobutton(f_mode, text="Reactant → Product Path", variable=self._vars_pes["scan_mode"], value="path", bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left")

        # Scan Type (distance / angle / dihedral)
        f_stype = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_stype.pack(fill="x", pady=4)
        tk.Label(f_stype, text="Scan Type:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        for val, lbl in [("distance", "Bond Distance"), ("angle", "Bond Angle"), ("dihedral", "Dihedral")]:
            tk.Radiobutton(f_stype, text=lbl, variable=self._vars_pes["scan_type"], value=val,
                           bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(side="left", padx=4)

        # Angle / Dihedral extra-atom row (shown always; labelled clearly)
        f_extra = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_extra.pack(fill="x", pady=2)
        tk.Label(f_extra, text="Extra atoms (angle/dih):", bg=_C["panel"], fg=_C["muted"],
                 width=20, anchor="w", font=("Segoe UI", 8, "italic")).pack(side="left")
        tk.Label(f_extra, text="A3:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(4, 2))
        tk.Entry(f_extra, textvariable=self._vars_pes["ang_a3"], bg=_C["entry"],
                 fg=_C["text"], width=4).pack(side="left")
        tk.Label(f_extra, text="A4 (dih):", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(f_extra, textvariable=self._vars_pes["dih_a4"], bg=_C["entry"],
                 fg=_C["text"], width=4).pack(side="left")

        # Reactant XYZ
        f_react = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_react.pack(fill="x", pady=4)
        tk.Label(f_react, text="Reactant XYZ:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Entry(f_react, textvariable=self._vars_pes["reactant"], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
        tk.Button(f_react, text="...", command=lambda: self._vars_pes["reactant"].set(filedialog.askopenfilename()), bg=_C["accent"]).pack(side="left")
        
        # Product XYZ (For Path Mode)
        f_prod = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_prod.pack(fill="x", pady=4)
        tk.Label(f_prod, text="Product XYZ (Path Mode):", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        tk.Entry(f_prod, textvariable=self._vars_pes["product"], bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=5)
        tk.Button(f_prod, text="...", command=lambda: self._vars_pes["product"].set(filedialog.askopenfilename()), bg=_C["accent"]).pack(side="left")
        
        # Engine
        f_eng = tk.Frame(lbl_cfg, bg=_C["panel"])
        f_eng.pack(fill="x", pady=4)
        tk.Label(f_eng, text="Engine:", bg=_C["panel"], fg=_C["text"], width=20, anchor="w").pack(side="left")
        ttk.Combobox(f_eng, textvariable=self._vars_pes["engine"], values=["xtb", "orca", "goat"], state="readonly", width=10).pack(side="left", padx=5)
        
        # Coord 1
        lbl_c1 = tk.LabelFrame(left, text=" Coordinate 1 (Required) ", fg=_C["green"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=10, pady=5)
        lbl_c1.pack(fill="x", pady=5)
        f_c1_a = tk.Frame(lbl_c1, bg=_C["panel"])
        f_c1_a.pack(fill="x", pady=2)
        tk.Label(f_c1_a, text="Atom 1 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_a, textvariable=self._vars_pes["c1_a1"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_a, text="Atom 2 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_a, textvariable=self._vars_pes["c1_a2"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        f_c1_d = tk.Frame(lbl_c1, bg=_C["panel"])
        f_c1_d.pack(fill="x", pady=2)
        tk.Label(f_c1_d, text="Start Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_start"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_d, text="End Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_end"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c1_d, text="Steps:", bg=_C["panel"], fg=_C["text"], width=10).pack(side="left")
        tk.Entry(f_c1_d, textvariable=self._vars_pes["c1_steps"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        # Coord 2
        lbl_c2 = tk.LabelFrame(left, text=" Coordinate 2 (For 3D Plot) ", fg=_C["yellow"], bg=_C["panel"], font=("Segoe UI", 9, "bold"), padx=10, pady=5)
        lbl_c2.pack(fill="x", pady=5)
        tk.Checkbutton(lbl_c2, text="Enable 2D Grid Scan", variable=self._vars_pes["use_c2"], bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)
        f_c2_a = tk.Frame(lbl_c2, bg=_C["panel"])
        f_c2_a.pack(fill="x", pady=2)
        tk.Label(f_c2_a, text="Atom 1 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_a, textvariable=self._vars_pes["c2_a1"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_a, text="Atom 2 Index:", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_a, textvariable=self._vars_pes["c2_a2"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        f_c2_d = tk.Frame(lbl_c2, bg=_C["panel"])
        f_c2_d.pack(fill="x", pady=2)
        tk.Label(f_c2_d, text="Start Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_start"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_d, text="End Dist (Å):", bg=_C["panel"], fg=_C["text"], width=15).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_end"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        tk.Label(f_c2_d, text="Steps:", bg=_C["panel"], fg=_C["text"], width=10).pack(side="left")
        tk.Entry(f_c2_d, textvariable=self._vars_pes["c2_steps"], bg=_C["entry"], fg=_C["text"], width=5).pack(side="left")
        
        # TS Options
        lbl_ts = tk.LabelFrame(left, text=" 2. TRANSITION STATE REFINEMENT ", fg=_C["red"], bg=_C["panel"], font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        lbl_ts.pack(fill="x", pady=5)
        tk.Checkbutton(lbl_ts, text="Find Saddle Point & Run TS Optimization (OptTS + Freq)", variable=self._vars_pes["run_ts"], bg=_C["panel"], fg=_C["text"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)
        tk.Checkbutton(lbl_ts, text="Predict TS via spline saddle-point detection (after scan)", variable=self._vars_pes["predict_ts_spline"], bg=_C["panel"], fg=_C["yellow"], selectcolor=_C["bg"]).pack(anchor="w", pady=2)

        # Convenience buttons for extended scan types
        ext_row = tk.Frame(left, bg=_C["bg"])
        ext_row.pack(fill="x", pady=4)
        tk.Button(ext_row, text=" ▶ Run Angle Scan ", command=self._start_angle_scan,
                  bg="#17a2b8", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" ▶ Run Dihedral Scan ", command=self._start_dihedral_scan,
                  bg="#6f42c1", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" ▶ ORCA 2D PES ", command=self._start_orca_2d_pes,
                  bg="#e05252", fg="white", font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)
        tk.Button(ext_row, text=" Barrier Analysis… ", command=self._open_barrier_analysis_dialog,
                  bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 10), padx=10, pady=4).pack(side="left", padx=4)
        
        # Run Button
        self.btn_run_pes = tk.Button(left, text="START PES & TS SEARCH", command=self._start_pes, bg=_C["run"], fg=_C["text"], font=("Segoe UI", 14, "bold"), pady=10)
        self.btn_run_pes.pack(fill="x", pady=15)
        
        # --- Right Panel: Terminal ---
        tk.Label(right, text=" PES/TS TERMINAL LOG ", bg=_C["panel"], fg=_C["text"], font=("Consolas", 10, "bold")).pack(pady=5)
        self.pes_term = tk.Text(right, bg=_C["entry"], fg="#00ff00", font=("Consolas", 9), state="disabled", wrap="word")
        self.pes_term.pack(fill="both", expand=True, padx=5, pady=5)

    def _build_results_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        tk.Button(top, text=" REFRESH ", command=self._refresh_results, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" ANALYZE FOLDER ", command=self._analyze_existing_folder, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" ANALYZE FILES (.out/.xyz) ", command=self._analyze_existing_files, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" AVOGADRO ", command=self._open_in_avogadro, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" EXPORT ", command=self._export_file, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Label(top, text="Double-click XYZ for interactive model viewer; hover for quick preview.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 10, "italic")).pack(side="right", padx=20)
        container = tk.Frame(parent, bg=_C["bg"])
        container.pack(fill="both", expand=True, padx=10, pady=10)
        for i in range(6):
            container.columnconfigure(i, weight=1)
        container.rowconfigure(0, weight=1)
        self.listboxes = []
        self.folders = ["01_Inputs_and_Clusters", "02_xTB_Results", "03_CREST_Results", "04_ORCA_Refinement", "05_Top_Models_Comparison", "06_File_Analysis_Images"]

        def make_listbox(col, title, fg_color=_C["green"]):
            f = tk.LabelFrame(container, text=title, bg=_C["panel"], fg=_C["accent"], font=("Segoe UI", 9, "bold"))
            f.grid(row=0, column=col, sticky="nsew", padx=2, pady=5)
            lb = tk.Listbox(f, bg=_C["entry"], fg=fg_color, font=("Consolas", 9), selectbackground=_C["accent"], exportselection=False)
            lb.pack(side="left", fill="both", expand=True, padx=2, pady=5)
            sb = ttk.Scrollbar(f, orient="vertical", command=lb.yview)
            sb.pack(side="right", fill="y")
            lb.config(yscrollcommand=sb.set)
            lb.bind("<Double-Button-1>", lambda e, l=lb, c=col: self._open_file(l, c))
            lb.bind("<Motion>", lambda e, l=lb, c=col: self._on_hover(e, l, c))
            lb.bind("<Leave>", lambda e: self._hide_preview())
            self.listboxes.append(lb)

        make_listbox(0, " 1. Clusters ")
        make_listbox(1, " 2. xTB Opt ")
        make_listbox(2, " 3. CREST ")
        make_listbox(3, " 4. ORCA DFT ")
        make_listbox(4, " 5. TOP 3 COMPARE ", fg_color=_C["yellow"])
        make_listbox(5, " 6. 3D IMAGES ", fg_color=_C["accent"])

    def _build_graph_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        r1 = tk.Frame(top, bg=_C["panel"])
        r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Series 1 Dir:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=12, anchor="w").pack(side="left", padx=(10, 0))
        tk.Entry(r1, textvariable=self._vars_graph["dir1"], bg=_C["entry"], fg=_C["text"], width=25, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Button(r1, text="...", command=lambda: self._vars_graph["dir1"].set(filedialog.askdirectory()), bg=_C["accent"], fg=_C["text"], bd=0, padx=5).pack(side="left")
        tk.Label(r1, text="Legend 1:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        tk.Entry(r1, textvariable=self._vars_graph["name1"], bg=_C["entry"], fg=_C["text"], width=15, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Label(r1, text="Series 2 Dir:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=12, anchor="w").pack(side="left", padx=(25, 0))
        tk.Entry(r1, textvariable=self._vars_graph["dir2"], bg=_C["entry"], fg=_C["text"], width=25, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Button(r1, text="...", command=lambda: self._vars_graph["dir2"].set(filedialog.askdirectory()), bg=_C["accent"], fg=_C["text"], bd=0, padx=5).pack(side="left")
        tk.Label(r1, text="Legend 2:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        tk.Entry(r1, textvariable=self._vars_graph["name2"], bg=_C["entry"], fg=_C["text"], width=15, bd=0).pack(side="left", padx=5, ipady=3)

        r2 = tk.Frame(top, bg=_C["panel"])
        r2.pack(fill="x", pady=(10, 2))
        tk.Label(r2, text="Custom X-Axis Labels:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold"), width=18, anchor="w").pack(side="left", padx=(10, 0))
        tk.Entry(r2, textvariable=self._vars_graph["x_labels"], bg=_C["entry"], fg=_C["text"], width=30, bd=0).pack(side="left", padx=5, ipady=3)
        tk.Checkbutton(r2, text="Add Blank Space for 3D Models", variable=self._vars_graph["top_space"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black", font=("Segoe UI", 9, "bold")).pack(side="left", padx=10)

        r4 = tk.Frame(top, bg=_C["panel"])
        r4.pack(fill="x", pady=(10, 2))
        tk.Label(r4, text="Connection Line:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["conn_style"], values=["Smooth (Bezier)", "Straight", "Wavy", "Zigzag", "Curled (Arc)"], width=15, state="readonly").pack(side="left", padx=5)
        tk.Label(r4, text="Delta Arrow Style:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["delta_arrow"], values=["Straight", "Wavy", "Zigzag", "Curled (Arc)", "No Arrow"], width=12, state="readonly").pack(side="left", padx=5)
        tk.Label(r4, text="Label Box:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r4, textvariable=self._vars_graph["label_box"], values=["Rounded Box", "Square Box", "No Box"], width=12, state="readonly").pack(side="left", padx=5)

        r3 = tk.Frame(top, bg=_C["panel"])
        r3.pack(fill="x", pady=(15, 2))
        tk.Label(r3, text="Energy Source:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(r3, textvariable=self._vars_graph["method"], values=["ORCA", "CREST", "xTB"], width=10, state="readonly").pack(side="left", padx=5)
        tk.Label(r3, text="Metric:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(15, 5))
        ttk.Combobox(r3, textvariable=self._vars_graph["metric"], values=["Total Energy (ΔE)", "Gibbs Free Energy (ΔG)"], width=20, state="readonly").pack(side="left", padx=5)
        tk.Button(r3, text=" Plot Publication Energy Profile ", command=self._plot_reaction_profile, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=15).pack(side="left", padx=(20, 10))
        tk.Button(r3, text=" Plot CREST vs ORCA Method Acc. ", command=self._plot_methods, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=15).pack(side="left", padx=10)
        tk.Button(r3, text=" Plot All Optimized ", command=self._plot_all_optimized, bg="#8957e5", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Button(r3, text=" Plot Top Conformers ", command=self._plot_top_conformers, bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Label(r3, text="Top N:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(8, 2))
        tk.Entry(r3, textvariable=self._vars_graph["conformer_top_n"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Button(r3, text=" Stacked xTB/CREST/ORCA ", command=self._plot_stacked_energy, bg="#c0392b", fg="white", font=("Segoe UI", 10, "bold"), padx=12).pack(side="left", padx=8)
        tk.Button(r3, text=" Copy to Clipboard ", command=lambda: self._copy_to_clipboard(self.fig), bg="#6e40c9", fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="right", padx=20)
        tk.Button(r3, text=" Download High-Res Graph ", command=self._export_high_res_graph, bg=_C["yellow"], fg="black", font=("Segoe UI", 10, "bold"), padx=15).pack(side="right", padx=10)
        self._build_visual_controls(top)

        self.fig = Figure(figsize=(12, 7), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax2 = None
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        self.graph_toolbar = NavigationToolbar2Tk(self.canvas, parent, pack_toolbar=False)
        self.graph_toolbar.update()
        self.graph_toolbar.pack(fill="x", padx=10, pady=(0, 6))

    def _build_visual_controls(self, top):
        row = tk.Frame(top, bg=_C["panel"])
        row.pack(fill="x", pady=(8, 2))
        tk.Label(row, text="JACS visual colors:", bg=_C["panel"], fg=_C["yellow"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 6))
        for label, key in [("Series 1", "series1_color"), ("Series 2", "series2_color"), ("ORCA", "orca_color"), ("CREST", "crest_color"), ("BG", "graph_bg"), ("Axis", "axis_color"), ("Grid", "grid_color")]:
            self._color_button(row, label, key)
        row2 = tk.Frame(top, bg=_C["panel"])
        row2.pack(fill="x", pady=(4, 2))
        tk.Label(row2, text="Model:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(row2, textvariable=self._vars_graph["model_style"], values=["Ball-and-stick", "CPK", "Wireframe", "Licorice"], width=14, state="readonly").pack(side="left", padx=3)
        for label, key in [("C", "atom_C"), ("H", "atom_H"), ("N", "atom_N"), ("O", "atom_O"), ("F", "atom_F"), ("S", "atom_S"), ("Bond", "bond_color"), ("Model BG", "model_bg")]:
            self._color_button(row2, label, key, width=5)
        row3 = tk.Frame(top, bg=_C["panel"])
        row3.pack(fill="x", pady=(4, 2))
        tk.Label(row3, text="3D bonds:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        ttk.Combobox(
            row3,
            textvariable=self._vars_graph["bond_mode"],
            values=["Covalent radii", "Distance cutoff", "Hydrogen bonds", "All close contacts"],
            width=16,
            state="readonly",
        ).pack(side="left", padx=4)
        tk.Label(row3, text="Cutoff A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(row3, textvariable=self._vars_graph["bond_cutoff"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Label(row3, text="Tol A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(row3, textvariable=self._vars_graph["bond_tolerance"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Checkbutton(row3, text="Distances", variable=self._vars_graph["show_bond_distances"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=8)
        tk.Checkbutton(row3, text="Atom labels", variable=self._vars_graph["show_atom_labels"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        tk.Checkbutton(row3, text="Axes", variable=self._vars_graph["show_3d_axes"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        for label, key in [("Elev", "model_elev"), ("Azim", "model_azim"), ("DPI", "image_dpi")]:
            tk.Label(row3, text=f"{label}:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
            tk.Entry(row3, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        row4 = tk.Frame(top, bg=_C["panel"])
        row4.pack(fill="x", pady=(4, 2))
        tk.Label(row4, text="Crop axes:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 5))
        for label, key in [("X min", "crop_xmin"), ("X max", "crop_xmax"), ("Y min", "crop_ymin"), ("Y max", "crop_ymax")]:
            tk.Label(row4, text=label, bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(5, 2))
            tk.Entry(row4, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=7, bd=0).pack(side="left", ipady=2)
        tk.Button(row4, text="Apply Crop", command=self._apply_graph_crop, bg=_C["accent"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)
        tk.Button(row4, text="Reset View", command=self._reset_graph_view, bg=_C["dim"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=4)
        tk.Button(row4, text="Pan", command=lambda: self.graph_toolbar.pan(), bg=_C["panel"], fg=_C["text"], relief="groove").pack(side="left", padx=4)
        tk.Button(row4, text="Zoom", command=lambda: self.graph_toolbar.zoom(), bg=_C["panel"], fg=_C["text"], relief="groove").pack(side="left", padx=4)

    def _color_button(self, parent, label, key, width=8):
        frame = tk.Frame(parent, bg=_C["panel"])
        frame.pack(side="left", padx=3)
        tk.Label(frame, text=label, bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 2))
        btn = tk.Button(frame, text="", width=width, bg=self._vars_graph[key].get(), relief="flat", command=lambda k=key: self._pick_color(k))
        btn.pack(side="left")
        self._color_buttons[key] = btn

    def _pick_color(self, key):
        picked = colorchooser.askcolor(color=self._vars_graph[key].get(), parent=self.root)[1]
        if picked:
            self._vars_graph[key].set(picked)
            if key in self._color_buttons:
                self._color_buttons[key].config(bg=picked)
            if hasattr(self, "canvas"):
                self._apply_custom_visual_theme()
                self.canvas.draw_idle()

    def _build_table_tab(self, parent):
        top = tk.Frame(parent, bg=_C["panel"], pady=10)
        top.pack(fill="x")
        tk.Button(top, text=" Refresh from Graph Dirs ", command=self._refresh_thermo_table, bg=_C["accent"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Button(top, text=" Export CSV ", command=self._export_thermo_csv, bg=_C["green"], fg=_C["text"], font=("Segoe UI", 10, "bold"), padx=10).pack(side="left", padx=10)
        tk.Label(top, text="Scans the Series 1 & 2 directories from the Graph tab to tabulate all energies.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 10, "italic")).pack(side="left", padx=20)
        cols = ("Series", "Ratio", "Method", "Electronic (Eh)", "Gibbs (Eh)", "Rel. Energy (kcal/mol)")
        style = ttk.Style()
        style.configure("Custom.Treeview", font=("Consolas", 10), rowheight=25)
        style.configure("Custom.Treeview.Heading", font=("Segoe UI", 10, "bold"))
        self.thermo_tree = ttk.Treeview(parent, columns=cols, show="headings", style="Custom.Treeview")
        for col in cols:
            self.thermo_tree.heading(col, text=col)
            self.thermo_tree.column(col, width=150, anchor="center")
        scroll = ttk.Scrollbar(parent, orient="vertical", command=self.thermo_tree.yview)
        self.thermo_tree.configure(yscrollcommand=scroll.set)
        self.thermo_tree.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scroll.pack(side="right", fill="y", pady=10)

    def _extract_all_thermo(self, base_dir, method_col):
        data = []
        if not base_dir or not os.path.isdir(base_dir):
            return []
        for root, dirs, files in os.walk(base_dir):
            if "Energy_Comparison.csv" in files:
                csv_path = os.path.join(root, "Energy_Comparison.csv")
                parent_folder = os.path.basename(os.path.dirname(root))
                match = re.search(r"(\d+)[_:]+(\d+)", parent_folder)
                if match:
                    ratio_str = f"{match.group(1)}:{match.group(2)}"
                    sort_key = int(match.group(1)) + int(match.group(2))
                else:
                    ratio_str = parent_folder
                    sort_key = 999
                try:
                    with open(csv_path, "r", encoding="utf-8") as f:
                        for line in f.readlines()[1:]:
                            parts = line.strip().split(",")
                            if len(parts) >= 4 and parts[0] == method_col:
                                data.append({"ratio": ratio_str, "ele": parts[2].strip(), "gibbs": parts[3].strip(), "sort": sort_key})
                except Exception as e:
                    print(f"Error parsing {csv_path}: {e}")
        data.sort(key=lambda x: x["sort"])
        return data

    def _refresh_thermo_table(self):
        for row in self.thermo_tree.get_children():
            self.thermo_tree.delete(row)
        for d, name in [(self._vars_graph["dir1"].get(), self._vars_graph["name1"].get().strip() or "Series 1"), (self._vars_graph["dir2"].get(), self._vars_graph["name2"].get().strip() or "Series 2")]:
            if not d:
                continue
            data = self._extract_all_thermo(d, self._vars_graph["method"].get())
            if not data:
                continue
            base_e, is_gibbs = None, False
            for item in data:
                if item["gibbs"] not in ("N/A", "0.000000"):
                    base_e = float(item["gibbs"])
                    is_gibbs = True
                    break
                if item["ele"] not in ("N/A", "0.000000"):
                    base_e = float(item["ele"])
                    break
            for item in data:
                rel_e = "N/A"
                if base_e is not None:
                    val = float(item["gibbs"]) if is_gibbs and item["gibbs"] != "N/A" else float(item["ele"])
                    rel_e = f"{(val - base_e) * EH2KCAL:.2f}"
                self.thermo_tree.insert("", "end", values=(name, item["ratio"], self._vars_graph["method"].get(), item["ele"], item["gibbs"], rel_e))

    def _export_thermo_csv(self):
        dest = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], title="Export Thermodynamic Data")
        if dest:
            with open(dest, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Series", "Ratio", "Method", "Electronic (Eh)", "Gibbs (Eh)", "Rel. Energy (kcal/mol)"])
                for row_id in self.thermo_tree.get_children():
                    writer.writerow(self.thermo_tree.item(row_id)["values"])
            messagebox.showinfo("Success", f"Data exported to {dest}")

    def _extract_dir_energies(self, base_dir, method_col, metric_type):
        data = {}
        if not base_dir or not os.path.isdir(base_dir):
            return []
        col_idx = 3 if "Gibbs" in metric_type else 2
        for root, dirs, files in os.walk(base_dir):
            if "Energy_Comparison.csv" in files:
                csv_path = os.path.join(root, "Energy_Comparison.csv")
                parent_folder = os.path.basename(os.path.dirname(root))
                match = re.search(r"(\d+)[_:]+(\d+)", parent_folder)
                if match:
                    ratio_str = f"{match.group(1)}:{match.group(2)}"
                    sort_key = int(match.group(1)) + int(match.group(2))
                else:
                    ratio_str = parent_folder
                    sort_key = 999
                try:
                    with open(csv_path, "r", encoding="utf-8") as f:
                        for line in f.readlines()[1:]:
                            parts = line.strip().split(",")
                            if len(parts) > col_idx and parts[0] == method_col:
                                val_str = parts[col_idx].strip()
                                if val_str not in ("N/A", "0.000000"):
                                    data[ratio_str] = {"energy": float(val_str), "sort": sort_key}
                except Exception as e:
                    print(f"Error parsing {csv_path}: {e}")
        return [(k, v["energy"]) for k, v in sorted(data.items(), key=lambda x: x[1]["sort"])]

    def _apply_thesis_theme(self):
        self.ax.clear()
        if self.ax2 is not None:
            self.ax2.remove()
            self.ax2 = None
        bg = self._vars_graph["graph_bg"].get()
        axis_c = self._vars_graph["axis_color"].get()
        self.ax.set_facecolor(bg)
        self.fig.patch.set_facecolor(bg)
        self.ax.tick_params(colors=axis_c, labelsize=11)
        self.ax.xaxis.label.set_color(axis_c)
        self.ax.yaxis.label.set_color(axis_c)
        self.ax.title.set_color(axis_c)
        for spine in self.ax.spines.values():
            spine.set_edgecolor(axis_c)
            spine.set_linewidth(1.5)

    def _make_bbox(self, style, edge_c="#333", alpha=0.85, lw=0.7):
        if style == "No Box":
            return None
        bs = "round,pad=0.25" if style == "Rounded Box" else "square,pad=0.25"
        return dict(boxstyle=bs, facecolor=self._vars_graph["graph_bg"].get(), edgecolor=edge_c, alpha=alpha, linewidth=lw)

    def _plot_reaction_profile(self):
        dir1, dir2 = self._vars_graph["dir1"].get(), self._vars_graph["dir2"].get()
        name1 = self._vars_graph["name1"].get().strip() or "Series 1"
        name2 = self._vars_graph["name2"].get().strip() or "Series 2"
        method = self._vars_graph["method"].get()
        metric = self._vars_graph["metric"].get()
        custom_x = [l.strip() for l in self._vars_graph["x_labels"].get().split(",") if l.strip()]
        conn_style = self._vars_graph["conn_style"].get()
        arrow_style = self._vars_graph["delta_arrow"].get()
        lbl_box_style = self._vars_graph["label_box"].get()
        if method in ["CREST", "xTB"] and "Gibbs" in metric:
            messagebox.showwarning("Metric Auto-Corrected", f"{method} does not compute Gibbs Free Energy. Switching to Total Electronic Energy.")
            self._vars_graph["metric"].set("Total Energy (ΔE)")
            metric = "Total Energy (ΔE)"
        self._apply_thesis_theme()
        data1 = self._extract_dir_energies(dir1, method, metric) if dir1 else []
        data2 = self._extract_dir_energies(dir2, method, metric) if dir2 else []
        if not data1 and not data2:
            messagebox.showerror("Error", "No valid data found.")
            return
        all_labels = []
        for d in [data1, data2]:
            for lbl, _ in d:
                if lbl not in all_labels:
                    all_labels.append(lbl)

        def sort_ratio(lbl):
            try:
                a, b = map(int, lbl.replace("_", ":").split(":"))
                return a + b
            except Exception:
                return 999

        all_labels.sort(key=sort_ratio)
        final_labels = custom_x if custom_x and len(custom_x) >= len(all_labels) else all_labels
        label_to_x = {lbl: i for i, lbl in enumerate(all_labels)}
        all_energies = []
        for d in [data1, data2]:
            if d:
                base_e = d[0][1]
                all_energies.extend([(e - base_e) * EH2KCAL for _, e in d])
        y_span = max(all_energies) - min(all_energies) if all_energies else 1.0
        if y_span == 0:
            y_span = 1.0
        y_pad = y_span * 0.05

        def plot_series(data, color, label, is_series_one):
            if not data:
                return
            base_e = data[0][1]
            rel_energies = [(e - base_e) * EH2KCAL for _, e in data]
            x_positions = [label_to_x[lbl] for lbl, _ in data]
            for i in range(len(data)):
                x_pos, y_val = x_positions[i], rel_energies[i]
                self.ax.hlines(y_val, x_pos - 0.35, x_pos + 0.35, color=color, lw=5, label=label if i == 0 else "")
                val_pad = y_pad if is_series_one else -y_pad
                va_align = "bottom" if is_series_one else "top"
                txt_kw = dict(ha="center", va=va_align, color=color, fontweight="bold", fontsize=11, zorder=9)
                bbox = self._make_bbox(lbl_box_style, edge_c=color, lw=1.5)
                if bbox:
                    txt_kw["bbox"] = bbox
                t = self.ax.text(x_pos, y_val + val_pad, f"{y_val:.1f}", **txt_kw)
                try:
                    t.set_draggable(True)
                except Exception:
                    pass
                if i > 0:
                    prev_x, prev_y = x_positions[i - 1], rel_energies[i - 1]
                    start_x, start_y = prev_x + 0.35, prev_y
                    end_x, end_y = x_pos - 0.35, y_val
                    kw_line = dict(color=color, alpha=0.60, lw=2.5, zorder=3)
                    if conn_style == "Straight":
                        self.ax.plot([start_x, end_x], [start_y, end_y], **kw_line)
                    elif conn_style in ("Smooth (Bezier)", "Smooth"):
                        xs = np.linspace(start_x, end_x, 60)
                        ts = (xs - start_x) / max(end_x - start_x, 1e-9)
                        self.ax.plot(xs, start_y + (end_y - start_y) * (3 * ts**2 - 2 * ts**3), **kw_line)
                    elif conn_style == "Wavy":
                        _draw_wavy(self.ax, start_x, start_y, end_x, end_y, n_waves=6, amp_frac=0.04, **kw_line)
                    elif conn_style == "Zigzag":
                        _draw_zigzag(self.ax, start_x, start_y, end_x, end_y, n_zigs=8, amp_frac=0.04, **kw_line)
                    elif conn_style == "Curled (Arc)":
                        _draw_curled(self.ax, start_x, start_y, end_x, end_y, rad=0.30, **kw_line)
                    delta = y_val - prev_y
                    mid_x, mid_y = (start_x + end_x) / 2, (start_y + end_y) / 2
                    if arrow_style != "No Arrow":
                        _draw_fancy_arrow(self.ax, mid_x, mid_y + (y_pad if is_series_one else -y_pad) * 0.8, mid_x, mid_y, style=arrow_style, color=color, lw=1.5, alpha=0.8, zorder=11)
                    d_kw = dict(ha="center", va="center", color=color, fontsize=10, fontweight="bold", zorder=12)
                    d_bbox = self._make_bbox(lbl_box_style, edge_c=color, alpha=0.95, lw=1.5)
                    if d_bbox:
                        d_kw["bbox"] = d_bbox
                    t_del = self.ax.text(mid_x, mid_y + (y_pad if is_series_one else -y_pad) * 0.8, f"$\\Delta$={delta:.1f}", **d_kw)
                    try:
                        t_del.set_draggable(True)
                    except Exception:
                        pass

        plot_series(data1, self._vars_graph["series1_color"].get(), name1, True)
        plot_series(data2, self._vars_graph["series2_color"].get(), name2, False)
        self.ax.set_xticks(range(len(all_labels)))
        self.ax.set_xticklabels(final_labels[: len(all_labels)], fontweight="bold", fontsize=12)
        self.ax.set_xlim(left=-0.75, right=len(all_labels) - 0.25)
        if self._vars_graph["top_space"].get():
            y_min, y_max = self.ax.get_ylim()
            self.ax.set_ylim(y_min - y_span * 0.1, y_max + y_span * 0.5)
        self.ax2 = self.ax.twinx()
        y1_min, y1_max = self.ax.get_ylim()
        self.ax2.set_ylim(y1_min * KCAL2KJ, y1_max * KCAL2KJ)
        self.ax2.set_ylabel("Relative Energy (kJ/mol)", fontweight="bold", fontsize=14, color=self._vars_graph["axis_color"].get())
        self.ax2.tick_params(colors=self._vars_graph["axis_color"].get(), labelsize=11)
        self.ax2.spines["right"].set_linewidth(1.5)
        symb = "ΔG" if "Gibbs" in metric else "ΔE"
        self.ax.set_ylabel(f"Relative Energy {symb} (kcal/mol)", fontweight="bold", fontsize=14)
        self.ax.set_title(f"Reaction Energy Profile Diagram ({symb})", fontweight="bold", fontsize=18, pad=20)
        self.ax.grid(axis="y", linestyle="-", alpha=0.25, color=self._vars_graph["grid_color"].get())
        self.ax.legend(loc="lower left" if self._vars_graph["top_space"].get() else "best", framealpha=0.95, fontsize=12, edgecolor=self._vars_graph["axis_color"].get())
        watermark = f"Level of Theory: {method}"
        if method == "ORCA":
            watermark += f" ({self._vars['orca_method'].get()})"
        self.ax.text(0.99, 0.02, watermark, ha="right", va="bottom", color=self._vars_graph["watermark_color"].get(), fontsize=10, transform=self.ax.transAxes, style="italic")
        self.fig.tight_layout()
        self.canvas.draw()

    def _plot_methods(self):
        dir1 = self._vars_graph["dir1"].get()
        name1 = self._vars_graph["name1"].get().strip() or "Series"
        metric = self._vars_graph["metric"].get()
        custom_x = [l.strip() for l in self._vars_graph["x_labels"].get().split(",") if l.strip()]
        if "Gibbs" in metric:
            messagebox.showwarning("Metric Auto-Corrected", "CREST vs ORCA comparison uses Total Energy.")
            self._vars_graph["metric"].set("Total Energy (ΔE)")
            metric = "Total Energy (ΔE)"
        if not dir1:
            messagebox.showerror("Error", "Please specify Series 1 Directory.")
            return
        crest_data = self._extract_dir_energies(dir1, "CREST", metric)
        orca_data = self._extract_dir_energies(dir1, "ORCA", metric)
        self._apply_thesis_theme()
        plotted_any = False
        all_labels = []
        if crest_data:
            plotted_any = True
            all_labels = [l for l, _ in crest_data]
            x_c = np.arange(len(all_labels))
            base_c = crest_data[0][1]
            y_c = [(e - base_c) * EH2KCAL for _, e in crest_data]
            self.ax.plot(x_c, y_c, marker="o", markersize=10, linestyle="--", linewidth=2.5, color=self._vars_graph["crest_color"].get(), label="CREST Trend")
        if orca_data:
            plotted_any = True
            all_labels = [l for l, _ in orca_data]
            x_o = np.arange(len(all_labels))
            base_o = orca_data[0][1]
            y_o = [(e - base_o) * EH2KCAL for _, e in orca_data]
            self.ax.plot(x_o, y_o, marker="s", markersize=10, linestyle="-", linewidth=3.5, color=self._vars_graph["orca_color"].get(), label="ORCA DFT Trend")
        if not plotted_any:
            messagebox.showerror("Error", "No valid data found.")
            return
        final_labels = custom_x if custom_x and len(custom_x) >= len(all_labels) else all_labels
        self.ax.set_xticks(np.arange(len(all_labels)))
        self.ax.set_xticklabels(final_labels[: len(all_labels)], fontweight="bold", fontsize=12)
        if self._vars_graph["top_space"].get():
            y_min, y_max = self.ax.get_ylim()
            self.ax.set_ylim(y_min, y_max + ((y_max - y_min) * 0.5))
        self.ax.set_ylabel("Relative Energy ΔE (kcal/mol)", fontsize=14, fontweight="bold", color=self._vars_graph["axis_color"].get())
        self.ax.set_title(f"Method Accuracy Comparison: {name1}", fontsize=18, fontweight="bold", color=self._vars_graph["axis_color"].get(), pad=20)
        self.ax.legend(loc="best", framealpha=0.95, fontsize=12, edgecolor=self._vars_graph["axis_color"].get())
        self.ax.grid(True, alpha=0.3, color=self._vars_graph["grid_color"].get(), linestyle="-")
        self.ax.text(0.99, 0.02, f"Level of Theory (DFT): {self._vars['orca_method'].get()}", ha="right", va="bottom", color=self._vars_graph["watermark_color"].get(), fontsize=10, transform=self.ax.transAxes, style="italic")
        self.fig.tight_layout()
        self.canvas.draw()

    def _collect_plot_records(self, base_dir, method_filter="ALL", metric="Total Energy (ΔE)", top_n=0):
        if not base_dir or not os.path.isdir(base_dir):
            return []
        job_dirs = self._find_iak_job_dirs(base_dir)
        if not job_dirs:
            job_dirs = [base_dir]
        records = []
        method_filter = method_filter.upper()
        for job_dir in job_dirs:
            job_label = os.path.basename(job_dir.rstrip("\\/")) or "job"
            job_records = self._collect_existing_job_records(job_dir)
            for method, method_records in job_records.items():
                if method_filter != "ALL" and method.upper() != method_filter:
                    continue
                for rec in method_records:
                    energy = rec.get("gibbs") if ("Gibbs" in metric and method == "ORCA" and rec.get("gibbs")) else rec.get("energy")
                    if energy is None:
                        continue
                    records.append({
                        "method": method,
                        "job": job_label,
                        "source": rec.get("source", ""),
                        "energy": float(energy),
                        "label": f"{job_label}:{rec.get('source','')}",
                    })
            if method_filter in ("ALL", "CREST"):
                crest_dir = os.path.join(job_dir, "03_CREST_Results")
                if os.path.isdir(crest_dir):
                    for conf_path in Path(crest_dir).glob("crest_conformers_*.xyz"):
                        for idx, mol in enumerate(read_multi_xyz(str(conf_path))):
                            if mol.energy_eh:
                                records.append({
                                    "method": "CREST",
                                    "job": job_label,
                                    "source": f"{conf_path.stem}_conf_{idx}",
                                    "energy": float(mol.energy_eh),
                                    "label": f"{job_label}:{conf_path.stem}_{idx}",
                                })
        if top_n and top_n > 0:
            limited = []
            for method in ["xTB", "CREST", "ORCA"]:
                group = [r for r in records if r["method"] == method]
                group.sort(key=lambda item: item["energy"])
                limited.extend(group[:top_n])
            records = limited
        return records

    def _plot_records_by_method(self, records, title):
        if not records:
            messagebox.showerror("No Data", "No optimized/conformer energy records were found for plotting.")
            return
        self._apply_thesis_theme()
        colors = {"xTB": self._vars_graph["series1_color"].get(), "CREST": self._vars_graph["crest_color"].get(), "ORCA": self._vars_graph["orca_color"].get()}
        x_labels = []
        x_pos = 0
        for method in ["xTB", "CREST", "ORCA"]:
            group = [r for r in records if r["method"] == method]
            if not group:
                continue
            group.sort(key=lambda item: item["energy"])
            base = group[0]["energy"]
            xs, ys = [], []
            for rec in group:
                xs.append(x_pos)
                ys.append((rec["energy"] - base) * EH2KCAL)
                x_labels.append(rec["label"])
                x_pos += 1
            self.ax.plot(xs, ys, marker="o", linewidth=2.2, markersize=7, color=colors.get(method, "#333333"), label=f"{method} relative")
        self.ax.set_xticks(range(len(x_labels)))
        self.ax.set_xticklabels(x_labels, rotation=60, ha="right", fontsize=8)
        self.ax.set_ylabel("Relative Energy (kcal/mol)", fontweight="bold", fontsize=13)
        self.ax.set_title(title, fontweight="bold", fontsize=16, pad=16)
        self.ax.grid(axis="y", linestyle="-", alpha=0.25, color=self._vars_graph["grid_color"].get())
        self.ax.legend(loc="best", framealpha=0.95, fontsize=10)
        self.fig.tight_layout()
        self.canvas.draw()

    def _plot_all_optimized(self):
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        records = self._collect_plot_records(base_dir, method_filter="ALL", metric=self._vars_graph["metric"].get(), top_n=0)
        self._plot_records_by_method(records, "All Optimized Structures: xTB vs CREST vs ORCA")

    def _plot_top_conformers(self):
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        try:
            top_n = max(1, int(self._vars_graph["conformer_top_n"].get()))
        except Exception:
            top_n = 10
        method = self._vars_graph["method"].get()
        records = self._collect_plot_records(base_dir, method_filter=method, metric=self._vars_graph["metric"].get(), top_n=top_n)
        self._plot_records_by_method(records, f"Top {top_n} {method} Conformers / Optimized Structures")

    def _plot_stacked_energy(self):
        """Plot a stacked bar chart comparing xTB, CREST, and ORCA energies for each conformer."""
        if not MATPLOTLIB_AVAILABLE:
            messagebox.showerror("Plot Error", "matplotlib is not available.")
            return
        base_dir = self._vars_graph["dir1"].get() or self._vars["out"].get()
        if not base_dir or not os.path.isdir(base_dir):
            messagebox.showwarning("No Directory", "Set a valid output directory in Graph Settings.")
            return
        records_xtb   = self._collect_plot_records(base_dir, method_filter="xTB",  metric="energy", top_n=0)
        records_crest = self._collect_plot_records(base_dir, method_filter="CREST", metric="energy", top_n=0)
        records_orca  = self._collect_plot_records(base_dir, method_filter="ORCA",  metric="energy", top_n=0)
        if not any([records_xtb, records_crest, records_orca]):
            messagebox.showinfo("No Data", "No xTB/CREST/ORCA energy data found in the selected directory.")
            return
        self.ax.clear()
        if getattr(self, "ax2", None):
            self.ax2.clear()
        def _energies(recs):
            return [r.get("energy", 0.0) if isinstance(r, dict) else getattr(r, "energy", 0.0) for r in recs]
        labels = [f"C{i+1}" for i in range(max(len(records_xtb), len(records_crest), len(records_orca)))]
        import numpy as np
        x = np.arange(len(labels))
        w = 0.25
        e_xtb   = _energies(records_xtb)   + [0.0] * (len(labels) - len(records_xtb))
        e_crest = _energies(records_crest) + [0.0] * (len(labels) - len(records_crest))
        e_orca  = _energies(records_orca)  + [0.0] * (len(labels) - len(records_orca))
        # Normalize relative to minimum
        base = min(v for v in e_xtb + e_crest + e_orca if v != 0.0) if any(e_xtb + e_crest + e_orca) else 0.0
        e_xtb   = [(v - base) * 627.509 for v in e_xtb]
        e_crest = [(v - base) * 627.509 for v in e_crest]
        e_orca  = [(v - base) * 627.509 for v in e_orca]
        ax = self.ax
        ax.bar(x - w, e_xtb,   w, label="xTB",   color="#2196F3", alpha=0.85)
        ax.bar(x,     e_crest, w, label="CREST",  color="#4CAF50", alpha=0.85)
        ax.bar(x + w, e_orca,  w, label="ORCA",   color="#FF5722", alpha=0.85)
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_xlabel("Conformer"); ax.set_ylabel("Rel. Energy (kcal/mol)")
        ax.set_title("Stacked Method Comparison: xTB / CREST / ORCA")
        ax.legend()
        ax.grid(axis="y", alpha=0.3)
        if hasattr(self, "canvas"):
            self.canvas.draw()


        if not hasattr(self, "ax"):
            return
        bg = self._vars_graph["graph_bg"].get()
        axis_c = self._vars_graph["axis_color"].get()
        grid_c = self._vars_graph["grid_color"].get()
        self.fig.patch.set_facecolor(bg)
        for axis in [self.ax] + ([self.ax2] if getattr(self, "ax2", None) else []):
            axis.set_facecolor(bg)
            axis.tick_params(colors=axis_c)
            axis.xaxis.label.set_color(axis_c)
            axis.yaxis.label.set_color(axis_c)
            axis.title.set_color(axis_c)
            for spine in axis.spines.values():
                spine.set_edgecolor(axis_c)
            for gridline in axis.get_xgridlines() + axis.get_ygridlines():
                gridline.set_color(grid_c)
                gridline.set_alpha(0.35)

    def _parse_crop(self, value):
        value = (value or "").strip()
        return None if not value else float(value)

    def _apply_graph_crop(self):
        try:
            xmin = self._parse_crop(self._vars_graph["crop_xmin"].get())
            xmax = self._parse_crop(self._vars_graph["crop_xmax"].get())
            ymin = self._parse_crop(self._vars_graph["crop_ymin"].get())
            ymax = self._parse_crop(self._vars_graph["crop_ymax"].get())
        except Exception:
            return messagebox.showerror("Crop Error", "Crop values must be numeric or blank.")
        if xmin is not None or xmax is not None:
            current = self.ax.get_xlim()
            self.ax.set_xlim(xmin if xmin is not None else current[0], xmax if xmax is not None else current[1])
        if ymin is not None or ymax is not None:
            current = self.ax.get_ylim()
            self.ax.set_ylim(ymin if ymin is not None else current[0], ymax if ymax is not None else current[1])
            if self.ax2 is not None:
                yl = self.ax.get_ylim()
                self.ax2.set_ylim(yl[0] * KCAL2KJ, yl[1] * KCAL2KJ)
        self._apply_custom_visual_theme()
        self.canvas.draw_idle()

    def _reset_graph_view(self):
        self.ax.relim()
        self.ax.autoscale_view()
        if self.ax2 is not None:
            yl = self.ax.get_ylim()
            self.ax2.set_ylim(yl[0] * KCAL2KJ, yl[1] * KCAL2KJ)
        for key in ["crop_xmin", "crop_xmax", "crop_ymin", "crop_ymax"]:
            self._vars_graph[key].set("")
        self._apply_custom_visual_theme()
        self.canvas.draw_idle()

    def _copy_to_clipboard(self, figure):
        import tempfile

        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
                tmp_path = f.name
            figure.savefig(tmp_path, dpi=300, bbox_inches="tight")
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms;"
                "Add-Type -AssemblyName System.Drawing;"
                f"$img = [System.Drawing.Image]::FromFile('{tmp_path}');"
                "[System.Windows.Forms.Clipboard]::SetImage($img);"
                "$img.Dispose();"
            )
            result = subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], capture_output=True, timeout=10)
            if result.returncode == 0:
                messagebox.showinfo("Clipboard", "Plot copied to Windows Clipboard.")
            else:
                messagebox.showerror("Clipboard Error", result.stderr.decode(errors="replace"))
        except Exception as e:
            messagebox.showerror("Clipboard Error", str(e))
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass

    def _export_high_res_graph(self):
        dest = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Image", "*.png"), ("PDF Document", "*.pdf"), ("JPEG Image", "*.jpg"), ("SVG Vector", "*.svg")], title="Export High-Res Graph")
        if dest:
            self.fig.savefig(dest, dpi=600, bbox_inches="tight")
            messagebox.showinfo("Export Successful", f"High-resolution publication graph saved to:\n{dest}")

    def _get_selected_filepath(self):
        for col, lb in enumerate(self.listboxes):
            sel = lb.curselection()
            if sel:
                fname = lb.get(sel[0])
                if fname.startswith("("):
                    return None
                return os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        return None

    def _open_file(self, listbox, col):
        sel = listbox.curselection()
        if not sel:
            return
        fname = listbox.get(sel[0])
        if fname.startswith("("):
            return
        path = os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        if not os.path.exists(path):
            return messagebox.showerror("Missing File", f"File not found:\n{path}")
        if path.lower().endswith(".xyz") and MATPLOTLIB_AVAILABLE:
            return self._open_model_viewer(path)
        try:
            if sys.platform == "win32":
                os.startfile(path)
            else:
                webbrowser.open(Path(path).as_uri())
        except Exception as exc:
            messagebox.showerror("Open Error", str(exc))

    def _open_in_avogadro(self):
        path = self._get_selected_filepath()
        if not path:
            return messagebox.showwarning("Select File", "Please select a file first.")
        cmd = None
        if shutil.which("avogadro"):
            cmd = ["avogadro", path]
        elif shutil.which("avogadro2"):
            cmd = ["avogadro2", path]
        elif sys.platform == "win32":
            cps = [
                r"C:\Program Files\Avogadro\bin\avogadro.exe",
                r"C:\Program Files (x86)\Avogadro\bin\avogadro.exe",
                r"C:\Program Files\Avogadro\avogadro.exe",
                r"C:\Program Files (x86)\Avogadro\avogadro.exe",
                r"C:\Program Files\Avogadro2\bin\avogadro2.exe",
                r"C:\Program Files\Avogadro2\avogadro2.exe",
            ]
            for cp in cps:
                if os.path.exists(cp):
                    cmd = [cp, path]
                    break
        if not cmd:
            return messagebox.showerror("Not Found", "Avogadro not found in standard paths.")
        try:
            subprocess.Popen(cmd)
        except Exception as e:
            messagebox.showerror("Error", f"Launch failed: {e}")

    def _export_file(self):
        path = self._get_selected_filepath()
        if not path:
            return messagebox.showwarning("Select File", "Please select a file first.")
        dest = filedialog.asksaveasfilename(defaultextension=Path(path).suffix, initialfile=os.path.basename(path), title="Export")
        if dest:
            shutil.copy2(path, dest)

    def _on_hover(self, event, listbox, col):
        idx = listbox.nearest(event.y)
        bbox = listbox.bbox(idx)
        if not bbox or not (bbox[1] <= event.y <= bbox[1] + bbox[3]):
            return self._hide_preview()
        fname = listbox.get(idx)
        if fname.startswith("("):
            return self._hide_preview()
        filepath = os.path.join(os.path.abspath(self._vars["out"].get().strip(" \"'")), self.folders[col], fname)
        if not os.path.exists(filepath) or not fname.endswith(".xyz"):
            return
        if self.preview_file == filepath and self.preview_tw is not None:
            return
        self._show_preview(event.x_root, event.y_root, filepath)

    def _hide_preview(self):
        if self.preview_tw:
            self.preview_tw.destroy()
            self.preview_tw = None
        self.preview_file = None

    def _read_xyz_atoms(self, filepath):
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        n = int(lines[0].strip())
        return [(p[0], float(p[1]), float(p[2]), float(p[3])) for l in lines[2 : 2 + n] for p in [l.split()] if len(p) >= 4]

    def _model_projection(self, atoms):
        coords = np.array([[a[1], a[2], a[3]] for a in atoms], dtype=float)
        coords -= np.mean(coords, axis=0)
        rx = np.array([[1, 0, 0], [0, math.cos(0.35), -math.sin(0.35)], [0, math.sin(0.35), math.cos(0.35)]])
        ry = np.array([[math.cos(0.61), 0, math.sin(0.61)], [0, 1, 0], [-math.sin(0.61), 0, math.cos(0.61)]])
        return coords @ rx @ ry

    def _atom_color(self, symbol):
        if symbol == "Cl":
            key = "atom_Cl"
        elif symbol in {"H", "C", "N", "O", "F", "S"}:
            key = f"atom_{symbol}"
        else:
            key = "atom_other"
        return self._vars_graph[key].get()

    def _covalent_radius(self, symbol):
        radii = {
            "H": 0.31,
            "B": 0.85,
            "C": 0.76,
            "N": 0.71,
            "O": 0.66,
            "F": 0.57,
            "P": 1.07,
            "S": 1.05,
            "Cl": 1.02,
            "Br": 1.20,
            "I": 1.39,
            "Si": 1.11,
            "Na": 1.66,
            "K": 2.03,
            "Mg": 1.41,
            "Ca": 1.76,
            "Fe": 1.24,
            "Cu": 1.32,
            "Zn": 1.22,
        }
        return radii.get(symbol, 0.80)

    def _vdw_radius(self, symbol):
        radii = {
            "H": 1.20,
            "C": 1.70,
            "N": 1.55,
            "O": 1.52,
            "F": 1.47,
            "P": 1.80,
            "S": 1.80,
            "Cl": 1.75,
            "Br": 1.85,
            "I": 1.98,
        }
        return radii.get(symbol, 1.65)

    def _float_var(self, key, fallback):
        try:
            return float(self._vars_graph[key].get())
        except Exception:
            return fallback

    def _detect_bonds(self, atoms, coords):
        mode = self._vars_graph["bond_mode"].get()
        cutoff = self._float_var("bond_cutoff", 1.85)
        tolerance = self._float_var("bond_tolerance", 0.45)
        bonds = []
        for i in range(len(atoms)):
            for j in range(i + 1, len(atoms)):
                dist = float(np.linalg.norm(coords[i] - coords[j]))
                sym_i, sym_j = atoms[i][0], atoms[j][0]
                include = False
                kind = "bond"
                if mode == "Distance cutoff":
                    include = dist <= cutoff
                elif mode == "Hydrogen bonds":
                    pair = {sym_i, sym_j}
                    include = "H" in pair and bool(pair.intersection({"O", "N", "F", "S"})) and 1.3 <= dist <= cutoff
                    kind = "hbond"
                elif mode == "All close contacts":
                    include = dist <= cutoff
                    kind = "contact"
                else:
                    include = dist <= self._covalent_radius(sym_i) + self._covalent_radius(sym_j) + tolerance
                if include and dist > 0.25:
                    bonds.append((i, j, dist, kind))
        return bonds

    def _set_3d_equal_axes(self, axis, coords):
        mins = coords.min(axis=0)
        maxs = coords.max(axis=0)
        centers = (mins + maxs) / 2.0
        radius = max(float(np.max(maxs - mins)) / 2.0, 1.0)
        pad = radius * 0.22
        radius += pad
        axis.set_xlim(centers[0] - radius, centers[0] + radius)
        axis.set_ylim(centers[1] - radius, centers[1] + radius)
        axis.set_zlim(centers[2] - radius, centers[2] + radius)
        try:
            axis.set_box_aspect((1, 1, 1))
        except Exception:
            pass

    def _render_xyz_model(self, axis, filepath):
        axis.clear()
        axis.set_facecolor(self._vars_graph["model_bg"].get())
        axis.figure.patch.set_facecolor(self._vars_graph["model_bg"].get())
        atoms = self._read_xyz_atoms(filepath)
        coords = np.array([[a[1], a[2], a[3]] for a in atoms], dtype=float)
        coords -= np.mean(coords, axis=0)
        style = self._vars_graph["model_style"].get()
        bond_color = self._vars_graph["bond_color"].get()
        bond_lw = {"Wireframe": 1.1, "Ball-and-stick": 2.6, "Licorice": 6.0, "CPK": 0.8}.get(style, 2.6)
        atom_scale = {"Wireframe": 18, "Ball-and-stick": 180, "Licorice": 90, "CPK": 520}.get(style, 180)
        bonds = self._detect_bonds(atoms, coords)
        if style != "CPK":
            for i, j, dist, kind in bonds:
                linestyle = "--" if kind in {"hbond", "contact"} else "-"
                alpha = 0.55 if kind in {"hbond", "contact"} else 0.95
                axis.plot(
                    [coords[i, 0], coords[j, 0]],
                    [coords[i, 1], coords[j, 1]],
                    [coords[i, 2], coords[j, 2]],
                    color=bond_color,
                    linewidth=bond_lw,
                    linestyle=linestyle,
                    solid_capstyle="round",
                    alpha=alpha,
                    zorder=1,
                )
                if self._vars_graph["show_bond_distances"].get():
                    mid = (coords[i] + coords[j]) / 2.0
                    axis.text(
                        mid[0],
                        mid[1],
                        mid[2],
                        f"{dist:.2f} A",
                        color=self._vars_graph["axis_color"].get(),
                        fontsize=7,
                        ha="center",
                        va="center",
                    )
        for idx in range(len(atoms)):
            symbol = atoms[idx][0]
            base = self._vdw_radius(symbol) if style == "CPK" else self._covalent_radius(symbol) + 0.30
            size = atom_scale * (base**2)
            if style == "Wireframe":
                size *= 0.35
            elif style == "CPK":
                size *= 0.75
            elif style == "Licorice":
                size *= 0.55
            axis.scatter(
                coords[idx, 0],
                coords[idx, 1],
                coords[idx, 2],
                s=size,
                color=self._atom_color(symbol),
                edgecolors="#111827",
                linewidths=0.65,
                depthshade=True,
                zorder=3,
            )
            if self._vars_graph["show_atom_labels"].get():
                axis.text(
                    coords[idx, 0],
                    coords[idx, 1],
                    coords[idx, 2],
                    f"{symbol}{idx + 1}",
                    color=self._vars_graph["axis_color"].get(),
                    fontsize=8,
                )
        self._set_3d_equal_axes(axis, coords)
        axis.view_init(elev=self._float_var("model_elev", 18.0), azim=self._float_var("model_azim", 38.0))
        if self._vars_graph["show_3d_axes"].get():
            axis.set_xlabel("X (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.set_ylabel("Y (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.set_zlabel("Z (A)", color=self._vars_graph["axis_color"].get(), fontsize=8)
            axis.tick_params(colors=self._vars_graph["axis_color"].get(), labelsize=7)
        else:
            axis.set_axis_off()
        for pane in [axis.xaxis.pane, axis.yaxis.pane, axis.zaxis.pane]:
            pane.set_facecolor(self._vars_graph["model_bg"].get())
            pane.set_edgecolor("#d0d7de")

    def _show_preview(self, x, y, filepath):
        self._hide_preview()
        self.preview_file = filepath
        tw = tk.Toplevel(self.root)
        self.preview_tw = tw
        tw.wm_overrideredirect(True)
        tw.geometry(f"+{x + 15}+{y + 15}")
        cv = tk.Canvas(tw, width=270, height=270, bg=self._vars_graph["model_bg"].get(), highlightthickness=2, highlightbackground=_C["accent"])
        cv.pack()
        try:
            atoms = self._read_xyz_atoms(filepath)
            coords = self._model_projection(atoms)
            xy, z = coords[:, :2], coords[:, 2]
            span = max(float(np.max(np.abs(xy))), 1.0)
            xy = xy * (105.0 / span) + 135.0
            distances = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)
            style = self._vars_graph["model_style"].get()
            bond_width = {"Wireframe": 1, "Ball-and-stick": 3, "Licorice": 6, "CPK": 1}.get(style, 3)
            if style != "CPK":
                for i in range(len(atoms)):
                    for j in range(i + 1, len(atoms)):
                        if 0.4 < distances[i, j] < 1.85:
                            cv.create_line(xy[i, 0], xy[i, 1], xy[j, 0], xy[j, 1], fill=self._vars_graph["bond_color"].get(), width=bond_width)
            for idx in sorted(range(len(atoms)), key=lambda i: z[i]):
                symbol = atoms[idx][0]
                radius = 4 if symbol == "H" else 8
                if style == "CPK":
                    radius = 11 if symbol == "H" else 18
                elif style == "Wireframe":
                    radius = 3
                elif style == "Licorice":
                    radius = 5 if symbol == "H" else 7
                cv.create_oval(xy[idx, 0] - radius, xy[idx, 1] - radius, xy[idx, 0] + radius, xy[idx, 1] + radius, fill=self._atom_color(symbol), outline="#111827")
        except Exception:
            cv.create_text(135, 135, text="Preview unavailable", fill="white")

    def _open_model_viewer(self, filepath):
        win = tk.Toplevel(self.root)
        win.title(f"IAK Model Viewer - {os.path.basename(filepath)}")
        win.geometry("900x720")
        win.configure(bg=_C["bg"])
        controls = tk.Frame(win, bg=_C["panel"])
        controls.pack(fill="x", padx=8, pady=8)
        tk.Label(controls, text="Model style:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(5, 4))
        ttk.Combobox(controls, textvariable=self._vars_graph["model_style"], values=["Ball-and-stick", "CPK", "Wireframe", "Licorice"], width=15, state="readonly").pack(side="left", padx=4)
        tk.Label(controls, text="Bonds:", bg=_C["panel"], fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(10, 4))
        ttk.Combobox(
            controls,
            textvariable=self._vars_graph["bond_mode"],
            values=["Covalent radii", "Distance cutoff", "Hydrogen bonds", "All close contacts"],
            width=16,
            state="readonly",
        ).pack(side="left", padx=4)
        tk.Label(controls, text="Cutoff A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(controls, textvariable=self._vars_graph["bond_cutoff"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Label(controls, text="Tol A:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
        tk.Entry(controls, textvariable=self._vars_graph["bond_tolerance"], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        tk.Checkbutton(controls, text="Distances", variable=self._vars_graph["show_bond_distances"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=8)
        tk.Checkbutton(controls, text="Atom labels", variable=self._vars_graph["show_atom_labels"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        tk.Checkbutton(controls, text="Axes", variable=self._vars_graph["show_3d_axes"], bg=_C["panel"], fg=_C["yellow"], selectcolor="black").pack(side="left", padx=4)
        for label, key in [("Elev", "model_elev"), ("Azim", "model_azim")]:
            tk.Label(controls, text=f"{label}:", bg=_C["panel"], fg=_C["muted"]).pack(side="left", padx=(8, 2))
            tk.Entry(controls, textvariable=self._vars_graph[key], bg=_C["entry"], fg=_C["text"], width=5, bd=0).pack(side="left", ipady=2)
        fig = Figure(figsize=(7, 6), dpi=110)
        ax = fig.add_subplot(111, projection="3d")
        canvas = FigureCanvasTkAgg(fig, master=win)
        toolbar = NavigationToolbar2Tk(canvas, win, pack_toolbar=False)

        def redraw():
            self._render_xyz_model(ax, filepath)
            canvas.draw_idle()

        tk.Button(controls, text="Redraw", command=redraw, bg=_C["accent"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)
        tk.Button(controls, text="Export Image", command=lambda: self._export_model_figure(fig), bg=_C["green"], fg=_C["text"], relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=4)
        tk.Label(controls, text="Drag to rotate; use toolbar pan/zoom to inspect and crop.", bg=_C["panel"], fg=_C["muted"], font=("Segoe UI", 9, "italic")).pack(side="left", padx=12)
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=(0, 8))
        toolbar.update()
        toolbar.pack(fill="x", padx=8, pady=(0, 8))
        redraw()

    def _export_model_figure(self, fig):
        dest = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Image", "*.png"), ("PDF Document", "*.pdf"), ("SVG Vector", "*.svg"), ("JPEG Image", "*.jpg")], title="Export Model Image")
        if dest:
            image_dpi = int(self._float_var("image_dpi", 600))
            image_dpi = max(72, min(image_dpi, 1200))
            fig.savefig(dest, dpi=image_dpi, bbox_inches="tight")
            messagebox.showinfo("Export Successful", f"Model image saved to:\n{dest}")

    def _refresh_results(self):
        out_dir = os.path.abspath(self._vars["out"].get().strip(" \"'"))
        for col, lb in enumerate(self.listboxes):
            lb.delete(0, tk.END)
            path = os.path.join(out_dir, self.folders[col])
            if os.path.exists(path):
                files = sorted([f for f in os.listdir(path) if f.lower().endswith((".xyz", ".json", ".csv", ".md", ".png", ".jpg", ".jpeg", ".svg", ".pdf"))])
                for f in files:
                    lb.insert(tk.END, f)
                if not files:
                    lb.insert(tk.END, "(Empty)")

    def _is_iak_job_dir(self, folder):
        if not os.path.isdir(folder):
            return False
        markers = [
            "01_Inputs_and_Clusters",
            "02_xTB_Results",
            "03_CREST_Results",
            "04_ORCA_Refinement",
            "05_Top_Models_Comparison",
            "state.json",
        ]
        return any(os.path.exists(os.path.join(folder, marker)) for marker in markers)

    def _find_iak_job_dirs(self, folder):
        folder = os.path.abspath(folder)
        if self._is_iak_job_dir(folder):
            return [folder]
        jobs = []
        for root, dirs, files in os.walk(folder):
            if self._is_iak_job_dir(root):
                jobs.append(root)
                dirs[:] = []
        return sorted(set(jobs))

    def _resolve_existing_path(self, job_dir, path_value):
        if not path_value:
            return None
        path_value = str(path_value)
        if os.path.exists(path_value):
            return path_value
        basename = os.path.basename(path_value)
        if not basename:
            return None
        for root, _, files in os.walk(job_dir):
            if basename in files:
                return os.path.join(root, basename)
        return None

    def _xyz_comment_energy(self, path):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
            if len(lines) < 2:
                return None
            return float(lines[1].split()[0])
        except Exception:
            return None

    def _parse_orca_out(self, out_path):
        energy, gibbs, imag, success = None, None, 0, False
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                content = handle.read()
            for line in content.splitlines():
                if "FINAL SINGLE POINT ENERGY" in line:
                    try:
                        energy = float(line.split()[-1])
                    except Exception:
                        pass
                elif "Final Gibbs free energy" in line:
                    try:
                        gibbs = float(line.split()[-2])
                    except Exception:
                        pass
                elif "*** imaginary mode ***" in line:
                    imag += 1
                elif "ORCA TERMINATED NORMALLY" in line:
                    success = True
            xyz_path = None
            folder = os.path.dirname(out_path)
            stem = Path(out_path).stem
            candidates = [
                os.path.join(folder, f"{stem}_trj.xyz"),
                os.path.join(folder, f"{stem}.xyz"),
            ]
            candidates.extend(str(p) for p in Path(folder).glob("*_trj.xyz"))
            candidates.extend(str(p) for p in Path(folder).glob("*.xyz"))
            for candidate in candidates:
                if os.path.exists(candidate):
                    xyz_path = candidate
                    break
            if xyz_path is None:
                extracted = os.path.join(folder, f"{stem}_final_from_out.xyz")
                if self._extract_orca_final_xyz(out_path, extracted):
                    xyz_path = extracted
            if energy is None:
                success = False
            return {
                "status": "success" if success and energy is not None else "failed",
                "energy": energy,
                "gibbs": gibbs or 0.0,
                "imag": imag,
                "path": xyz_path,
                "out_path": out_path,
            }
        except Exception:
            return {"status": "failed", "energy": None, "gibbs": 0.0, "imag": 0, "path": None, "out_path": out_path}

    def _extract_orca_final_xyz(self, out_path, dest_xyz):
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
            blocks = []
            idx = 0
            while idx < len(lines):
                line = lines[idx]
                upper = line.upper()
                if "CARTESIAN COORDINATES" in upper and ("ANGSTROEM" in upper or "ANGSTROM" in upper):
                    idx += 1
                    block = []
                    while idx < len(lines):
                        raw = lines[idx].strip()
                        idx += 1
                        if not raw:
                            if block:
                                break
                            continue
                        if set(raw) <= {"-"}:
                            continue
                        parts = raw.split()
                        if len(parts) >= 4 and re.match(r"^[A-Z][a-z]?$", parts[0]):
                            try:
                                block.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                                continue
                            except Exception:
                                pass
                        if block:
                            break
                    if block:
                        blocks.append(block)
                else:
                    idx += 1
            if not blocks:
                return None
            atoms = blocks[-1]
            os.makedirs(os.path.dirname(dest_xyz), exist_ok=True)
            with open(dest_xyz, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(f"{len(atoms)}\nExtracted final coordinates from {os.path.basename(out_path)}\n")
                for sym, x, y, z in atoms:
                    handle.write(f"{sym:<4} {x:15.6f} {y:15.6f} {z:15.6f}\n")
            return dest_xyz
        except Exception:
            return None

    def _parse_orca_thermo(self, out_path):
        data = {
            "final_single_point_energy_eh": None,
            "zero_point_energy_eh": None,
            "total_thermal_energy_eh": None,
            "total_enthalpy_eh": None,
            "final_entropy_term_eh": None,
            "final_gibbs_free_energy_eh": None,
            "temperature_k": None,
            "pressure_atm": None,
            "imaginary_frequencies": 0,
            "normal_termination": False,
        }
        labels = {
            "FINAL SINGLE POINT ENERGY": "final_single_point_energy_eh",
            "Zero point energy": "zero_point_energy_eh",
            "Total thermal energy": "total_thermal_energy_eh",
            "Total Enthalpy": "total_enthalpy_eh",
            "Final entropy term": "final_entropy_term_eh",
            "Final Gibbs free energy": "final_gibbs_free_energy_eh",
        }
        try:
            with open(out_path, "r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    stripped = line.strip()
                    for label, key in labels.items():
                        if label.lower() in stripped.lower():
                            floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                            if floats:
                                data[key] = float(floats[-1])
                    if "*** imaginary mode ***" in stripped:
                        data["imaginary_frequencies"] += 1
                    if "ORCA TERMINATED NORMALLY" in stripped:
                        data["normal_termination"] = True
                    if "Temperature" in stripped and "K" in stripped:
                        floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                        if floats:
                            data["temperature_k"] = float(floats[-1])
                    if "Pressure" in stripped and ("atm" in stripped.lower() or "ATM" in stripped):
                        floats = re.findall(r"[-+]?\d+\.\d+(?:[Ee][-+]?\d+)?", stripped)
                        if floats:
                            data["pressure_atm"] = float(floats[-1])
        except Exception:
            pass
        return data

    def _copy_unique_result(self, src, dest):
        if not src or not os.path.exists(src):
            return None
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.abspath(src) == os.path.abspath(dest):
            return dest
        shutil.copy2(src, dest)
        return dest

    def _collect_existing_job_records(self, job_dir):
        state_path = os.path.join(job_dir, "state.json")
        state = {"xtb": {}, "crest": {}, "orca": {}}
        if os.path.exists(state_path):
            try:
                with open(state_path, "r", encoding="utf-8") as handle:
                    state.update(json.load(handle))
            except Exception:
                pass

        records = {"xTB": [], "CREST": [], "ORCA": []}

        for key, value in state.get("xtb", {}).items():
            if value.get("status") == "success" and value.get("energy") is not None:
                path = self._resolve_existing_path(job_dir, value.get("path"))
                records["xTB"].append({"source": key, "energy": float(value["energy"]), "gibbs": None, "imag": None, "path": path})

        xtb_dir = os.path.join(job_dir, "02_xTB_Results")
        if not records["xTB"] and os.path.isdir(xtb_dir):
            for path in Path(xtb_dir).rglob("*.xyz"):
                energy = self._xyz_comment_energy(str(path))
                if energy is not None:
                    records["xTB"].append({"source": path.stem, "energy": energy, "gibbs": None, "imag": None, "path": str(path)})

        for key, value in state.get("crest", {}).items():
            if value.get("status") == "success":
                path = self._resolve_existing_path(job_dir, value.get("best_path") or value.get("path"))
                if path:
                    mols = read_multi_xyz(path)
                    energy = mols[0].energy_eh if mols else self._xyz_comment_energy(path)
                    if energy is not None:
                        records["CREST"].append({"source": key, "energy": float(energy), "gibbs": None, "imag": None, "path": path})

        crest_dir = os.path.join(job_dir, "03_CREST_Results")
        if os.path.isdir(crest_dir):
            for path in list(Path(crest_dir).glob("crest_best_*.xyz")) + list(Path(crest_dir).glob("crest_conformers_*.xyz")):
                mols = read_multi_xyz(str(path))
                energy = mols[0].energy_eh if mols else self._xyz_comment_energy(str(path))
                if energy is not None:
                    records["CREST"].append({"source": path.stem, "energy": float(energy), "gibbs": None, "imag": None, "path": str(path)})

        for key, value in state.get("orca", {}).items():
            if value.get("status") == "success" and value.get("energy") is not None:
                path = self._resolve_existing_path(job_dir, value.get("best_path") or value.get("path"))
                records["ORCA"].append({
                    "source": key,
                    "energy": float(value["energy"]),
                    "gibbs": float(value.get("gibbs", 0.0) or 0.0),
                    "imag": int(value.get("imag", 0) or 0),
                    "path": path,
                })

        orca_dir = os.path.join(job_dir, "04_ORCA_Refinement")
        if os.path.isdir(orca_dir):
            for out_path in Path(orca_dir).rglob("*.out"):
                parsed = self._parse_orca_out(str(out_path))
                if parsed["status"] == "success" and parsed["energy"] is not None:
                    records["ORCA"].append({
                        "source": out_path.stem,
                        "energy": float(parsed["energy"]),
                        "gibbs": float(parsed.get("gibbs", 0.0) or 0.0),
                        "imag": int(parsed.get("imag", 0) or 0),
                        "path": parsed.get("path"),
                    })
        return records

    def _write_existing_analysis_outputs(self, job_dir):
        comp_dir = os.path.join(job_dir, "05_Top_Models_Comparison")
        logs_dir = os.path.join(job_dir, "logs")
        os.makedirs(comp_dir, exist_ok=True)
        os.makedirs(logs_dir, exist_ok=True)
        records = self._collect_existing_job_records(job_dir)
        rows = []

        xtb_best = min(records["xTB"], key=lambda item: item["energy"], default=None)
        if xtb_best:
            self._copy_unique_result(xtb_best.get("path"), os.path.join(comp_dir, "1_BEST_xTB.xyz"))
            rows.append(["xTB", xtb_best["source"], f"{xtb_best['energy']:.6f}", "N/A", "N/A"])

        crest_best = min(records["CREST"], key=lambda item: item["energy"], default=None)
        if crest_best:
            self._copy_unique_result(crest_best.get("path"), os.path.join(comp_dir, "2_BEST_CREST.xyz"))
            rows.append(["CREST", crest_best["source"], f"{crest_best['energy']:.6f}", "N/A", "N/A"])

        orca_candidates = records["ORCA"]
        true_minima = [item for item in orca_candidates if item.get("imag", 0) == 0]
        rank_pool = true_minima or orca_candidates
        orca_best = min(rank_pool, key=lambda item: item["gibbs"] if item.get("gibbs", 0.0) else item["energy"], default=None)
        if orca_best:
            self._copy_unique_result(orca_best.get("path"), os.path.join(comp_dir, "3_BEST_ORCA.xyz"))
            rows.append(["ORCA", orca_best["source"], f"{orca_best['energy']:.6f}", f"{orca_best.get('gibbs', 0.0):.6f}", "N/A"])

        csv_path = os.path.join(comp_dir, "Energy_Comparison.csv")
        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Level_of_Theory", "Source_ID", "Total_Energy_Eh", "Gibbs_Free_Energy_Eh", "Binding_Energy_kcal_mol"])
            writer.writerows(rows)

        report_path = os.path.join(comp_dir, "Existing_Folder_Analysis_Report.md")
        with open(report_path, "w", encoding="utf-8") as handle:
            handle.write(f"# Existing Folder Analysis\n\n")
            handle.write(f"- **Analyzed folder:** `{job_dir}`\n")
            handle.write(f"- **Analysis time:** {_now()}\n")
            handle.write(f"- **xTB records found:** {len(records['xTB'])}\n")
            handle.write(f"- **CREST records found:** {len(records['CREST'])}\n")
            handle.write(f"- **ORCA records found:** {len(records['ORCA'])}\n")
            handle.write(f"- **ORCA true minima (0 imaginary frequencies):** {len(true_minima)}\n\n")
            handle.write("## Best Extracted Models\n\n")
            handle.write("| Method | Source | Energy (Eh) | Gibbs (Eh) | Notes |\n")
            handle.write("|---|---|---:|---:|---|\n")
            if xtb_best:
                handle.write(f"| xTB | {xtb_best['source']} | {xtb_best['energy']:.6f} | N/A | Best available xTB record |\n")
            if crest_best:
                handle.write(f"| CREST | {crest_best['source']} | {crest_best['energy']:.6f} | N/A | Best available CREST record |\n")
            if orca_best:
                handle.write(f"| ORCA | {orca_best['source']} | {orca_best['energy']:.6f} | {orca_best.get('gibbs', 0.0):.6f} | Ranked by Gibbs when available |\n")
            if not rows:
                handle.write("| N/A | N/A | N/A | N/A | No parseable energy records were found |\n")

        with open(os.path.join(logs_dir, "Existing_Folder_Analysis.json"), "w", encoding="utf-8") as handle:
            json.dump({"folder": job_dir, "time": _now(), "records": records}, handle, indent=2)
        file_analysis = self._generate_file_level_analysis(job_dir)
        return {"job_dir": job_dir, "rows": len(rows), "report": report_path, "csv": csv_path, "file_analysis": file_analysis}

    def _count_xyz_atoms(self, xyz_path):
        try:
            with open(xyz_path, "r", encoding="utf-8", errors="replace") as handle:
                return int(handle.readline().strip())
        except Exception:
            return None

    def _unique_analysis_path(self, folder, stem, suffix, used_names):
        clean_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem).strip("_") or "analysis"
        candidate = f"{clean_stem}{suffix}"
        idx = 1
        while candidate.lower() in used_names or os.path.exists(os.path.join(folder, candidate)):
            candidate = f"{clean_stem}_{idx}{suffix}"
            idx += 1
        used_names.add(candidate.lower())
        return os.path.join(folder, candidate)

    def _generate_structure_image(self, xyz_path, image_path):
        if not MATPLOTLIB_AVAILABLE or not xyz_path or not os.path.exists(xyz_path):
            return None
        try:
            image_dpi = int(self._float_var("image_dpi", 300))
            image_dpi = max(72, min(image_dpi, 1200))
            fig = Figure(figsize=(5.6, 5.2), dpi=min(image_dpi, 220))
            ax = fig.add_subplot(111, projection="3d")
            self._render_xyz_model(ax, xyz_path)
            ax.set_title(os.path.basename(xyz_path), fontsize=8, color=self._vars_graph["axis_color"].get())
            fig.savefig(image_path, dpi=image_dpi, bbox_inches="tight")
            return image_path
        except Exception:
            return None

    def _analysis_value(self, value):
        if value is None or value == "":
            return "N/A"
        if isinstance(value, float):
            return f"{value:.8f}"
        return str(value)

    def _relative_report_path(self, target, report_dir):
        try:
            return os.path.relpath(target, report_dir).replace("\\", "/")
        except Exception:
            return target.replace("\\", "/")

    def _analyze_xyz_file_record(self, xyz_path, images_dir, image_names):
        energy = self._xyz_comment_energy(xyz_path)
        image_path = self._unique_analysis_path(images_dir, Path(xyz_path).stem, ".png", image_names)
        generated_image = self._generate_structure_image(xyz_path, image_path)
        return {
            "source_file": xyz_path,
            "file_type": "XYZ",
            "status": "parsed",
            "atoms": self._count_xyz_atoms(xyz_path),
            "xyz_path": xyz_path,
            "image_path": generated_image,
            "final_single_point_energy_eh": energy,
            "zero_point_energy_eh": None,
            "total_thermal_energy_eh": None,
            "total_enthalpy_eh": None,
            "final_entropy_term_eh": None,
            "final_gibbs_free_energy_eh": None,
            "temperature_k": None,
            "pressure_atm": None,
            "imaginary_frequencies": None,
            "normal_termination": None,
            "notes": "Energy read from XYZ comment line." if energy is not None else "Structure image generated; no thermodynamic data present in XYZ.",
        }

    def _analyze_orca_out_record(self, out_path, images_dir, image_names):
        thermo = self._parse_orca_thermo(out_path)
        parsed = self._parse_orca_out(out_path)
        xyz_path = parsed.get("path")
        image_path = None
        if xyz_path and os.path.exists(xyz_path):
            image_path = self._unique_analysis_path(images_dir, Path(out_path).stem, ".png", image_names)
            image_path = self._generate_structure_image(xyz_path, image_path)
        status = "parsed" if thermo.get("final_single_point_energy_eh") is not None or xyz_path else "partial"
        notes = []
        if thermo.get("final_gibbs_free_energy_eh") is not None:
            notes.append("Thermodynamic Gibbs energy found.")
        if thermo.get("total_enthalpy_eh") is not None:
            notes.append("Thermodynamic enthalpy found.")
        if image_path:
            notes.append("Molecular image generated from final/output coordinates.")
        elif not xyz_path:
            notes.append("No final Cartesian coordinate block or matching XYZ was found.")
        return {
            "source_file": out_path,
            "file_type": "ORCA OUT",
            "status": status,
            "atoms": self._count_xyz_atoms(xyz_path) if xyz_path else None,
            "xyz_path": xyz_path,
            "image_path": image_path,
            "final_single_point_energy_eh": thermo.get("final_single_point_energy_eh") if thermo.get("final_single_point_energy_eh") is not None else parsed.get("energy"),
            "zero_point_energy_eh": thermo.get("zero_point_energy_eh"),
            "total_thermal_energy_eh": thermo.get("total_thermal_energy_eh"),
            "total_enthalpy_eh": thermo.get("total_enthalpy_eh"),
            "final_entropy_term_eh": thermo.get("final_entropy_term_eh"),
            "final_gibbs_free_energy_eh": thermo.get("final_gibbs_free_energy_eh") if thermo.get("final_gibbs_free_energy_eh") is not None else parsed.get("gibbs"),
            "temperature_k": thermo.get("temperature_k"),
            "pressure_atm": thermo.get("pressure_atm"),
            "imaginary_frequencies": thermo.get("imaginary_frequencies"),
            "normal_termination": thermo.get("normal_termination"),
            "notes": " ".join(notes) if notes else "ORCA output parsed.",
        }

    def _generate_file_level_analysis(self, analysis_dir):
        comp_dir = os.path.join(analysis_dir, "05_Top_Models_Comparison")
        logs_dir = os.path.join(analysis_dir, "logs")
        images_dir = os.path.join(analysis_dir, "06_File_Analysis_Images")
        opts = self._get_report_options() if hasattr(self, "_get_report_options") else {}
        include_thermo = opts.get("thermodynamics", True)
        include_images = opts.get("images", True)
        os.makedirs(comp_dir, exist_ok=True)
        os.makedirs(logs_dir, exist_ok=True)
        os.makedirs(images_dir, exist_ok=True)

        source_files = []
        for path in Path(analysis_dir).rglob("*"):
            if not path.is_file():
                continue
            lower_path = str(path).lower()
            if "06_file_analysis_images" in lower_path or "__pycache__" in lower_path:
                continue
            if path.name.lower().endswith("_final_from_out.xyz"):
                continue
            if path.suffix.lower() in (".out", ".xyz"):
                source_files.append(str(path))
        source_files = sorted(set(source_files))

        image_names = set()
        rows = []
        for file_path in source_files:
            if file_path.lower().endswith(".out"):
                rows.append(self._analyze_orca_out_record(file_path, images_dir, image_names))
            elif file_path.lower().endswith(".xyz"):
                rows.append(self._analyze_xyz_file_record(file_path, images_dir, image_names))

        csv_path = os.path.join(logs_dir, "File_Analysis_Summary.csv")
        fields = [
            "source_file",
            "file_type",
            "status",
            "atoms",
            "xyz_path",
            "notes",
        ]
        thermo_fields = [
            "final_single_point_energy_eh",
            "zero_point_energy_eh",
            "total_thermal_energy_eh",
            "total_enthalpy_eh",
            "final_entropy_term_eh",
            "final_gibbs_free_energy_eh",
            "temperature_k",
            "pressure_atm",
            "imaginary_frequencies",
            "normal_termination",
        ]
        if include_thermo:
            fields[4:4] = thermo_fields
        if include_images:
            fields.insert(-1, "image_path")
        else:
            for row in rows:
                row["image_path"] = ""
        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key, "") for key in fields})

        report_path = os.path.join(comp_dir, "File_Analysis_Report.md")
        with open(report_path, "w", encoding="utf-8") as handle:
            handle.write("# File-Level Structure and Thermodynamic Analysis\n\n")
            handle.write(f"- **Analyzed folder:** `{analysis_dir}`\n")
            handle.write(f"- **Analysis time:** {_now()}\n")
            handle.write(f"- **Files analyzed:** {len(rows)}\n")
            if include_images:
                handle.write(f"- **Images generated:** {sum(1 for row in rows if row.get('image_path'))}\n")
            if include_thermo:
                handle.write(f"- **Thermodynamic ORCA records:** {sum(1 for row in rows if row.get('final_gibbs_free_energy_eh') not in (None, 0.0) or row.get('total_enthalpy_eh') is not None)}\n")
            handle.write("\n")
            handle.write("## Summary Table\n\n")
            if include_thermo:
                handle.write("| File | Type | Atoms | E(eh) | H(eh) | G(eh) | ZPE(eh) | Imag | Normal | Notes |\n")
                handle.write("|---|---|---:|---:|---:|---:|---:|---:|---|---|\n")
            else:
                handle.write("| File | Type | Atoms | Notes |\n")
                handle.write("|---|---|---:|---|\n")
            for row in rows:
                if include_thermo:
                    handle.write(
                        f"| {os.path.basename(row['source_file'])} | {row['file_type']} | {self._analysis_value(row.get('atoms'))} | "
                        f"{self._analysis_value(row.get('final_single_point_energy_eh'))} | "
                        f"{self._analysis_value(row.get('total_enthalpy_eh'))} | "
                        f"{self._analysis_value(row.get('final_gibbs_free_energy_eh'))} | "
                        f"{self._analysis_value(row.get('zero_point_energy_eh'))} | "
                        f"{self._analysis_value(row.get('imaginary_frequencies'))} | "
                        f"{self._analysis_value(row.get('normal_termination'))} | {row.get('notes','')} |\n"
                    )
                else:
                    handle.write(f"| {os.path.basename(row['source_file'])} | {row['file_type']} | {self._analysis_value(row.get('atoms'))} | {row.get('notes','')} |\n")
            if rows and include_images:
                handle.write("\n## Generated Molecular Images\n\n")
                for row in rows:
                    if row.get("image_path"):
                        rel_image = self._relative_report_path(row["image_path"], comp_dir)
                        handle.write(f"### {os.path.basename(row['source_file'])}\n\n")
                        handle.write(f"![{os.path.basename(row['source_file'])}]({rel_image})\n\n")
            else:
                handle.write("\nNo `.out` or `.xyz` files were found for file-level analysis.\n")

        return {"csv": csv_path, "report": report_path, "images_dir": images_dir, "file_count": len(rows)}

    def _copy_loose_file(self, src, dest_dir, used_names):
        os.makedirs(dest_dir, exist_ok=True)
        name = os.path.basename(src)
        stem, suffix = os.path.splitext(name)
        candidate = name
        idx = 1
        while candidate.lower() in used_names or os.path.exists(os.path.join(dest_dir, candidate)):
            candidate = f"{stem}_{idx}{suffix}"
            idx += 1
        used_names.add(candidate.lower())
        dest = os.path.join(dest_dir, candidate)
        shutil.copy2(src, dest)
        return dest

    def _prepare_selected_files_analysis_dir(self, files, analysis_name="IAK_selected_files_analysis"):
        parents = [os.path.dirname(os.path.abspath(path)) for path in files]
        try:
            base_dir = os.path.commonpath(parents)
            if not os.path.isdir(base_dir):
                base_dir = parents[0]
        except Exception:
            base_dir = parents[0]
        analysis_dir = os.path.join(base_dir, analysis_name)
        inputs_dir = os.path.join(analysis_dir, "01_Inputs_and_Clusters")
        orca_dir = os.path.join(analysis_dir, "04_ORCA_Refinement")
        os.makedirs(inputs_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "02_xTB_Results"), exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "03_CREST_Results"), exist_ok=True)
        os.makedirs(orca_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "05_Top_Models_Comparison"), exist_ok=True)
        used = set()
        copied_xyz, copied_out = 0, 0
        for src in files:
            lower = src.lower()
            if lower.endswith(".xyz"):
                self._copy_loose_file(src, inputs_dir, used)
                copied_xyz += 1
            elif lower.endswith(".out"):
                self._copy_loose_file(src, orca_dir, used)
                copied_out += 1
        return analysis_dir, copied_xyz, copied_out

    def _create_loose_folder_analysis(self, folder):
        analysis_dir = os.path.join(folder, "IAK_existing_analysis")
        inputs_dir = os.path.join(analysis_dir, "01_Inputs_and_Clusters")
        orca_dir = os.path.join(analysis_dir, "04_ORCA_Refinement")
        os.makedirs(inputs_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "02_xTB_Results"), exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "03_CREST_Results"), exist_ok=True)
        os.makedirs(orca_dir, exist_ok=True)
        os.makedirs(os.path.join(analysis_dir, "05_Top_Models_Comparison"), exist_ok=True)
        used = set()
        copied_xyz, copied_out = 0, 0
        for root, dirs, files in os.walk(folder):
            if os.path.abspath(root).startswith(os.path.abspath(analysis_dir)):
                continue
            for name in files:
                src = os.path.join(root, name)
                lower = name.lower()
                if lower.endswith(".xyz") and copied_xyz < 300:
                    self._copy_loose_file(src, inputs_dir, used)
                    copied_xyz += 1
                elif lower.endswith(".out") and copied_out < 300:
                    self._copy_loose_file(src, orca_dir, used)
                    copied_out += 1
                elif lower == "energy_comparison.csv":
                    self._copy_loose_file(src, os.path.join(analysis_dir, "05_Top_Models_Comparison"), used)
        return analysis_dir

    def _analyze_existing_folder(self):
        folder = filedialog.askdirectory(title="Select existing IAK result folder or folder containing XYZ/ORCA files")
        if not folder:
            return
        folder = os.path.abspath(folder)
        self._reset_progress_ui()
        self._apply_progress_payload({"stage": "Validation", "percent": 5.0, "status": "running", "message": "Scanning existing folder.", "elapsed_seconds": 0.0})
        self._append_text(f"\n[Existing Analysis] Scanning folder: {folder}\n")
        try:
            job_dirs = self._find_iak_job_dirs(folder)
            if not job_dirs:
                self._append_text("[Existing Analysis] No IAK folder structure found. Creating loose-file analysis folder...\n")
                job_dirs = [self._create_loose_folder_analysis(folder)]

            results = []
            total = max(len(job_dirs), 1)
            started = time.time()
            for idx, job_dir in enumerate(job_dirs, start=1):
                percent = 10.0 + 80.0 * ((idx - 1) / total)
                self._apply_progress_payload({
                    "stage": "Reports",
                    "percent": percent,
                    "status": "running",
                    "message": f"Analyzing existing job {idx}/{total}.",
                    "elapsed_seconds": time.time() - started,
                })
                results.append(self._write_existing_analysis_outputs(job_dir))

            first_job = results[0]["job_dir"]
            self._vars["out"].set(first_job)
            if MATPLOTLIB_AVAILABLE:
                self._vars_graph["dir1"].set(folder if len(results) > 1 else first_job)
                self._vars_graph["name1"].set(os.path.basename(folder.rstrip("\\/")) or "Existing Data")
                if hasattr(self, "thermo_tree"):
                    self._refresh_thermo_table()
            self._refresh_results()
            self.nb.select(self.tab_res)
            self._apply_progress_payload({
                "stage": "Complete",
                "percent": 100.0,
                "status": "completed",
                "message": f"Analyzed {len(results)} existing folder(s).",
                "elapsed_seconds": time.time() - started,
            })
            self._append_text(f"[Existing Analysis] Complete. Loaded results from: {first_job}\n")
            messagebox.showinfo(
                "Existing Folder Analysis Complete",
                f"Analyzed {len(results)} folder(s).\n\nLoaded first result folder:\n{first_job}\n\nReports and Energy_Comparison.csv files were generated where possible.",
            )
        except Exception as exc:
            self._append_text(f"[Existing Analysis Error] {exc}\n")
            self._apply_progress_payload({"stage": "Failed", "percent": 100.0, "status": "failed", "message": str(exc), "elapsed_seconds": 0.0})
            messagebox.showerror("Existing Folder Analysis Error", str(exc))

    def _analyze_existing_files(self):
        files = filedialog.askopenfilenames(
            title="Select existing ORCA .out and/or XYZ files",
            filetypes=[
                ("ORCA output and XYZ", "*.out *.xyz"),
                ("ORCA output", "*.out"),
                ("XYZ structures", "*.xyz"),
                ("All files", "*.*"),
            ],
        )
        files = [os.path.abspath(path) for path in files if path.lower().endswith((".out", ".xyz"))]
        if not files:
            return
        self._reset_progress_ui()
        started = time.time()
        self._apply_progress_payload({
            "stage": "Validation",
            "percent": 5.0,
            "status": "running",
            "message": f"Preparing {len(files)} selected file(s).",
            "elapsed_seconds": 0.0,
        })
        try:
            analysis_dir, copied_xyz, copied_out = self._prepare_selected_files_analysis_dir(files)
            self._append_text(
                f"\n[Existing File Analysis] Selected {len(files)} file(s): "
                f"{copied_xyz} XYZ and {copied_out} ORCA OUT copied into {analysis_dir}\n"
            )
            self._apply_progress_payload({
                "stage": "Reports",
                "percent": 55.0,
                "status": "running",
                "message": "Parsing selected files and writing analysis outputs.",
                "elapsed_seconds": time.time() - started,
            })
            result = self._write_existing_analysis_outputs(analysis_dir)
            self._vars["out"].set(analysis_dir)
            if MATPLOTLIB_AVAILABLE:
                self._vars_graph["dir1"].set(analysis_dir)
                self._vars_graph["name1"].set("Selected Files")
                if hasattr(self, "thermo_tree"):
                    self._refresh_thermo_table()
            self._refresh_results()
            self.nb.select(self.tab_res)
            self._apply_progress_payload({
                "stage": "Complete",
                "percent": 100.0,
                "status": "completed",
                "message": "Selected file analysis complete.",
                "elapsed_seconds": time.time() - started,
            })
            messagebox.showinfo(
                "Existing File Analysis Complete",
                "Selected files were analyzed.\n\n"
                f"Analysis folder:\n{analysis_dir}\n\n"
                f"XYZ files: {copied_xyz}\nORCA .out files: {copied_out}\n"
                f"Energy rows parsed: {result['rows']}",
            )
        except Exception as exc:
            self._append_text(f"[Existing File Analysis Error] {exc}\n")
            self._apply_progress_payload({
                "stage": "Failed",
                "percent": 100.0,
                "status": "failed",
                "message": str(exc),
                "elapsed_seconds": time.time() - started,
            })
            messagebox.showerror("Existing File Analysis Error", str(exc))

    def _resume_existing_job(self):
        folder = filedialog.askdirectory(title="Select stopped/failed IAK job folder or parent folder")
        if not folder:
            return
        folder = os.path.abspath(folder)
        job_dirs = self._find_iak_job_dirs(folder)
        if not job_dirs:
            return messagebox.showerror("Resume Job", "No IAK job folder was found in the selected location.")
        job_dir = job_dirs[0]
        inputs_dir = os.path.join(job_dir, "01_Inputs_and_Clusters")
        anchor = os.path.join(inputs_dir, "raw_input_anchor.xyz")
        guest = os.path.join(inputs_dir, "raw_input_guest.xyz")
        if not os.path.exists(anchor):
            candidates = list(Path(inputs_dir).glob("*.xyz")) if os.path.isdir(inputs_dir) else []
            anchor = str(candidates[0]) if candidates else ""
        if anchor and os.path.exists(anchor):
            self._vars["a"].set(anchor)
        if os.path.exists(guest):
            self._vars["b"].set(guest)
        else:
            self._vars["b"].set("")
        folder_name = os.path.basename(job_dir.rstrip("\\/"))
        match = re.search(r"(\d+)[_:](\d+)$", folder_name)
        if match:
            self._vars["ratio"].set(f"{match.group(1)}:{match.group(2)}")
        self._vars["out"].set(job_dir)
        self._refresh_results()
        self.nb.select(self.tab_main)
        self._append_text(
            f"\n[Resume] Loaded existing job folder:\n{job_dir}\n"
            "Press START BATCH PIPELINE to continue. Successful stages in state.json will be skipped automatically.\n"
        )
        messagebox.showinfo(
            "Resume Ready",
            "Existing job loaded.\n\nPress START BATCH PIPELINE to continue from the saved state.\nAlready successful xTB/CREST/ORCA jobs will be skipped.",
        )

    def _update_guest_count_label(self):
        n = len(self._guest_list)
        color = _C["green"] if n > 0 else _C["muted"]
        self._guest_count_lbl.config(
            text=f"{n} guest(s) queued" if n != 1 else "1 guest queued",
            fg=color)

    def _start(self):
        v = {}
        for k, var in self._vars.items():
            val = var.get().strip(" \"'")
            if k in ["a", "b"] and val:
                val = os.path.abspath(val)
            v[k] = val
        inject_embedded_engines()
        self._update_installation_labels()
        if not os.path.isfile(v["a"]):
            self._append_text(f"\n[Error] Anchor XYZ file not found or invalid path: {v['a']}\n")
            return messagebox.showerror("Error", f"Anchor XYZ file not found:\n{v['a']}")

        # Resolve effective guest list: multi-guest panel takes priority over legacy field
        effective_guests = [p for p in self._guest_list if os.path.isfile(p)]
        if not effective_guests and v["b"] and os.path.isfile(v["b"]):
            effective_guests = [v["b"]]

        if not effective_guests:
            if "0" not in v["ratio"]:
                ans = messagebox.askyesno("Single Molecule Mode",
                    "No Guest (B) file found in queue or legacy field.\n"
                    "Run as single isolated molecule (Ratio 1:0)?")
                if ans:
                    v["ratio"] = "1:0"
                else:
                    return
        v["_guests"] = effective_guests  # pass resolved list to worker
        self._reset_progress_ui()
        self.go_btn.config(state="disabled", text="RUNNING BATCH QUEUE...")
        self.nb.select(0)
        g_count = len(effective_guests)
        self._append_text(
            f"\n[System] Initialization complete. "
            f"{g_count} guest molecule(s) queued. "
            f"Booting Batch Pipeline Thread...\n")
        self.start_time = time.time()
        self.is_running = True
        threading.Thread(target=self._worker, args=(v,), daemon=True).start()

    def _worker(self, v):
        try:
            mode_name = v.get("mode", "balanced").lower()
            base_mode = RunMode.BALANCED if mode_name == "custom" else RunMode[mode_name.upper()]
            config = Config.from_mode(base_mode)
            config.preopt_inputs = self.run_preopt.get()
            try:
                config.cores = int(v.get("cores", 4))
                config.maxcore = int(v.get("maxcore", 2000))
                config.charge = int(v.get("charge", 0))
                config.multiplicity = int(v.get("mult", 1))
                config.n_generate = int(v.get("n_generate", config.n_generate))
                config.n_keep_scored = int(v.get("n_keep_scored", config.n_keep_scored))
                config.n_keep_clustered = int(v.get("n_keep_clustered", config.n_keep_clustered))
                config.n_run_xtb = int(v.get("n_run_xtb", config.n_run_xtb))
                config.n_run_crest = int(v.get("n_run_crest", config.n_run_crest))
                config.random_seed = int(v.get("random_seed", config.random_seed))
                config.max_placement_attempts = int(v.get("max_placement_attempts", config.max_placement_attempts))
                config.rmsd_cutoff = float(v.get("rmsd_cutoff", config.rmsd_cutoff))
                config.xtb_ewin_kcal = float(v.get("xtb_ewin_kcal", config.xtb_ewin_kcal))
                config.crest_ewin_kcal = float(v.get("crest_ewin_kcal", config.crest_ewin_kcal))
            except ValueError:
                raise RuntimeError("Host-controlled numerical inputs must be valid numbers.")
            if config.n_generate < 1 or config.n_keep_scored < 1 or config.n_keep_clustered < 1:
                raise RuntimeError("Generate/keep counts must be at least 1.")
            if config.n_run_xtb < 0 or config.n_run_crest < 0:
                raise RuntimeError("xTB/CREST run counts cannot be negative.")
            if config.max_placement_attempts < 1:
                raise RuntimeError("Placement attempts must be at least 1.")
            config.xtb_method = v.get("xtb_method", config.xtb_method).strip() or "--gfn2"
            config.crest_method = v.get("crest_method", config.crest_method).strip() or "--gfn2"
            config.orca_method = v.get("orca_method", "B97-3c Opt Freq")
            config.report_options = self._get_report_options()
            reaction_type = normalize_reaction_type(v.get("reaction_type", "Non-covalent"))
            try:
                if v.get("e_a"):
                    config.energy_a = float(v.get("e_a"))
                if v.get("e_b"):
                    config.energy_b = float(v.get("e_b"))
            except ValueError:
                raise RuntimeError("Monomer Energies must be valid decimals. Leave empty if not calculating Binding Energy.")
            ratio_pairs = []
            for r in v["ratio"].split(","):
                r = r.strip()
                if not r:
                    continue
                if ":" in r:
                    parts = tuple(int(p) for p in r.split(":"))
                    ratio_pairs.append(parts)
                else:
                    ratio_pairs.append((1, int(r)))
            if not ratio_pairs:
                raise RuntimeError("Please provide at least one valid ratio (e.g., 1:0, 1:1).")

            # Resolve guest files: multi-guest list (may be empty → single-molecule mode)
            guest_paths = v.get("_guests") or ([] if not v.get("b") else [v["b"]])
            if not guest_paths:
                guest_paths = [None]  # sentinel → single-molecule

            base_out_dir = v["out"].rstrip("/\\ ")
            # Simple, unambiguous prefix: append "_" to whatever the user typed.
            # Do NOT regex-strip trailing digits — that mangles paths like "CO_H2" or "_1_1_2".
            prefix = base_out_dir + "_"

            total_jobs = len(ratio_pairs)
            job_idx = 0
            for r_tuple in ratio_pairs:
                job_idx += 1
                n_A = r_tuple[0]
                n_guests_list = list(r_tuple[1:]) if len(r_tuple) > 1 else [0]

                # Build ratio_label from the ORIGINAL tuple BEFORE any padding so that
                # "1:1", "1:1:0", "1:1:0:0" each produce a UNIQUE output folder even
                # when n_guests_list gets extended to the same length by the next block.
                ratio_label = "_".join(map(str, r_tuple))

                # Align n_guests_list length with queued guest files (placement counts only)
                if guest_paths != [None]:
                    if len(n_guests_list) > len(guest_paths):
                        self.root.after(0, lambda r=r_tuple, ng=len(n_guests_list), gp=len(guest_paths): self._append_text(
                            f"\n[WARNING] Ratio {r}: {ng} guest component(s) specified but only {gp} guest file(s) queued. Extra ignored.\n"))
                        n_guests_list = n_guests_list[:len(guest_paths)]
                    elif len(n_guests_list) < len(guest_paths):
                        n_guests_list.extend([0] * (len(guest_paths) - len(n_guests_list)))

                # If ratio signifies single molecule (either no guest or 0 copies of all guests)
                is_single = (sum(n_guests_list) == 0)

                try:
                    # Validation inside the per-ratio try so one bad ratio doesn't abort the rest
                    if n_A < 0 or any(x < 0 for x in n_guests_list):
                        raise RuntimeError(f"Negative stoichiometry is not allowed: {r_tuple}")
                    if n_A == 0 and is_single:
                        raise RuntimeError(f"Invalid ratio {r_tuple}: at least one species count must be > 0.")

                    current_out_name = f"{prefix}{ratio_label}"
                    current_out = os.path.abspath(current_out_name)
                    self.root.after(0, lambda o=current_out_name: self._vars["out"].set(o))
                    self.root.after(0, lambda r=r_tuple, o=current_out_name, ji=job_idx, jt=total_jobs:
                        self._append_text(
                            f"\n{'=' * 70}\n"
                            f"[BATCH QUEUE] Job {ji}/{jt} | Ratio {r} | Folder: {o}\n"
                            f"{'=' * 70}\n"))
                    
                    eff_a_path = v["a"] if n_A > 0 else None
                    eff_b_paths = guest_paths if not is_single else []

                    # Validate and auto-correct spin multiplicity based on total electrons.
                    anchor_mol = Molecule.from_xyz(eff_a_path) if eff_a_path and os.path.exists(eff_a_path) else Molecule([])
                    guest_mols = [Molecule.from_xyz(p) for p in eff_b_paths if p and os.path.exists(p)]
                    job_config = dataclasses.replace(config)
                    cm_check = validate_charge_multiplicity(
                        anchor_mol,
                        guest_mols,
                        n_A,
                        n_guests_list,
                        job_config.charge,
                        job_config.multiplicity,
                    )
                    if not cm_check["valid"]:
                        total_electrons = cm_check.get("total_electrons")
                        suggested = int(cm_check.get("suggested_multiplicity", job_config.multiplicity))
                        if total_electrons is not None and total_electrons > 0 and suggested >= 1:
                            old_mult = job_config.multiplicity
                            job_config.multiplicity = suggested
                            self.root.after(
                                0,
                                lambda r=r_tuple, m=cm_check["message"], om=old_mult, sm=suggested: self._append_text(
                                    f"\n[SPIN AUTO-CORRECTION] Ratio {r}: {m} "
                                    f"Using multiplicity {om} -> {sm}.\n"
                                ),
                            )
                        else:
                            raise RuntimeError(f"Ratio {r_tuple}: {cm_check['message']}")
                    else:
                        self.root.after(
                            0,
                            lambda r=r_tuple, te=cm_check.get("total_electrons"): self._append_text(
                                f"[Validation] Ratio {r}: total electrons = {te}; charge/multiplicity validated.\n"
                            ),
                        )
                    
                    pipe = Pipeline(
                        eff_a_path,
                        eff_b_paths,
                        n_guests_list,
                        job_config,
                        current_out,
                        ratio_label=ratio_label,
                        progress_cb=self._progress_cb,
                        reaction_type=reaction_type,
                        n_anchor=n_A,
                    )
                    pipe.run(run_xtb=self.run_xtb.get(), run_crest=self.run_crest.get(),
                             run_orca=self.run_orca.get(), log_cb=self._append_text,
                             status_cb=self._status_cb)
                    self.root.after(0, self._refresh_results)
                except Exception as iter_e:
                    self.root.after(0, lambda e=iter_e, r=r_tuple:
                        self._append_text(
                            f"\n[CRITICAL BATCH ERROR] Ratio {r} aborted: "
                            f"{str(e)}. Proceeding to next job...\n"))
            self.root.after(0, lambda jt=total_jobs: messagebox.showinfo(
                "Batch Complete",
                f"All {jt} job(s) completed!\n\n"
                f"Guests processed: {len(guest_paths) if guest_paths != [None] else 0}\n"
                f"Ratios processed: {len(ratio_pairs)}\n\n"
                "Check the respective folders for Top Models, Energy CSVs, and Job Summary Reports."))
        except Exception as e:
            self.root.after(0, lambda e=e: self._append_text(f"\n[CRITICAL ERROR] Pipeline aborted: {str(e)}\n"))
            self.root.after(0, lambda e=e: messagebox.showerror("Error", str(e)))
        finally:
            self.is_running = False
            self.root.after(0, lambda: self.go_btn.config(state="normal", text="START BATCH PIPELINE"))

    def _pes_log(self, text):
        self.root.after(0, lambda: self.pes_term.config(state="normal"))
        self.root.after(0, lambda: self.pes_term.insert("end", text + "\n"))
        self.root.after(0, lambda: self.pes_term.see("end"))
        self.root.after(0, lambda: self.pes_term.config(state="disabled"))

    def _start_pes(self):
        v = {k: var.get() for k, var in self._vars_pes.items()}
        if not v["reactant"] or not os.path.exists(v["reactant"]):
            return messagebox.showerror("Error", "Valid Reactant XYZ is required for PES Scan.")
        self.btn_run_pes.config(state="disabled", text="RUNNING PES/TS...")
        self._pes_log("="*60)
        self._pes_log(" INITIALIZING PES & TS SEARCH PIPELINE ")
        self._pes_log("="*60)
        threading.Thread(target=self._worker_pes, args=(v,), daemon=True).start()

    def _worker_pes(self, v):
        try:
            # 1. Parse Input Geometry
            react_path = os.path.abspath(v["reactant"])
            react_name = os.path.splitext(os.path.basename(react_path))[0]
            work_dir = os.path.abspath(f"PES_{react_name}_{int(time.time())}")
            os.makedirs(work_dir, exist_ok=True)
            shutil.copy2(react_path, os.path.join(work_dir, "reactant.xyz"))
            reaction_type = normalize_reaction_type(self._vars.get("reaction_type").get() if "reaction_type" in self._vars else "Non-covalent")

            charge = _safe_int(self._vars.get("charge").get() if "charge" in self._vars else 0)
            multiplicity = _safe_int(self._vars.get("mult").get() if "mult" in self._vars else 1)
            if charge is None:
                raise RuntimeError("System charge must be an integer for PES/TS calculations.")
            if multiplicity is None or multiplicity < 1:
                raise RuntimeError("Multiplicity must be a positive integer for PES/TS calculations.")

            reactant_mol = Molecule.from_xyz(react_path)
            pes_cm_check = validate_charge_multiplicity(reactant_mol, [], 1, [], charge, multiplicity)
            if not pes_cm_check["valid"]:
                total_electrons = pes_cm_check.get("total_electrons")
                suggested = int(pes_cm_check.get("suggested_multiplicity", multiplicity))
                if total_electrons is not None and total_electrons > 0 and suggested >= 1:
                    self._pes_log(
                        f"[SPIN AUTO-CORRECTION] {pes_cm_check['message']} "
                        f"Using multiplicity {multiplicity} -> {suggested}."
                    )
                    multiplicity = suggested
                else:
                    raise RuntimeError(pes_cm_check["message"])
            else:
                self._pes_log(f"[Validation] Total electrons = {pes_cm_check.get('total_electrons')}; charge/multiplicity validated.")
            
            scan_mode = v.get("scan_mode", "coord")
            engine = v["engine"]
            
            if scan_mode == "path":
                if not v["product"] or not os.path.exists(v["product"]):
                    raise RuntimeError("Product XYZ is required for Reactant -> Product Path Interpolation.")
                prod_path = os.path.abspath(v["product"])
                shutil.copy2(prod_path, os.path.join(work_dir, "product.xyz"))
                product_mol = Molecule.from_xyz(prod_path)
                balanced, balance_message = validate_reactant_product_atom_balance(reactant_mol, product_mol, reaction_type)
                if not balanced:
                    raise RuntimeError(balance_message)
                self._pes_log(f"[Validation] {balance_message}")
                
                self._pes_log(f"Working Directory: {work_dir}")
                self._pes_log(f"Engine: {engine.upper()}")
                self._pes_log(f"Mode: Reactant -> Product Path Interpolation ({reaction_type})")
                
                if engine == "xtb":
                    self._run_xtb_path(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_neb(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_neb(work_dir, "reactant.xyz", "product.xyz", charge, multiplicity)
                else:
                    raise RuntimeError(f"Engine {engine} not supported for Path Interpolation.")
            else:
                try:
                    c1_a1, c1_a2 = int(v["c1_a1"]), int(v["c1_a2"])
                    c1_s, c1_e, c1_steps = float(v["c1_start"]), float(v["c1_end"]), int(v["c1_steps"])
                except ValueError:
                    raise RuntimeError("Invalid values for Coordinate 1. Must be numerical.")
                
                use_c2 = int(v["use_c2"]) == 1
                if use_c2:
                    try:
                        c2_a1, c2_a2 = int(v["c2_a1"]), int(v["c2_a2"])
                        c2_s, c2_e, c2_steps = float(v["c2_start"]), float(v["c2_end"]), int(v["c2_steps"])
                    except ValueError:
                        raise RuntimeError("Invalid values for Coordinate 2. Must be numerical.")
                else:
                    c2_a1=c2_a2=c2_s=c2_e=c2_steps=None
                
                self._pes_log(f"Working Directory: {work_dir}")
                self._pes_log(f"Engine: {engine.upper()}")
                self._pes_log("Mode: Coordinate Grid Scan")
                
                if engine == "xtb":
                    self._run_xtb_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_pes(work_dir, "reactant.xyz", c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity)
                else:
                    raise RuntimeError(f"Engine {engine} not supported for PES.")
                
            # 4. Extract TS Guess and Run OptTS if checked
            run_ts = int(v["run_ts"]) == 1
            if run_ts:
                self._pes_log("\n--- Proceeding to Transition State Refinement ---")
                ts_guess_path = os.path.join(work_dir, "ts_guess.xyz")
                if not os.path.exists(ts_guess_path):
                    raise RuntimeError("Saddle point (ts_guess.xyz) not found from PES scan. Cannot run TS Opt.")
                if engine == "xtb":
                    self._run_xtb_ts(work_dir, ts_guess_path, charge, multiplicity)
                elif engine == "orca":
                    self._run_orca_ts(work_dir, ts_guess_path, charge, multiplicity)
                elif engine == "goat":
                    self._run_goat_ts(work_dir, ts_guess_path, charge, multiplicity)
                    
            self._pes_log("\n[SUCCESS] PES/TS Workflow Completed!")
            self.root.after(0, lambda: messagebox.showinfo("PES/TS Complete", f"Workflow finished.\nOutputs saved in:\n{work_dir}"))
        except Exception as e:
            _emsg = str(e)
            self._pes_log(f"\n[ERROR] PES Pipeline failed: {_emsg}")
            self.root.after(0, lambda m=_emsg: messagebox.showerror("PES Error", m))
        finally:
            self.root.after(0, lambda: self.btn_run_pes.config(state="normal", text="START PES & TS SEARCH"))

    def _run_xtb_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        scan_inp = os.path.join(work_dir, "scan.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  {c1_a1} {c1_a2} : {c1_s}, {c1_e}, {c1_steps}\n")
            if use_c2:
                f.write(f"  {c2_a1} {c2_a2} : {c2_s}, {c2_e}, {c2_steps}\n")
            f.write("$end\n")
        self._pes_log("Running xTB relaxed scan... (This may take a while)")
        
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
             raise RuntimeError("xTB not found on path.")
             
        cmd = f"\"{xtb_exe}\" {mol_file} --opt --input scan.inp"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_pes.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
            
        self._pes_log("xTB Scan finished. Parsing xtbscan.log...")
        scan_log = os.path.join(work_dir, "xtbscan.log")
        if not os.path.exists(scan_log):
             raise RuntimeError("xtbscan.log not found. The xTB scan failed.")
             
        energies = []
        geoms = []
        with open(scan_log, "r") as f:
             lines = f.readlines()
        
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 if "energy:" in lines[i+1]:
                     en = float(re.search(r"energy:\s*([-0-9.]+)", lines[i+1]).group(1))
                 else:
                     en = 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No step energies found in xtbscan.log.")
             
        self._pes_log(f"Extracted {len(energies)} points from scan.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy point found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        if use_c2 and MATPLOTLIB_AVAILABLE:
            self._generate_3d_pes_plot(work_dir, c1_steps, c2_steps, energies)

    def _run_orca_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        self._pes_log("Running ORCA relaxed scan... (This may take a very long time)")
        mol = Molecule.from_xyz(os.path.join(work_dir, mol_file))
        inp_path = os.path.join(work_dir, "orca_pes.inp")
        
        # NOTE: ORCA atom indices are 0-based for scanning!
        with open(inp_path, "w") as f:
            f.write("! B97-3c Opt\n")
            f.write("%geom Scan\n")
            f.write(f"  B {c1_a1-1} {c1_a2-1} = {c1_s}, {c1_e}, {c1_steps}\n")
            if use_c2:
                f.write(f"  B {c2_a1-1} {c2_a2-1} = {c2_s}, {c2_e}, {c2_steps}\n")
            f.write("end end\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_pes.inp > orca_pes.out"
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_pes.out")
        if not os.path.exists(out_path):
             raise RuntimeError("orca_pes.out not found. The ORCA scan failed.")
             
        trj_path = os.path.join(work_dir, "orca_pes.trj")
        if not os.path.exists(trj_path):
             self._pes_log("Warning: orca_pes.trj not found. Attempting to parse ORCA output for TS guess manually.")
             # Very basic fallback
             return

        # Parse orca.trj
        energies = []
        geoms = []
        with open(trj_path, "r") as f:
             lines = f.readlines()
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 en_match = re.search(r"[-0-9.]+", lines[i+1])
                 en = float(en_match.group(0)) if en_match else 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No step energies found in orca_pes.trj.")
             
        self._pes_log(f"Extracted {len(energies)} points from ORCA scan.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy point found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        if use_c2 and MATPLOTLIB_AVAILABLE:
            self._generate_3d_pes_plot(work_dir, c1_steps, c2_steps, energies)

    def _run_xtb_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log("Running xTB Transition State Optimization (--opt ts)...")
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        ts_mol = os.path.basename(ts_guess_path)
        cmd = f"\"{xtb_exe}\" {ts_mol} --opt ts --hess"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_ts.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
        
        imag_freqs = []
        for line in p.stdout.splitlines():
            if re.match(r"^\s*\d+\s+-\d+\.\d+", line):
                parts = line.split()
                if len(parts) >= 2 and float(parts[1]) < 0:
                     imag_freqs.append(float(parts[1]))
                     
        self._pes_log(f"xTB TS Output: Found {len(imag_freqs)} imaginary frequencies.")
        if len(imag_freqs) == 1:
             self._pes_log(f"SUCCESS: True TS confirmed! Imaginary mode: {imag_freqs[0]} cm-1")
        else:
             self._pes_log(f"WARNING: Found {len(imag_freqs)} imaginary modes. This might not be a valid TS.")

    def _run_orca_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log("Generating ORCA OptTS input...")
        mol = Molecule.from_xyz(ts_guess_path)
        inp_path = os.path.join(work_dir, "orca_ts.inp")
        with open(inp_path, "w") as f:
            f.write("! B97-3c OptTS Freq\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_ts.inp > orca_ts.out"
        self._pes_log("Running ORCA OptTS... (this may take a long time)")
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_ts.out")
        if not os.path.exists(out_path):
            raise RuntimeError("ORCA TS output not found.")
            
        with open(out_path, "r") as f:
            content = f.read()
            
        imag_freqs = re.findall(r"^\s*\d+:\s+-\d+\.\d+\s+cm\*\*-1", content, re.MULTILINE)
        self._pes_log(f"ORCA TS Output: Found {len(imag_freqs)} imaginary frequencies.")
        if len(imag_freqs) == 1:
             self._pes_log(f"SUCCESS: True TS confirmed! Imaginary mode: {imag_freqs[0].strip()}")
        else:
             self._pes_log(f"WARNING: Found {len(imag_freqs)} imaginary modes. This might not be a valid TS.")

    def _run_goat_neb(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log(f"Generating GOAT NEB-TS input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_neb.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"NEB\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    reactant: \"{reactant_file}\"\n    product: \"{product_file}\"\n")
            f.write(f"    charge: {charge}\n    multiplicity: {multiplicity}\n")
        self._pes_log("Running Chemrefine GOAT NEB...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    def _run_goat_pes(self, work_dir, mol_file, c1_a1, c1_a2, c1_s, c1_e, c1_steps, use_c2, c2_a1, c2_a2, c2_s, c2_e, c2_steps, charge, multiplicity):
        self._pes_log(f"Generating GOAT PES input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_pes.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"PES\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    geometry: \"{mol_file}\"\n")
            f.write(f"    scan:\n      - atoms: [{c1_a1}, {c1_a2}]\n        start: {c1_s}\n        end: {c1_e}\n        steps: {c1_steps}\n")
            if use_c2:
                f.write(f"      - atoms: [{c2_a1}, {c2_a2}]\n        start: {c2_s}\n        end: {c2_e}\n        steps: {c2_steps}\n")
        self._pes_log("Running Chemrefine GOAT PES...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    def _run_goat_ts(self, work_dir, ts_guess_path, charge, multiplicity):
        self._pes_log(f"Generating GOAT TS Refinement input for MLIP Model: {self._vars['goat_model'].get()}")
        yaml_path = os.path.join(work_dir, "goat_ts.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"steps:\n  - step: 1\n    operation: \"OPT+TS\"\n    engine: \"MLFF\"\n")
            f.write(f"    mlff:\n      model_name: \"{self._vars['goat_model'].get()}\"\n      task_name: \"omol\"\n      device: \"cuda\"\n")
            f.write(f"    geometry: \"{os.path.basename(ts_guess_path)}\"\n")
        self._pes_log("Running Chemrefine GOAT TS Optimization...")
        subprocess.run(f"chemrefine {yaml_path}", shell=True, cwd=work_dir)

    # =========================================================================
    # TRANSITION STATE PREDICTION METHODS
    # =========================================================================

    def _predict_ts_from_scan(self, energies: list, coords: list, work_dir: str) -> dict:
        """Predict TS location from a 1-D PES scan using cubic-spline interpolation.

        Parameters
        ----------
        energies : list of float
            Raw energies (Hartree) at each scan step.
        coords   : list of float
            Corresponding coordinate values (Å or degrees).
        work_dir : str
            Directory to write the spline-predicted PES plot and report.

        Returns
        -------
        dict with keys:
            ts_coord   – predicted TS coordinate value
            ts_energy  – spline energy at TS (Eh)
            ts_index   – raw-data index closest to TS
            barrier_fwd – forward  barrier ΔE‡ in kcal/mol
            barrier_rev – reverse barrier ΔE‡ in kcal/mol
            delta_e    – reaction energy ΔErxn in kcal/mol
        """
        import numpy as np
        EH2KCAL = 627.5094740631

        n = len(energies)
        if n < 4:
            self._pes_log("[TS-Predict] Need at least 4 scan points for spline interpolation.")
            return {}

        x = np.array(coords, dtype=float)
        y = np.array(energies, dtype=float)

        # Cubic spline via numpy (no scipy required)
        try:
            from scipy.interpolate import CubicSpline
            cs = CubicSpline(x, y)
            x_fine = np.linspace(x[0], x[-1], 2000)
            y_fine = cs(x_fine)
            y_deriv = cs(x_fine, 1)   # first derivative
        except ImportError:
            # Fallback: parabolic fit around raw maximum
            self._pes_log("[TS-Predict] scipy not available — using raw-data maximum as TS guess.")
            max_idx = int(np.argmax(y))
            result = {
                "ts_coord": float(x[max_idx]),
                "ts_energy": float(y[max_idx]),
                "ts_index": max_idx,
                "barrier_fwd": float((y[max_idx] - y[0]) * EH2KCAL),
                "barrier_rev": float((y[max_idx] - y[-1]) * EH2KCAL),
                "delta_e": float((y[-1] - y[0]) * EH2KCAL),
            }
            self._pes_log(
                f"[TS-Predict] Raw-max TS at coord={result['ts_coord']:.4f}, "
                f"ΔE‡(fwd)={result['barrier_fwd']:.2f} kcal/mol"
            )
            return result

        # Find sign-change of derivative → saddle point
        sign_changes = np.where(np.diff(np.sign(y_deriv)))[0]
        # Keep only local maxima (deriv goes + → -)
        max_idxs = [i for i in sign_changes if y_deriv[i] > 0]

        if not max_idxs:
            # No saddle found by derivative; fall back to global max
            max_idxs = [int(np.argmax(y_fine))]

        # Pick the highest saddle
        saddle_i = max_idxs[int(np.argmax([y_fine[i] for i in max_idxs]))]
        ts_coord = float(x_fine[saddle_i])
        ts_energy = float(y_fine[saddle_i])
        ts_index = int(np.argmin(np.abs(x - ts_coord)))

        e_react = float(y[0])
        e_prod = float(y[-1])
        barrier_fwd = (ts_energy - e_react) * EH2KCAL
        barrier_rev = (ts_energy - e_prod) * EH2KCAL
        delta_e = (e_prod - e_react) * EH2KCAL

        result = {
            "ts_coord": ts_coord,
            "ts_energy": ts_energy,
            "ts_index": ts_index,
            "barrier_fwd": barrier_fwd,
            "barrier_rev": barrier_rev,
            "delta_e": delta_e,
        }

        self._pes_log(
            f"[TS-Predict] Spline saddle-point: coord={ts_coord:.4f}, "
            f"E(TS)={ts_energy:.6f} Eh\n"
            f"  ΔE‡(fwd) = {barrier_fwd:.2f} kcal/mol\n"
            f"  ΔE‡(rev) = {barrier_rev:.2f} kcal/mol\n"
            f"  ΔErxn    = {delta_e:.2f} kcal/mol"
        )

        # Write text report
        report_path = os.path.join(work_dir, "ts_prediction_report.txt")
        with open(report_path, "w") as f:
            f.write("IAK Transition State Prediction Report\n")
            f.write("=" * 45 + "\n\n")
            f.write(f"Method: Cubic-spline saddle-point detection\n")
            f.write(f"Scan points used: {n}\n\n")
            f.write(f"Predicted TS coordinate : {ts_coord:.6f}\n")
            f.write(f"Predicted TS energy     : {ts_energy:.6f} Eh\n")
            f.write(f"Nearest scan step index : {ts_index} (0-based)\n\n")
            f.write(f"Forward  barrier ΔE‡    : {barrier_fwd:.4f} kcal/mol\n")
            f.write(f"Reverse  barrier ΔE‡    : {barrier_rev:.4f} kcal/mol\n")
            f.write(f"Reaction energy ΔErxn   : {delta_e:.4f} kcal/mol\n\n")
            f.write("All saddle-point candidates (spline maxima):\n")
            for si in max_idxs:
                f.write(f"  coord={x_fine[si]:.4f}  E={y_fine[si]:.6f} Eh\n")
        self._pes_log(f"[TS-Predict] Report saved → {report_path}")

        # Spline plot
        if MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(x, (y - y[0]) * EH2KCAL, "o", color="#388bfd",
                        label="Scan points", zorder=3)
                ax.plot(x_fine, (y_fine - y[0]) * EH2KCAL, "-",
                        color="#17a2b8", lw=2, label="Cubic spline")
                ax.axvline(ts_coord, color="#e05252", ls="--", lw=1.5,
                           label=f"TS guess ({ts_coord:.3f})")
                ax.scatter([ts_coord], [(ts_energy - y[0]) * EH2KCAL],
                           s=120, color="#e05252", zorder=5)
                ax.set_xlabel("Scan Coordinate")
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("PES Scan — TS Prediction (Spline)")
                ax.legend()
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                plot_path = os.path.join(work_dir, "ts_prediction_spline.png")
                plt.savefig(plot_path, dpi=200)
                plt.close(fig)
                self._pes_log(f"[TS-Predict] Spline plot saved → {plot_path}")
            except Exception as exc:
                self._pes_log(f"[TS-Predict] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _ts_barrier_analysis(
        self,
        e_reactant: float,
        e_ts: float,
        e_product: float,
        label_r: str = "Reactant",
        label_ts: str = "TS",
        label_p: str = "Product",
        work_dir: str = "",
    ) -> dict:
        """Compute thermochemical quantities from three-point energies (Eh).

        Returns a dict:  barrier_fwd, barrier_rev, delta_e (all kcal/mol),
        plus Evans–Polanyi coefficient alpha and a text summary.
        Optionally writes an energy-level diagram PNG to work_dir.
        """
        EH2KCAL = 627.5094740631
        barrier_fwd = (e_ts - e_reactant) * EH2KCAL
        barrier_rev = (e_ts - e_product) * EH2KCAL
        delta_e = (e_product - e_reactant) * EH2KCAL
        # Evans–Polanyi α = ΔE‡(fwd) / (ΔE‡(fwd) + ΔE‡(rev))
        denom = barrier_fwd + barrier_rev
        alpha = barrier_fwd / denom if denom != 0 else float("nan")

        summary = (
            f"  {label_r} → [{label_ts}]‡ → {label_p}\n"
            f"  ΔE‡(fwd) = {barrier_fwd:+.3f} kcal/mol\n"
            f"  ΔE‡(rev) = {barrier_rev:+.3f} kcal/mol\n"
            f"  ΔErxn    = {delta_e:+.3f} kcal/mol\n"
            f"  Evans–Polanyi α = {alpha:.3f}"
        )
        self._pes_log("[Barrier Analysis]\n" + summary)

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 4))
                rel = [0.0, barrier_fwd, delta_e]
                x_pos = [0, 1, 2]
                labels = [label_r, label_ts, label_p]
                colors = ["#388bfd", "#e05252", "#22c55e"]
                for xi, yi, lbl, col in zip(x_pos, rel, labels, colors):
                    ax.hlines(yi, xi - 0.2, xi + 0.2, colors=col, lw=3)
                    ax.text(xi, yi + 0.5, f"{lbl}\n{yi:+.2f}", ha="center",
                            va="bottom", fontsize=9, color=col)
                # Bezier-like connection
                for i in range(len(x_pos) - 1):
                    ax.annotate(
                        "",
                        xy=(x_pos[i + 1] - 0.2, rel[i + 1]),
                        xytext=(x_pos[i] + 0.2, rel[i]),
                        arrowprops=dict(arrowstyle="-", color="#888", lw=1.2,
                                        connectionstyle="arc3,rad=-0.3"),
                    )
                ax.set_xticks([])
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("Energy Level Diagram")
                ax.grid(axis="y", alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "energy_level_diagram.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[Barrier Analysis] Energy diagram saved → {out}")
            except Exception as exc:
                self._pes_log(f"[Barrier Analysis] Plot error: {exc}")

        return {
            "barrier_fwd": barrier_fwd,
            "barrier_rev": barrier_rev,
            "delta_e": delta_e,
            "alpha": alpha,
            "summary": summary,
        }

    # -------------------------------------------------------------------------

    def _interpolate_path_idpp(
        self,
        reactant_xyz: str,
        product_xyz: str,
        n_images: int,
        work_dir: str,
    ) -> list:
        """Generate NEB initial path images via IDPP (Image Dependent Pair Potential)
        linear interpolation with pair-distance correction.

        Returns a list of XYZ-block strings (one per image including endpoints).
        Also writes image_NNN.xyz files to work_dir.
        """
        def _read_xyz(path):
            with open(path) as f:
                lines = f.readlines()
            n = int(lines[0])
            atoms, coords = [], []
            for l in lines[2 : 2 + n]:
                parts = l.split()
                atoms.append(parts[0])
                coords.append([float(parts[1]), float(parts[2]), float(parts[3])])
            return atoms, np.array(coords)

        self._pes_log(f"[IDPP] Generating {n_images} interpolated images …")
        atoms, r_coords = _read_xyz(reactant_xyz)
        _, p_coords = _read_xyz(product_xyz)

        if len(atoms) != len(_):
            raise RuntimeError("Reactant and product have different atom counts.")

        n_atoms = len(atoms)
        images = []
        all_blocks = []

        for k in range(n_images + 2):  # includes endpoints
            t = k / (n_images + 1)
            # Linear interpolation
            coords_k = (1 - t) * r_coords + t * p_coords

            # IDPP correction: repulsion term to prevent atom clashes
            if 0 < k <= n_images:
                for _ in range(5):  # 5 micro-iterations
                    grad = np.zeros_like(coords_k)
                    for i in range(n_atoms):
                        for j in range(i + 1, n_atoms):
                            rij = coords_k[i] - coords_k[j]
                            dist = np.linalg.norm(rij) + 1e-10
                            # Target interpolated distance
                            d_r = np.linalg.norm(r_coords[i] - r_coords[j])
                            d_p = np.linalg.norm(p_coords[i] - p_coords[j])
                            d_target = (1 - t) * d_r + t * d_p + 1e-10
                            f_ij = 2.0 * (dist - d_target) / (d_target ** 4) * (rij / dist)
                            grad[i] += f_ij
                            grad[j] -= f_ij
                    coords_k -= 0.01 * grad

            images.append(coords_k.copy())

            # Build XYZ block
            block = f"{n_atoms}\nImage {k} (IDPP)\n"
            for sym, (x, y, z) in zip(atoms, coords_k):
                block += f"{sym:4s}  {x:12.6f}  {y:12.6f}  {z:12.6f}\n"
            all_blocks.append(block)

            out_xyz = os.path.join(work_dir, f"image_{k:03d}.xyz")
            with open(out_xyz, "w") as f:
                f.write(block)

        self._pes_log(f"[IDPP] Wrote {n_images + 2} images (incl. endpoints) to {work_dir}")
        return all_blocks

    # -------------------------------------------------------------------------

    def _run_orca_ts_with_hessian(
        self, work_dir: str, ts_guess_path: str, charge: int, mult: int,
        method: str = "B97-3c", cores: int = 4,
    ):
        """ORCA OptTS using a pre-computed numerical Hessian as initial Hessian.

        Workflow:
          1. Run a single-point + frequency calculation to obtain the Hessian.
          2. Feed that Hessian into OptTS via InHessName keyword.
          3. Confirm TS: exactly one imaginary frequency.
        """
        self._pes_log("[ORCA-OptTS+Hess] Step 1: Computing numerical Hessian …")
        mol = Molecule.from_xyz(ts_guess_path)
        basename = os.path.splitext(os.path.basename(ts_guess_path))[0]

        # --- Step 1: Hessian calc ---
        hess_inp = os.path.join(work_dir, f"{basename}_hess.inp")
        with open(hess_inp, "w") as f:
            f.write(f"! {method} NumFreq\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        p1 = subprocess.run(
            f"orca {basename}_hess.inp > {basename}_hess.out",
            shell=True, cwd=work_dir, capture_output=False,
        )
        hess_file = os.path.join(work_dir, f"{basename}_hess.hess")
        if not os.path.exists(hess_file):
            self._pes_log("[ORCA-OptTS+Hess] Hessian file not found — falling back to standard OptTS.")
            self._run_orca_ts(work_dir, ts_guess_path, charge, mult)
            return

        self._pes_log("[ORCA-OptTS+Hess] Step 2: Running OptTS with initial Hessian …")
        ts_inp = os.path.join(work_dir, f"{basename}_optts.inp")
        with open(ts_inp, "w") as f:
            f.write(f"! {method} OptTS Freq\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write("%geom\n")
            f.write(f'  InHessName "{basename}_hess.hess"\n')
            f.write("  Calc_Hess false\n")
            f.write("end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        subprocess.run(
            f"orca {basename}_optts.inp > {basename}_optts.out",
            shell=True, cwd=work_dir,
        )
        out_path = os.path.join(work_dir, f"{basename}_optts.out")
        result = self._parse_orca_ts_result(out_path, work_dir)
        self._report_ts_result(result)

    # -------------------------------------------------------------------------

    def _parse_orca_ts_result(self, out_path: str, work_dir: str) -> dict:
        """Parse an ORCA output file to extract TS energy, imaginary frequencies,
        and the optimised TS geometry (written as ts_confirmed.xyz).

        Returns dict: energy_eh, imag_freqs (list[float]), n_imag, converged, ts_xyz_path
        """
        result = {
            "energy_eh": None,
            "imag_freqs": [],
            "n_imag": 0,
            "converged": False,
            "ts_xyz_path": None,
        }
        if not os.path.exists(out_path):
            self._pes_log(f"[ParseORCA-TS] Output not found: {out_path}")
            return result

        with open(out_path, "r", errors="replace") as f:
            content = f.read()
            lines = content.splitlines()

        # Convergence
        result["converged"] = "HURRAY" in content or "THE OPTIMIZATION HAS CONVERGED" in content

        # Final energy
        for line in reversed(lines):
            m = re.search(r"FINAL SINGLE POINT ENERGY\s+([-\d.]+)", line)
            if m:
                result["energy_eh"] = float(m.group(1))
                break

        # Imaginary frequencies (negative values in freq block)
        imag = []
        in_freq = False
        for line in lines:
            if "VIBRATIONAL FREQUENCIES" in line:
                in_freq = True
            if in_freq:
                m = re.match(r"\s*\d+:\s+(-\d+\.\d+)\s+cm\*\*-1", line)
                if m:
                    imag.append(float(m.group(1)))
            if in_freq and line.strip() == "" and imag:
                break  # end of freq block
        result["imag_freqs"] = imag
        result["n_imag"] = len(imag)

        # Extract final optimised geometry
        geom_lines = []
        in_geom = False
        for i, line in enumerate(lines):
            if "CARTESIAN COORDINATES (ANGSTROEM)" in line:
                in_geom = True
                geom_lines = []
                continue
            if in_geom:
                if line.strip() == "" and geom_lines:
                    break
                if re.match(r"\s*[A-Za-z]", line):
                    geom_lines.append(line.strip())

        if geom_lines:
            ts_xyz_path = os.path.join(work_dir, "ts_confirmed.xyz")
            with open(ts_xyz_path, "w") as f:
                f.write(f"{len(geom_lines)}\n")
                f.write(
                    f"TS E={result['energy_eh']} Eh  "
                    f"nimag={result['n_imag']}\n"
                )
                for gl in geom_lines:
                    parts = gl.split()
                    f.write(
                        f"{parts[0]:<4}  "
                        f"{float(parts[1]):15.8f}  "
                        f"{float(parts[2]):15.8f}  "
                        f"{float(parts[3]):15.8f}\n"
                    )
            result["ts_xyz_path"] = ts_xyz_path

        return result

    # -------------------------------------------------------------------------

    def _parse_xtb_ts_result(self, log_path: str, work_dir: str) -> dict:
        """Parse an xTB output/log to extract TS energy and imaginary frequencies.

        Returns dict: energy_eh, imag_freqs, n_imag, converged.
        """
        result = {"energy_eh": None, "imag_freqs": [], "n_imag": 0, "converged": False}
        if not os.path.exists(log_path):
            return result

        with open(log_path, "r", errors="replace") as f:
            lines = f.readlines()

        imag = []
        for line in lines:
            # xTB freq output: "     1     -243.34  (i)" or similar
            m = re.search(r"(-\d+\.\d+)\s+\(i\)", line)
            if m:
                imag.append(float(m.group(1)))
            # Also catch plain negative freq columns
            m2 = re.match(r"^\s*\d+\s+(-\d+\.\d+)\s+cm", line)
            if m2:
                imag.append(float(m2.group(1)))
            # Total energy
            m3 = re.search(r"TOTAL ENERGY\s+([-\d.]+)\s+Eh", line)
            if m3:
                result["energy_eh"] = float(m3.group(1))
            # Convergence
            if "GEOMETRY OPTIMIZATION CONVERGED" in line or "converged" in line.lower():
                result["converged"] = True

        result["imag_freqs"] = list(dict.fromkeys(imag))  # deduplicate
        result["n_imag"] = len(result["imag_freqs"])
        return result

    # -------------------------------------------------------------------------

    def _run_orca_irc(
        self, work_dir: str, ts_xyz_path: str, charge: int, mult: int,
        method: str = "B97-3c", direction: str = "both", cores: int = 4,
    ):
        """Run an Intrinsic Reaction Coordinate (IRC) calculation from a TS geometry.

        direction: 'forward', 'backward', or 'both' (runs two separate ORCA jobs).
        Output: IRC_forward.trj and/or IRC_backward.trj + summary plot.
        """
        if not os.path.exists(ts_xyz_path):
            self._pes_log(f"[IRC] TS file not found: {ts_xyz_path}")
            return

        mol = Molecule.from_xyz(ts_xyz_path)
        dirs = (
            ["forward", "backward"] if direction == "both"
            else [direction]
        )

        energies_by_dir: dict = {}

        for d in dirs:
            self._pes_log(f"[IRC] Running IRC {d} from TS …")
            inp_name = f"irc_{d}.inp"
            out_name = f"irc_{d}.out"
            inp_path = os.path.join(work_dir, inp_name)
            with open(inp_path, "w") as f:
                f.write(f"! {method} IRC\n")
                f.write(f"%pal nprocs {cores} end\n")
                f.write(f"%irc\n")
                f.write(f"  Direction {d.capitalize()}\n")
                f.write(f"  MaxIter 80\n")
                f.write(f"  StepSize 0.1\n")
                f.write("end\n")
                f.write(f"* xyz {charge} {mult}\n")
                for a in mol.atoms:
                    f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
                f.write("*\n")

            subprocess.run(
                f"orca {inp_name} > {out_name}",
                shell=True, cwd=work_dir,
            )

            # Parse IRC energies from trajectory
            trj = os.path.join(work_dir, f"irc_{d}.trj")
            if not os.path.exists(trj):
                # ORCA may name it differently
                alts = [
                    os.path.join(work_dir, f"irc_{d}_IRC_Full_trj.xyz"),
                    os.path.join(work_dir, "IRC_Full_trj.xyz"),
                ]
                for a in alts:
                    if os.path.exists(a):
                        trj = a
                        break

            ens = []
            if os.path.exists(trj):
                with open(trj) as f:
                    lines = f.readlines()
                i = 0
                while i < len(lines):
                    try:
                        nat = int(lines[i].strip())
                        m = re.search(r"([-\d.]+)", lines[i + 1])
                        ens.append(float(m.group(1)) if m else 0.0)
                        i += 2 + nat
                    except Exception:
                        i += 1
                energies_by_dir[d] = ens
                self._pes_log(f"[IRC-{d}] {len(ens)} points parsed.")
            else:
                self._pes_log(f"[IRC-{d}] Trajectory file not found — ORCA may have failed.")

        # Plot combined IRC
        if energies_by_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                EH2KCAL = 627.5094740631
                fig, ax = plt.subplots(figsize=(8, 5))
                offset = 0
                color_map = {"forward": "#388bfd", "backward": "#e05252"}
                for d, ens in energies_by_dir.items():
                    y = np.array(ens)
                    y_rel = (y - y[0]) * EH2KCAL
                    x_irc = np.arange(len(y)) * (1 if d == "forward" else -1) + offset
                    ax.plot(x_irc, y_rel, "-o", ms=3, lw=1.5,
                            color=color_map.get(d, "gray"), label=f"IRC {d}")
                ax.axhline(0, color="#888", ls="--", lw=0.8)
                ax.set_xlabel("IRC Step")
                ax.set_ylabel("Relative Energy (kcal/mol)")
                ax.set_title("Intrinsic Reaction Coordinate (IRC)")
                ax.legend()
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out_plot = os.path.join(work_dir, "IRC_plot.png")
                plt.savefig(out_plot, dpi=200)
                plt.close(fig)
                self._pes_log(f"[IRC] Plot saved → {out_plot}")
            except Exception as exc:
                self._pes_log(f"[IRC] Plot error: {exc}")

    # -------------------------------------------------------------------------

    def _run_xtb_irc(
        self, work_dir: str, ts_xyz_path: str, charge: int, mult: int,
    ):
        """Approximate IRC using xTB --path from TS toward reactant and product.

        xTB does not have a native IRC command; this method runs two path
        calculations: one with the TS as start, one as end, effectively
        tracing both sides of the reaction coordinate under GFN2-xTB.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            self._pes_log("[xTB-IRC] xTB not found on PATH.")
            return

        reactant_path = os.path.join(work_dir, "reactant.xyz")
        product_path = os.path.join(work_dir, "product.xyz")

        for target, label in [(reactant_path, "backward"), (product_path, "forward")]:
            if not os.path.exists(target):
                self._pes_log(f"[xTB-IRC] {label} target file not found: {target}")
                continue
            self._pes_log(f"[xTB-IRC] Path {label}: TS → {label} endpoint …")
            ts_base = os.path.basename(ts_xyz_path)
            cmd = f'"{xtb_exe}" {ts_base} --path {os.path.basename(target)}'
            if charge:
                cmd += f" --chrg {charge}"
            if mult != 1:
                cmd += f" --uhf {mult - 1}"

            irc_dir = os.path.join(work_dir, f"xtb_irc_{label}")
            os.makedirs(irc_dir, exist_ok=True)
            import shutil as _shutil
            _shutil.copy2(ts_xyz_path, irc_dir)
            _shutil.copy2(target, irc_dir)

            p = subprocess.run(cmd, shell=True, cwd=irc_dir,
                               capture_output=True, text=True)
            log_out = os.path.join(irc_dir, f"xtb_irc_{label}.log")
            with open(log_out, "w") as f:
                f.write(p.stdout + p.stderr)
            self._pes_log(f"[xTB-IRC] {label} done — log: {log_out}")

    # -------------------------------------------------------------------------

    def _validate_ts_geometry(
        self,
        ts_xyz_path: str,
        reactant_xyz_path: str,
        product_xyz_path: str,
        bond_cutoff: float = 1.85,
    ) -> dict:
        """Validate that a TS geometry makes chemical sense by checking:
        (a) It has bonds that are breaking/forming relative to reactant and product.
        (b) The imaginary-mode displacement correlates with those bond changes.

        Uses a simple distance-threshold bond matrix (no force field needed).
        Returns a dict with keys: bonds_breaking, bonds_forming, is_valid, notes.
        """
        def _bond_matrix(xyz_path, cutoff):
            mat = {}
            if not os.path.exists(xyz_path):
                return mat
            with open(xyz_path) as f:
                lines = f.readlines()
            n = int(lines[0])
            atoms, coords = [], []
            for l in lines[2:2 + n]:
                p = l.split()
                atoms.append(p[0])
                coords.append([float(p[1]), float(p[2]), float(p[3])])
            for i in range(n):
                for j in range(i + 1, n):
                    d = sum((coords[i][k] - coords[j][k]) ** 2 for k in range(3)) ** 0.5
                    if d < cutoff:
                        mat[(i, j)] = round(d, 4)
            return mat

        r_bonds = _bond_matrix(reactant_xyz_path, bond_cutoff)
        p_bonds = _bond_matrix(product_xyz_path, bond_cutoff)
        ts_bonds = _bond_matrix(ts_xyz_path, bond_cutoff)

        r_set = set(r_bonds)
        p_set = set(p_bonds)
        ts_set = set(ts_bonds)

        # Bonds present in reactant but absent in product → breaking
        breaking = r_set - p_set
        # Bonds present in product but absent in reactant → forming
        forming = p_set - r_set

        # Check TS has partial character for these bonds
        ts_breaking_present = breaking & ts_set
        ts_forming_present = forming & ts_set

        notes = []
        if not breaking and not forming:
            notes.append("No bond changes detected between reactant and product.")
        if ts_breaking_present:
            notes.append(
                f"TS retains {len(ts_breaking_present)}/{len(breaking)} breaking bond(s) — expected for early TS."
            )
        if ts_forming_present:
            notes.append(
                f"TS already has {len(ts_forming_present)}/{len(forming)} forming bond(s) — late TS character."
            )

        is_valid = bool(breaking or forming)

        result = {
            "bonds_breaking": sorted(breaking),
            "bonds_forming": sorted(forming),
            "ts_breaking_present": sorted(ts_breaking_present),
            "ts_forming_present": sorted(ts_forming_present),
            "is_valid": is_valid,
            "notes": notes,
        }

        self._pes_log("[TS-Validate] Bond-change analysis:")
        self._pes_log(f"  Bonds breaking (R→P): {sorted(breaking)}")
        self._pes_log(f"  Bonds forming  (R→P): {sorted(forming)}")
        for note in notes:
            self._pes_log(f"  {note}")
        if is_valid:
            self._pes_log("[TS-Validate] TS geometry is consistent with expected bond changes.")
        else:
            self._pes_log("[TS-Validate] WARNING: No bond changes detected — check atom numbering.")

        return result

    # -------------------------------------------------------------------------

    def _report_ts_result(self, result: dict):
        """Log a human-readable summary of a parsed TS result dict."""
        if result.get("energy_eh") is not None:
            self._pes_log(f"[TS Result] Energy       : {result['energy_eh']:.6f} Eh")
        self._pes_log(f"[TS Result] Converged    : {result.get('converged', 'unknown')}")
        n = result.get("n_imag", 0)
        freqs = result.get("imag_freqs", [])
        if n == 1:
            self._pes_log(
                f"[TS Result] ✓ TRUE TS confirmed — 1 imaginary freq: {freqs[0]:.1f} cm⁻¹"
            )
        elif n == 0:
            self._pes_log(
                "[TS Result] ✗ No imaginary frequencies — geometry converged to a MINIMUM, not a TS."
            )
        else:
            self._pes_log(
                f"[TS Result] ✗ {n} imaginary frequencies found: {freqs} cm⁻¹ — higher-order saddle point."
            )
        if result.get("ts_xyz_path"):
            self._pes_log(f"[TS Result] Geometry saved → {result['ts_xyz_path']}")

    # =========================================================================
    # END TRANSITION STATE PREDICTION METHODS
    # =========================================================================

    def _run_xtb_path(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log("Running xTB Reactant -> Product Path Interpolation (--path)...")
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
             raise RuntimeError("xTB not found on path.")
             
        cmd = f"\"{xtb_exe}\" {reactant_file} --path {product_file}"
        if charge != 0:
            cmd += f" --chrg {charge}"
        if multiplicity != 1:
            cmd += f" --uhf {multiplicity - 1}"
        cmd = f"ulimit -s unlimited && export OMP_STACKSIZE=1G && {cmd}"
        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_path.log"), "w") as f:
            f.write(p.stdout)
            f.write(p.stderr)
            
        self._pes_log("xTB Path Interpolation finished. Parsing xtbpath.xyz...")
        path_log = os.path.join(work_dir, "xtbpath.xyz")
        if not os.path.exists(path_log):
             raise RuntimeError("xtbpath.xyz not found. The xTB path interpolation failed.")
             
        # Extract highest energy point (or just take point #5 if arbitrary)
        # xTB NEB logs energy in the comment line of each frame in xtbpath.xyz
        energies = []
        geoms = []
        with open(path_log, "r") as f:
             lines = f.readlines()
        
        i = 0
        while i < len(lines):
             line = lines[i].strip()
             if not line:
                 i += 1; continue
             try:
                 n_atoms = int(line)
                 en_match = re.search(r"energy:\s*([-0-9.]+)", lines[i+1].lower())
                 en = float(en_match.group(1)) if en_match else 0.0
                 energies.append(en)
                 block = lines[i:i+2+n_atoms]
                 geoms.append("".join(block))
                 i += 2 + n_atoms
             except Exception:
                 i += 1
                 
        if not energies:
             raise RuntimeError("No structures parsed from xtbpath.xyz.")
             
        self._pes_log(f"Extracted {len(energies)} frames from path.")
        max_idx = np.argmax(energies)
        self._pes_log(f"Highest energy frame found at Step {max_idx+1} (E = {energies[max_idx]} Eh). Saving as ts_guess.xyz")
        
        with open(os.path.join(work_dir, "ts_guess.xyz"), "w") as f:
            f.write(geoms[max_idx])
            
        # Optional: Generate a simple 1D plot
        if MATPLOTLIB_AVAILABLE:
            self._generate_1d_pes_plot(work_dir, energies)

    def _run_orca_neb(self, work_dir, reactant_file, product_file, charge, multiplicity):
        self._pes_log("Running ORCA NEB-TS Interpolation... (This will take a very long time)")
        mol_react = Molecule.from_xyz(os.path.join(work_dir, reactant_file))
        inp_path = os.path.join(work_dir, "orca_neb.inp")
        
        with open(inp_path, "w") as f:
            f.write("! B97-3c OptTS NEB-TS\n")
            f.write(f"%neb NEB_End_XYZFile \"{product_file}\" end\n")
            f.write(f"* xyz {charge} {multiplicity}\n")
            for a in mol_react.atoms:
                f.write(f"{a.symbol} {a.x} {a.y} {a.z}\n")
            f.write("*\n")
            
        cmd = f"orca orca_neb.inp > orca_neb.out"
        subprocess.run(cmd, shell=True, cwd=work_dir)
        
        out_path = os.path.join(work_dir, "orca_neb.out")
        if not os.path.exists(out_path):
             raise RuntimeError("orca_neb.out not found. The ORCA NEB failed.")
             
        # ORCA NEB-TS automatically performs the TS optimization and outputs it
        # We can extract the final geometry as ts_guess.xyz
        # For simplicity, if ORCA finishes properly, we just look for orca_neb.xyz
        final_xyz = os.path.join(work_dir, "orca_neb.xyz")
        if os.path.exists(final_xyz):
             shutil.copy2(final_xyz, os.path.join(work_dir, "ts_guess.xyz"))
             self._pes_log("Found final ORCA NEB-TS geometry. Saved as ts_guess.xyz")
        else:
             self._pes_log("Warning: orca_neb.xyz not found. Cannot set ts_guess.xyz.")

    def _generate_1d_pes_plot(self, work_dir, energies):
        try:
            import matplotlib.pyplot as plt
            fig = plt.figure(figsize=(8,6))
            plt.plot(range(1, len(energies)+1), energies, marker='o', linestyle='-', color='b')
            plt.title("Reactant -> Product Interpolation Path")
            plt.xlabel("Interpolation Step")
            plt.ylabel("Energy (Eh)")
            plt.grid(True)
            plot_path = os.path.join(work_dir, "Path_1D_Plot.png")
            plt.savefig(plot_path, dpi=300)
            plt.close()
            self._pes_log(f"1D Path Plot saved to {plot_path}")
        except Exception as e:
            self._pes_log(f"Failed to generate 1D plot: {str(e)}")

    def _generate_3d_pes_plot(self, work_dir, c1_steps, c2_steps, energies):
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D
            
            N = len(energies)
            # Adjust dimensions depending on inclusive/exclusive steps. Usually step count = N intervals -> N+1 points.
            # But let's just attempt a safe reshape.
            # Try to infer dims if c1_steps and c2_steps don't match exactly
            import math
            possible_cols = [int(c1_steps), int(c1_steps)+1, int(c2_steps), int(c2_steps)+1]
            cols = None
            for c in possible_cols:
                if c > 0 and N % c == 0:
                    cols = c
                    break
                    
            if cols is None:
                self._pes_log(f"Warning: Cannot reshape energy array ({N} points) for a 3D plot smoothly. Plot skipped.")
                return
                
            rows = N // cols
            Z = np.array(energies).reshape(rows, cols)
            X, Y = np.meshgrid(range(cols), range(rows))
            
            fig = plt.figure(figsize=(8,6))
            ax = fig.add_subplot(111, projection='3d')
            surf = ax.plot_surface(X, Y, Z, cmap='viridis')
            fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
            ax.set_title("2D Relaxed Scan PES")
            ax.set_xlabel("Coord 1 (Steps)")
            ax.set_ylabel("Coord 2 (Steps)")
            ax.set_zlabel("Energy (Eh)")
            
            plot_path = os.path.join(work_dir, "PES_3D_Plot.png")
            plt.savefig(plot_path, dpi=300)
            plt.close()
            self._pes_log(f"3D PES Plot saved to {plot_path}")
        except Exception as e:
            self._pes_log(f"Failed to generate 3D plot: {str(e)}")

    # =========================================================================
    # EXTENDED PES METHODS — Multi-dimensional scans, angular, umbrella, FES
    # =========================================================================

    def _run_xtb_angle_scan(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int, a3: int,
        angle_start: float, angle_end: float, n_steps: int,
        charge: int, mult: int,
    ):
        """Relaxed bond-angle scan using xTB ($scan block with 3-atom angle).

        Writes xtbscan_angle.log and ts_guess_angle.xyz (highest-energy frame).
        Also produces a 1-D plot.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        scan_inp = os.path.join(work_dir, "scan_angle.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  angle: {a1}, {a2}, {a3}, {angle_start}, {angle_end}, {n_steps}\n")
            f.write("$end\n")

        self._pes_log(
            f"[Angle Scan] xTB angle {a1}-{a2}-{a3}: "
            f"{angle_start}° → {angle_end}° in {n_steps} steps …"
        )
        cmd = f'"{xtb_exe}" {mol_file} --opt --input scan_angle.inp'
        if charge:
            cmd += f" --chrg {charge}"
        if mult != 1:
            cmd += f" --uhf {mult - 1}"

        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        log_path = os.path.join(work_dir, "xtb_angle_scan.log")
        with open(log_path, "w") as f:
            f.write(p.stdout + p.stderr)

        scan_log = os.path.join(work_dir, "xtbscan.log")
        energies, geoms = self._parse_xyz_trajectory(scan_log)
        if not energies:
            raise RuntimeError("No energies in xtbscan.log (angle scan).")

        self._pes_log(f"[Angle Scan] {len(energies)} points. Max-E frame → ts_guess_angle.xyz")
        max_i = int(np.argmax(energies))
        with open(os.path.join(work_dir, "ts_guess_angle.xyz"), "w") as f:
            f.write(geoms[max_i])

        angles = np.linspace(angle_start, angle_end, len(energies))
        self._plot_1d_pes(
            work_dir, angles, energies,
            xlabel="Bond Angle (°)",
            title=f"Angle Scan {a1}-{a2}-{a3}",
            filename="angle_scan_pes.png",
        )

    # -------------------------------------------------------------------------

    def _run_xtb_dihedral_scan(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int, a3: int, a4: int,
        dih_start: float, dih_end: float, n_steps: int,
        charge: int, mult: int,
    ):
        """Relaxed dihedral (torsion) scan using xTB (4-atom $scan block).

        Writes xtb_dihedral_scan.log, ts_guess_dihedral.xyz, dihedral_scan_pes.png.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        scan_inp = os.path.join(work_dir, "scan_dih.inp")
        with open(scan_inp, "w") as f:
            f.write("$scan\n")
            f.write(f"  dihedral: {a1}, {a2}, {a3}, {a4}, {dih_start}, {dih_end}, {n_steps}\n")
            f.write("$end\n")

        self._pes_log(
            f"[Dihedral Scan] xTB dihedral {a1}-{a2}-{a3}-{a4}: "
            f"{dih_start}° → {dih_end}° in {n_steps} steps …"
        )
        cmd = f'"{xtb_exe}" {mol_file} --opt --input scan_dih.inp'
        if charge:
            cmd += f" --chrg {charge}"
        if mult != 1:
            cmd += f" --uhf {mult - 1}"

        p = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True)
        with open(os.path.join(work_dir, "xtb_dihedral_scan.log"), "w") as f:
            f.write(p.stdout + p.stderr)

        energies, geoms = self._parse_xyz_trajectory(os.path.join(work_dir, "xtbscan.log"))
        if not energies:
            raise RuntimeError("No energies in xtbscan.log (dihedral scan).")

        max_i = int(np.argmax(energies))
        with open(os.path.join(work_dir, "ts_guess_dihedral.xyz"), "w") as f:
            f.write(geoms[max_i])

        dihedrals = np.linspace(dih_start, dih_end, len(energies))
        self._plot_1d_pes(
            work_dir, dihedrals, energies,
            xlabel="Dihedral Angle (°)",
            title=f"Dihedral Scan {a1}-{a2}-{a3}-{a4}",
            filename="dihedral_scan_pes.png",
        )
        self._pes_log(f"[Dihedral Scan] Done. Max-E step: {max_i + 1}")

    # -------------------------------------------------------------------------

    def _run_orca_2d_pes(
        self,
        work_dir: str,
        mol_file: str,
        c1_a1: int, c1_a2: int, c1_start: float, c1_end: float, c1_steps: int,
        c2_a1: int, c2_a2: int, c2_start: float, c2_end: float, c2_steps: int,
        charge: int, mult: int,
        method: str = "B97-3c",
        cores: int = 4,
    ):
        """Full 2-D relaxed PES scan in ORCA (nested B-scan blocks).

        Generates a filled-contour plot (FES-style) in kcal/mol relative units
        and writes PES_2D_contour.png + PES_2D_data.csv.
        """
        self._pes_log(
            f"[ORCA 2D-PES] Scanning "
            f"B({c1_a1-1},{c1_a2-1}) {c1_start}→{c1_end} × "
            f"B({c2_a1-1},{c2_a2-1}) {c2_start}→{c2_end} with {method} …"
        )
        mol = Molecule.from_xyz(os.path.join(work_dir, mol_file))
        inp_path = os.path.join(work_dir, "orca_2d_pes.inp")
        with open(inp_path, "w") as f:
            f.write(f"! {method} Opt\n")
            f.write(f"%pal nprocs {cores} end\n")
            f.write("%geom Scan\n")
            f.write(f"  B {c1_a1-1} {c1_a2-1} = {c1_start}, {c1_end}, {c1_steps}\n")
            f.write(f"  B {c2_a1-1} {c2_a2-1} = {c2_start}, {c2_end}, {c2_steps}\n")
            f.write("end end\n")
            f.write(f"* xyz {charge} {mult}\n")
            for a in mol.atoms:
                f.write(f"  {a.symbol:<3} {a.x:15.8f} {a.y:15.8f} {a.z:15.8f}\n")
            f.write("*\n")

        subprocess.run(
            "orca orca_2d_pes.inp > orca_2d_pes.out",
            shell=True, cwd=work_dir,
        )

        trj = os.path.join(work_dir, "orca_2d_pes.trj")
        energies, _ = self._parse_xyz_trajectory(trj)
        if not energies:
            self._pes_log("[ORCA 2D-PES] No trajectory energies found.")
            return

        n_total = len(energies)
        self._pes_log(f"[ORCA 2D-PES] Parsed {n_total} points.")
        self._generate_2d_contour_pes(
            work_dir, energies, c1_steps, c2_steps,
            c1_start, c1_end, c2_start, c2_end,
            xlabel=f"Bond {c1_a1}-{c1_a2} (Å)",
            ylabel=f"Bond {c2_a1}-{c2_a2} (Å)",
        )

    # -------------------------------------------------------------------------

    def _generate_2d_contour_pes(
        self,
        work_dir: str,
        energies: list,
        c1_steps: int, c2_steps: int,
        c1_start: float, c1_end: float,
        c2_start: float, c2_end: float,
        xlabel: str = "Coord 1",
        ylabel: str = "Coord 2",
        filename: str = "PES_2D_contour.png",
    ):
        """Render a filled-contour 2-D PES map in kcal/mol and export CSV."""
        if not MATPLOTLIB_AVAILABLE:
            self._pes_log("[2D-Contour] matplotlib not available — skipping plot.")
            return
        import matplotlib.pyplot as plt
        EH2KCAL = 627.5094740631

        y = np.array(energies, dtype=float)
        # Infer grid shape
        for cols in [c1_steps, c1_steps + 1, c2_steps, c2_steps + 1]:
            if cols > 0 and len(y) % cols == 0:
                rows = len(y) // cols
                break
        else:
            self._pes_log(f"[2D-Contour] Cannot reshape {len(y)} points into grid.")
            return

        Z = (y - y.min()).reshape(rows, cols) * EH2KCAL
        X = np.linspace(c1_start, c1_end, cols)
        Y_ax = np.linspace(c2_start, c2_end, rows)
        XX, YY = np.meshgrid(X, Y_ax)

        fig, ax = plt.subplots(figsize=(7, 6))
        levels = np.linspace(0, Z.max(), 30)
        cf = ax.contourf(XX, YY, Z, levels=levels, cmap="RdYlGn_r")
        ax.contour(XX, YY, Z, levels=levels[::3], colors="k", linewidths=0.5, alpha=0.5)
        cbar = fig.colorbar(cf, ax=ax)
        cbar.set_label("Relative Energy (kcal/mol)")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title("2-D Relaxed PES (Contour)")
        fig.tight_layout()
        out = os.path.join(work_dir, filename)
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[2D-Contour] Plot saved → {out}")

        # CSV export
        csv_path = os.path.join(work_dir, "PES_2D_data.csv")
        with open(csv_path, "w") as f:
            f.write(f"{xlabel},{ylabel},E_rel_kcalmol\n")
            for ri in range(rows):
                for ci in range(cols):
                    f.write(f"{XX[ri,ci]:.4f},{YY[ri,ci]:.4f},{Z[ri,ci]:.4f}\n")
        self._pes_log(f"[2D-Contour] Data CSV saved → {csv_path}")

    # -------------------------------------------------------------------------

    def _plot_1d_pes(
        self,
        work_dir: str,
        x_vals,
        energies: list,
        xlabel: str = "Coordinate",
        ylabel: str = "Energy (Eh)",
        title: str = "PES Scan",
        filename: str = "pes_1d.png",
        relative_kcal: bool = True,
    ):
        """Generic 1-D PES plotter. Converts to kcal/mol relative if requested."""
        if not MATPLOTLIB_AVAILABLE:
            return
        import matplotlib.pyplot as plt
        EH2KCAL = 627.5094740631

        x = np.asarray(x_vals, dtype=float)
        y = np.asarray(energies, dtype=float)
        if relative_kcal:
            y = (y - y[0]) * EH2KCAL
            ylabel = "Relative Energy (kcal/mol)"

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(x, y, "-o", color="#388bfd", ms=4, lw=2)
        ax.fill_between(x, y, alpha=0.12, color="#388bfd")
        ax.axhline(0, color="#888", ls="--", lw=0.8)

        # Mark max
        max_i = int(np.argmax(y))
        ax.scatter([x[max_i]], [y[max_i]], color="#e05252", s=100, zorder=5,
                   label=f"Max ({y[max_i]:.2f})")
        ax.annotate(
            f"{y[max_i]:.2f}",
            (x[max_i], y[max_i]),
            textcoords="offset points", xytext=(6, 6),
            fontsize=8, color="#e05252",
        )

        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        out = os.path.join(work_dir, filename)
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[PES Plot] Saved → {out}")

    # -------------------------------------------------------------------------

    def _parse_xyz_trajectory(self, trj_path: str):
        """Parse a multi-frame XYZ trajectory (xtbscan.log, ORCA .trj, etc.).

        Returns (energies: list[float], geom_blocks: list[str]).
        Energy is read from the comment line: first float found.
        """
        energies, geoms = [], []
        if not os.path.exists(trj_path):
            return energies, geoms
        with open(trj_path, "r", errors="replace") as f:
            lines = f.readlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue
            try:
                n_at = int(line)
                comment = lines[i + 1] if i + 1 < len(lines) else ""
                m = re.search(r"energy:\s*([-\d.]+)", comment, re.IGNORECASE)
                if not m:
                    m = re.search(r"([-\d.]+)", comment)
                en = float(m.group(1)) if m else 0.0
                energies.append(en)
                geoms.append("".join(lines[i : i + 2 + n_at]))
                i += 2 + n_at
            except Exception:
                i += 1
        return energies, geoms

    # =========================================================================
    # FREE ENERGY SURFACE (FES) METHODS
    # =========================================================================

    def _compute_fes_from_populations(
        self,
        populations: list,
        coords: list,
        temperature: float = 298.15,
        work_dir: str = "",
        xlabel: str = "Coordinate",
        filename: str = "FES_1D.png",
    ) -> dict:
        """Compute 1-D Free Energy Surface from histogram populations via
        Boltzmann inversion: F(ξ) = -kT ln P(ξ) + const.

        Parameters
        ----------
        populations : list of float
            Population counts or probabilities at each bin.
        coords      : list of float
            Bin centre coordinate values.
        temperature : float
            Temperature in Kelvin (default 298.15 K).
        work_dir    : str
            Directory to save plot/report (optional).

        Returns
        -------
        dict: fes (kcal/mol array), coords, min_coord, min_fes, barriers
        """
        KB_KCAL = 0.001987204  # kcal mol⁻¹ K⁻¹
        kT = KB_KCAL * temperature

        p = np.array(populations, dtype=float)
        x = np.array(coords, dtype=float)

        # Avoid log(0)
        p = np.where(p <= 0, np.nan, p)
        fes = -kT * np.log(p / np.nanmax(p))
        fes -= np.nanmin(fes)  # shift minimum to 0

        # Locate minima and barriers
        valid = ~np.isnan(fes)
        fes_v = fes[valid]
        x_v = x[valid]
        min_idx = int(np.argmin(fes_v))
        max_idx = int(np.argmax(fes_v))

        result = {
            "fes": fes,
            "coords": x,
            "min_coord": float(x_v[min_idx]),
            "min_fes": float(fes_v[min_idx]),
            "max_coord": float(x_v[max_idx]),
            "max_fes": float(fes_v[max_idx]),
            "barrier": float(fes_v[max_idx] - fes_v[min_idx]),
            "temperature": temperature,
        }

        self._pes_log(
            f"[FES] T={temperature} K | "
            f"kT={kT:.4f} kcal/mol\n"
            f"  Global minimum: ξ={result['min_coord']:.4f}, F=0.00 kcal/mol\n"
            f"  Barrier peak  : ξ={result['max_coord']:.4f}, "
            f"F={result['barrier']:.3f} kcal/mol"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(x_v, fes_v, "-", color="#388bfd", lw=2, label=f"FES  T={temperature} K")
                ax.fill_between(x_v, fes_v, alpha=0.15, color="#388bfd")
                ax.scatter([result["min_coord"]], [0], color="#22c55e", s=100, zorder=5,
                           label=f"Min ({result['min_coord']:.3f})")
                ax.scatter([result["max_coord"]], [result["barrier"]], color="#e05252",
                           s=100, zorder=5, label=f"Barrier ({result['barrier']:.2f} kcal/mol)")
                ax.set_xlabel(xlabel)
                ax.set_ylabel("Free Energy (kcal/mol)")
                ax.set_title(f"Free Energy Surface  (T = {temperature} K)")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, filename)
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[FES] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _compute_fes_2d_from_populations(
        self,
        hist2d,
        x_edges,
        y_edges,
        temperature: float = 298.15,
        work_dir: str = "",
        xlabel: str = "CV1",
        ylabel: str = "CV2",
        filename: str = "FES_2D.png",
    ) -> dict:
        """Compute 2-D Free Energy Surface from a 2-D histogram via Boltzmann
        inversion.  Returns FES array in kcal/mol.

        Parameters
        ----------
        hist2d   : 2-D array-like, shape (ny, nx), population counts or weights.
        x_edges  : bin edges for CV1 (length nx+1).
        y_edges  : bin edges for CV2 (length ny+1).
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        H = np.asarray(hist2d, dtype=float)
        H = np.where(H <= 0, np.nan, H)
        F = -kT * np.log(H / np.nanmax(H))
        F -= np.nanmin(F)

        x_centers = 0.5 * (np.asarray(x_edges[:-1]) + np.asarray(x_edges[1:]))
        y_centers = 0.5 * (np.asarray(y_edges[:-1]) + np.asarray(y_edges[1:]))
        XX, YY = np.meshgrid(x_centers, y_centers)

        min_pos = np.unravel_index(np.nanargmin(F), F.shape)
        max_pos = np.unravel_index(np.nanargmax(F), F.shape)

        result = {
            "fes_2d": F,
            "x_centers": x_centers,
            "y_centers": y_centers,
            "min_coords": (float(XX[min_pos]), float(YY[min_pos])),
            "max_coords": (float(XX[max_pos]), float(YY[max_pos])),
            "barrier": float(np.nanmax(F)),
            "temperature": temperature,
        }

        self._pes_log(
            f"[2D-FES] T={temperature} K  barrier={result['barrier']:.3f} kcal/mol\n"
            f"  Min at CV1={result['min_coords'][0]:.3f}, CV2={result['min_coords'][1]:.3f}\n"
            f"  Max at CV1={result['max_coords'][0]:.3f}, CV2={result['max_coords'][1]:.3f}"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 6))
                F_plot = np.where(np.isnan(F), np.nanmax(F), F)
                levels = np.linspace(0, np.nanmax(F), 25)
                cf = ax.contourf(XX, YY, F_plot, levels=levels, cmap="RdYlGn_r")
                ax.contour(XX, YY, F_plot, levels=levels[::4], colors="k",
                           linewidths=0.5, alpha=0.6)
                cbar = fig.colorbar(cf, ax=ax)
                cbar.set_label("Free Energy (kcal/mol)")
                ax.scatter(*result["min_coords"], color="#22c55e", s=120, zorder=5,
                           label="Min", marker="*")
                ax.scatter(*result["max_coords"], color="#e05252", s=120, zorder=5,
                           label="Max", marker="^")
                ax.set_xlabel(xlabel)
                ax.set_ylabel(ylabel)
                ax.set_title(f"2-D Free Energy Surface  (T = {temperature} K)")
                ax.legend(fontsize=8)
                fig.tight_layout()
                out = os.path.join(work_dir, filename)
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[2D-FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[2D-FES] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _run_umbrella_sampling_setup(
        self,
        work_dir: str,
        mol_file: str,
        a1: int, a2: int,
        window_centers: list,
        spring_k: float = 50.0,
        charge: int = 0, mult: int = 1,
        n_steps: int = 5000,
        method: str = "gfn2",
    ) -> str:
        """Set up xTB umbrella sampling windows using a harmonic bias potential.

        For each window centre ξ₀ the method writes an xTB constraint file and
        runs a short MD.  Outputs are saved under work_dir/us_window_NNN/.
        WHAM analysis is delegated to _run_wham_analysis.

        Returns path to a summary file listing all window output dirs.
        """
        from platform import system as _os_sys
        xtb_exe = "xtb.exe" if _os_sys() == "Windows" else "xtb"
        if not is_tool_available("xtb"):
            raise RuntimeError("xTB not found on PATH.")

        self._pes_log(
            f"[US] Setting up {len(window_centers)} umbrella windows\n"
            f"  Atoms {a1}-{a2}, k={spring_k} kcal/mol/Å², n_steps={n_steps}"
        )
        summary_lines = []
        mol_src = os.path.join(work_dir, mol_file)

        for idx, xi in enumerate(window_centers):
            w_dir = os.path.join(work_dir, f"us_window_{idx:03d}")
            os.makedirs(w_dir, exist_ok=True)
            import shutil as _sh
            _sh.copy2(mol_src, w_dir)

            # xTB constraint input (harmonic spring on distance)
            cstr_path = os.path.join(w_dir, "xtb_us.inp")
            with open(cstr_path, "w") as f:
                f.write("$constrain\n")
                f.write(f"  force constant={spring_k:.4f}\n")
                f.write(f"  distance: {a1}, {a2}, {xi:.4f}\n")
                f.write("$end\n")
                f.write("$md\n")
                f.write(f"  time={n_steps * 0.5e-3:.2f}  # ps\n")
                f.write("  step=0.5\n")
                f.write(f"  temp=298.15\n")
                f.write("$end\n")

            cmd = f'"{xtb_exe}" {mol_file} --md --input xtb_us.inp'
            if charge:
                cmd += f" --chrg {charge}"
            if mult != 1:
                cmd += f" --uhf {mult - 1}"
            if method.lower() != "gfn2":
                cmd += f" --{method.lower()}"

            self._pes_log(f"[US] Window {idx:03d}  ξ₀={xi:.3f} Å — running MD …")
            p = subprocess.run(cmd, shell=True, cwd=w_dir,
                               capture_output=True, text=True)
            with open(os.path.join(w_dir, "xtb_us.log"), "w") as f:
                f.write(p.stdout + p.stderr)
            summary_lines.append(f"{idx}\t{xi:.4f}\t{w_dir}\n")

        summary_path = os.path.join(work_dir, "us_windows_summary.txt")
        with open(summary_path, "w") as f:
            f.write("window\txi0\tdir\n")
            f.writelines(summary_lines)
        self._pes_log(f"[US] All windows done. Summary → {summary_path}")
        return summary_path

    # -------------------------------------------------------------------------

    def _run_wham_analysis(
        self,
        summary_path: str,
        a1: int, a2: int,
        temperature: float = 298.15,
        n_bins: int = 50,
        tol: float = 1e-6,
        max_iter: int = 10000,
    ) -> dict:
        """Pure-Python WHAM (Weighted Histogram Analysis Method) to reconstruct
        the 1-D PMF (Potential of Mean Force) from umbrella-sampling windows.

        Reads the xTB MD trajectory (xtb.trj) from each window directory listed
        in the summary file, extracts the reaction coordinate (atom pair distance
        a1-a2), builds windowed histograms, and iterates WHAM equations to
        convergence.

        Returns dict: pmf (kcal/mol), bin_centers, barrier_fwd, barrier_rev.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature
        BETA = 1.0 / kT

        if not os.path.exists(summary_path):
            self._pes_log("[WHAM] Summary file not found.")
            return {}

        # --- Read window metadata ---
        windows = []
        with open(summary_path) as f:
            next(f)  # header
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 3:
                    windows.append({"xi0": float(parts[1]), "dir": parts[2]})

        if not windows:
            self._pes_log("[WHAM] No windows found in summary.")
            return {}

        self._pes_log(f"[WHAM] {len(windows)} windows loaded. Extracting distances …")

        def _extract_distances(w_dir):
            """Read xtb.trj and compute atom-pair distances (a1, a2)."""
            trj = os.path.join(w_dir, "xtb.trj")
            if not os.path.exists(trj):
                return []
            dists = []
            with open(trj, errors="replace") as f:
                lines = f.readlines()
            i = 0
            while i < len(lines):
                try:
                    n_at = int(lines[i].strip())
                    coords = []
                    for l in lines[i + 2 : i + 2 + n_at]:
                        p = l.split()
                        coords.append([float(p[1]), float(p[2]), float(p[3])])
                    if len(coords) >= max(a1, a2):
                        v = [coords[a1 - 1][k] - coords[a2 - 1][k] for k in range(3)]
                        dists.append(sum(x**2 for x in v) ** 0.5)
                    i += 2 + n_at
                except Exception:
                    i += 1
            return dists

        all_xi = [_extract_distances(w["dir"]) for w in windows]
        all_flat = [x for wl in all_xi for x in wl]
        if not all_flat:
            self._pes_log("[WHAM] No distance data extracted from trajectories.")
            return {}

        xi_min, xi_max = min(all_flat), max(all_flat)
        bin_edges = np.linspace(xi_min, xi_max, n_bins + 1)
        bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])

        # Build per-window histograms
        hists = []
        for wl in all_xi:
            h, _ = np.histogram(wl, bins=bin_edges)
            hists.append(h.astype(float))

        N_w = np.array([sum(wl) for wl in all_xi], dtype=float)
        xi0_arr = np.array([w["xi0"] for w in windows])
        # Spring constants (kcal/mol/Å² — hard-coded; could be read from summary)
        spring_k_arr = np.full(len(windows), 50.0)

        # --- WHAM iterations ---
        F_k = np.zeros(len(windows))  # window free energies (natural units: kT)
        for iteration in range(max_iter):
            # Denominator: Σ_k N_k exp(F_k - β U_k(ξ))
            denom = np.zeros(n_bins)
            for k, (xi0, spring_k) in enumerate(zip(xi0_arr, spring_k_arr)):
                bias = 0.5 * spring_k * (bin_centers - xi0) ** 2  # kcal/mol
                denom += N_w[k] * np.exp(F_k[k] - BETA * bias)

            # Numerator: total histogram
            H_total = sum(hists)
            rho = np.where(denom > 0, H_total / denom, 0.0)

            # Update F_k
            F_k_new = np.zeros(len(windows))
            for k, (xi0, spring_k) in enumerate(zip(xi0_arr, spring_k_arr)):
                bias = 0.5 * spring_k * (bin_centers - xi0) ** 2
                F_k_new[k] = -np.log(np.dot(rho, np.exp(-BETA * bias)) + 1e-300)

            F_k_new -= F_k_new[0]  # anchor to first window
            if np.max(np.abs(F_k_new - F_k)) < tol:
                self._pes_log(f"[WHAM] Converged in {iteration + 1} iterations.")
                break
            F_k = F_k_new

        # PMF = -kT ln ρ(ξ)
        pmf = np.where(rho > 0, -kT * np.log(rho), np.nan)
        pmf -= np.nanmin(pmf)

        valid = ~np.isnan(pmf)
        max_i = int(np.argmax(pmf[valid]))
        min_i = int(np.argmin(pmf[valid]))
        barrier_fwd = float(np.nanmax(pmf))

        self._pes_log(
            f"[WHAM] PMF barrier = {barrier_fwd:.3f} kcal/mol  "
            f"at ξ={bin_centers[np.nanargmax(pmf)]:.4f} Å"
        )

        # Write CSV
        work_dir = os.path.dirname(summary_path)
        csv_path = os.path.join(work_dir, "WHAM_PMF.csv")
        with open(csv_path, "w") as f:
            f.write("xi_Angstrom,PMF_kcalmol\n")
            for xi, pval in zip(bin_centers, pmf):
                f.write(f"{xi:.5f},{pval:.5f}\n")
        self._pes_log(f"[WHAM] PMF CSV saved → {csv_path}")

        # Plot
        if MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(bin_centers[valid], pmf[valid], "-o", ms=3,
                        color="#388bfd", lw=2, label="PMF (WHAM)")
                ax.fill_between(bin_centers[valid], pmf[valid], alpha=0.12,
                                color="#388bfd")
                ax.set_xlabel(f"Distance atoms {a1}-{a2} (Å)")
                ax.set_ylabel("PMF (kcal/mol)")
                ax.set_title(f"WHAM Potential of Mean Force  (T={temperature} K)")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "WHAM_PMF.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[WHAM] PMF plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[WHAM] Plot error: {exc}")

        return {
            "pmf": pmf,
            "bin_centers": bin_centers,
            "barrier_fwd": barrier_fwd,
            "F_windows": F_k * kT,
        }

    # =========================================================================
    # PERTURBATION THEORY METHODS (FEP / LRA / BAR)
    # =========================================================================

    def _compute_fep(
        self,
        energies_0: list,
        energies_1: list,
        temperature: float = 298.15,
        direction: str = "forward",
        work_dir: str = "",
    ) -> dict:
        """Free Energy Perturbation (FEP) — Zwanzig exponential average.

        ΔA = -kT ln < exp(-ΔU/kT) >₀   (forward, Zwanzig 1954)
        ΔA = +kT ln < exp(+ΔU/kT) >₁   (backward)

        Parameters
        ----------
        energies_0 : potential energies sampled at state 0 (kcal/mol).
        energies_1 : potential energies sampled at state 1 (kcal/mol) —
                     must correspond 1-to-1 with energies_0 (same configs).
        direction  : 'forward', 'backward', or 'both'.

        Returns
        -------
        dict: delta_A_fwd, delta_A_bwd, delta_A_bar (BAR estimate),
              overlap, convergence info.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        u0 = np.array(energies_0, dtype=float)
        u1 = np.array(energies_1, dtype=float)
        dU = u1 - u0   # ΔU = U₁ - U₀

        # --- Forward FEP (Zwanzig) ---
        dU_shifted = dU - dU.max()  # numerical stability
        delta_A_fwd = -kT * (np.log(np.mean(np.exp(-dU_shifted / kT))) + dU.max() / kT)

        # --- Backward FEP ---
        dU_b_shifted = -dU - (-dU).max()
        delta_A_bwd = kT * (np.log(np.mean(np.exp(-dU_b_shifted / kT))) + (-dU).max() / kT)

        # --- Simple BAR (Bennett Acceptance Ratio) estimate ---
        # Full iterative BAR would require root-finding; here use the average of fwd/bwd
        delta_A_bar = 0.5 * (delta_A_fwd - delta_A_bwd)

        # --- Phase-space overlap (Bhattacharyya coefficient approximation) ---
        n_bins = max(20, len(u0) // 10)
        all_vals = np.concatenate([dU, -dU])
        bins = np.linspace(all_vals.min(), all_vals.max(), n_bins + 1)
        h0, _ = np.histogram(dU, bins=bins, density=True)
        h1, _ = np.histogram(-dU, bins=bins, density=True)
        db = bins[1] - bins[0]
        overlap = float(np.sum(np.sqrt(h0 * h1)) * db)

        result = {
            "delta_A_fwd": delta_A_fwd,
            "delta_A_bwd": delta_A_bwd,
            "delta_A_bar": delta_A_bar,
            "overlap": overlap,
            "temperature": temperature,
            "n_samples": len(u0),
        }

        self._pes_log(
            f"[FEP]  T={temperature} K  n={len(u0)} samples\n"
            f"  ΔA (forward  FEP) = {delta_A_fwd:+.4f} kcal/mol\n"
            f"  ΔA (backward FEP) = {delta_A_bwd:+.4f} kcal/mol\n"
            f"  ΔA (BAR est.)     = {delta_A_bar:+.4f} kcal/mol\n"
            f"  Phase-space overlap (Bhattacharyya) = {overlap:.4f}"
        )
        if overlap < 0.05:
            self._pes_log(
                "[FEP] WARNING: Very low overlap (<0.05). "
                "FEP estimate unreliable — consider shorter λ spacing."
            )

        if work_dir and MATPLOTLIB_AVAILABLE:
            self._plot_fep_distribution(work_dir, dU, temperature, result)

        return result

    # -------------------------------------------------------------------------

    def _compute_ti(
        self,
        dU_dl_by_lambda: list,
        lambda_vals: list,
        temperature: float = 298.15,
        work_dir: str = "",
    ) -> dict:
        """Thermodynamic Integration (TI) — integrate ⟨∂U/∂λ⟩_λ over λ.

        Parameters
        ----------
        dU_dl_by_lambda : list of lists / arrays.
            Each element is a list of ∂U/∂λ samples at the corresponding λ.
        lambda_vals : list of float
            λ values in [0, 1] for each window.

        Returns
        -------
        dict: delta_A_ti, lambdas, mean_dUdl, se_dUdl, integrand_plot path.
        """
        lambdas = np.array(lambda_vals, dtype=float)
        means = np.array([np.mean(w) for w in dU_dl_by_lambda], dtype=float)
        stds = np.array([np.std(w, ddof=1) / max(len(w) ** 0.5, 1)
                         for w in dU_dl_by_lambda], dtype=float)

        # Trapezoidal integration
        delta_A = float(np.trapz(means, lambdas))

        result = {
            "delta_A_ti": delta_A,
            "lambdas": lambdas,
            "mean_dUdl": means,
            "se_dUdl": stds,
            "temperature": temperature,
        }

        self._pes_log(
            f"[TI]  λ from {lambdas[0]:.3f} to {lambdas[-1]:.3f}  "
            f"({len(lambdas)} windows)\n"
            f"  ΔA (TI trapz) = {delta_A:+.4f} kcal/mol"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 4))
                ax.plot(lambdas, means, "-o", color="#388bfd", lw=2, ms=5,
                        label="⟨∂U/∂λ⟩")
                ax.fill_between(lambdas, means - stds, means + stds,
                                alpha=0.25, color="#388bfd", label="±1 SE")
                ax.fill_between(lambdas, 0, means, alpha=0.12, color="#17a2b8")
                ax.axhline(0, color="#888", ls="--", lw=0.8)
                ax.set_xlabel("λ")
                ax.set_ylabel("⟨∂U/∂λ⟩ (kcal/mol)")
                ax.set_title(f"Thermodynamic Integration  ΔA = {delta_A:+.4f} kcal/mol")
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "TI_integrand.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[TI] Integrand plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[TI] Plot error: {exc}")

        return result

    # -------------------------------------------------------------------------

    def _compute_lra(
        self,
        dU_state0: list,
        dU_state1: list,
        temperature: float = 298.15,
    ) -> dict:
        """Linear Response Approximation (LRA) free energy estimate.

        ΔA_LRA = ½ (⟨ΔU⟩₀ + ⟨ΔU⟩₁)

        where ΔU = U₁ - U₀ sampled at states 0 and 1 respectively.
        Also computes the reorganisation energy:
            λ_reorg = ½ (⟨ΔU⟩₀ - ⟨ΔU⟩₁)

        Returns dict: delta_A_lra, lambda_reorg, mean_dU_0, mean_dU_1.
        """
        u0 = np.asarray(dU_state0, dtype=float)
        u1 = np.asarray(dU_state1, dtype=float)

        mean0 = float(np.mean(u0))
        mean1 = float(np.mean(u1))
        delta_A_lra = 0.5 * (mean0 + mean1)
        lambda_reorg = 0.5 * (mean0 - mean1)

        result = {
            "delta_A_lra": delta_A_lra,
            "lambda_reorg": lambda_reorg,
            "mean_dU_0": mean0,
            "mean_dU_1": mean1,
            "temperature": temperature,
        }

        self._pes_log(
            f"[LRA]  T={temperature} K\n"
            f"  ⟨ΔU⟩₀ = {mean0:+.4f} kcal/mol\n"
            f"  ⟨ΔU⟩₁ = {mean1:+.4f} kcal/mol\n"
            f"  ΔA_LRA       = {delta_A_lra:+.4f} kcal/mol\n"
            f"  λ_reorg      = {lambda_reorg:+.4f} kcal/mol"
        )
        return result

    # -------------------------------------------------------------------------

    def _compute_bar(
        self,
        energies_0: list,
        energies_1: list,
        temperature: float = 298.15,
        max_iter: int = 1000,
        tol: float = 1e-8,
    ) -> dict:
        """Bennett Acceptance Ratio (BAR) — iterative solution for ΔA.

        Solves  Σᵢ f(U₁ᵢ - U₀ᵢ - C) = Σⱼ f(U₀ⱼ - U₁ⱼ + C)
        where f(x) = 1/(1 + exp(x/kT))  (Fermi function).

        Parameters
        ----------
        energies_0 : ΔU = U₁-U₀ values sampled at state 0 (kcal/mol).
        energies_1 : ΔU = U₁-U₀ values sampled at state 1 (kcal/mol).

        Returns dict: delta_A_bar, n_iter, converged.
        """
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature

        u_fwd = np.asarray(energies_0, dtype=float)  # ΔU at state 0
        u_bwd = -np.asarray(energies_1, dtype=float)  # -ΔU at state 1

        n0, n1 = len(u_fwd), len(u_bwd)
        C = 0.0  # initial guess for ΔA (kT units)

        def _fermi(x):
            return np.where(x > 500, 0.0, 1.0 / (1.0 + np.exp(np.clip(x, -500, 500))))

        converged = False
        for it in range(max_iter):
            lhs = np.mean(_fermi((u_fwd - C) / kT))
            rhs = np.mean(_fermi((u_bwd + C) / kT))
            # Newton step
            C_new = C + kT * np.log(n0 * lhs / (n1 * rhs + 1e-300))
            if abs(C_new - C) < tol:
                converged = True
                C = C_new
                break
            C = C_new

        delta_A = float(C + kT * np.log(float(n1) / float(n0)))

        result = {
            "delta_A_bar": delta_A,
            "n_iter": it + 1,
            "converged": converged,
            "temperature": temperature,
        }

        self._pes_log(
            f"[BAR]  T={temperature} K  n0={n0} n1={n1}\n"
            f"  ΔA (BAR) = {delta_A:+.4f} kcal/mol  "
            f"({'converged' if converged else 'not converged'} in {it+1} iters)"
        )
        return result

    # -------------------------------------------------------------------------

    def _plot_fep_distribution(
        self,
        work_dir: str,
        dU: np.ndarray,
        temperature: float,
        fep_result: dict,
    ):
        """Plot forward/backward ΔU distributions and FEP convergence diagnostics."""
        if not MATPLOTLIB_AVAILABLE:
            return
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        # Left: histogram of ΔU
        ax = axes[0]
        ax.hist(dU, bins=40, color="#388bfd", alpha=0.7, density=True,
                label="ΔU = U₁-U₀ (state 0 samples)")
        ax.hist(-dU, bins=40, color="#e05252", alpha=0.5, density=True,
                label="-ΔU (state 1 samples)")
        ax.set_xlabel("ΔU (kcal/mol)")
        ax.set_ylabel("Density")
        ax.set_title("FEP Overlap Distribution")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.text(
            0.05, 0.95,
            f"Overlap = {fep_result['overlap']:.3f}",
            transform=ax.transAxes, va="top", fontsize=9,
            bbox=dict(boxstyle="round", fc="white", alpha=0.7),
        )

        # Right: block average of ΔA_fwd
        KB_KCAL = 0.001987204
        kT = KB_KCAL * temperature
        ax2 = axes[1]
        n = len(dU)
        block_sizes = np.unique(np.round(np.linspace(10, n, 40)).astype(int))
        block_dA = []
        for bs in block_sizes:
            chunk = dU[:bs]
            shifted = chunk - chunk.max()
            block_dA.append(
                -kT * (np.log(np.mean(np.exp(-shifted / kT))) + chunk.max() / kT)
            )
        ax2.plot(block_sizes, block_dA, "-o", ms=3, color="#388bfd", lw=1.5)
        ax2.axhline(fep_result["delta_A_fwd"], color="#e05252", ls="--", lw=1.2,
                    label=f"ΔA_fwd = {fep_result['delta_A_fwd']:+.3f}")
        ax2.axhline(fep_result["delta_A_bar"], color="#22c55e", ls=":", lw=1.2,
                    label=f"ΔA_BAR = {fep_result['delta_A_bar']:+.3f}")
        ax2.set_xlabel("Block size (samples)")
        ax2.set_ylabel("ΔA (kcal/mol)")
        ax2.set_title("FEP Block-Average Convergence")
        ax2.legend(fontsize=8)
        ax2.grid(True, alpha=0.3)

        fig.tight_layout()
        out = os.path.join(work_dir, "FEP_diagnostics.png")
        plt.savefig(out, dpi=200)
        plt.close(fig)
        self._pes_log(f"[FEP] Diagnostics plot saved → {out}")

    # -------------------------------------------------------------------------

    def _compute_alchemical_lambda_schedule(
        self,
        n_windows: int,
        schedule: str = "linear",
        softcore_alpha: float = 0.5,
    ) -> list:
        """Generate λ values for alchemical FEP/TI calculations.

        schedule options:
          'linear'    – uniform spacing in [0,1]
          'gauss-leg' – Gaussian-Legendre quadrature points (optimal for TI)
          'softcore'  – clustered near endpoints for better overlap
        """
        if schedule == "gauss-leg":
            try:
                from numpy.polynomial.legendre import leggauss
                pts, wts = leggauss(n_windows)
                lambdas = list(0.5 * (pts + 1))
            except Exception:
                lambdas = list(np.linspace(0, 1, n_windows))
        elif schedule == "softcore":
            # More windows near 0 and 1 for soft-core perturbations
            x = np.linspace(0, np.pi, n_windows)
            lambdas = list(0.5 * (1 - np.cos(x)))
        else:
            lambdas = list(np.linspace(0, 1, n_windows))

        self._pes_log(
            f"[Alchemical] λ schedule '{schedule}', {n_windows} windows:\n"
            f"  {[round(l, 4) for l in lambdas]}"
        )
        return lambdas

    # -------------------------------------------------------------------------

    def _fes_from_metadynamics_hills(
        self,
        hills_file: str,
        cv_range: tuple,
        n_bins: int = 100,
        temperature: float = 298.15,
        work_dir: str = "",
        cv_label: str = "CV (Å)",
        gamma: float = None,
    ) -> dict:
        """Reconstruct 1-D FES from a PLUMED-style HILLS file (well-tempered
        or standard metadynamics).

        The HILLS file format assumed (space-separated):
          time  CV  sigma  height  biasfactor

        FES is approximated by summing Gaussian hills (negative sum).
        Well-tempered bias: height is rescaled by exp factor.

        Parameters
        ----------
        hills_file : path to HILLS file.
        cv_range   : (cv_min, cv_max) tuple in Å.
        gamma      : well-tempered bias factor (γ). None → standard metadynamics.

        Returns dict: fes (kcal/mol), cv_grid, min_cv, barrier.
        """
        if not os.path.exists(hills_file):
            self._pes_log(f"[MetaD-FES] HILLS file not found: {hills_file}")
            return {}

        self._pes_log(f"[MetaD-FES] Reading HILLS from {hills_file} …")
        hills = []
        with open(hills_file, errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    try:
                        hills.append({
                            "time": float(parts[0]),
                            "cv": float(parts[1]),
                            "sigma": float(parts[2]),
                            "height": float(parts[3]),
                            "biasfactor": float(parts[4]) if len(parts) > 4 else 1.0,
                        })
                    except ValueError:
                        continue

        self._pes_log(f"[MetaD-FES] {len(hills)} Gaussian hills read.")
        cv_grid = np.linspace(cv_range[0], cv_range[1], n_bins)
        V_bias = np.zeros(n_bins)

        for h in hills:
            gauss = h["height"] * np.exp(
                -0.5 * ((cv_grid - h["cv"]) / h["sigma"]) ** 2
            )
            if gamma is not None and gamma > 1:
                # Well-tempered scaling factor
                KB_KCAL = 0.001987204
                kT = KB_KCAL * temperature
                gauss *= (gamma - 1) / gamma
            V_bias += gauss

        # FES = -V_bias (up to a constant)
        fes = -V_bias
        fes -= fes.min()

        min_i = int(np.argmin(fes))
        max_i = int(np.argmax(fes))
        barrier = float(fes[max_i] - fes[min_i])

        result = {
            "fes": fes,
            "cv_grid": cv_grid,
            "min_cv": float(cv_grid[min_i]),
            "max_cv": float(cv_grid[max_i]),
            "barrier": barrier,
            "n_hills": len(hills),
        }

        self._pes_log(
            f"[MetaD-FES] Barrier = {barrier:.3f} kcal/mol  "
            f"Min at CV={result['min_cv']:.4f}"
        )

        if work_dir and MATPLOTLIB_AVAILABLE:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(cv_grid, fes, "-", color="#388bfd", lw=2,
                        label="MetaD FES")
                ax.fill_between(cv_grid, fes, alpha=0.15, color="#388bfd")
                ax.scatter([cv_grid[min_i]], [0], color="#22c55e", s=120,
                           zorder=5, label="Min")
                ax.scatter([cv_grid[max_i]], [barrier], color="#e05252",
                           s=120, zorder=5,
                           label=f"Barrier {barrier:.2f} kcal/mol")
                ax.set_xlabel(cv_label)
                ax.set_ylabel("Free Energy (kcal/mol)")
                ax.set_title(
                    f"Metadynamics FES  "
                    f"({'well-tempered γ='+str(gamma) if gamma else 'standard'})"
                )
                ax.legend(fontsize=8)
                ax.grid(True, alpha=0.3)
                fig.tight_layout()
                out = os.path.join(work_dir, "MetaD_FES.png")
                plt.savefig(out, dpi=200)
                plt.close(fig)
                self._pes_log(f"[MetaD-FES] Plot saved → {out}")
            except Exception as exc:
                self._pes_log(f"[MetaD-FES] Plot error: {exc}")

        return result

    # =========================================================================
    # END EXTENDED PES / FES / PERTURBATION METHODS
    # =========================================================================

    # =========================================================================
    # FES & PERTURBATION TAB + PES SCAN LAUNCHERS
    # =========================================================================

    def _start_angle_scan(self):
        """Launch angle scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("Angle Scan", "Set Reactant XYZ first.")
        out_dir = os.path.join(os.path.dirname(mol), "pes_angle_scan")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            a1, a2, a3 = int(v["c1_a1"].get()), int(v["c1_a2"].get()), int(v["ang_a3"].get())
            a_start, a_end, n_steps = float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get())
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Angle Scan", f"Invalid parameter: {exc}")
        self._pes_log(f"[Angle Scan] Launching: atoms {a1}-{a2}-{a3}, {a_start}°→{a_end}° ({n_steps} steps)")
        threading.Thread(
            target=lambda: self._run_xtb_angle_scan(out_dir, mol_base, a1, a2, a3, a_start, a_end, n_steps, charge, mult),
            daemon=True,
        ).start()

    def _start_dihedral_scan(self):
        """Launch dihedral scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("Dihedral Scan", "Set Reactant XYZ first.")
        out_dir = os.path.join(os.path.dirname(mol), "pes_dihedral_scan")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            a1, a2 = int(v["c1_a1"].get()), int(v["c1_a2"].get())
            a3, a4 = int(v["ang_a3"].get()), int(v["dih_a4"].get())
            d_start, d_end, n_steps = float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get())
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Dihedral Scan", f"Invalid parameter: {exc}")
        self._pes_log(f"[Dihedral Scan] atoms {a1}-{a2}-{a3}-{a4}, {d_start}°→{d_end}°")
        threading.Thread(
            target=lambda: self._run_xtb_dihedral_scan(out_dir, mol_base, a1, a2, a3, a4, d_start, d_end, n_steps, charge, mult),
            daemon=True,
        ).start()

    def _start_orca_2d_pes(self):
        """Launch ORCA 2-D PES scan from PES tab controls."""
        import threading
        v = self._vars_pes
        mol = v["reactant"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("ORCA 2D PES", "Set Reactant XYZ first.")
        if not v["use_c2"].get():
            return messagebox.showerror("ORCA 2D PES", "Enable 'Coordinate 2' first.")
        out_dir = os.path.join(os.path.dirname(mol), "orca_2d_pes")
        os.makedirs(out_dir, exist_ok=True)
        import shutil as _sh
        _sh.copy2(mol, out_dir)
        mol_base = os.path.basename(mol)
        try:
            c1 = (int(v["c1_a1"].get()), int(v["c1_a2"].get()),
                  float(v["c1_start"].get()), float(v["c1_end"].get()), int(v["c1_steps"].get()))
            c2 = (int(v["c2_a1"].get()), int(v["c2_a2"].get()),
                  float(v["c2_start"].get()), float(v["c2_end"].get()), int(v["c2_steps"].get()))
            charge, mult = int(self._vars["charge"].get()), int(self._vars["mult"].get())
            cores = int(self._vars["cores"].get())
        except ValueError as exc:
            return messagebox.showerror("ORCA 2D PES", f"Invalid parameter: {exc}")
        self._pes_log("[ORCA 2D PES] Launching …")
        threading.Thread(
            target=lambda: self._run_orca_2d_pes(
                out_dir, mol_base, *c1, *c2, charge, mult, cores=cores),
            daemon=True,
        ).start()

    def _open_barrier_analysis_dialog(self):
        """Simple dialog to enter 3 energies (R / TS / P in Eh) and get barriers."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Barrier Analysis")
        dlg.configure(bg=_C["panel"])
        dlg.geometry("400x260")
        dlg.grab_set()
        dlg.transient(self.root)
        tk.Label(dlg, text="Enter energies in Hartree (Eh):", bg=_C["panel"],
                 fg=_C["accent"], font=("Segoe UI", 11, "bold")).pack(pady=(14, 6))
        vars_dlg = {}
        for lbl, key, default in [
            ("Reactant E (Eh):", "e_r", "-10.000000"),
            ("TS       E (Eh):", "e_ts", "-9.980000"),
            ("Product  E (Eh):", "e_p", "-9.990000"),
            ("Temperature (K):", "temp", "298.15"),
        ]:
            row = tk.Frame(dlg, bg=_C["panel"])
            row.pack(fill="x", padx=20, pady=3)
            tk.Label(row, text=lbl, bg=_C["panel"], fg=_C["text"],
                     width=22, anchor="w").pack(side="left")
            v = tk.StringVar(value=default)
            vars_dlg[key] = v
            tk.Entry(row, textvariable=v, bg=_C["entry"], fg=_C["text"],
                     bd=0, width=16).pack(side="left", padx=4)

        def _run():
            try:
                e_r = float(vars_dlg["e_r"].get())
                e_ts = float(vars_dlg["e_ts"].get())
                e_p = float(vars_dlg["e_p"].get())
                temp = float(vars_dlg["temp"].get())
            except ValueError:
                return messagebox.showerror("Barrier", "Enter valid numbers.", parent=dlg)
            out = self._vars_pes["reactant"].get()
            work_dir = os.path.dirname(out) if out else ""
            self._ts_barrier_analysis(e_r, e_ts, e_p, work_dir=work_dir)
            dlg.destroy()

        tk.Button(dlg, text="Compute Barriers", command=_run,
                  bg=_C["green"], fg="black",
                  font=("Segoe UI", 11, "bold"), pady=6).pack(pady=12)

    # -------------------------------------------------------------------------

    def _build_fes_tab(self, parent):
        """Free Energy Surface & Perturbation Theory tab."""
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        # ── Sub-tab 1: Umbrella Sampling / WHAM ──────────────────────────────
        tab_us = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_us, text=" Umbrella / WHAM ")

        us_top = tk.Frame(tab_us, bg=_C["bg"])
        us_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(us_top, text="Umbrella Sampling & WHAM PMF",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        pane_us = tk.Frame(us_top, bg=_C["panel"])
        pane_us.pack(fill="x", pady=6)

        def _lrow(parent, label, key, browse=False, btype="file"):
            row = tk.Frame(parent, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=28, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if browse:
                def _b(k=key, bt=btype):
                    fp = (filedialog.askopenfilename() if bt == "file"
                          else filedialog.askdirectory())
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white",
                          command=_b).pack(side="left")

        _lrow(pane_us, "Molecule XYZ:", "us_mol", browse=True)
        for label, key in [("Atom 1 Index:", "us_a1"), ("Atom 2 Index:", "us_a2"),
                            ("Window centres (comma-sep Å):", "us_centers"),
                            ("Spring k (kcal/mol/Å²):", "us_spring_k"),
                            ("MD steps per window:", "us_steps"),
                            ("Temperature (K):", "temperature"),
                            ("N bins (WHAM):", "n_bins"),
                            ("US summary file (for WHAM):", "us_summary"),
                            ("Output folder:", "fes_out")]:
            _lrow(pane_us, label, key,
                  browse=(key in ("us_summary", "fes_out")),
                  btype=("file" if key == "us_summary" else "dir"))

        btn_us = tk.Frame(us_top, bg=_C["bg"])
        btn_us.pack(fill="x", pady=6)
        tk.Button(btn_us, text=" ▶ Setup US Windows ",
                  command=self._launch_umbrella_setup,
                  bg=_C["green"], fg="black",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(side="left", padx=4)
        tk.Button(btn_us, text=" ▶ Run WHAM Analysis ",
                  command=self._launch_wham,
                  bg="#17a2b8", fg="white",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(side="left", padx=4)

        # ── Sub-tab 2: Metadynamics FES ───────────────────────────────────────
        tab_meta = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_meta, text=" MetaD FES ")

        meta_top = tk.Frame(tab_meta, bg=_C["bg"])
        meta_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(meta_top, text="Metadynamics Free Energy Surface (HILLS → FES)",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        pane_meta = tk.Frame(meta_top, bg=_C["panel"])
        pane_meta.pack(fill="x", pady=6)

        for label, key, brs in [
            ("HILLS file (PLUMED):", "hills_file", True),
            ("CV min:", "hills_cv_min", False),
            ("CV max:", "hills_cv_max", False),
            ("CV axis label:", "hills_cv_label", False),
            ("Well-tempered γ (blank=standard):", "hills_gamma", False),
            ("N bins:", "n_bins", False),
            ("Temperature (K):", "temperature", False),
            ("Output folder:", "fes_out", True),
        ]:
            row = tk.Frame(pane_meta, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=34, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if brs:
                def _b(k=key):
                    fp = filedialog.askopenfilename() if k == "hills_file" else filedialog.askdirectory()
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white", command=_b).pack(side="left")

        tk.Button(meta_top, text=" ▶ Reconstruct FES from HILLS ",
                  command=self._launch_metad_fes,
                  bg="#6f42c1", fg="white",
                  font=("Segoe UI", 11, "bold"), padx=16, pady=4).pack(anchor="w", pady=8)

        # ── Sub-tab 3: FEP / TI / LRA / BAR ─────────────────────────────────
        tab_fep = tk.Frame(nb, bg=_C["bg"])
        nb.add(tab_fep, text=" FEP / TI / BAR ")

        fep_top = tk.Frame(tab_fep, bg=_C["bg"])
        fep_top.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(fep_top, text="Free Energy Perturbation (FEP)  ·  TI  ·  BAR  ·  LRA",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 12, "bold")).pack(anchor="w")

        info = (
            "Load two CSV files each containing one column of energies (kcal/mol).\n"
            "  • File 0 = ΔU = U₁–U₀ values sampled at state 0  (forward FEP)\n"
            "  • File 1 = ΔU = U₁–U₀ values sampled at state 1  (backward FEP / BAR)\n"
            "TI: provide ∂U/∂λ CSV files per λ window (one value per row per window, comma-separated header = lambda values)."
        )
        tk.Label(fep_top, text=info, bg=_C["bg"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic"), justify="left", wraplength=700).pack(anchor="w", pady=4)

        pane_fep = tk.Frame(fep_top, bg=_C["panel"])
        pane_fep.pack(fill="x", pady=6)

        for label, key in [
            ("Energy file 0 (state 0 samples CSV):", "fep_file0"),
            ("Energy file 1 (state 1 samples CSV):", "fep_file1"),
            ("Temperature (K):", "temperature"),
            ("Output folder:", "fes_out"),
            ("λ schedule (linear/gauss-leg/softcore):", "lambda_schedule"),
            ("N λ windows:", "n_lambda"),
        ]:
            row = tk.Frame(pane_fep, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=38, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_fes[key], bg=_C["entry"],
                     fg=_C["text"], bd=0).pack(side="left", fill="x", expand=True, padx=4)
            if key in ("fep_file0", "fep_file1"):
                def _b(k=key):
                    fp = filedialog.askopenfilename(
                        filetypes=[("CSV", "*.csv"), ("Text", "*.txt"), ("All", "*")])
                    if fp:
                        self._vars_fes[k].set(fp)
                tk.Button(row, text="...", bg=_C["accent"], fg="white", command=_b).pack(side="left")

        btn_fep = tk.Frame(fep_top, bg=_C["bg"])
        btn_fep.pack(fill="x", pady=8)
        for label, cmd, col in [
            (" ▶ Run FEP (Zwanzig) ", self._launch_fep, "#e05252"),
            (" ▶ Run BAR (iterative) ", self._launch_bar, "#388bfd"),
            (" ▶ Run LRA ", self._launch_lra, "#22c55e"),
            (" λ Schedule Preview ", self._launch_lambda_preview, _C["panel"]),
        ]:
            tk.Button(btn_fep, text=label, command=cmd,
                      bg=col, fg=("white" if col != _C["panel"] else _C["text"]),
                      font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="left", padx=4)

        # ── Shared terminal log ───────────────────────────────────────────────
        for tab, name in [(tab_us, "us"), (tab_meta, "meta"), (tab_fep, "fep")]:
            log_f = tk.Frame(tab, bg=_C["bg"])
            log_f.pack(fill="both", expand=True, padx=8, pady=(4, 6))
            tk.Label(log_f, text="Log:", bg=_C["bg"], fg=_C["muted"],
                     font=("Segoe UI", 8, "italic")).pack(anchor="w")
            term = tk.Text(log_f, bg="#0c0c0c", fg="#d4d4d4",
                           font=("Consolas", 9), wrap="none",
                           state="disabled", height=10)
            term.pack(fill="both", expand=True)
            sb = tk.Scrollbar(log_f, orient="vertical", command=term.yview)
            sb.pack(side="right", fill="y")
            term.config(yscrollcommand=sb.set)
            setattr(self, f"_fes_term_{name}", term)

    # ── FES tab launcher helpers ──────────────────────────────────────────────

    def _fes_log(self, msg: str, tab: str = "us"):
        """Thread-safe log to the FES sub-tab terminal."""
        term = getattr(self, f"_fes_term_{tab}", None)
        if term is None:
            self._pes_log(msg)
            return
        def _do():
            term.config(state="normal")
            term.insert("end", msg + "\n")
            term.see("end")
            term.config(state="disabled")
        self.root.after(0, _do)

    def _launch_umbrella_setup(self):
        import threading
        v = self._vars_fes
        mol = v["us_mol"].get().strip()
        if not mol or not os.path.isfile(mol):
            return messagebox.showerror("US", "Set molecule XYZ first.")
        out = v["fes_out"].get().strip() or os.path.join(os.path.dirname(mol), "umbrella_sampling")
        os.makedirs(out, exist_ok=True)
        import shutil as _sh; _sh.copy2(mol, out)
        mol_base = os.path.basename(mol)
        try:
            a1, a2 = int(v["us_a1"].get()), int(v["us_a2"].get())
            centers = [float(x.strip()) for x in v["us_centers"].get().split(",")]
            spring_k = float(v["us_spring_k"].get())
            n_steps = int(v["us_steps"].get())
            temp = float(v["temperature"].get())
            charge = int(self._vars["charge"].get())
            mult = int(self._vars["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("US", str(exc))
        self._fes_log(f"[US] Setting up {len(centers)} windows …", "us")
        def _worker():
            try:
                summary = self._run_umbrella_sampling_setup(
                    out, mol_base, a1, a2, centers, spring_k, charge, mult, n_steps)
                self._vars_fes["us_summary"].set(summary)
                self._fes_log(f"[US] Done. Summary: {summary}", "us")
            except Exception as exc:
                self._fes_log(f"[US] ERROR: {exc}", "us")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_wham(self):
        import threading
        v = self._vars_fes
        summary = v["us_summary"].get().strip()
        if not summary or not os.path.isfile(summary):
            return messagebox.showerror("WHAM", "Provide the US summary file (us_windows_summary.txt).")
        try:
            a1, a2 = int(v["us_a1"].get()), int(v["us_a2"].get())
            temp = float(v["temperature"].get())
            n_bins = int(v["n_bins"].get())
        except ValueError as exc:
            return messagebox.showerror("WHAM", str(exc))
        self._fes_log("[WHAM] Starting …", "us")
        threading.Thread(
            target=lambda: self._run_wham_analysis(summary, a1, a2, temp, n_bins),
            daemon=True,
        ).start()

    def _launch_metad_fes(self):
        import threading
        v = self._vars_fes
        hills = v["hills_file"].get().strip()
        if not hills or not os.path.isfile(hills):
            return messagebox.showerror("MetaD FES", "Select a HILLS file.")
        out = v["fes_out"].get().strip() or os.path.dirname(hills)
        try:
            cv_min = float(v["hills_cv_min"].get())
            cv_max = float(v["hills_cv_max"].get())
            temp = float(v["temperature"].get())
            n_bins = int(v["n_bins"].get())
            gamma_s = v["hills_gamma"].get().strip()
            gamma = float(gamma_s) if gamma_s else None
            cv_label = v["hills_cv_label"].get() or "CV"
        except ValueError as exc:
            return messagebox.showerror("MetaD FES", str(exc))
        self._fes_log("[MetaD FES] Reconstructing …", "meta")
        threading.Thread(
            target=lambda: self._fes_from_metadynamics_hills(
                hills, (cv_min, cv_max), n_bins, temp, out, cv_label, gamma),
            daemon=True,
        ).start()

    def _load_energy_csv(self, path: str) -> list:
        """Read a single-column CSV/TXT of energy values (kcal/mol). Returns list of floats."""
        vals = []
        with open(path, errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    vals.append(float(line.split(",")[0]))
                except ValueError:
                    continue
        return vals

    def _launch_fep(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("FEP", "Load both energy CSV files.")
        out = v["fes_out"].get().strip() or os.path.dirname(f0)
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("FEP", str(exc))
        self._fes_log("[FEP] Loading data …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                self._fes_log(f"[FEP] n0={len(u0)} n1={len(u1)}", "fep")
                result = self._compute_fep(u0, u1, temp, work_dir=out)
            except Exception as exc:
                self._fes_log(f"[FEP] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_bar(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("BAR", "Load both energy CSV files.")
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("BAR", str(exc))
        self._fes_log("[BAR] Running …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                result = self._compute_bar(u0, u1, temp)
                self._fes_log(
                    f"[BAR] ΔA = {result['delta_A_bar']:+.4f} kcal/mol  "
                    f"({'converged' if result['converged'] else 'not converged'}  "
                    f"in {result['n_iter']} iterations)", "fep")
            except Exception as exc:
                self._fes_log(f"[BAR] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_lra(self):
        import threading
        v = self._vars_fes
        f0, f1 = v["fep_file0"].get().strip(), v["fep_file1"].get().strip()
        if not (f0 and f1 and os.path.isfile(f0) and os.path.isfile(f1)):
            return messagebox.showerror("LRA", "Load both energy CSV files.")
        try:
            temp = float(v["temperature"].get())
        except ValueError as exc:
            return messagebox.showerror("LRA", str(exc))
        self._fes_log("[LRA] Computing …", "fep")
        def _worker():
            try:
                u0 = self._load_energy_csv(f0)
                u1 = self._load_energy_csv(f1)
                result = self._compute_lra(u0, u1, temp)
                self._fes_log(
                    f"[LRA] ΔA_LRA = {result['delta_A_lra']:+.4f}  "
                    f"λ_reorg = {result['lambda_reorg']:+.4f} kcal/mol", "fep")
            except Exception as exc:
                self._fes_log(f"[LRA] ERROR: {exc}", "fep")
        threading.Thread(target=_worker, daemon=True).start()

    def _launch_lambda_preview(self):
        """Show a small plot of the chosen λ schedule."""
        try:
            n = int(self._vars_fes["n_lambda"].get())
            schedule = self._vars_fes["lambda_schedule"].get().strip() or "linear"
        except ValueError:
            return messagebox.showerror("λ Schedule", "Enter a valid N λ windows.")
        lambdas = self._compute_alchemical_lambda_schedule(n, schedule)
        if not MATPLOTLIB_AVAILABLE:
            self._fes_log(f"[λ] Schedule ({schedule}, {n}): {lambdas}", "fep")
            return
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.plot(range(n), lambdas, "o-", color="#388bfd")
        ax.set_xlabel("Window index")
        ax.set_ylabel("λ")
        ax.set_title(f"λ schedule: {schedule}  (N={n})")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        plt.show()

    # =========================================================================
    # NEW TAB BUILDERS — NEB/TS, Reaction Library, PES Tutorial
    # =========================================================================

    def _build_neb_tab(self, parent):
        """Dedicated NEB / TS-Search tab."""
        top = tk.Frame(parent, bg=_C["bg"])
        top.pack(fill="both", expand=True, padx=10, pady=8)

        tk.Label(top, text="NEB / Transition State Search",
                 bg=_C["bg"], fg=_C["green"], font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))

        pane = tk.Frame(top, bg=_C["panel"], bd=1, relief="flat")
        pane.pack(fill="x", pady=4)

        def _browse_neb(key):
            fp = filedialog.askopenfilename(title=f"Select {key.title()} XYZ",
                                            filetypes=[("XYZ", "*.xyz"), ("All", "*")])
            if fp:
                self._vars_neb[key].set(fp)

        for key, label in [("reactant", "Reactant (start) XYZ:"),
                            ("product",  "Product  (end)   XYZ:")]:
            row = tk.Frame(pane, bg=_C["panel"])
            row.pack(fill="x", padx=8, pady=3)
            tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                     width=24, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            tk.Entry(row, textvariable=self._vars_neb[key], bg=_C["entry"],
                     fg=_C["text"], bd=0, font=("Consolas", 9)).pack(side="left", fill="x", expand=True, padx=4)
            tk.Button(row, text="...", bg=_C["accent"], fg="white",
                      command=lambda k=key: _browse_neb(k)).pack(side="left")

        # Parameter row
        params = tk.Frame(pane, bg=_C["panel"])
        params.pack(fill="x", padx=8, pady=4)
        for label, key, width in [
            ("Engine:",     "engine",        10),
            ("Images:",     "images",         5),
            ("Spring k:",   "spring_k",       7),
            ("Charge:",     "charge",          5),
            ("Multiplicity:", "mult",          5),
            ("Max Iter:",   "max_iter",        6),
        ]:
            tk.Label(params, text=label, bg=_C["panel"], fg=_C["text"],
                     font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
            if key == "engine":
                ttk.Combobox(params, textvariable=self._vars_neb[key],
                             values=["xtb", "orca"], width=width,
                             state="readonly").pack(side="left", padx=(0, 6))
            else:
                tk.Entry(params, textvariable=self._vars_neb[key], width=width,
                         bg=_C["entry"], fg=_C["text"], bd=0).pack(side="left", padx=(0, 6))

        chk_row = tk.Frame(pane, bg=_C["panel"])
        chk_row.pack(fill="x", padx=8, pady=(2, 6))
        tk.Checkbutton(chk_row, text="Run TS refinement after NEB",
                       variable=self._vars_neb["run_ts_refine"],
                       bg=_C["panel"], fg=_C["text"], selectcolor=_C["entry"],
                       font=("Segoe UI", 9)).pack(side="left", padx=4)
        tk.Checkbutton(chk_row, text="Compute Hessian at TS",
                       variable=self._vars_neb["ts_hess"],
                       bg=_C["panel"], fg=_C["text"], selectcolor=_C["entry"],
                       font=("Segoe UI", 9)).pack(side="left", padx=4)

        # Action buttons
        btn_row = tk.Frame(top, bg=_C["bg"])
        btn_row.pack(fill="x", pady=6)
        tk.Button(btn_row, text=" ▶  Run NEB ", command=self._start_neb,
                  bg=_C["green"], fg="black", font=("Segoe UI", 11, "bold"),
                  padx=20, pady=4).pack(side="left", padx=4)
        tk.Button(btn_row, text=" ✗  Stop ", command=self._stop_neb,
                  bg=_C["red"], fg="white", font=("Segoe UI", 11, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)
        tk.Button(btn_row, text=" Open Output Folder ",
                  command=self._open_neb_output_folder,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 10),
                  padx=10, pady=4).pack(side="left", padx=4)

        # Terminal log widget
        log_frame = tk.Frame(top, bg=_C["bg"])
        log_frame.pack(fill="both", expand=True, pady=(4, 0))
        tk.Label(log_frame, text="NEB Log:", bg=_C["bg"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._neb_term = tk.Text(log_frame, bg="#0c0c0c", fg="#d4d4d4",
                                  font=("Consolas", 9), wrap="none",
                                  state="disabled", height=20)
        self._neb_term.pack(fill="both", expand=True)
        nsb = tk.Scrollbar(log_frame, orient="vertical", command=self._neb_term.yview)
        nsb.pack(side="right", fill="y")
        self._neb_term.config(yscrollcommand=nsb.set)

    def _neb_log(self, msg: str):
        """Append message to NEB terminal log (thread-safe)."""
        def _do():
            self._neb_term.config(state="normal")
            self._neb_term.insert("end", msg + "\n")
            self._neb_term.see("end")
            self._neb_term.config(state="disabled")
        self.root.after(0, _do)

    def _stop_neb(self):
        """Signal the NEB worker to stop by setting is_running=False."""
        self.is_running = False
        self._neb_log("[NEB] Stop requested — current step will finish then exit.")

    def _open_neb_output_folder(self):
        """Open the NEB output folder in Explorer."""
        reactant = self._vars_neb["reactant"].get().strip()
        folder = os.path.join(os.path.dirname(reactant), "neb_run") if reactant else ""
        if not folder or not os.path.isdir(folder):
            folder = self._vars["out"].get().strip()
        if folder and os.path.isdir(folder):
            os.startfile(folder)
        else:
            messagebox.showinfo("Open Folder", "Output folder not found yet — run NEB first.")

    def _start_neb(self):
        """Launch NEB/TS worker thread."""
        v = {k: (var.get() if not isinstance(var, tk.BooleanVar) else var.get())
             for k, var in self._vars_neb.items()}
        if not v["reactant"] or not os.path.isfile(v["reactant"]):
            return messagebox.showerror("NEB", "Reactant XYZ file missing or invalid.")
        if not v["product"] or not os.path.isfile(v["product"]):
            return messagebox.showerror("NEB", "Product XYZ file missing or invalid.")
        self._neb_log(f"[NEB] Starting NEB with engine={v['engine']}, images={v['images']}")
        threading.Thread(target=self._worker_neb, args=(v,), daemon=True).start()

    def _worker_neb(self, v: dict):
        """Background worker — calls existing NEB/path engine."""
        import traceback
        out_dir = os.path.join(os.path.dirname(v["reactant"]), "neb_run")
        os.makedirs(out_dir, exist_ok=True)
        try:
            engine = v["engine"].lower()
            if engine == "orca":
                self._neb_log("[NEB] Running ORCA NEB-CI …")
                result = self._run_orca_neb(
                    reactant_xyz=v["reactant"],
                    product_xyz=v["product"],
                    out_dir=out_dir,
                    images=int(v["images"]),
                    charge=int(v["charge"]),
                    mult=int(v["mult"]),
                )
            else:
                self._neb_log("[NEB] Running xTB path (NEB-like) …")
                result = self._run_xtb_path(
                    reactant_xyz=v["reactant"],
                    product_xyz=v["product"],
                    out_dir=out_dir,
                    images=int(v["images"]),
                    charge=int(v["charge"]),
                    mult=int(v["mult"]),
                )
            if isinstance(result, dict):
                self._neb_log(f"[NEB] Done. Status: {result.get('status', 'unknown')}")
                if result.get("ts_energy"):
                    self._neb_log(f"[NEB] TS Energy: {result['ts_energy']:.6f} Eh")
            else:
                self._neb_log(f"[NEB] Done. Output: {result}")
        except Exception:
            self._neb_log(f"[NEB] ERROR:\n{traceback.format_exc()}")

    # -------------------------------------------------------------------------

    def _build_reaction_library_tab(self, parent):
        """Reaction Library browser tab."""
        tk.Label(parent, text="Reaction Library — Curated Presets",
                 bg=_C["bg"], fg=_C["green"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=10, pady=(8, 4))

        pane = tk.Frame(parent, bg=_C["bg"])
        pane.pack(fill="both", expand=True, padx=10, pady=4)

        # Left: treeview
        left = tk.Frame(pane, bg=_C["panel"], width=280)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="Reactions", bg=_C["panel"], fg=_C["accent"],
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=6, pady=4)

        tv = ttk.Treeview(left, columns=("type",), show="tree headings",
                          selectmode="browse")
        tv.heading("#0", text="Name")
        tv.heading("type", text="Type")
        tv.column("#0", width=190)
        tv.column("type", width=110, stretch=False)
        tv.pack(fill="both", expand=True, padx=4, pady=4)
        tsb = tk.Scrollbar(left, orient="vertical", command=tv.yview)
        tsb.pack(side="right", fill="y")
        tv.config(yscrollcommand=tsb.set)

        categories: dict[str, list] = {}
        for name, info in REACTION_LIBRARY.items():
            cat = info.get("type", "Other")
            categories.setdefault(cat, []).append(name)

        cat_nodes: dict[str, str] = {}
        for cat, names in sorted(categories.items()):
            node = tv.insert("", "end", text=f"  {cat}", values=("",), open=True,
                             tags=("cat",))
            cat_nodes[cat] = node
            for n in names:
                tv.insert(node, "end", text=n, iid=n,
                          values=(REACTION_LIBRARY[n].get("type", ""),))

        tv.tag_configure("cat", foreground="#e0b040")

        # Right: detail panel
        right = tk.Frame(pane, bg=_C["panel"])
        right.pack(side="left", fill="both", expand=True)

        detail_title = tk.Label(right, text="Select a reaction →", bg=_C["panel"],
                                fg=_C["accent"], font=("Segoe UI", 11, "bold"),
                                wraplength=500, justify="left")
        detail_title.pack(anchor="w", padx=10, pady=(8, 2))

        detail_txt = tk.Text(right, bg=_C["entry"], fg=_C["text"],
                             font=("Consolas", 9), wrap="word", height=12,
                             bd=0, state="disabled")
        detail_txt.pack(fill="both", expand=True, padx=10, pady=4)

        apply_row = tk.Frame(right, bg=_C["panel"])
        apply_row.pack(fill="x", padx=10, pady=6)
        self._rxn_lib_selected: str = ""

        def _on_select(_evt):
            iid = tv.focus()
            if not iid or iid not in REACTION_LIBRARY:
                return
            self._rxn_lib_selected = iid
            info = REACTION_LIBRARY[iid]
            detail_title.config(text=iid)
            dist = info.get("distance", ("?", "?"))
            body = (
                f"Type         : {info.get('type', 'N/A')}\n"
                f"Distance (Å) : {dist[0]:.1f} – {dist[1]:.1f}\n"
                f"Anchor role  : {info.get('anchor_role', 'N/A')}\n"
                f"Guest role   : {info.get('guest_role', 'N/A')}\n\n"
                f"Description  :\n  {info.get('description', '')}\n\n"
                f"Reference    :\n  {info.get('ref', 'N/A')}\n"
            )
            detail_txt.config(state="normal")
            detail_txt.delete("1.0", "end")
            detail_txt.insert("end", body)
            detail_txt.config(state="disabled")

        tv.bind("<<TreeviewSelect>>", _on_select)

        def _apply_to_pipeline():
            if not self._rxn_lib_selected:
                return
            info = REACTION_LIBRARY[self._rxn_lib_selected]
            rtype = info.get("type", "Non-covalent")
            # Map library type to pipeline combo values
            match = rtype if rtype in REACTION_TYPE_CHOICES else "Non-covalent"
            self._vars["reaction_type"].set(match)
            self._append_text(
                f"\n[Reaction Library] Applied: {self._rxn_lib_selected}\n"
                f"  Reaction type set to: {match}\n"
                f"  Typical distance: {info.get('distance', ('?','?'))[0]:.1f}–{info.get('distance',('?','?'))[1]:.1f} Å\n"
            )
            self.nb.select(self.tab_main)

        def _apply_to_neb():
            if not self._rxn_lib_selected:
                return
            self._append_text(f"\n[Reaction Library → NEB] Switched to NEB tab for: {self._rxn_lib_selected}\n")
            self.nb.select(self.tab_neb)

        tk.Button(apply_row, text="Apply to Pipeline Tab", command=_apply_to_pipeline,
                  bg=_C["green"], fg="black", font=("Segoe UI", 10, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)
        tk.Button(apply_row, text="Apply to NEB Tab", command=_apply_to_neb,
                  bg=_C["accent"], fg="white", font=("Segoe UI", 10, "bold"),
                  padx=14, pady=4).pack(side="left", padx=4)

        # Search bar
        search_row = tk.Frame(right, bg=_C["panel"])
        search_row.pack(fill="x", padx=10, pady=(0, 6))
        tk.Label(search_row, text="Search:", bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9)).pack(side="left")
        search_var = tk.StringVar()
        tk.Entry(search_row, textvariable=search_var, bg=_C["entry"], fg=_C["text"],
                 bd=0, font=("Segoe UI", 9), width=28).pack(side="left", padx=6)

        def _search(_evt=None):
            q = search_var.get().lower()
            tv.selection_remove(*tv.selection())
            for iid in REACTION_LIBRARY:
                try:
                    if q in iid.lower() or q in REACTION_LIBRARY[iid].get("type", "").lower():
                        tv.focus(iid)
                        tv.selection_set(iid)
                        tv.see(iid)
                        _on_select(None)
                        break
                except Exception:
                    pass

        search_var.trace_add("write", lambda *_: _search())

    # =========================================================================
    # PREBIOTIC CHEMISTRY MODULE
    # =========================================================================

    # ── Backend computation helpers ───────────────────────────────────────────

    def _prebiotic_match_conditions(
        self,
        rxn_data: dict,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
    ) -> dict:
        """Score how well user conditions match a prebiotic reaction entry.

        Returns dict with keys:
          score       (0–100, higher = better match)
          T_match     (True/False/partial)
          pH_match
          P_match
          atm_match   fraction of required gases present
          mineral_match fraction of catalysts present
          warnings    list of text warnings
          suggestions list of optimisation suggestions
        """
        warnings = []
        suggestions = []
        score = 0.0

        # Temperature
        t_range = rxn_data.get("T_K", (None, None, None))
        t_min, t_max, t_opt = (t_range + (None,))[:3] if len(t_range) >= 2 else (None, None, None)
        t_match = "unknown"
        if t_min is not None and t_max is not None:
            if t_min <= T_K <= t_max:
                t_match = True
                score += 30
                if t_opt is not None:
                    deviation = abs(T_K - t_opt) / max(t_max - t_min, 1)
                    score += max(0, 10 * (1 - deviation))
            else:
                t_match = False
                if T_K < t_min:
                    warnings.append(f"Temperature {T_K} K is below minimum {t_min} K.")
                    suggestions.append(f"Raise temperature to at least {t_min} K ({t_min - 273:.0f} °C).")
                else:
                    warnings.append(f"Temperature {T_K} K exceeds maximum {t_max} K.")
                    suggestions.append(f"Lower temperature below {t_max} K ({t_max - 273:.0f} °C).")
        else:
            t_match = "n/a"
            score += 15

        # pH
        ph_range = rxn_data.get("pH", (None, None, None))
        ph_min, ph_max = ph_range[0], ph_range[1]
        ph_match = "unknown"
        if ph_min is not None and ph_max is not None:
            if ph_min <= pH <= ph_max:
                ph_match = True
                score += 25
                if len(ph_range) >= 3 and ph_range[2] is not None:
                    dev = abs(pH - ph_range[2]) / max(ph_max - ph_min, 0.1)
                    score += max(0, 10 * (1 - dev))
            else:
                ph_match = False
                if pH < ph_min:
                    warnings.append(f"pH {pH:.1f} is too acidic (need ≥ {ph_min}).")
                    suggestions.append(f"Raise pH toward {ph_range[2] or ph_min} (add NH3, Na2CO3).")
                else:
                    warnings.append(f"pH {pH:.1f} is too basic (need ≤ {ph_max}).")
                    suggestions.append(f"Lower pH toward {ph_range[2] or ph_max} (add CO2, HCl).")
        else:
            ph_match = "n/a"
            score += 12

        # Pressure
        p_range = rxn_data.get("P_atm") or (None, None)
        p_min, p_max = p_range[0], p_range[1]
        p_match = "unknown"
        if p_min is not None and p_max is not None:
            if p_min <= P_atm <= p_max:
                p_match = True
                score += 10
            else:
                p_match = False
                if P_atm < p_min:
                    warnings.append(f"Pressure {P_atm:.1f} atm below minimum {p_min} atm.")
                    suggestions.append(f"Increase pressure to ≥ {p_min} atm (hydrothermal/deep sea).")
                else:
                    warnings.append(f"Pressure {P_atm:.1f} atm above maximum {p_max} atm.")
        else:
            p_match = "n/a"
            score += 5

        # Atmosphere
        required_atm = [a.lower() for a in (rxn_data.get("atmosphere") or [])]
        provided_atm = [a.strip().lower() for a in user_atm]
        atm_found = sum(1 for a in required_atm if any(a in p for p in provided_atm))
        atm_match = atm_found / len(required_atm) if required_atm else 1.0
        score += 15 * atm_match
        for a in required_atm:
            if not any(a in p for p in provided_atm):
                warnings.append(f"Required atmospheric component missing: {a.upper()}")
                suggestions.append(f"Add {a.upper()} to reaction atmosphere.")

        # Minerals
        required_min = [m.lower() for m in (rxn_data.get("minerals") or [])]
        provided_min = [m.strip().lower() for m in user_minerals]
        min_found = sum(1 for m in required_min if any(m.split("(")[0].strip() in p for p in provided_min))
        mineral_match = min_found / len(required_min) if required_min else 1.0
        score += 10 * mineral_match
        for m in required_min:
            if not any(m.split("(")[0].strip() in p for p in provided_min):
                suggestions.append(f"Consider adding mineral catalyst: {m}")

        score = min(100.0, score)
        return {
            "score": round(score, 1),
            "T_match": t_match,
            "pH_match": ph_match,
            "P_match": p_match,
            "atm_match": round(atm_match * 100),
            "mineral_match": round(mineral_match * 100),
            "warnings": warnings,
            "suggestions": suggestions,
        }

    def _prebiotic_filter_reactions(
        self,
        category: str = "All",
        env_keyword: str = "All",
        query: str = "",
    ) -> list:
        """Return list of (rxn_name, rxn_data) matching the filters."""
        results = []
        q = query.strip().lower()
        for name, data in PREBIOTIC_DB.items():
            if category != "All" and data.get("category", "") != category:
                continue
            if env_keyword != "All":
                env_list = " ".join(data.get("env", [])).lower()
                if env_keyword.lower() not in env_list:
                    continue
            if q:
                blob = (
                    name + " " +
                    data.get("category", "") + " " +
                    " ".join(data.get("products", [])) + " " +
                    " ".join(str(v) for v in data.get("reactants", {}).keys()) + " " +
                    data.get("pathway", "") + " " +
                    " ".join(data.get("env", []))
                ).lower()
                if q not in blob:
                    continue
            results.append((name, data))
        return results

    def _prebiotic_generate_report(
        self,
        rxn_name: str,
        rxn_data: dict,
        match: dict,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
        output_dir: str,
    ) -> str:
        """Write a detailed plain-text elucidation report; return file path."""
        lines = [
            "=" * 72,
            "  PREBIOTIC REACTION CONDITION ELUCIDATION REPORT",
            f"  IAK Pipeline v11.2  |  Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            "=" * 72,
            "",
            f"REACTION  : {rxn_name}",
            f"CATEGORY  : {rxn_data.get('category', 'N/A')}",
            f"MATCH SCORE: {match['score']:.1f} / 100",
            "",
            "─" * 72,
            "USER CONDITIONS",
            "─" * 72,
            f"  Temperature : {T_K} K  ({T_K - 273.15:.1f} °C)",
            f"  pH          : {pH}",
            f"  Pressure    : {P_atm} atm",
            f"  Atmosphere  : {', '.join(user_atm) or 'not specified'}",
            f"  Minerals    : {', '.join(user_minerals) or 'none'}",
            "",
            "─" * 72,
            "OPTIMAL / REPORTED CONDITIONS",
            "─" * 72,
        ]
        t_range = rxn_data.get("T_K", ())
        if len(t_range) == 3:
            lines.append(f"  Temperature : {t_range[0]}–{t_range[1]} K  (optimal {t_range[2]} K)")
        ph_range = rxn_data.get("pH", ())
        if len(ph_range) >= 2 and ph_range[0] is not None:
            lines.append(f"  pH          : {ph_range[0]}–{ph_range[1]}")
        p_range = rxn_data.get("P_atm") or ()
        if len(p_range) == 2 and p_range[0] is not None:
            lines.append(f"  Pressure    : {p_range[0]}–{p_range[1]} atm")
        lines += [
            f"  Atmosphere  : {', '.join(rxn_data.get('atmosphere', [])) or 'none required'}",
            f"  Minerals    : {', '.join(rxn_data.get('minerals', [])) or 'none required'}",
            f"  Environment : {', '.join(rxn_data.get('env', []))}",
            "",
            "─" * 72,
            "REACTION DETAILS",
            "─" * 72,
            "  Reactants:",
        ]
        for mol, role in (rxn_data.get("reactants") or {}).items():
            lines.append(f"    • {mol}  [{role}]")
        lines.append("  Products:")
        for p in rxn_data.get("products", []):
            lines.append(f"    • {p}")
        dg = rxn_data.get("energy_kJ")
        if dg is not None:
            sign = "endergonic (+)" if dg > 0 else "exergonic (−)"
            lines.append(f"  ΔG° (STP)   : {dg:+.1f} kJ/mol  [{sign}]")
        lines += [
            "",
            f"  Mechanism   : {rxn_data.get('pathway', 'N/A')}",
            "",
            "─" * 72,
            "CONDITION MATCH ANALYSIS",
            "─" * 72,
            f"  Temperature match : {match['T_match']}",
            f"  pH match          : {match['pH_match']}",
            f"  Pressure match    : {match['P_match']}",
            f"  Atmosphere match  : {match['atm_match']}%",
            f"  Mineral match     : {match['mineral_match']}%",
        ]
        if match["warnings"]:
            lines += ["", "  WARNINGS:"]
            for w in match["warnings"]:
                lines.append(f"    ⚠  {w}")
        if match["suggestions"]:
            lines += ["", "  SUGGESTIONS:"]
            for s in match["suggestions"]:
                lines.append(f"    →  {s}")
        lines += [
            "",
            "─" * 72,
            "FEASIBILITY NOTES",
            "─" * 72,
            "  " + rxn_data.get("feasibility_notes", "").replace("\n", "\n  "),
            "",
            "─" * 72,
            "KEY REFERENCES",
            "─" * 72,
        ]
        for ref in rxn_data.get("refs", []):
            lines.append(f"  [{ref}]")
        lines += ["", "=" * 72, "END OF REPORT", "=" * 72, ""]
        report_text = "\n".join(lines)

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_", rxn_name)[:60]
        report_path = os.path.join(output_dir, f"prebiotic_{safe_name}.txt")
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_text)
        return report_path

    def _prebiotic_plot_condition_radar(
        self,
        rxn_name: str,
        match: dict,
        output_dir: str,
    ) -> str:
        """Draw a radar (spider) chart showing the condition match; save PNG."""
        if not MATPLOTLIB_AVAILABLE:
            return ""
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        labels = ["Temperature", "pH", "Pressure", "Atmosphere", "Minerals"]

        def _bool_to_score(v):
            if v is True:
                return 100
            if v is False:
                return 0
            return 50  # partial / n/a

        values = [
            _bool_to_score(match["T_match"]),
            _bool_to_score(match["pH_match"]),
            _bool_to_score(match["P_match"]),
            match["atm_match"],
            match["mineral_match"],
        ]

        N = len(labels)
        angles = [n / float(N) * 2 * math.pi for n in range(N)]
        angles += angles[:1]
        vals_plot = values + values[:1]

        fig, ax = plt.subplots(figsize=(5, 5), subplot_kw=dict(polar=True))
        fig.patch.set_facecolor(_C["panel"])
        ax.set_facecolor(_C["panel"])
        ax.plot(angles, vals_plot, "o-", linewidth=2, color=_C["green"])
        ax.fill(angles, vals_plot, alpha=0.25, color=_C["green"])
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=9, color=_C["text"])
        ax.set_ylim(0, 100)
        ax.set_yticks([25, 50, 75, 100])
        ax.set_yticklabels(["25", "50", "75", "100"], fontsize=7, color=_C["muted"])
        ax.set_title(f"Condition Match\n{rxn_name[:45]}", fontsize=10, pad=14,
                     color=_C["text"], fontweight="bold")
        score_patch = mpatches.Patch(color=_C["green"],
                                     label=f"Overall score: {match['score']:.0f}/100")
        ax.legend(handles=[score_patch], loc="upper right",
                  bbox_to_anchor=(1.3, 1.1), fontsize=9)
        fig.tight_layout()

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_", rxn_name)[:50]
        out_path = os.path.join(output_dir, f"prebiotic_radar_{safe_name}.png")
        fig.savefig(out_path, dpi=120, bbox_inches="tight",
                    facecolor=_C["panel"])
        plt.close(fig)
        return out_path

    def _prebiotic_plot_energy_diagram(
        self,
        rxn_data: dict,
        output_dir: str,
    ) -> str:
        """Draw a simple reaction energy diagram for the prebiotic reaction."""
        if not MATPLOTLIB_AVAILABLE:
            return ""
        import matplotlib.pyplot as plt

        dg = rxn_data.get("energy_kJ")
        if dg is None:
            return ""

        reactants = list((rxn_data.get("reactants") or {}).keys())
        products = rxn_data.get("products", ["Products"])
        r_label = " + ".join(str(r) for r in reactants[:2]) or "Reactants"
        p_label = " + ".join(str(p) for p in products[:2]) or "Products"

        fig, ax = plt.subplots(figsize=(6, 4))
        fig.patch.set_facecolor(_C["panel"])
        ax.set_facecolor(_C["panel"])

        e_r, e_ts, e_p = 0.0, max(dg + 15, 15), dg
        for x, y, lbl, col in [
            (0.1, e_r, r_label, _C["accent"]),
            (0.5, e_ts, "Transition State†", _C["red"]),
            (0.9, e_p, p_label, _C["green"]),
        ]:
            ax.plot([x - 0.05, x + 0.05], [y, y], linewidth=3, color=col)
            ax.text(x, y + 2, lbl[:28], ha="center", va="bottom",
                    fontsize=8, color=col, fontweight="bold")

        ax.plot([0.15, 0.45], [e_r, e_ts], "k--", lw=1, alpha=0.5)
        ax.plot([0.55, 0.85], [e_ts, e_p], "k--", lw=1, alpha=0.5)

        ax.annotate("", xy=(0.5, e_ts), xytext=(0.5, e_r),
                    arrowprops=dict(arrowstyle="<->", color=_C["red"], lw=1.5))
        ax.text(0.52, (e_ts + e_r) / 2, f"+{e_ts:.0f} kJ/mol", fontsize=8,
                color=_C["red"], va="center")
        ax.annotate("", xy=(0.9, e_p), xytext=(0.9, e_r),
                    arrowprops=dict(arrowstyle="<->", color=_C["green"], lw=1.5))
        ax.text(0.92, (e_p + e_r) / 2, f"{dg:+.0f} kJ/mol", fontsize=8,
                color=_C["green"], va="center")

        ax.set_ylabel("Relative Energy (kJ/mol)", color=_C["text"])
        ax.set_xlim(0, 1.05)
        ax.set_xticks([])
        ax.set_title(f"Prebiotic Reaction Energy Profile", fontsize=10,
                     color=_C["text"], fontweight="bold")
        ax.spines[["top", "right", "bottom"]].set_visible(False)
        ax.tick_params(colors=_C["muted"])
        ax.yaxis.label.set_color(_C["muted"])
        fig.tight_layout()

        os.makedirs(output_dir, exist_ok=True)
        safe_name = re.sub(r"[^\w\-]", "_",
                           rxn_data.get("category", "rxn"))[:40]
        out_path = os.path.join(output_dir, f"prebiotic_energy_{safe_name}.png")
        fig.savefig(out_path, dpi=120, bbox_inches="tight",
                    facecolor=_C["panel"])
        plt.close(fig)
        return out_path

    def _prebiotic_run_xtb_thermo(
        self,
        mol_file: str,
        T_K: float,
        charge: int,
        mult: int,
        output_dir: str,
        method: str = "--gfn2",
        solvent: str = "",
    ) -> dict:
        """Run xTB opt + Hessian at the given temperature; return thermo dict."""
        if not is_tool_available("xtb"):
            return {"error": "xTB not found on PATH."}
        from platform import system as _sys
        xtb = "xtb.exe" if _sys() == "Windows" else "xtb"
        os.makedirs(output_dir, exist_ok=True)
        solvent_flag = f"--alpb {solvent}" if solvent else ""
        cmd = (
            f'"{xtb}" "{mol_file}" {method} --opt --hess --temp {T_K}'
            f' --chrg {charge} --uhf {mult - 1}'
            f' {solvent_flag} > xtb_prebiotic.log 2>&1'
        )
        subprocess.run(cmd, shell=True, cwd=output_dir)
        log = os.path.join(output_dir, "xtb_prebiotic.log")
        result = {"log": log, "T_K": T_K, "charge": charge, "mult": mult}
        if os.path.isfile(log):
            text = open(log, errors="replace").read()
            for pattern, key in [
                (r"TOTAL FREE ENERGY\s*=\s*([-\d.]+)", "G_Eh"),
                (r"TOTAL ENTHALPY\s*=\s*([-\d.]+)", "H_Eh"),
                (r"ZERO POINT ENERGY\s*=\s*([-\d.]+)", "ZPE_Eh"),
                (r"G\(RRHO\)\s*=\s*([-\d.]+)", "G_RRHO_Eh"),
                (r"(-?\d+\.\d+) Eh\s+TOTAL ENERGY", "E_Eh"),
            ]:
                m = re.search(pattern, text)
                if m:
                    result[key] = float(m.group(1))
        return result

    def _prebiotic_rank_all(
        self,
        T_K: float,
        pH: float,
        P_atm: float,
        user_atm: list,
        user_minerals: list,
        category: str = "All",
    ) -> list:
        """Score every reaction in PREBIOTIC_DB against the user conditions;
        return sorted list of (score, name, match_dict)."""
        results = []
        for name, data in PREBIOTIC_DB.items():
            if category != "All" and data.get("category") != category:
                continue
            match = self._prebiotic_match_conditions(
                data, T_K, pH, P_atm, user_atm, user_minerals)
            results.append((match["score"], name, match, data))
        results.sort(key=lambda x: -x[0])
        return results

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_prebiotic_tab(self, parent):
        """Prebiotic Reaction Condition Elucidation — multi-module notebook."""
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True, padx=4, pady=4)

        # ── Sub-tabs ──────────────────────────────────────────────────────────
        tab_db    = tk.Frame(nb, bg=_C["bg"])
        tab_rxn   = tk.Frame(nb, bg=_C["bg"])
        tab_xtb   = tk.Frame(nb, bg=_C["bg"])
        tab_crest = tk.Frame(nb, bg=_C["bg"])
        tab_orca  = tk.Frame(nb, bg=_C["bg"])
        tab_tut   = tk.Frame(nb, bg=_C["bg"])

        nb.add(tab_db,    text="  📚 Reaction Library  ")
        nb.add(tab_rxn,   text="  🧪 Custom Reactants  ")
        nb.add(tab_xtb,   text="  ⚡ xTB Module  ")
        nb.add(tab_crest, text="  🔄 CREST Module  ")
        nb.add(tab_orca,  text="  🎯 ORCA Module  ")
        nb.add(tab_tut,   text="  📖 Tutorials  ")

        self._build_prebiotic_db_subtab(tab_db)
        self._build_prebiotic_rxn_subtab(tab_rxn)
        self._build_prebiotic_xtb_subtab(tab_xtb)
        self._build_prebiotic_crest_subtab(tab_crest)
        self._build_prebiotic_orca_subtab(tab_orca)
        self._build_prebiotic_tutorial_subtab(tab_tut)

    # ── Shared helpers ────────────────────────────────────────────────────────

    def _prebiotic_output_dir(self) -> str:
        d = self._vars_prebiotic["output_dir"].get().strip()
        if not d:
            d = os.path.join(os.getcwd(), "prebiotic_output")
        return d

    def _prebio_file_row(self, parent, label, key, *, filetypes=None, directory=False):
        """Helper: labelled file-browse row."""
        row = tk.Frame(parent, bg=_C["panel"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                 width=18, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row, textvariable=self._vars_prebiotic[key],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)
        def _browse():
            if directory:
                v = filedialog.askdirectory()
            else:
                v = filedialog.askopenfilename(
                    filetypes=filetypes or [("XYZ", "*.xyz"), ("All", "*")])
            if v:
                self._vars_prebiotic[key].set(v)
        tk.Button(row, text="…", command=_browse,
                  bg=_C["accent"], fg="white", bd=0, width=3).pack(side="left")

    def _prebio_entry_row(self, parent, label, key, width=14, tooltip=None):
        row = tk.Frame(parent, bg=_C["panel"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text=label, bg=_C["panel"], fg=_C["text"],
                 width=22, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row, textvariable=self._vars_prebiotic[key],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=width).pack(side="left", padx=4)
        if tooltip:
            tk.Label(row, text=tooltip, bg=_C["panel"], fg=_C["muted"],
                     font=("Segoe UI", 8, "italic")).pack(side="left")

    def _prebio_log_widget(self, parent, height=14):
        """Return a disabled Text + scrollbar packed into parent."""
        f = tk.Frame(parent, bg=_C["panel"])
        f.pack(fill="both", expand=True, padx=4, pady=4)
        t = tk.Text(f, bg="#0c0c0c", fg="#d4d4d4",
                    font=("Consolas", 9), wrap="word",
                    state="disabled", height=height)
        t.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(f, orient="vertical", command=t.yview)
        sb.pack(side="right", fill="y")
        t.config(yscrollcommand=sb.set)
        for tag, fg_col in [("header", _C["accent"]), ("good", "#22c55e"),
                             ("warn", "#f59e0b"), ("bad", _C["red"]),
                             ("muted", _C["muted"])]:
            t.tag_config(tag, foreground=fg_col,
                         font=("Consolas", 10, "bold") if tag == "header" else None)
        return t

    def _prebio_write(self, widget, text, clear=False):
        """Thread-safe write to a log Text widget."""
        def _do():
            widget.config(state="normal")
            if clear:
                widget.delete("1.0", "end")
            widget.insert("end", text + "\n")
            widget.see("end")
            widget.config(state="disabled")
        self.root.after(0, _do)

    # ── Tab 1 : Reaction Library (DB) ─────────────────────────────────────────

    def _build_prebiotic_db_subtab(self, parent):
        paned = tk.PanedWindow(parent, orient=tk.HORIZONTAL,
                               sashwidth=5, bg=_C["border"])
        paned.pack(fill="both", expand=True, padx=6, pady=6)

        left = tk.Frame(paned, bg=_C["bg"], width=360)
        paned.add(left, minsize=320)

        # ── Conditions ────────────────────────────────────────────────────────
        cond_f = tk.LabelFrame(left, text=" Primitive Earth Conditions ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        cond_f.pack(fill="x", padx=6, pady=4)
        self._prebio_entry_row(cond_f, "Temperature (K):", "T_K",
                               tooltip="298 … 600")
        self._prebio_entry_row(cond_f, "pH:", "pH", tooltip="0 … 14")
        self._prebio_entry_row(cond_f, "Pressure (atm):", "P_atm", tooltip="1 … 500")
        self._prebio_entry_row(cond_f, "Atmosphere (csv):", "atmosphere",
                               tooltip="e.g. N2, CO2, H2, CH4")
        self._prebio_entry_row(cond_f, "Minerals (csv):", "minerals",
                               tooltip="e.g. Montmorillonite, FeS")

        # ── Presets ───────────────────────────────────────────────────────────
        preset_f = tk.LabelFrame(left, text=" Environment Presets ",
                                 bg=_C["panel"], fg=_C["yellow"],
                                 font=("Segoe UI", 9, "bold"), padx=8, pady=4)
        preset_f.pack(fill="x", padx=6, pady=3)
        presets = {
            "Miller-Urey flask": dict(T_K="298", pH="7.0", P_atm="1.0",
                                      atmosphere="H2, NH3, CH4, H2O", minerals=""),
            "Alkaline vent":     dict(T_K="373", pH="11.0", P_atm="50",
                                      atmosphere="H2, CO2",
                                      minerals="FeS, Greigite, Serpentine"),
            "Ice eutectic":      dict(T_K="253", pH="9.0", P_atm="1.0",
                                      atmosphere="HCN, NH3, CO2", minerals=""),
            "Tidal flat":        dict(T_K="333", pH="8.0", P_atm="1.0",
                                      atmosphere="N2, CO2, H2O, NH3",
                                      minerals="Montmorillonite, Hydroxyapatite"),
            "Volcanic fumarole": dict(T_K="573", pH="2.5", P_atm="3.0",
                                      atmosphere="SO2, HCl, H2O, CO2",
                                      minerals="Apatite, Fe3O4"),
            "Soda lake":         dict(T_K="298", pH="10.0", P_atm="1.0",
                                      atmosphere="CO2, N2, H2O",
                                      minerals="Na2CO3, Borate minerals"),
        }
        rows = [tk.Frame(preset_f, bg=_C["panel"]) for _ in range(2)]
        for r in rows:
            r.pack(fill="x", pady=1)
        for i, (nm, vals) in enumerate(presets.items()):
            def _ap(v=vals):
                for k2, v2 in v.items():
                    self._vars_prebiotic[k2].set(v2)
            tk.Button(rows[i // 3], text=nm[:20],
                      command=_ap, bg=_C["dim"], fg=_C["text"],
                      font=("Segoe UI", 8), padx=3, pady=2,
                      relief="flat", cursor="hand2").pack(
                          side="left", padx=2, expand=True, fill="x")

        # ── Filters ───────────────────────────────────────────────────────────
        filt_f = tk.LabelFrame(left, text=" Filter / Search ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=8, pady=4)
        filt_f.pack(fill="x", padx=6, pady=3)
        cats = ["All"] + sorted(set(
            d.get("category", "Other") for d in PREBIOTIC_DB.values()))
        envs = ["All", "Hydrothermal vent", "Ice eutectic", "Mineral surface",
                "Tidal pool", "Alkaline lake", "Volcanic", "Aqueous solution"]
        for lbl, key, vals in [
            ("Category:", "filter_category", cats),
            ("Environment:", "filter_env", envs),
        ]:
            r = tk.Frame(filt_f, bg=_C["panel"])
            r.pack(fill="x", pady=1)
            tk.Label(r, text=lbl, bg=_C["panel"], fg=_C["text"],
                     width=13, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            ttk.Combobox(r, textvariable=self._vars_prebiotic[key],
                         values=vals, state="readonly", width=22).pack(
                             side="left", padx=4)
        sr = tk.Frame(filt_f, bg=_C["panel"])
        sr.pack(fill="x", pady=1)
        tk.Label(sr, text="Search:", bg=_C["panel"], fg=_C["text"],
                 width=13, anchor="w", font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(sr, textvariable=self._vars_prebiotic["search_query"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=24).pack(
                     side="left", padx=4)

        # ── Buttons ───────────────────────────────────────────────────────────
        bf = tk.Frame(left, bg=_C["bg"])
        bf.pack(fill="x", padx=6, pady=6)
        tk.Button(bf, text="⟳ Refresh",
                  command=self._prebiotic_refresh_list,
                  bg=_C["accent"], fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)
        tk.Button(bf, text="★ Rank by Conditions",
                  command=self._prebiotic_rank_and_show,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)
        tk.Button(bf, text="▶ Elucidate Selected",
                  command=self._prebiotic_elucidate_selected,
                  bg="#6f42c1", fg="white",
                  font=("Segoe UI", 9, "bold"), padx=6, pady=3).pack(
                      side="left", padx=2)

        # ── Right: list + detail ───────────────────────────────────────────────
        right = tk.Frame(paned, bg=_C["bg"])
        paned.add(right, minsize=420)

        list_f = tk.LabelFrame(right, text=" Prebiotic Reactions ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        list_f.pack(fill="both", expand=True, padx=6, pady=(6, 2))
        lbf = tk.Frame(list_f, bg=_C["panel"])
        lbf.pack(fill="both", expand=True)
        self._prebiotic_listbox = tk.Listbox(
            lbf, bg=_C["entry"], fg=_C["text"],
            font=("Consolas", 9), selectbackground=_C["accent"],
            selectforeground="white", activestyle="none",
            exportselection=False)
        self._prebiotic_listbox.pack(side="left", fill="both", expand=True)
        lb_sb = ttk.Scrollbar(lbf, orient="vertical",
                              command=self._prebiotic_listbox.yview)
        lb_sb.pack(side="right", fill="y")
        self._prebiotic_listbox.config(yscrollcommand=lb_sb.set)
        self._prebiotic_listbox.bind("<<ListboxSelect>>",
                                     self._prebiotic_on_select)

        det_f = tk.LabelFrame(right, text=" Reaction Details & Condition Analysis ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        det_f.pack(fill="both", expand=True, padx=6, pady=(2, 6))
        self._prebiotic_detail = self._prebio_log_widget(det_f, height=16)

        # ── Output dir ────────────────────────────────────────────────────────
        odf = tk.Frame(left, bg=_C["bg"])
        odf.pack(fill="x", padx=6, pady=2)
        self._prebio_file_row(odf, "Output dir:", "output_dir", directory=True)
        tk.Checkbutton(left, text="Export full text report (.txt)",
                       variable=self._vars_prebiotic["export_report"],
                       bg=_C["bg"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", padx=6)

        self._prebiotic_refresh_list()

    # ── Tab 2 : Custom Reactants & Bond-breaking / forming ───────────────────

    def _build_prebiotic_rxn_subtab(self, parent):
        """Define your own reactants, specify bonds to break/form, run PES scan."""
        header = tk.LabelFrame(parent,
                               text=" User-Defined Reaction Pathway ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Specify reactant/product SMILES or names, choose which bonds "
                      "break or form,\nthen drive the reaction coordinate with an xTB "
                      "constrained bond scan.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        # Reactant / product ──────────────────────────────────────────────────
        mol_lf = tk.LabelFrame(left_f, text=" Molecules ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)

        self._prebio_file_row(mol_lf, "Reactant XYZ:", "mol_file")
        self._prebio_file_row(mol_lf, "Product XYZ:", "product_file")

        row_rct = tk.Frame(mol_lf, bg=_C["panel"])
        row_rct.pack(fill="x", pady=2)
        tk.Label(row_rct, text="Reactant names/SMILES:", bg=_C["panel"],
                 fg=_C["text"], width=22, anchor="w",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row_rct, textvariable=self._vars_prebiotic["user_reactants"],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)

        row_prd = tk.Frame(mol_lf, bg=_C["panel"])
        row_prd.pack(fill="x", pady=2)
        tk.Label(row_prd, text="Product names/SMILES:", bg=_C["panel"],
                 fg=_C["text"], width=22, anchor="w",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(row_prd, textvariable=self._vars_prebiotic["user_products"],
                 bg=_C["entry"], fg=_C["text"], bd=0).pack(
                     side="left", fill="x", expand=True, padx=4)

        chrg_row = tk.Frame(mol_lf, bg=_C["panel"])
        chrg_row.pack(fill="x", pady=2)
        tk.Label(chrg_row, text="Charge:", bg=_C["panel"],
                 fg=_C["text"], font=("Segoe UI", 9)).pack(side="left")
        tk.Entry(chrg_row, textvariable=self._vars_prebiotic["charge"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=5).pack(
                     side="left", padx=4)
        tk.Label(chrg_row, text="Mult:", bg=_C["panel"],
                 fg=_C["text"], font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
        tk.Entry(chrg_row, textvariable=self._vars_prebiotic["mult"],
                 bg=_C["entry"], fg=_C["text"], bd=0, width=5).pack(side="left")

        # Bond breaking / forming ─────────────────────────────────────────────
        bond_lf = tk.LabelFrame(left_f,
                                text=" Bond Breaking & Forming ",
                                bg=_C["panel"], fg=_C["yellow"],
                                font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Use 1-based atom indices from the XYZ.\n"
                      "Multiple pairs: comma-separated, e.g.  1-2, 3-4",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Bonds to BREAK:", "bond_break",
                               tooltip="e.g. 1-2, 3-4")
        self._prebio_entry_row(bond_lf, "Bonds to FORM:", "bond_form",
                               tooltip="e.g. 5-6")

        # Scan parameters ─────────────────────────────────────────────────────
        scan_lf = tk.LabelFrame(left_f,
                                text=" Constrained Bond-Scan (xTB) ",
                                bg=_C["panel"], fg=_C["accent"],
                                font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        scan_lf.pack(fill="x", pady=4)
        tk.Label(scan_lf,
                 text="Drive atom pair distance from start → end Å",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(scan_lf, "Atom 1 (idx):", "scan_dist_A1")
        self._prebio_entry_row(scan_lf, "Atom 2 (idx):", "scan_dist_A2")
        self._prebio_entry_row(scan_lf, "Start distance (Å):", "scan_start")
        self._prebio_entry_row(scan_lf, "End distance (Å):", "scan_end")
        self._prebio_entry_row(scan_lf, "Steps:", "scan_steps")
        self._prebio_entry_row(scan_lf, "xTB method:", "xtb_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(scan_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / none")
        self._prebio_file_row(scan_lf, "Output dir:", "output_dir", directory=True)

        btn_f = tk.Frame(left_f, bg=_C["bg"])
        btn_f.pack(fill="x", pady=4)
        tk.Button(btn_f, text="▶ Run Bond Scan",
                  command=self._prebiotic_run_bond_scan,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=10, pady=4).pack(
                      side="left", padx=2)
        tk.Button(btn_f, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=10, pady=4).pack(
                      side="left", padx=2)

        # Log + plot area ─────────────────────────────────────────────────────
        log_lf = tk.LabelFrame(right_f, text=" Bond-Scan Log ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_rxn_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 3 : xTB Module ────────────────────────────────────────────────────

    def _build_prebiotic_xtb_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" xTB Thermochemistry at Prebiotic Conditions ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Optimise + compute Hessian with GFN2-xTB (or GFN-FF / GFN1) at the "
                      "chosen temperature.\nParses G, H, ZPE and plots the energy profile.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Molecule ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Molecule XYZ:", "mol_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        xtb_lf = tk.LabelFrame(left_f, text=" xTB Settings ",
                               bg=_C["panel"], fg=_C["yellow"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        xtb_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(xtb_lf, "Method:", "xtb_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(xtb_lf, "Temperature (K):", "T_K")
        self._prebio_entry_row(xtb_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / methanol / none")
        tk.Checkbutton(xtb_lf, text="Run xTB thermo (--hess --temp)",
                       variable=self._vars_prebiotic["run_xtb_thermo"],
                       bg=_C["panel"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", pady=2)

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run xTB Thermo",
                  command=self._prebiotic_run_xtb_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" xTB Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_xtb_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 4 : CREST Module ──────────────────────────────────────────────────

    def _build_prebiotic_crest_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" CREST Conformer / Reactive Sampling ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="CREST explores the conformational space at prebiotic temperature "
                      "using iMTD-GC.\nUse --T or --cinp for reactive sampling across bond "
                      "rearrangements.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Input ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Molecule XYZ:", "mol_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        crest_lf = tk.LabelFrame(left_f, text=" CREST Settings ",
                                 bg=_C["panel"], fg=_C["yellow"],
                                 font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        crest_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(crest_lf, "Method:", "crest_method",
                               tooltip="--gfn2 / --gfnff / --gfn1")
        self._prebio_entry_row(crest_lf, "Temperature (K):", "crest_T",
                               tooltip="MD temperature for iMTD-GC")
        self._prebio_entry_row(crest_lf, "Energy window (kcal):", "crest_ewin",
                               tooltip="default 6 kcal/mol above minimum")
        self._prebio_entry_row(crest_lf, "Keep top-N conformers:", "crest_keep_n",
                               tooltip="written to crest_conformers_top.xyz")
        self._prebio_entry_row(crest_lf, "Atmosphere (csv):", "atmosphere",
                               tooltip="informational only; see solvent below")
        self._prebio_entry_row(crest_lf, "Solvent (ALPB):", "xtb_solvent",
                               tooltip="water / none")

        bond_lf = tk.LabelFrame(left_f,
                                text=" Reactive Constraint (optional) ",
                                bg=_C["panel"], fg=_C["muted"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=4)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Force a bond to break/form during CREST sampling\n"
                      "via a constrained input file (--cinp).",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Constrain bond (A1-A2):", "bond_break",
                               tooltip="e.g. 1-2")

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run CREST",
                  command=self._prebiotic_run_crest_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)
        tk.Button(bf, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" CREST Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_crest_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 5 : ORCA Module ───────────────────────────────────────────────────

    def _build_prebiotic_orca_subtab(self, parent):
        header = tk.LabelFrame(parent,
                               text=" ORCA High-Level Optimisation / TS Search / NEB ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        header.pack(fill="x", padx=8, pady=6)
        tk.Label(header,
                 text="Run ORCA Opt, Freq, OptTS, or NEB-TS using DFT/composite methods.\n"
                      "Bond-breaking/forming is modelled by providing reactant+product "
                      "geometries for NEB interpolation.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        lf = tk.Frame(parent, bg=_C["bg"])
        lf.pack(fill="both", expand=True)
        left_f = tk.Frame(lf, bg=_C["bg"])
        left_f.pack(side="left", fill="y", padx=(8, 4), pady=4)
        right_f = tk.Frame(lf, bg=_C["bg"])
        right_f.pack(side="left", fill="both", expand=True, padx=(4, 8), pady=4)

        mol_lf = tk.LabelFrame(left_f, text=" Input Structures ",
                               bg=_C["panel"], fg=_C["green"],
                               font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        mol_lf.pack(fill="x", pady=4)
        self._prebio_file_row(mol_lf, "Reactant XYZ:", "mol_file")
        self._prebio_file_row(mol_lf, "Product XYZ (NEB):", "product_file")
        self._prebio_entry_row(mol_lf, "Charge:", "charge")
        self._prebio_entry_row(mol_lf, "Mult:", "mult")
        self._prebio_file_row(mol_lf, "Output dir:", "output_dir", directory=True)

        orca_lf = tk.LabelFrame(left_f, text=" ORCA Settings ",
                                bg=_C["panel"], fg=_C["yellow"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=6)
        orca_lf.pack(fill="x", pady=4)
        self._prebio_entry_row(orca_lf, "Method:", "orca_method",
                               tooltip="B97-3c / PBE0 / DLPNO-CCSD(T)")
        self._prebio_entry_row(orca_lf, "Basis set:", "orca_basis",
                               tooltip="def2-mTZVP / def2-SVP / leave blank for B97-3c")
        self._prebio_entry_row(orca_lf, "Keywords:", "orca_keywords",
                               tooltip="Opt Freq / OptTS / NEB-TS / SP")
        self._prebio_entry_row(orca_lf, "nProc:", "orca_nproc")
        self._prebio_entry_row(orca_lf, "MaxCore (MB):", "orca_maxcore")
        tk.Checkbutton(orca_lf, text="Use NEB-TS (reactant + product needed)",
                       variable=self._vars_prebiotic["orca_neb"],
                       bg=_C["panel"], fg=_C["text"],
                       selectcolor=_C["entry"]).pack(anchor="w", pady=2)

        bond_lf = tk.LabelFrame(left_f,
                                text=" Bond Making / Breaking Hint ",
                                bg=_C["panel"], fg=_C["muted"],
                                font=("Segoe UI", 9, "bold"), padx=10, pady=4)
        bond_lf.pack(fill="x", pady=4)
        tk.Label(bond_lf,
                 text="Optional: add %geom Modify_Internal constraints\n"
                      "to the ORCA input to steer the optimisation.",
                 bg=_C["panel"], fg=_C["muted"],
                 font=("Segoe UI", 8, "italic")).pack(anchor="w")
        self._prebio_entry_row(bond_lf, "Break bond (A1-A2):", "bond_break",
                               tooltip="adds ModRedundant {B a1 a2 D}")
        self._prebio_entry_row(bond_lf, "Form bond (A1-A2):", "bond_form",
                               tooltip="adds ModRedundant {B a1 a2 A}")

        bf = tk.Frame(left_f, bg=_C["bg"])
        bf.pack(fill="x", pady=6)
        tk.Button(bf, text="▶ Run ORCA",
                  command=self._prebiotic_run_orca_module,
                  bg=_C["green"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)
        tk.Button(bf, text="⏹ Stop",
                  command=lambda: setattr(self, "is_running", False),
                  bg=_C["red"], fg="white",
                  font=("Segoe UI", 10, "bold"), padx=8, pady=4).pack(
                      side="left", padx=2)

        log_lf = tk.LabelFrame(right_f, text=" ORCA Output ",
                               bg=_C["panel"], fg=_C["accent"],
                               font=("Segoe UI", 9, "bold"), padx=4, pady=2)
        log_lf.pack(fill="both", expand=True)
        self._prebio_orca_log = self._prebio_log_widget(log_lf, height=22)

    # ── Tab 6 : Tutorials ─────────────────────────────────────────────────────

    def _build_prebiotic_tutorial_subtab(self, parent):
        nb2 = ttk.Notebook(parent)
        nb2.pack(fill="both", expand=True, padx=4, pady=4)

        sections = {
            "📚 Reaction Library": _PREBIOTIC_TUT_DB,
            "🧪 Custom Reactants": _PREBIOTIC_TUT_RXN,
            "⚡ xTB Module": _PREBIOTIC_TUT_XTB,
            "🔄 CREST Module": _PREBIOTIC_TUT_CREST,
            "🎯 ORCA Module": _PREBIOTIC_TUT_ORCA,
        }
        for title, text in sections.items():
            tf = tk.Frame(nb2, bg=_C["bg"])
            nb2.add(tf, text=f"  {title}  ")
            t = tk.Text(tf, bg="#0c0c0c", fg="#d4d4d4",
                        font=("Consolas", 9), wrap="word",
                        state="normal", padx=10, pady=10)
            sb = ttk.Scrollbar(tf, orient="vertical", command=t.yview)
            sb.pack(side="right", fill="y")
            t.pack(side="left", fill="both", expand=True)
            t.config(yscrollcommand=sb.set)
            # Style tags
            t.tag_config("h1", foreground=_C["accent"],
                         font=("Segoe UI", 12, "bold"))
            t.tag_config("h2", foreground=_C["green"],
                         font=("Segoe UI", 10, "bold"))
            t.tag_config("code", foreground="#d19a66",
                         font=("Consolas", 9))
            t.tag_config("tip", foreground="#22c55e",
                         font=("Segoe UI", 9, "italic"))
            t.tag_config("warn", foreground="#f59e0b",
                         font=("Segoe UI", 9, "italic"))
            # Render tutorial text with basic markup
            for chunk in text.split("\n"):
                if chunk.startswith("## "):
                    t.insert("end", chunk[3:] + "\n", "h1")
                elif chunk.startswith("### "):
                    t.insert("end", chunk[4:] + "\n", "h2")
                elif chunk.startswith("```"):
                    pass
                elif chunk.startswith("TIP:"):
                    t.insert("end", chunk + "\n", "tip")
                elif chunk.startswith("WARN:"):
                    t.insert("end", chunk + "\n", "warn")
                else:
                    # inline code: text between backticks
                    import re as _re
                    parts = _re.split(r'(`[^`]+`)', chunk)
                    for part in parts:
                        if part.startswith("`") and part.endswith("`"):
                            t.insert("end", part[1:-1], "code")
                        else:
                            t.insert("end", part)
                    t.insert("end", "\n")
            t.config(state="disabled")

    # ── Prebiotic UI callbacks ────────────────────────────────────────────────

    def _prebiotic_log(self, msg: str):
        """Write to the DB-tab detail pane (thread-safe)."""
        def _do():
            self._prebiotic_detail.config(state="normal")
            self._prebiotic_detail.insert("end", msg + "\n")
            self._prebiotic_detail.see("end")
            self._prebiotic_detail.config(state="disabled")
        self.root.after(0, _do)

    def _prebiotic_set_detail(self, text: str):
        self._prebiotic_detail.config(state="normal")
        self._prebiotic_detail.delete("1.0", "end")
        self._prebiotic_detail.insert("end", text)
        self._prebiotic_detail.config(state="disabled")

    def _prebiotic_refresh_list(self):
        category = self._vars_prebiotic["filter_category"].get()
        env = self._vars_prebiotic["filter_env"].get()
        query = self._vars_prebiotic["search_query"].get()
        matches = self._prebiotic_filter_reactions(category, env, query)
        self._prebiotic_listbox.delete(0, "end")
        self._prebiotic_list_data = []
        for name, data in matches:
            cat = data.get("category", "")
            dg = data.get("energy_kJ")
            dg_str = f"{dg:+.0f} kJ" if dg is not None else "??"
            self._prebiotic_listbox.insert(
                "end",
                f"  {name[:46]:<46}  [{cat[:22]}]  ΔG≈{dg_str}")
            self._prebiotic_list_data.append((name, data))

    def _prebiotic_rank_and_show(self):
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
        except ValueError:
            return messagebox.showerror("Prebiotic",
                                        "Enter valid T, pH, P values.")
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        cat = self._vars_prebiotic["filter_category"].get()
        ranked = self._prebiotic_rank_all(T, pH, P, atm, mins, cat)
        self._prebiotic_listbox.delete(0, "end")
        self._prebiotic_list_data = []
        for score, name, match, data in ranked:
            bar = "█" * int(score // 10) + "░" * (10 - int(score // 10))
            self._prebiotic_listbox.insert(
                "end",
                f"  {score:5.1f}/100  {bar}  {name[:40]:<40}"
                f"  [{data.get('category','')[:18]}]")
            self._prebiotic_list_data.append((name, data))
        self._prebiotic_set_detail(
            f"Ranked {len(ranked)} reactions.\n"
            f"  T={T} K  pH={pH}  P={P} atm\n"
            f"  Atmosphere: {', '.join(atm) or '–'}\n"
            f"  Minerals  : {', '.join(mins) or '–'}\n\n"
            "Click a reaction → details.  "
            "▶ Elucidate Selected → full report + plots.")

    def _prebiotic_on_select(self, event=None):
        sel = self._prebiotic_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self._prebiotic_list_data):
            return
        name, data = self._prebiotic_list_data[idx]
        self._vars_prebiotic["selected_rxn"].set(name)
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
        except ValueError:
            T, pH, P = 298.0, 7.0, 1.0
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        match = self._prebiotic_match_conditions(data, T, pH, P, atm, mins)
        lines = [
            f"{'═'*60}",
            f"  {name}",
            f"{'═'*60}",
            f"  Category    : {data.get('category', 'N/A')}",
            f"  Match Score : {match['score']:.1f} / 100",
            f"  Environments: {', '.join(data.get('env', []))}",
            "", "  REACTANTS:",
        ]
        for mol, role in (data.get("reactants") or {}).items():
            lines.append(f"    • {mol}  [{role}]")
        lines.append("  PRODUCTS:")
        for p in data.get("products", []):
            lines.append(f"    • {p}")
        dg = data.get("energy_kJ")
        if dg is not None:
            lines.append(f"  ΔG° ≈ {dg:+.1f} kJ/mol  "
                         f"({'endergonic' if dg > 0 else 'exergonic'})")
        lines += [
            "", f"  PATHWAY: {data.get('pathway', 'N/A')}",
            "", "  CONDITION MATCH:",
            f"    T  : {'✓' if match['T_match'] is True else '✗' if match['T_match'] is False else '—'}",
            f"    pH : {'✓' if match['pH_match'] is True else '✗' if match['pH_match'] is False else '—'}",
            f"    P  : {'✓' if match['P_match'] is True else '✗' if match['P_match'] is False else '—'}",
            f"    Atm: {match['atm_match']}%",
            f"    Min: {match['mineral_match']}%",
        ]
        if match["warnings"]:
            lines += ["", "  WARNINGS:"]
            for w in match["warnings"]:
                lines.append(f"    ⚠  {w}")
        if match["suggestions"]:
            lines += ["", "  SUGGESTIONS:"]
            for s in match["suggestions"]:
                lines.append(f"    →  {s}")
        lines += [
            "", "  FEASIBILITY:",
            "    " + data.get("feasibility_notes", "").replace("\n", "\n    "),
            "", "  REFERENCES:",
        ]
        for ref in data.get("refs", []):
            lines.append(f"    [{ref}]")
        self._prebiotic_set_detail("\n".join(lines))

    def _prebiotic_elucidate_selected(self):
        name = self._vars_prebiotic["selected_rxn"].get().strip()
        if not name or name not in PREBIOTIC_DB:
            return messagebox.showerror(
                "Prebiotic", "Select a reaction from the list first.")
        rxn_data = PREBIOTIC_DB[name]
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            pH = float(self._vars_prebiotic["pH"].get())
            P = float(self._vars_prebiotic["P_atm"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Prebiotic", f"Invalid parameter: {exc}")
        atm = [a.strip() for a in
               self._vars_prebiotic["atmosphere"].get().split(",") if a.strip()]
        mins = [m.strip() for m in
                self._vars_prebiotic["minerals"].get().split(",") if m.strip()]
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        out_base = self._vars_prebiotic["output_dir"].get().strip() or os.path.join(
            os.getcwd(), "prebiotic_output",
            re.sub(r"[^\w]", "_", name)[:40])

        def _worker():
            try:
                self._prebiotic_log(f"\n[Elucidator] {name}")
                match = self._prebiotic_match_conditions(
                    rxn_data, T, pH, P, atm, mins)
                self._prebiotic_log(
                    f"[Elucidator] Match score: {match['score']:.1f}/100")
                if self._vars_prebiotic["export_report"].get():
                    rp = self._prebiotic_generate_report(
                        name, rxn_data, match, T, pH, P, atm, mins, out_base)
                    self._prebiotic_log(f"[Report] Saved: {rp}")
                radar = self._prebiotic_plot_condition_radar(name, match, out_base)
                if radar:
                    self._prebiotic_log(f"[Radar] Saved: {radar}")
                ediag = self._prebiotic_plot_energy_diagram(rxn_data, out_base)
                if ediag:
                    self._prebiotic_log(f"[Energy diagram] Saved: {ediag}")
                if self._vars_prebiotic["run_xtb_thermo"].get() \
                        and mol_file and os.path.isfile(mol_file):
                    self._prebiotic_log(f"[xTB] Running at T={T} K …")
                    thermo = self._prebiotic_run_xtb_thermo(
                        mol_file, T, charge, mult, out_base)
                    if "error" in thermo:
                        self._prebiotic_log(f"[xTB] {thermo['error']}")
                    else:
                        self._prebiotic_log(
                            f"[xTB] G={thermo.get('G_Eh','?')} Eh  "
                            f"H={thermo.get('H_Eh','?')} Eh")
                self._prebiotic_log(f"[Elucidator] Done → {out_base}")
                self.root.after(
                    0, lambda: messagebox.showinfo(
                        "Prebiotic Elucidator",
                        f"Done!  Match score: {match['score']:.0f}/100\n"
                        f"Outputs: {out_base}"))
            except Exception as exc:
                _m = str(exc)
                self._prebiotic_log(f"[Elucidator] ERROR: {_m}")
                self.root.after(
                    0, lambda m=_m: messagebox.showerror("Prebiotic Elucidator", m))

        threading.Thread(target=_worker, daemon=True).start()

    # ── Bond-scan runner ─────────────────────────────────────────────────────

    def _prebiotic_run_bond_scan(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("Bond Scan",
                                        "Select a valid reactant XYZ file.")
        try:
            a1 = int(self._vars_prebiotic["scan_dist_A1"].get())
            a2 = int(self._vars_prebiotic["scan_dist_A2"].get())
            start = float(self._vars_prebiotic["scan_start"].get())
            end = float(self._vars_prebiotic["scan_end"].get())
            steps = int(self._vars_prebiotic["scan_steps"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("Bond Scan", f"Invalid value: {exc}")

        method = self._vars_prebiotic["xtb_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        out_dir = self._prebiotic_output_dir()
        bond_break_raw = self._vars_prebiotic["bond_break"].get().strip()
        bond_form_raw = self._vars_prebiotic["bond_form"].get().strip()

        self.is_running = True
        self._prebio_write(self._prebio_rxn_log,
                           f"[Bond Scan] {mol_file}\n"
                           f"  Atoms {a1}-{a2}  {start}→{end} Å  ({steps} steps)\n"
                           f"  Method: {method}  solvent: {solvent or 'none'}\n"
                           f"  Break: {bond_break_raw or '–'}  Form: {bond_form_raw or '–'}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                xtb_exe = "xtb.exe" if _sys() == "Windows" else "xtb"
                os.makedirs(out_dir, exist_ok=True)

                # Build xTB input file with $scan block
                scan_inp = os.path.join(out_dir, "scan_prebio.inp")
                with open(scan_inp, "w") as fh:
                    fh.write("$constrain\n")
                    fh.write(f"  force constant=1.0\n")
                    fh.write(f"  distance: {a1}, {a2}, {start}\n")
                    fh.write("$scan\n")
                    fh.write(f"  1: {start:.3f},{end:.3f},{steps}\n")
                    # Bond-break constraints: add weak repulsion
                    for pair in [p.strip() for p in bond_break_raw.split(",") if p.strip()]:
                        parts2 = pair.replace("-", " ").split()
                        if len(parts2) == 2:
                            fh.write(f"$fix\n  distance: {parts2[0]}, {parts2[1]}, break\n")
                    fh.write("$end\n")

                solvent_flag = f"--alpb {solvent}" if solvent else ""
                cmd = (f'"{xtb_exe}" "{mol_file}" {method} '
                       f'--input "{scan_inp}" --opt '
                       f'--chrg {charge} --uhf {mult - 1} '
                       f'{solvent_flag} > xtb_scan_prebio.log 2>&1')
                self._prebio_write(self._prebio_rxn_log,
                                   f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse xtbscan.log energies
                scan_log = os.path.join(out_dir, "xtbscan.log")
                energies = []
                if os.path.isfile(scan_log):
                    for line in open(scan_log, errors="replace"):
                        m = re.search(r"(-?\d+\.\d{6,})", line)
                        if m:
                            energies.append(float(m.group(1)))
                if not energies:
                    # fallback: grep main log
                    main_log = os.path.join(out_dir, "xtb_scan_prebio.log")
                    if os.path.isfile(main_log):
                        for line in open(main_log, errors="replace"):
                            if "TOTAL ENERGY" in line:
                                m = re.search(r"(-?\d+\.\d+)", line)
                                if m:
                                    energies.append(float(m.group(1)))

                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] {len(energies)} energy points parsed.")

                if energies and MATPLOTLIB_AVAILABLE:
                    import matplotlib.pyplot as plt
                    import numpy as np
                    dists = np.linspace(start, end, len(energies))
                    E_rel = np.array(energies)
                    E_rel = (E_rel - E_rel[0]) * 2625.5  # Eh → kJ/mol
                    fig, ax = plt.subplots(figsize=(6, 4))
                    fig.patch.set_facecolor(_C["panel"])
                    ax.set_facecolor(_C["panel"])
                    ax.plot(dists, E_rel, "o-", color=_C["green"], lw=2)
                    ax.axhline(0, ls="--", color=_C["muted"], lw=0.8)
                    ts_idx = int(np.argmax(E_rel))
                    ax.axvline(dists[ts_idx], ls=":", color=_C["red"], lw=1.5,
                               label=f"TS† ≈ {dists[ts_idx]:.2f} Å")
                    ax.set_xlabel(f"d(A{a1}–A{a2}) / Å",
                                  color=_C["muted"])
                    ax.set_ylabel("ΔE / kJ mol⁻¹",
                                  color=_C["muted"])
                    ax.set_title("Prebiotic Bond-Scan PES",
                                 color=_C["text"], fontweight="bold")
                    ax.legend(facecolor=_C["panel"], labelcolor=_C["text"])
                    ax.tick_params(colors=_C["muted"])
                    for sp in ax.spines.values():
                        sp.set_color(_C["border"])
                    fig.tight_layout()
                    png = os.path.join(out_dir, "prebio_bond_scan.png")
                    fig.savefig(png, dpi=120, bbox_inches="tight",
                                facecolor=_C["panel"])
                    plt.close(fig)
                    self._prebio_write(self._prebio_rxn_log,
                                       f"[Plot] Saved: {png}")
                    ts_e = E_rel[ts_idx]
                    self._prebio_write(self._prebio_rxn_log,
                                       f"[Bond Scan] TS† ≈ {dists[ts_idx]:.2f} Å, "
                                       f"ΔE‡ ≈ {ts_e:.1f} kJ/mol")
                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_rxn_log,
                                   f"[Bond Scan] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── xTB module runner ─────────────────────────────────────────────────────

    def _prebiotic_run_xtb_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("xTB Module",
                                        "Select a valid molecule XYZ file.")
        try:
            T = float(self._vars_prebiotic["T_K"].get())
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
        except ValueError as exc:
            return messagebox.showerror("xTB Module", str(exc))

        out_dir = self._prebiotic_output_dir()
        method = self._vars_prebiotic["xtb_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        self._prebio_write(self._prebio_xtb_log,
                           f"[xTB] {mol_file}\n  Method:{method}  T={T}K  "
                           f"solvent:{solvent or 'none'}",
                           clear=True)

        def _worker():
            try:
                thermo = self._prebiotic_run_xtb_thermo(
                    mol_file, T, charge, mult, out_dir,
                    method=method, solvent=solvent)
                if "error" in thermo:
                    self._prebio_write(self._prebio_xtb_log,
                                       f"[xTB] {thermo['error']}")
                    return
                self._prebio_write(self._prebio_xtb_log, "[xTB] Parsed thermochemistry:")
                for k2, v2 in thermo.items():
                    if k2 not in ("log", "T_K", "charge", "mult"):
                        self._prebio_write(self._prebio_xtb_log,
                                           f"  {k2:15s} = {v2}")
                self._prebio_write(self._prebio_xtb_log,
                                   f"[xTB] Log: {thermo.get('log','')}")
                self._prebio_write(self._prebio_xtb_log, "[xTB] Done.")
            except Exception as exc:
                self._prebio_write(self._prebio_xtb_log,
                                   f"[xTB] ERROR: {exc}")

        threading.Thread(target=_worker, daemon=True).start()

    # ── CREST module runner ───────────────────────────────────────────────────

    def _prebiotic_run_crest_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("CREST Module",
                                        "Select a valid molecule XYZ file.")
        try:
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
            T_crest = float(self._vars_prebiotic["crest_T"].get())
            ewin = float(self._vars_prebiotic["crest_ewin"].get())
            keep_n = int(self._vars_prebiotic["crest_keep_n"].get())
        except ValueError as exc:
            return messagebox.showerror("CREST Module", str(exc))

        method = self._vars_prebiotic["crest_method"].get().strip() or "--gfn2"
        solvent = self._vars_prebiotic["xtb_solvent"].get().strip()
        bond_constrain = self._vars_prebiotic["bond_break"].get().strip()
        out_dir = self._prebiotic_output_dir()
        self.is_running = True
        self._prebio_write(self._prebio_crest_log,
                           f"[CREST] {mol_file}\n  Method:{method}  T={T_crest}K  "
                           f"ewin={ewin}  keep={keep_n}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                crest_exe = "crest.exe" if _sys() == "Windows" else "crest"
                os.makedirs(out_dir, exist_ok=True)
                solvent_flag = f"--alpb {solvent}" if solvent else ""
                cinp_flag = ""
                if bond_constrain:
                    # Write --cinp file for reactive constraint
                    cinp_path = os.path.join(out_dir, "crest_prebio.inp")
                    pairs = [p.strip() for p in bond_constrain.split(",") if p.strip()]
                    with open(cinp_path, "w") as fh:
                        fh.write("$constrain\n  force constant=0.5\n")
                        for pair in pairs:
                            idxs = pair.replace("-", " ").split()
                            if len(idxs) == 2:
                                fh.write(f"  distance: {idxs[0]}, {idxs[1]}, auto\n")
                        fh.write("$end\n")
                    cinp_flag = f'--cinp "{cinp_path}"'

                cmd = (f'"{crest_exe}" "{mol_file}" {method} '
                       f'--T {T_crest:.0f} --ewin {ewin:.1f} '
                       f'--chrg {charge} --uhf {mult - 1} '
                       f'{solvent_flag} {cinp_flag} '
                       f'> crest_prebio.log 2>&1')
                self._prebio_write(self._prebio_crest_log, f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse ensemble
                ensemble = os.path.join(out_dir, "crest_conformers.xyz")
                n_conf = 0
                if os.path.isfile(ensemble):
                    with open(ensemble, errors="replace") as ef:
                        lines_e = ef.readlines()
                    # count frames
                    i2 = 0
                    conf_energies = []
                    while i2 < len(lines_e):
                        try:
                            nat = int(lines_e[i2].strip())
                            comment = lines_e[i2 + 1].strip() if i2 + 1 < len(lines_e) else ""
                            energy_m = re.search(r"(-?\d+\.\d+)", comment)
                            if energy_m:
                                conf_energies.append(float(energy_m.group(1)))
                            n_conf += 1
                            i2 += nat + 2
                        except (ValueError, IndexError):
                            break

                    self._prebio_write(self._prebio_crest_log,
                                       f"[CREST] {n_conf} conformers found.")

                    # Keep top-N
                    if keep_n > 0 and n_conf > 0:
                        top_path = os.path.join(out_dir, "crest_conformers_top.xyz")
                        with open(ensemble, errors="replace") as ef:
                            raw = ef.read()
                        frames = []
                        i2 = 0
                        src_lines = raw.splitlines(True)
                        while i2 < len(src_lines):
                            try:
                                nat = int(src_lines[i2].strip())
                                frame = "".join(src_lines[i2:i2 + nat + 2])
                                frames.append(frame)
                                i2 += nat + 2
                            except (ValueError, IndexError):
                                break
                        with open(top_path, "w") as fh:
                            fh.write("".join(frames[:keep_n]))
                        self._prebio_write(self._prebio_crest_log,
                                           f"[CREST] Top-{keep_n} saved: {top_path}")

                    # Energy plot
                    if conf_energies and MATPLOTLIB_AVAILABLE:
                        import matplotlib.pyplot as plt
                        import numpy as np
                        E_rel = np.array(conf_energies)
                        E_rel = (E_rel - E_rel[0]) * 2625.5
                        fig, ax = plt.subplots(figsize=(6, 3))
                        fig.patch.set_facecolor(_C["panel"])
                        ax.set_facecolor(_C["panel"])
                        ax.bar(range(1, len(E_rel) + 1), E_rel,
                               color=_C["accent"], edgecolor=_C["border"])
                        ax.set_xlabel("Conformer #", color=_C["muted"])
                        ax.set_ylabel("ΔE / kJ mol⁻¹", color=_C["muted"])
                        ax.set_title("CREST Conformer Energies",
                                     color=_C["text"], fontweight="bold")
                        ax.tick_params(colors=_C["muted"])
                        fig.tight_layout()
                        png = os.path.join(out_dir, "crest_energies.png")
                        fig.savefig(png, dpi=120, bbox_inches="tight",
                                    facecolor=_C["panel"])
                        plt.close(fig)
                        self._prebio_write(self._prebio_crest_log,
                                           f"[Plot] Saved: {png}")
                else:
                    self._prebio_write(self._prebio_crest_log,
                                       "[CREST] crest_conformers.xyz not found. "
                                       "Check crest_prebio.log.")
                self._prebio_write(self._prebio_crest_log,
                                   f"[CREST] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_crest_log,
                                   f"[CREST] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── ORCA module runner ────────────────────────────────────────────────────

    def _prebiotic_run_orca_module(self):
        mol_file = self._vars_prebiotic["mol_file"].get().strip()
        if not mol_file or not os.path.isfile(mol_file):
            return messagebox.showerror("ORCA Module",
                                        "Select a valid reactant XYZ file.")
        try:
            charge = int(self._vars_prebiotic["charge"].get())
            mult = int(self._vars_prebiotic["mult"].get())
            nproc = int(self._vars_prebiotic["orca_nproc"].get())
            maxcore = int(self._vars_prebiotic["orca_maxcore"].get())
        except ValueError as exc:
            return messagebox.showerror("ORCA Module", str(exc))

        method = self._vars_prebiotic["orca_method"].get().strip() or "B97-3c"
        basis = self._vars_prebiotic["orca_basis"].get().strip()
        keywords = self._vars_prebiotic["orca_keywords"].get().strip() or "Opt Freq"
        use_neb = self._vars_prebiotic["orca_neb"].get()
        product_file = self._vars_prebiotic["product_file"].get().strip()
        bond_break_raw = self._vars_prebiotic["bond_break"].get().strip()
        bond_form_raw = self._vars_prebiotic["bond_form"].get().strip()
        out_dir = self._prebiotic_output_dir()
        self.is_running = True
        self._prebio_write(self._prebio_orca_log,
                           f"[ORCA] {mol_file}\n"
                           f"  Method: {method}  Basis: {basis or 'built-in'}\n"
                           f"  Keywords: {keywords}  NEB: {use_neb}",
                           clear=True)

        def _worker():
            try:
                from platform import system as _sys
                orca_exe = "orca.exe" if _sys() == "Windows" else "orca"
                os.makedirs(out_dir, exist_ok=True)

                # Read reactant coords
                with open(mol_file, errors="replace") as f2:
                    xyz_lines = f2.readlines()
                # Strip first 2 lines for coord block
                coord_block = "".join(xyz_lines[2:]).strip()

                inp_path = os.path.join(out_dir, "orca_prebio.inp")

                if use_neb and product_file and os.path.isfile(product_file):
                    # NEB-TS input
                    kw_line = (f"! {method} {basis} NEB-TS FREQ"
                               if "NEB" not in keywords.upper()
                               else f"! {method} {basis} {keywords}")
                    with open(inp_path, "w") as fh:
                        fh.write(f"{kw_line}\n")
                        fh.write(f"%pal nprocs {nproc} end\n")
                        fh.write(f"%maxcore {maxcore}\n")
                        fh.write("%neb\n")
                        fh.write(f'  product "{product_file}"\n')
                        fh.write("  nimages 8\n")
                        fh.write("end\n")
                        fh.write(f"* xyz {charge} {mult}\n")
                        fh.write(coord_block + "\n*\n")
                else:
                    kw_line = f"! {method} {basis} {keywords}".strip()
                    with open(inp_path, "w") as fh:
                        fh.write(f"{kw_line}\n")
                        fh.write(f"%pal nprocs {nproc} end\n")
                        fh.write(f"%maxcore {maxcore}\n")
                        # Bond-break/form via Modify_Internal
                        break_pairs = [p.strip() for p in
                                       bond_break_raw.split(",") if p.strip()]
                        form_pairs = [p.strip() for p in
                                      bond_form_raw.split(",") if p.strip()]
                        if break_pairs or form_pairs:
                            fh.write("%geom\n  Modify_Internal\n")
                            for pair in break_pairs:
                                idxs = pair.replace("-", " ").split()
                                if len(idxs) == 2:
                                    # 0-based for ORCA
                                    i1 = int(idxs[0]) - 1
                                    i2b = int(idxs[1]) - 1
                                    fh.write(f"    {{B {i1} {i2b} D}}\n")
                            for pair in form_pairs:
                                idxs = pair.replace("-", " ").split()
                                if len(idxs) == 2:
                                    i1 = int(idxs[0]) - 1
                                    i2b = int(idxs[1]) - 1
                                    fh.write(f"    {{B {i1} {i2b} A}}\n")
                            fh.write("  end\nend\n")
                        fh.write(f"* xyz {charge} {mult}\n")
                        fh.write(coord_block + "\n*\n")

                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] Input: {inp_path}")
                cmd = f'"{orca_exe}" "{inp_path}" > orca_prebio.log 2>&1'
                self._prebio_write(self._prebio_orca_log, f"[CMD] {cmd}")
                subprocess.run(cmd, shell=True, cwd=out_dir)

                # Parse results from ORCA log
                orca_log = os.path.join(out_dir, "orca_prebio.log")
                if os.path.isfile(orca_log):
                    text = open(orca_log, errors="replace").read()
                    for pattern, label in [
                        (r"FINAL SINGLE POINT ENERGY\s+([-\d.]+)", "Final SCF Energy (Eh)"),
                        (r"Total enthalpy\s*:\s*([-\d.]+)", "Enthalpy (Eh)"),
                        (r"Total Gibbs free energy\s*:\s*([-\d.]+)", "G (Eh)"),
                        (r"Zero point energy\s*:\s*([-\d.]+)", "ZPE (Eh)"),
                        (r"Imaginary frequency:\s*([-\d.]+)", "Imaginary freq (cm⁻¹)"),
                    ]:
                        m = re.search(pattern, text)
                        if m:
                            self._prebio_write(self._prebio_orca_log,
                                               f"  {label:35s} = {m.group(1)}")
                    # NEB barrier
                    m_ts = re.search(
                        r"NEB-TS.*?barrier\s*=\s*([\d.]+)\s*kcal", text, re.DOTALL)
                    if m_ts:
                        self._prebio_write(self._prebio_orca_log,
                                           f"  NEB-TS barrier = {m_ts.group(1)} kcal/mol")
                    # Frequencies
                    freqs = re.findall(r":\s+([-\d.]+)\s+cm\*\*-1", text)
                    if freqs:
                        self._prebio_write(self._prebio_orca_log,
                                           f"  Frequencies (cm⁻¹): "
                                           f"{', '.join(freqs[:8])} …")
                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] Done → {out_dir}")
            except Exception as exc:
                _m = str(exc)
                self._prebio_write(self._prebio_orca_log,
                                   f"[ORCA] ERROR: {_m}")
            finally:
                self.is_running = False

        threading.Thread(target=_worker, daemon=True).start()

    # ── Extended xTB thermo (now accepts method/solvent kwargs) ──────────────

    # -------------------------------------------------------------------------

    def _build_pes_tutorial_tab(self, parent):
        """Step-by-step PES tutorial + 3D surface help."""
        tk.Label(parent, text="PES Tutorial & 3D Surface Guide",
                 bg=_C["bg"], fg=_C["green"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=10, pady=(8, 4))

        # Notebook inside tutorial
        tnb = ttk.Notebook(parent)
        tnb.pack(fill="both", expand=True, padx=10, pady=4)

        # ── helper ────────────────────────────────────────────────────────────
        def _make_text_tab(notebook, tab_title, content):
            frame = tk.Frame(notebook, bg=_C["bg"])
            notebook.add(frame, text=tab_title)
            txt = tk.Text(frame, bg=_C["panel"], fg=_C["text"],
                          font=("Consolas", 9), wrap="word",
                          padx=12, pady=8, state="normal", relief="flat")
            sb = tk.Scrollbar(frame, orient="vertical", command=txt.yview)
            sb.pack(side="right", fill="y")
            txt.pack(fill="both", expand=True)
            txt.config(yscrollcommand=sb.set)
            txt.tag_configure("h1", font=("Segoe UI", 12, "bold"),
                              foreground=_C["green"])
            txt.tag_configure("h2", font=("Segoe UI", 10, "bold"),
                              foreground=_C["yellow"])
            txt.tag_configure("code", font=("Consolas", 9),
                              foreground=_C.get("cyan", "#00CED1"),
                              background=_C["entry"])
            txt.tag_configure("tip", foreground=_C.get("blue", "#87CEEB"))
            txt.tag_configure("warn", foreground=_C.get("red", "#FF6B6B"))
            for line in content.split("\n"):
                if line.startswith("## "):
                    txt.insert("end", line[3:] + "\n", "h1")
                elif line.startswith("### "):
                    txt.insert("end", line[4:] + "\n", "h2")
                elif line.startswith("`") and line.endswith("`"):
                    txt.insert("end", line[1:-1] + "\n", "code")
                elif line.startswith("TIP:"):
                    txt.insert("end", line + "\n", "tip")
                elif line.startswith("WARN:"):
                    txt.insert("end", line + "\n", "warn")
                else:
                    txt.insert("end", line + "\n")
            txt.config(state="disabled")

        # ── Tab 1 : Step-by-Step Guide ────────────────────────────────────────
        GUIDE = """\
══════════════════════════════════════════════════════════════════════
 IAK PES TUTORIAL — How to Run a Potential Energy Surface Scan
══════════════════════════════════════════════════════════════════════

## STEP 1 — Prepare your XYZ file

• Use a pre-optimised structure (e.g. from xTB Opt or CREST best conformer).
• Make sure atom indices start from 1 (IAK uses 1-based atom numbering).
• Place both molecules in the same XYZ file (multi-molecule complex) OR
  use the Anchor + Guest workflow to auto-assemble a complex first.

### Example — minimal XYZ header
`5`
`water dimer`
`O  0.000  0.000  0.119`
`H  0.000  0.756 -0.476`
`H  0.000 -0.756 -0.476`
`O  0.000  0.000  3.000`
`H  0.000  0.756  2.405`

## STEP 2 — Choose scan coordinate

• Bond scan        : two atom indices  (e.g. 1 and 4)
• Angle scan       : three atom indices (e.g. 1 2 3)
• Dihedral scan    : four atom indices  (e.g. 1 2 3 4)

TIP: Use a visualiser (Avogadro / MOLDEN) to check atom numbering before entering indices.

## STEP 3 — Set scan range

• Start distance   : typically 1.0 – 1.5 Å (equilibrium)
• End distance     : typically 3.0 – 5.0 Å (dissociation)
• Steps            : 10–30 points gives a smooth curve without too much CPU time

## STEP 4 — Launch the scan

Click  ▶ Run PES Scan  in the "PES Coordinate Scan" tab.
The progress log will show each point:  Point 1/20 … energy = -X.XXX Eh

## STEP 5 — Interpret the PES plot

• The lowest point is the equilibrium geometry.
• The highest point on the reaction pathway is the transition state (TS†).
• The barrier height  ΔE‡  is reported in kcal/mol and kJ/mol.

WARN: A monotonically rising curve means dissociation, not a barrier — check if you scanned the right bond.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " Step-by-Step Guide ", GUIDE)

        # ── Tab 2 : xTB Input Format ──────────────────────────────────────────
        XTB_FMT = """\
## xTB Constraint / Scan Input Format (IAK auto-generates this)

IAK writes a  xtb_scan.inp  file in your output directory.  Here is
what it looks like for a bond scan between atoms 1 and 4:

`$constrain`
`  force constant=0.5`
`  distance: 1, 4, auto`
`$scan`
`  mode=sequential`
`  distance: 1, 4, 1.0, 3.5, 20`
`$end`

### Angle scan example (atoms 1, 2, 3)
`$constrain`
`  force constant=0.5`
`  angle: 1, 2, 3, auto`
`$scan`
`  mode=sequential`
`  angle: 1, 2, 3, 80.0, 180.0, 20`
`$end`

### xTB command IAK runs
`xtb molecule.xyz --input xtb_scan.inp --gfn2 --chrg 0 --uhf 0`

TIP: Add --alpb water  in xTB Settings to include implicit solvation.
TIP: GFN-FF is much faster for large systems (>100 atoms) but less accurate.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " xTB Input Format ", XTB_FMT)

        # ── Tab 3 : 3D Surface Guide ──────────────────────────────────────────
        SURF3D = """\
## 3D PES Surface — How to Generate a 2D Scan Grid

To obtain a 3D surface you must vary TWO coordinates simultaneously.
Run two sequential scans OR use the grid mode (if enabled).

### Workflow
1. Run a coarse scan  (10×10 grid)  to locate the approximate TS region.
2. Refine with a fine  scan  (20×20 grid)  around the TS.
3. The surface is plotted as a heatmap + 3D wireframe.

### Interpreting the 3D surface
• Valleys    = stable intermediates or reactants / products
• Saddle point = transition state
• Ridge       = reaction path connecting two valleys through the TS

### Example — two-coordinate scan (bond A-B and bond C-D)
`$scan`
`  mode=sequential`
`  distance: 1, 2, 1.0, 3.0, 10`
`  distance: 3, 4, 1.0, 3.0, 10`
`$end`

TIP: Use  --opt  after the scan to relax each constrained point for a
     more accurate surface.

WARN: 3D scans scale as N² — a 20-step scan = 400 single-point calculations.
      Plan accordingly or use GFN-FF for speed.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " 3D Surface Guide ", SURF3D)

        # ── Tab 4 : Troubleshooting ───────────────────────────────────────────
        TROUBLESHOOT = """\
## Common PES Scan Problems & Fixes

### xtb not found
WARN: Make sure xTB is installed and on your PATH.
TIP:  In Settings → Paths, set the full path to the xtb executable.

### Scan produces NaN energies
• The geometry may have clashed.  Reduce the step size or increase the
  force constant in the constrain block.
• Try  --opt  to relax each step geometry.

### Monotonically increasing curve (no barrier)
• You may have scanned the wrong pair of atoms.
• Check indices (1-based) in a molecular viewer.

### Imaginary frequency at wrong point
• Run  xtb --hess  at the apparent TS to confirm.
• The true TS has exactly one negative frequency along the reaction coordinate.

### Memory / time errors
• Reduce molecule size or use GFN-FF (--gfnff) instead of GFN2-xTB.
• Split large systems into smaller fragments.

══════════════════════════════════════════════════════════════════════
"""
        _make_text_tab(tnb, " Troubleshooting ", TROUBLESHOOT)

# =============================================================================
# ENTRY POINT
# =============================================================================
