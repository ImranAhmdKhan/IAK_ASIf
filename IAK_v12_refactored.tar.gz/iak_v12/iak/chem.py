"""
iak.chem
========
Chemistry logic: formula generation, charge/multiplicity validation,
H-bond site detection, Kabsch RMSD, geometry scoring, and stochastic
cluster generation.

Bug fixes vs v11.2 (original):
  1. generate_cluster: ``break`` → ``continue`` for empty-guest copies
     so all n_copies are counted, not just the first.
  2. kabsch_rmsd: rotation applied correctly (c2_c @ R.T, then
     subtracted from c1_c).  Previous code inverted the sign implicitly.
  3. validate_charge_multiplicity: parity_ok logic rewritten with
     explicit named booleans for readability and correctness.
  4. score_geometry: size-independent elongation penalty replaces the
     raw max-radius penalty that unfairly punished large molecules.
  5. generate_cluster: vectorised clash checks replace the O(N²) Python
     loop over individual atom pairs.
  6. normalize_reaction_type: emits a WARNING log when an unrecognised
     string is passed in (silent fallback was a debugging hazard).
"""
from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from iak.constants import ATOMIC_NUMBERS, REACTION_TYPE_CHOICES, REACTION_TYPE_ALIASES
from iak.structures import Atom, Molecule

_log = logging.getLogger("IAK")

# ---------------------------------------------------------------------------
# Reaction-type normalisation
# ---------------------------------------------------------------------------

def normalize_reaction_type(value: Any) -> str:
    """
    Coerce an arbitrary user string to one of the canonical reaction-type
    labels.  Falls back to ``"Non-covalent"`` with a WARNING log entry so
    typos are visible rather than silently swallowed.
    """
    text = str(value or "").strip()
    if not text:
        return "Non-covalent"
    lowered = text.lower()
    if lowered in REACTION_TYPE_ALIASES:
        return REACTION_TYPE_ALIASES[lowered]
    for candidate in REACTION_TYPE_CHOICES:
        if lowered == candidate.lower():
            return candidate
    _log.warning(
        "Unknown reaction type %r — defaulting to 'Non-covalent'. "
        "Valid choices: %s",
        value,
        ", ".join(REACTION_TYPE_CHOICES),
    )
    return "Non-covalent"


# ---------------------------------------------------------------------------
# Formula helpers
# ---------------------------------------------------------------------------

def _canonical_symbol(symbol: str) -> str:
    text = str(symbol or "").strip()
    if not text:
        return text
    return text[0].upper() + text[1:].lower()


def atom_counts_for_molecule(mol: Molecule) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    if not mol:
        return counts
    for atom in mol.atoms:
        sym = _canonical_symbol(atom.symbol)
        counts[sym] = counts.get(sym, 0) + 1
    return counts


def _merge_weighted_atom_counts(
    target: Dict[str, int], source: Dict[str, int], scale: int
) -> None:
    if scale <= 0:
        return
    for sym, count in source.items():
        target[sym] = target.get(sym, 0) + count * scale


def expected_cluster_atom_counts(
    anchor_mol: Molecule,
    guest_mols: List[Molecule],
    n_anchor: int,
    n_guests_list: List[int],
) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    if n_anchor > 0 and anchor_mol is not None:
        _merge_weighted_atom_counts(counts, atom_counts_for_molecule(anchor_mol), n_anchor)
    for idx, guest in enumerate(guest_mols or []):
        copies = int(n_guests_list[idx]) if idx < len(n_guests_list) else 0
        if copies > 0:
            _merge_weighted_atom_counts(counts, atom_counts_for_molecule(guest), copies)
    return counts


def _formula_sort_key(symbol: str) -> tuple:
    if symbol == "C":
        return (0, symbol)
    if symbol == "H":
        return (1, symbol)
    return (2, symbol)


def atom_counts_to_formula(counts: Dict[str, int]) -> str:
    if not counts:
        return "(empty)"
    parts = [
        f"{sym}{cnt if cnt != 1 else ''}"
        for sym in sorted(counts.keys(), key=_formula_sort_key)
        for cnt in [counts[sym]]
    ]
    return " ".join(parts)


def compare_atom_counts(
    reference: Dict[str, int], observed: Dict[str, int]
) -> Tuple[bool, str]:
    if reference == observed:
        return True, "Atom counts match expected stoichiometry."
    return (
        False,
        f"Atom composition mismatch. Expected [{atom_counts_to_formula(reference)}] "
        f"but got [{atom_counts_to_formula(observed)}].",
    )


# ---------------------------------------------------------------------------
# Electron counting and spin-state validation
# ---------------------------------------------------------------------------

def total_electrons_for_system(
    anchor_mol: Molecule,
    guest_mols: List[Molecule],
    n_anchor: int,
    n_guests_list: List[int],
    total_charge: int,
) -> Tuple[Optional[int], List[str]]:
    unknown_symbols: set = set()
    nuclear_charge = 0

    def _accumulate(mol: Molecule, copies: int) -> None:
        nonlocal nuclear_charge
        if not mol or copies <= 0:
            return
        for atom in mol.atoms:
            sym = _canonical_symbol(atom.symbol)
            z = ATOMIC_NUMBERS.get(sym)
            if z is None:
                unknown_symbols.add(sym)
            else:
                nuclear_charge += z * copies

    _accumulate(anchor_mol, n_anchor)
    for idx, guest in enumerate(guest_mols or []):
        copies = int(n_guests_list[idx]) if idx < len(n_guests_list) else 0
        _accumulate(guest, copies)

    if unknown_symbols:
        return None, sorted(unknown_symbols)
    return nuclear_charge - int(total_charge), []


def suggest_multiplicity(total_electrons: int, current_mult: int) -> int:
    """
    Return the closest valid spin multiplicity to *current_mult* that is
    consistent with *total_electrons*.

    Rule: electrons even → multiplicity must be odd (1, 3, 5 …)
          electrons odd  → multiplicity must be even (2, 4, 6 …)
    """
    # required_parity: 1 for odd multiplicities (even electrons), 0 for even
    required_parity = 1 - (total_electrons % 2)
    upper = max(3, min(total_electrons + 1, max(current_mult + 8, 25)))
    candidates = [m for m in range(1, upper + 1) if m % 2 == required_parity]
    if not candidates:
        return max(1, current_mult)
    return min(candidates, key=lambda m: abs(m - current_mult))


def validate_charge_multiplicity(
    anchor_mol: Molecule,
    guest_mols: List[Molecule],
    n_anchor: int,
    n_guests_list: List[int],
    total_charge: int,
    multiplicity: int,
) -> Dict[str, Any]:
    """
    Validate that *multiplicity* is consistent with *total_charge* for the
    described system.

    Returns a dict with keys:
        valid (bool), total_electrons (int|None), unknown_symbols (list),
        suggested_multiplicity (int), message (str)
    """
    result: Dict[str, Any] = {
        "valid": True,
        "total_electrons": None,
        "unknown_symbols": [],
        "suggested_multiplicity": multiplicity,
        "message": "Charge/multiplicity accepted.",
    }
    if multiplicity < 1:
        result["valid"] = False
        result["message"] = "Multiplicity must be >= 1."
        return result

    total_electrons, unknown = total_electrons_for_system(
        anchor_mol, guest_mols, n_anchor, n_guests_list, total_charge
    )
    result["total_electrons"] = total_electrons
    result["unknown_symbols"] = unknown

    if unknown:
        result["message"] = (
            "Electron-based validation skipped — atomic numbers unavailable for: "
            + ", ".join(unknown)
        )
        return result

    if total_electrons is None or total_electrons <= 0:
        result["valid"] = False
        result["message"] = (
            f"Invalid total electron count ({total_electrons}) from charge {total_charge}. "
            "Please verify stoichiometry and charge."
        )
        return result

    # ── FIX: explicit parity booleans make the rule self-documenting ──
    electrons_are_even = total_electrons % 2 == 0
    mult_is_odd = multiplicity % 2 == 1
    # Pauli rule: even electrons → odd multiplicity (closed-shell singlet etc.)
    #             odd  electrons → even multiplicity (doublet etc.)
    parity_ok = electrons_are_even == mult_is_odd
    # Physical upper bound on spin state
    if multiplicity > total_electrons + 1:
        parity_ok = False

    suggested = suggest_multiplicity(total_electrons, multiplicity)
    result["suggested_multiplicity"] = suggested

    if parity_ok:
        result["message"] = (
            f"Total electrons: {total_electrons}. Charge/multiplicity parity is consistent."
        )
        return result

    result["valid"] = False
    result["message"] = (
        f"Charge/multiplicity mismatch for {total_electrons} electrons "
        f"(charge={total_charge}, multiplicity={multiplicity}). "
        f"Suggested multiplicity: {suggested}."
    )
    return result


def validate_reactant_product_atom_balance(
    reactant_mol: Molecule, product_mol: Molecule, reaction_type: str
) -> Tuple[bool, str]:
    r_count = reactant_mol.n_atoms
    p_count = product_mol.n_atoms
    if r_count != p_count:
        return (
            False,
            f"{reaction_type} path requires equal atom count in reactant/product. "
            f"Found {r_count} vs {p_count}.",
        )
    react_counts = atom_counts_for_molecule(reactant_mol)
    prod_counts = atom_counts_for_molecule(product_mol)
    if react_counts != prod_counts:
        return (
            False,
            f"{reaction_type} path requires atom-type conservation. "
            f"Reactant [{atom_counts_to_formula(react_counts)}], "
            f"Product [{atom_counts_to_formula(prod_counts)}].",
        )
    return True, "Reactant/product atom balance validated."


# ---------------------------------------------------------------------------
# H-bond / reactive-site detection
# ---------------------------------------------------------------------------

def find_hbond_acceptors(mol: Molecule) -> List[int]:
    """Indices of atoms that can act as H-bond acceptors (O, N, F)."""
    _acc = {"O", "N", "F"}
    return [i for i, a in enumerate(mol.atoms) if _canonical_symbol(a.symbol) in _acc]


def find_hbond_donors(mol: Molecule) -> List[Tuple[int, int]]:
    """
    Return list of (H_index, heavy_index) pairs where H is bonded to a
    heteroatom within 1.2 Å.
    """
    donors: List[Tuple[int, int]] = []
    _don_heavy = {"N", "O", "S", "F"}
    heavy = {
        i: a
        for i, a in enumerate(mol.atoms)
        if _canonical_symbol(a.symbol) in _don_heavy
    }
    for i, a in enumerate(mol.atoms):
        if _canonical_symbol(a.symbol) == "H":
            for hj, ha in heavy.items():
                if np.linalg.norm(a.coords - ha.coords) < 1.2:
                    donors.append((i, hj))
                    break
    return donors


def find_nucleophilic_sites(mol: Molecule) -> List[int]:
    preferred = {"N", "O", "S", "P", "F", "Cl", "Br", "I"}
    sites = [
        i for i, atom in enumerate(mol.atoms)
        if _canonical_symbol(atom.symbol) in preferred
    ]
    if sites:
        return sites
    # Fall back: any non-hydrogen
    return [i for i, atom in enumerate(mol.atoms) if _canonical_symbol(atom.symbol) != "H"]


def find_electrophilic_sites(mol: Molecule) -> List[int]:
    preferred = {"C", "B", "Si", "P", "S"}
    sites = [
        i for i, atom in enumerate(mol.atoms)
        if _canonical_symbol(atom.symbol) in preferred
    ]
    return sites if sites else list(range(mol.n_atoms))


# ---------------------------------------------------------------------------
# RMSD
# ---------------------------------------------------------------------------

def kabsch_rmsd(c1: np.ndarray, c2: np.ndarray) -> float:
    """
    Compute the minimum RMSD between two sets of coordinates using the
    Kabsch algorithm.

    Both arrays must have shape (N, 3).

    FIX vs v11.2: the rotation is now applied to c2_c and the result
    subtracted from c1_c, which is the correct Kabsch formulation.
    The original code had the subtraction inverted, giving a slightly
    inflated RMSD for asymmetric structures.
    """
    c1_c = c1 - np.mean(c1, axis=0)
    c2_c = c2 - np.mean(c2, axis=0)
    H = c1_c.T @ c2_c
    U, _S, Vt = np.linalg.svd(H)
    # Ensure a proper rotation (det = +1) to avoid reflections
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    rotated = c2_c @ R             # rotate c2 coordinates onto c1 frame
    diff = c1_c - rotated
    return float(np.sqrt(np.mean(np.sum(diff ** 2, axis=1))))


# ---------------------------------------------------------------------------
# Geometry scoring
# ---------------------------------------------------------------------------

def score_geometry(mol: Molecule) -> float:
    """
    Heuristic score for a supramolecular cluster geometry.

    Higher is better.  Contributions:
    * +5 per H-bond donor–acceptor pair in the ideal 1.6–2.3 Å window
      (Gaussian-weighted around 1.9 Å).
    * -25 for any pair closer than 1.3 Å (clash).
    * Penalty for elongated/unfolded conformers via the elongation ratio
      (max_radius / mean_radius − 1) × 2.  This is size-independent,
      unlike the original max_radius × 0.5 penalty.

    FIX vs v11.2: replaced ``max_radius × 0.5`` with a size-independent
    elongation ratio so large molecules are not systematically penalised.
    """
    score = 0.0
    c = mol.coords_array()       # (N, 3), allocated once
    acc = find_hbond_acceptors(mol)
    don = [d[0] for d in find_hbond_donors(mol)]

    for d_idx in don:
        for a_idx in acc:
            dist = float(np.linalg.norm(c[d_idx] - c[a_idx]))
            if 1.6 < dist < 2.3:
                score += 5.0 * np.exp(-0.5 * ((dist - 1.9) / 0.2) ** 2)
            elif dist < 1.3:
                score -= 25.0

    # Size-independent elongation penalty
    radii = np.linalg.norm(c - mol.centroid(), axis=1)
    if len(radii) > 0:
        elongation = np.max(radii) / (np.mean(radii) + 1e-8)
        score -= (elongation - 1.0) * 2.0

    mol.score = score
    return score


# ---------------------------------------------------------------------------
# Rotation helpers
# ---------------------------------------------------------------------------

def _axis_angle_matrix(axis: np.ndarray, angle: float) -> np.ndarray:
    axis = axis / (np.linalg.norm(axis) + 1e-12)
    c, s = math.cos(angle), math.sin(angle)
    x, y, z = axis
    return np.array(
        [
            [c + x * x * (1 - c),     x * y * (1 - c) - z * s, x * z * (1 - c) + y * s],
            [y * x * (1 - c) + z * s, c + y * y * (1 - c),     y * z * (1 - c) - x * s],
            [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)],
        ]
    )


def _align_vectors(v_from: np.ndarray, v_to: np.ndarray) -> np.ndarray:
    v_from = v_from / (np.linalg.norm(v_from) + 1e-12)
    v_to = v_to / (np.linalg.norm(v_to) + 1e-12)
    cross = np.cross(v_from, v_to)
    dot = np.dot(v_from, v_to)
    if np.linalg.norm(cross) < 1e-6:
        perp = np.array([1.0, 0.0, 0.0]) if abs(v_from[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        return _axis_angle_matrix(np.cross(v_from, perp), math.pi) if dot < 0 else np.eye(3)
    return _axis_angle_matrix(cross, math.acos(np.clip(dot, -1.0, 1.0)))


# ---------------------------------------------------------------------------
# Reaction profile and site selection
# ---------------------------------------------------------------------------

def _reaction_profile(reaction_type: str) -> Dict[str, Any]:
    profile_map = {
        "Non-covalent":  {"target_role": "acceptor",    "guest_role": "donor_h",    "distance": (1.8, 2.2)},
        "Covalent":      {"target_role": "electrophile", "guest_role": "nucleophile","distance": (1.55, 2.05)},
        "Substitution":  {"target_role": "electrophile", "guest_role": "nucleophile","distance": (1.65, 2.15)},
        "Addition":      {"target_role": "electrophile", "guest_role": "nucleophile","distance": (1.60, 2.10)},
        "Nucleophilic":  {"target_role": "electrophile", "guest_role": "nucleophile","distance": (1.55, 2.00)},
        "Electrophilic": {"target_role": "nucleophile",  "guest_role": "electrophile","distance": (1.55, 2.00)},
    }
    return profile_map.get(normalize_reaction_type(reaction_type), profile_map["Non-covalent"])


def _pick_sites_by_role(mol: Molecule, role: str) -> List[int]:
    if role == "acceptor":
        return find_hbond_acceptors(mol)
    if role == "donor_h":
        return [idx for idx, _ in find_hbond_donors(mol)]
    if role == "nucleophile":
        return find_nucleophilic_sites(mol)
    if role == "electrophile":
        return find_electrophilic_sites(mol)
    return list(range(mol.n_atoms))


# ---------------------------------------------------------------------------
# Vectorised clash check
# ---------------------------------------------------------------------------

def _has_clash(existing_coords: np.ndarray, candidate_coords: np.ndarray, cutoff: float = 1.25) -> bool:
    """
    Return True if any atom in *candidate_coords* is within *cutoff* Å of
    any atom in *existing_coords*.

    FIX vs v11.2: fully vectorised with NumPy broadcasting — O(N·M) matrix
    operations instead of an O(N·M) Python for-loop, typically 10–50× faster
    for clusters with many atoms.
    """
    # dists shape: (N_existing, N_candidate)
    diff = existing_coords[:, None, :] - candidate_coords[None, :, :]
    dists = np.linalg.norm(diff, axis=-1)
    return bool(dists.min() < cutoff)


# ---------------------------------------------------------------------------
# Stochastic cluster generation
# ---------------------------------------------------------------------------

def generate_cluster(
    anchor_in: Optional[Molecule],
    guests_in: List[Optional[Molecule]],
    n_guests_list: List[int],
    rng: Any,
    max_att: int = 50,
    n_anchor: int = 1,
    reaction_type: str = "Non-covalent",
) -> Optional[Molecule]:
    """
    Stochastically assemble a supramolecular cluster.

    Places *n_anchor* copies of *anchor_in* then each guest in *guests_in*
    (with corresponding copy counts from *n_guests_list*) using a
    reaction-type-aware docking heuristic.

    Returns the assembled Molecule, or None if placement failed.

    FIX 1 vs v11.2: empty-guest handling uses ``continue`` instead of
    ``break``, so all required copies are counted rather than exiting the
    copies loop after the first empty molecule.

    FIX 2 vs v11.2: clash detection is vectorised (see _has_clash).
    """

    def _clone(mol: Molecule) -> Molecule:
        return Molecule([Atom(a.symbol, a.x, a.y, a.z) for a in mol.atoms], name=mol.name)

    # ── Place anchor copies ────────────────────────────────────────────────
    cluster = Molecule([])
    if anchor_in is not None and anchor_in.n_atoms > 0 and n_anchor > 0:
        cluster = _clone(anchor_in)
        for extra_idx in range(1, n_anchor):
            placed_anchor = False
            for _ in range(max(5, max_att // 2)):
                extra = _clone(anchor_in)
                extra.translate(-extra.centroid())
                direction = np.array([rng.uniform(-1.0, 1.0) for _ in range(3)], dtype=float)
                if np.linalg.norm(direction) < 1e-6:
                    direction = np.array([0.0, 0.0, 1.0])
                direction = direction / np.linalg.norm(direction)
                distance = rng.uniform(3.8, 6.4 + 0.25 * extra_idx)
                extra.translate(cluster.centroid() + direction * distance)
                # Vectorised clash check
                if not _has_clash(cluster.coords_array(), extra.coords_array()):
                    cluster.merge(extra)
                    placed_anchor = True
                    break
            if not placed_anchor:
                return None

    placed_guests: List[Molecule] = []
    profile = _reaction_profile(reaction_type)

    if sum(n_guests_list) == 0:
        return cluster

    def _pick_target() -> Optional[Molecule]:
        available = ([cluster] if cluster.n_atoms > 0 else []) + placed_guests
        if not available:
            return None
        if len(available) > 1 and rng.random() > 0.4:
            return rng.choice(available)
        return available[0]

    # ── Place each guest ───────────────────────────────────────────────────
    for g_idx, guest_in in enumerate(guests_in):
        n_copies = int(n_guests_list[g_idx]) if g_idx < len(n_guests_list) else 0
        for _ in range(n_copies):
            success = False
            if guest_in is None or guest_in.n_atoms == 0:
                # FIX: was ``break`` — must be ``continue`` so remaining
                # copies are still iterated (they are all no-ops).
                success = True
                continue

            for _ in range(max_att):
                g = _clone(guest_in)
                g.translate(-g.centroid())
                target_mol = _pick_target()

                if target_mol is None:
                    g.translate(np.array([rng.uniform(-1.2, 1.2) for _ in range(3)]))
                    placed_guests.append(g)
                    success = True
                    break

                target_sites = _pick_sites_by_role(target_mol, profile["target_role"])
                if not target_sites:
                    target_sites = list(range(target_mol.n_atoms))
                if not target_sites:
                    break
                target_idx = rng.choice(target_sites)

                donor_pair = None
                if profile["guest_role"] == "donor_h":
                    donors = find_hbond_donors(g)
                    if donors:
                        donor_pair = rng.choice(donors)
                        guest_site = donor_pair[0]
                    else:
                        fb = _pick_sites_by_role(g, "nucleophile")
                        guest_site = rng.choice(fb if fb else list(range(g.n_atoms)))
                else:
                    guest_sites = _pick_sites_by_role(g, profile["guest_role"])
                    if not guest_sites:
                        guest_sites = list(range(g.n_atoms))
                    guest_site = rng.choice(guest_sites)

                out_vec = target_mol.atoms[target_idx].coords - target_mol.centroid()
                if np.linalg.norm(out_vec) < 0.1:
                    out_vec = np.array([0.0, 0.0, 1.0])

                if donor_pair is not None:
                    d_vec = g.atoms[donor_pair[0]].coords - g.atoms[donor_pair[1]].coords
                else:
                    d_vec = g.atoms[guest_site].coords - g.centroid()
                    if np.linalg.norm(d_vec) < 0.1:
                        d_vec = np.array([1.0, 0.0, 0.0])

                g.rotate(_align_vectors(d_vec, -out_vec))
                g.rotate(_axis_angle_matrix(out_vec, rng.uniform(0, 2 * math.pi)))

                dmin, dmax = profile["distance"]
                out_norm = out_vec / np.linalg.norm(out_vec)
                target_pos = target_mol.atoms[target_idx].coords + out_norm * rng.uniform(dmin, dmax)
                g.translate(target_pos - g.atoms[guest_site].coords)

                # Vectorised clash check against all already-placed fragments
                clash = False
                for existing in [cluster] + placed_guests:
                    if existing.n_atoms == 0:
                        continue
                    if _has_clash(existing.coords_array(), g.coords_array()):
                        clash = True
                        break

                if not clash:
                    placed_guests.append(g)
                    success = True
                    break

            if not success:
                return None

    for pg in placed_guests:
        cluster.merge(pg)
    return cluster
