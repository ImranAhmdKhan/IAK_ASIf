"""
iak.config
==========
RunMode enumeration and the Config dataclass that governs pipeline
sampling depths, method strings, and computational resource limits.
"""
from __future__ import annotations

import dataclasses
from enum import Enum
from typing import Optional


class RunMode(Enum):
    """Pre-defined sampling depth presets."""
    FAST = "fast"
    BALANCED = "balanced"
    THOROUGH = "thorough"


@dataclasses.dataclass
class Config:
    """
    All user-configurable parameters for a single pipeline run.

    Defaults correspond to the ``BALANCED`` preset.  Use
    ``Config.from_mode(RunMode.FAST)`` or ``Config.from_mode(RunMode.THOROUGH)``
    to obtain a preset-configured instance.
    """
    # ── Sampling ──────────────────────────────────────────────────────────
    n_generate: int = 200
    n_keep_scored: int = 50
    n_keep_clustered: int = 40
    n_run_xtb: int = 20
    n_run_crest: int = 5

    # ── Geometry filters ──────────────────────────────────────────────────
    rmsd_cutoff: float = 0.5       # Å — structures closer than this are duplicates
    clash_cutoff: float = 1.2      # Å — any pair closer than this is a clash

    # ── Engine method strings ─────────────────────────────────────────────
    xtb_method: str = "--gfn2"
    crest_method: str = "--gfn2"
    orca_method: str = "B97-3c Opt Freq"

    # ── System description ────────────────────────────────────────────────
    charge: int = 0
    multiplicity: int = 1
    energy_a: Optional[float] = None   # monomer A reference energy (Eh)
    energy_b: Optional[float] = None   # monomer B reference energy (Eh)

    # ── Energy windows ────────────────────────────────────────────────────
    xtb_ewin_kcal: float = 5.0
    crest_ewin_kcal: float = 3.0

    # ── Sampling control ──────────────────────────────────────────────────
    random_seed: int = 42
    max_placement_attempts: int = 50
    preopt_inputs: bool = True

    # ── Computational resources ───────────────────────────────────────────
    cores: int = 4
    maxcore: int = 2000             # MB per ORCA core

    # ── Execution environment ─────────────────────────────────────────────
    exec_env: str = "Local (Subprocess)"

    # ── GOAT (machine-learning PES) settings ─────────────────────────────
    goat_model: str = "uma-s-1"
    goat_device: str = "cuda"
    goat_task: str = "omol"

    # ── Optional per-run report sections (dict of bool) ───────────────────
    report_options: dataclasses.field(default_factory=dict) = dataclasses.field(default_factory=dict)

    # ------------------------------------------------------------------
    @classmethod
    def from_mode(cls, mode: RunMode) -> "Config":
        """Return a Config pre-configured for the requested sampling depth."""
        if mode == RunMode.FAST:
            return cls(
                n_generate=50,
                n_keep_scored=20,
                n_keep_clustered=10,
                n_run_xtb=5,
                n_run_crest=1,
            )
        if mode == RunMode.THOROUGH:
            return cls(
                n_generate=1000,
                n_keep_scored=300,
                n_keep_clustered=100,
                n_run_xtb=50,
                n_run_crest=10,
                xtb_ewin_kcal=10.0,
                crest_ewin_kcal=5.0,
            )
        # BALANCED (default)
        return cls()
