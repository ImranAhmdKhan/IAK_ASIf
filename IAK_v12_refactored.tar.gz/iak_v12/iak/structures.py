"""
iak.structures
==============
Core molecular data structures: Atom, Molecule, and XYZ I/O helpers.
Pure Python + NumPy only — no GUI, no engine calls.
"""
from __future__ import annotations

import os
from typing import List, Optional

import numpy as np


class Atom:
    """Single atom with a chemical symbol and Cartesian coordinates."""

    __slots__ = ("symbol", "x", "y", "z")

    def __init__(self, symbol: str, x: float, y: float, z: float) -> None:
        self.symbol = symbol
        self.x = x
        self.y = y
        self.z = z

    # ------------------------------------------------------------------
    # Coordinate property — get/set as a NumPy array for convenience
    # ------------------------------------------------------------------
    @property
    def coords(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z], dtype=float)

    @coords.setter
    def coords(self, v: np.ndarray) -> None:
        self.x, self.y, self.z = float(v[0]), float(v[1]), float(v[2])

    def __repr__(self) -> str:
        return f"Atom({self.symbol}, {self.x:.4f}, {self.y:.4f}, {self.z:.4f})"


class Molecule:
    """
    A collection of atoms with optional energy / scoring metadata.

    All heavy-data operations (coordinates, centroid, RMSD) use NumPy
    arrays obtained via ``coords_array()``.  Mutating methods (translate,
    rotate) update the individual Atom coordinates in place.
    """

    def __init__(self, atoms: List[Atom], name: str = "mol") -> None:
        self.atoms: List[Atom] = atoms
        self.name: str = name
        # Metadata set by pipeline / engine stages
        self.score: float = 0.0
        self.energy_eh: float = 0.0
        self.gibbs_eh: float = 0.0
        self.imag_freqs: int = 0
        self.lineage: List[str] = []

    # ------------------------------------------------------------------
    # Property: n_atoms  (was a plain method — changed to @property so
    # it is consistent with coords/centroid and removes call-site noise)
    # ------------------------------------------------------------------
    @property
    def n_atoms(self) -> int:
        return len(self.atoms)

    # ------------------------------------------------------------------
    # XYZ I/O
    # ------------------------------------------------------------------
    @classmethod
    def from_xyz(cls, path: str) -> "Molecule":
        """
        Parse a single-frame XYZ file.

        Handles:
        * Leading blank lines before the atom count
        * Empty comment lines (required by the XYZ spec)
        * Malformed coordinate lines (skipped with a continue)
        * Non-UTF-8 bytes (replaced, not raised)
        """
        if not path or not os.path.exists(path):
            return cls([])
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            raw = fh.readlines()

        stripped = [line.strip() for line in raw]
        # Skip leading blank lines
        idx = 0
        while idx < len(stripped) and not stripped[idx]:
            idx += 1
        try:
            n = int(stripped[idx])
        except (ValueError, IndexError) as exc:
            raise ValueError(f"Invalid XYZ format in {path}") from exc
        # Comment is always the very next line (may be blank)
        comment_line = stripped[idx + 1] if idx + 1 < len(stripped) else ""
        atoms: List[Atom] = []
        for line in stripped[idx + 2 : idx + 2 + n]:
            parts = line.split()
            if len(parts) >= 4:
                try:
                    atoms.append(Atom(parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                except ValueError:
                    continue
        return cls(atoms, comment_line or "mol")

    def to_xyz(self, path: str, comment: str = "") -> None:
        """Write the molecule to a single-frame XYZ file."""
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(f"{self.n_atoms}\n{comment}\n")
            for a in self.atoms:
                fh.write(f"{a.symbol:<4} {a.x:15.6f} {a.y:15.6f} {a.z:15.6f}\n")

    # ------------------------------------------------------------------
    # Geometry helpers
    # ------------------------------------------------------------------
    def coords_array(self) -> np.ndarray:
        """Return all atom coordinates as a (N, 3) float64 array."""
        return np.array([a.coords for a in self.atoms], dtype=float)

    def centroid(self) -> np.ndarray:
        """Geometric centroid of all atoms (unweighted)."""
        if self.n_atoms == 0:
            return np.zeros(3)
        return np.mean(self.coords_array(), axis=0)

    def translate(self, v: np.ndarray) -> None:
        """Translate all atoms by vector *v* in place."""
        for a in self.atoms:
            a.coords = a.coords + v

    def rotate(self, R: np.ndarray) -> None:
        """Apply rotation matrix *R* to all atoms in place."""
        for a in self.atoms:
            a.coords = R @ a.coords

    def merge(self, other: "Molecule") -> None:
        """Append copies of *other*'s atoms to this molecule."""
        self.atoms.extend(
            Atom(a.symbol, a.x, a.y, a.z) for a in other.atoms
        )

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return self.n_atoms

    def __repr__(self) -> str:
        return f"Molecule(name={self.name!r}, n_atoms={self.n_atoms})"


# ---------------------------------------------------------------------------
# Multi-frame XYZ reader
# ---------------------------------------------------------------------------

def read_multi_xyz(path: str) -> List[Molecule]:
    """
    Read a multi-frame XYZ trajectory file.

    Returns a list of Molecule objects.  If the comment line of a frame
    starts with a parseable float, it is stored as ``mol.energy_eh``.
    """
    mols: List[Molecule] = []
    if not os.path.exists(path):
        return mols
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        while True:
            line = fh.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            try:
                n = int(line)
            except ValueError:
                continue
            comment = fh.readline().strip()
            atoms: List[Atom] = []
            for _ in range(n):
                parts = fh.readline().split()
                if len(parts) >= 4:
                    try:
                        atoms.append(Atom(parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                    except ValueError:
                        continue
            mol = Molecule(atoms, name=comment)
            try:
                mol.energy_eh = float(comment.split()[0])
            except Exception:
                pass
            mols.append(mol)
    return mols
