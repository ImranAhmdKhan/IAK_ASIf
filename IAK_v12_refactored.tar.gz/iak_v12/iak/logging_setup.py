"""
iak.logging_setup
=================
IAK logging configuration: queue-based GUI handler and Unicode-safe
stream handler.  Call ``setup_logging()`` once at startup.
"""
from __future__ import annotations

import logging
import queue
import sys
from typing import Optional


class _QueueHandler(logging.Handler):
    """Logging handler that puts formatted messages on a queue (for GUI log panels)."""

    def __init__(self, q: queue.Queue) -> None:
        super().__init__()
        self._q = q

    def emit(self, record: logging.LogRecord) -> None:
        self._q.put(self.format(record))


class SafeStreamHandler(logging.StreamHandler):
    """StreamHandler that survives UnicodeEncodeError on narrow Windows consoles."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self.stream.write(msg + self.terminator)
            self.flush()
        except UnicodeEncodeError:
            msg = self.format(record)
            encoding = getattr(self.stream, "encoding", None) or "ascii"
            safe_msg = msg.encode(encoding, "replace").decode(encoding)
            try:
                self.stream.write(safe_msg + self.terminator)
                self.flush()
            except Exception:
                pass
        except Exception:
            self.handleError(record)


def setup_logging(
    verbose: bool = False,
    gui_queue: Optional[queue.Queue] = None,
) -> logging.Logger:
    """
    Configure the ``"IAK"`` logger.

    Parameters
    ----------
    verbose:
        If True, set level to DEBUG; otherwise INFO.
    gui_queue:
        If provided, attach a ``_QueueHandler`` so the GUI log panel
        receives formatted messages without polling stdout.

    Returns
    -------
    logging.Logger
        The configured ``"IAK"`` logger instance.
    """
    level = logging.DEBUG if verbose else logging.INFO
    logger = logging.getLogger("IAK")
    logger.setLevel(level)
    logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(message)s",
        datefmt="%H:%M:%S",
    )
    ch = SafeStreamHandler(sys.stdout)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    if gui_queue is not None:
        qh = _QueueHandler(gui_queue)
        qh.setFormatter(formatter)
        logger.addHandler(qh)

    return logger
