"""
iak.engine
==========
Engine manager: detects installed xTB, CREST, and ORCA binaries; handles
WSL path translation on Windows; and manages the optional embedded-engine
directory (``iak_engine/``).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Engine directory
# ---------------------------------------------------------------------------
ENGINE_DIR: str = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "iak_engine")

# Download URLs — ordered by preference (newest first)
XTB_URLS = [
    "https://github.com/grimme-lab/xtb/releases/download/v6.7.1/xtb-6.7.1-linux-x86_64.tar.xz",
    "https://github.com/grimme-lab/xtb/releases/download/v6.6.1/xtb-6.6.1-linux-x86_64.tar.xz",
]

CREST_URLS = [
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-x86_64-unknown-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-x86_64-pc-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest-linux-x86_64.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.2/crest.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v3.0.1/crest-x86_64-unknown-linux-gnu.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v2.12/crest.tar.xz",
    "https://github.com/grimme-lab/crest/releases/download/v2.11.2/crest.tar.xz",
]

# ---------------------------------------------------------------------------
# Mutable globals — set by inject_embedded_engines() at import time
# ---------------------------------------------------------------------------
XTB_DIR: Optional[str] = None
CREST_DIR: Optional[str] = None
ORCA_DIR: Optional[str] = None
ORCA_IS_WINDOWS: bool = False

# Cache the WSL-ORCA probe result (expensive subprocess)
_wsl_orca_exists: Optional[bool] = None


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def get_wsl_path(win_path: str) -> str:
    """Convert a Windows absolute path to its WSL ``/mnt/…`` equivalent."""
    drive, tail = os.path.splitdrive(win_path)
    if drive:
        return f"/mnt/{drive[0].lower()}{tail.replace(os.sep, '/')}"
    return win_path.replace(os.sep, "/")


# ---------------------------------------------------------------------------
# Tool detection
# ---------------------------------------------------------------------------

def is_tool_available(tool_name: str) -> bool:
    """
    Return True if *tool_name* (``"xtb"``, ``"crest"``, or ``"orca"``)
    is usable from the current environment.

    On Windows, ORCA availability also checks whether a WSL installation
    exists (cached after the first call).
    """
    global _wsl_orca_exists

    if tool_name == "xtb":
        return XTB_DIR is not None or shutil.which("xtb") is not None

    if tool_name == "crest":
        return CREST_DIR is not None or shutil.which("crest") is not None

    if tool_name == "orca":
        if ORCA_DIR is not None:
            return True
        if shutil.which("orca") is not None or shutil.which("orca.exe") is not None:
            return True
        if sys.platform == "win32":
            if _wsl_orca_exists is None:
                try:
                    proc = subprocess.run(
                        r"wsl -e bash -c 'export PATH=\"/usr/bin:/bin:/usr/local/bin:$PATH\"; which orca'",
                        shell=True,
                        capture_output=True,
                        timeout=3,
                    )
                    _wsl_orca_exists = proc.returncode == 0
                except Exception:
                    _wsl_orca_exists = False
            return bool(_wsl_orca_exists)
        return False

    return False


# ---------------------------------------------------------------------------
# Embedded engine injection
# ---------------------------------------------------------------------------

def inject_embedded_engines() -> None:
    """
    Walk ``ENGINE_DIR`` and set ``XTB_DIR``, ``CREST_DIR``, ``ORCA_DIR``
    globals to point at any detected embedded binaries.  Also marks WSL
    binaries executable on Windows.

    Called automatically at module import.
    """
    global XTB_DIR, CREST_DIR, ORCA_DIR, ORCA_IS_WINDOWS

    if not os.path.exists(ENGINE_DIR):
        return

    for root, _dirs, files in os.walk(ENGINE_DIR):
        try:
            # ── xTB ──────────────────────────────────────────────────────
            if (
                "xtb" in files
                and os.path.basename(root) == "bin"
                and os.path.isfile(os.path.join(root, "xtb"))
            ):
                XTB_DIR = root
                if sys.platform == "win32":
                    subprocess.run(
                        f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'xtb'))}\"",
                        shell=True, capture_output=True,
                    )

            # ── CREST ─────────────────────────────────────────────────────
            if (
                CREST_DIR is None
                and "crest" in files
                and os.path.isfile(os.path.join(root, "crest"))
            ):
                CREST_DIR = root
                if sys.platform == "win32":
                    subprocess.run(
                        f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'crest'))}\"",
                        shell=True, capture_output=True,
                    )

            # ── ORCA ──────────────────────────────────────────────────────
            if ORCA_DIR is None:
                if "orca.exe" in files and os.path.isfile(os.path.join(root, "orca.exe")):
                    ORCA_DIR = root
                    ORCA_IS_WINDOWS = True
                elif "orca" in files and os.path.isfile(os.path.join(root, "orca")):
                    ORCA_DIR = root
                    ORCA_IS_WINDOWS = False
                    if sys.platform == "win32":
                        subprocess.run(
                            f"wsl chmod +x \"{get_wsl_path(os.path.join(root, 'orca'))}\"",
                            shell=True, capture_output=True,
                        )
                        subprocess.run(
                            f"wsl chmod +x \"{get_wsl_path(root)}/orca_\"* 2>/dev/null",
                            shell=True, capture_output=True,
                        )
        except OSError:
            continue


# Auto-detect on import
inject_embedded_engines()
