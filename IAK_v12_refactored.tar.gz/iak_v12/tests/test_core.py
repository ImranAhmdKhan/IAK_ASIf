"""
tests/test_core.py
==================
Unit tests for IAK core scientific functions.
Run with:  pytest tests/test_core.py -v

Covers every function that had a bug in v11.2, plus the key
validation and formula helpers.
"""
from __future__ import annotations

import math
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import numpy as np
import pytest

from iak.structures import Atom, Molecule, read_multi_xyz
from iak.chem import (
    kabsch_rmsd,
    score_geometry,
    generate_cluster,
    validate_charge_multiplicity,
    suggest_multiplicity,
    normalize_reaction_type,
    atom_counts_to_formula,
    atom_counts_for_molecule,
    compare_atom_counts,
    find_hbond_acceptors,
    find_hbond_donors,
    _has_clash,
)
from iak.constants import ATOMIC_NUMBERS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _water() -> Molecule:
    """Simple water molecule (approximately correct geometry)."""
    return Molecule([
        Atom("O",  0.000,  0.000,  0.119),
        Atom("H",  0.000,  0.757, -0.476),
        Atom("H",  0.000, -0.757, -0.476),
    ], name="water")


def _ammonia() -> Molecule:
    return Molecule([
        Atom("N",  0.000,  0.000,  0.116),
        Atom("H",  0.000,  0.940, -0.271),
        Atom("H",  0.814, -0.470, -0.271),
        Atom("H", -0.814, -0.470, -0.271),
    ], name="ammonia")


# ---------------------------------------------------------------------------
# Atom / Molecule
# ---------------------------------------------------------------------------

class TestAtom:
    def test_coords_roundtrip(self):
        a = Atom("C", 1.0, 2.0, 3.0)
        assert np.allclose(a.coords, [1.0, 2.0, 3.0])

    def test_coords_setter(self):
        a = Atom("C", 0.0, 0.0, 0.0)
        a.coords = np.array([4.0, 5.0, 6.0])
        assert a.x == pytest.approx(4.0)
        assert a.y == pytest.approx(5.0)
        assert a.z == pytest.approx(6.0)


class TestMolecule:
    def test_n_atoms_property(self):
        mol = _water()
        assert mol.n_atoms == 3            # property, NOT mol.n_atoms()

    def test_centroid_water(self):
        mol = _water()
        c = mol.centroid()
        # centroid should be near the oxygen (which has mass but this is geometric)
        assert c.shape == (3,)

    def test_translate(self):
        mol = _water()
        original_centroid = mol.centroid().copy()
        mol.translate(np.array([1.0, 0.0, 0.0]))
        assert np.allclose(mol.centroid(), original_centroid + [1.0, 0.0, 0.0])

    def test_merge_preserves_atom_count(self):
        m1 = _water()
        m2 = _ammonia()
        m1.merge(m2)
        assert m1.n_atoms == 7

    def test_coords_array_shape(self):
        mol = _water()
        c = mol.coords_array()
        assert c.shape == (3, 3)

    def test_empty_molecule_centroid(self):
        mol = Molecule([])
        c = mol.centroid()
        assert np.allclose(c, [0, 0, 0])


# ---------------------------------------------------------------------------
# Kabsch RMSD  (FIX: rotation direction was inverted in v11.2)
# ---------------------------------------------------------------------------

class TestKabschRMSD:
    def test_identical_coords_give_zero(self):
        c = np.random.default_rng(0).random((10, 3))
        assert kabsch_rmsd(c, c) == pytest.approx(0.0, abs=1e-9)

    def test_pure_translation_gives_zero(self):
        c1 = np.random.default_rng(1).random((8, 3))
        c2 = c1 + np.array([3.0, -1.5, 2.0])
        assert kabsch_rmsd(c1, c2) == pytest.approx(0.0, abs=1e-9)

    def test_pure_rotation_gives_zero(self):
        """Kabsch RMSD between c1 and R·c1 should be zero."""
        c1 = np.random.default_rng(2).random((6, 3))
        # 90° rotation around z — apply to centred coords then de-centre
        theta = math.pi / 2
        R = np.array([[math.cos(theta), -math.sin(theta), 0],
                      [math.sin(theta),  math.cos(theta), 0],
                      [0,               0,                1]])
        c1_c = c1 - c1.mean(0)
        # Standard Kabsch: c2 is rotated WITH R (not R.T) relative to c1
        c2_c = c1_c @ R          # same structure, rotated
        c2 = c2_c + c1.mean(0)
        assert kabsch_rmsd(c1, c2) == pytest.approx(0.0, abs=1e-8)

    def test_symmetry(self):
        """RMSD(a, b) == RMSD(b, a)."""
        c1 = np.random.default_rng(3).random((5, 3))
        c2 = np.random.default_rng(4).random((5, 3))
        assert kabsch_rmsd(c1, c2) == pytest.approx(kabsch_rmsd(c2, c1), rel=1e-9)

    def test_known_displacement(self):
        """Single atom displaced by 1 Å: RMSD should be 1.0."""
        c1 = np.array([[0.0, 0.0, 0.0]])
        c2 = np.array([[1.0, 0.0, 0.0]])
        # After centering, both become zero, so RMSD = 0 — single atom edge case.
        # Use two atoms instead:
        c1 = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
        c2 = np.array([[0.5, 0.0, 0.0], [1.5, 0.0, 0.0]])
        assert kabsch_rmsd(c1, c2) == pytest.approx(0.0, abs=1e-9)  # pure translation


# ---------------------------------------------------------------------------
# suggest_multiplicity
# ---------------------------------------------------------------------------

class TestSuggestMultiplicity:
    def test_even_electrons_suggest_singlet(self):
        # 10 electrons (even) → must be odd multiplicity → 1 is closest to 1
        assert suggest_multiplicity(10, 1) == 1

    def test_odd_electrons_suggest_doublet(self):
        # 9 electrons (odd) → must be even multiplicity → 2 is closest to 1
        assert suggest_multiplicity(9, 1) == 2

    def test_preserves_higher_spin_when_parity_matches(self):
        # 10 electrons, requesting triplet (odd mult) → 3 is fine
        result = suggest_multiplicity(10, 3)
        assert result % 2 == 1   # must be odd

    def test_corrects_wrong_parity(self):
        # 10 electrons (even), multiplicity=2 (even) → wrong → should correct to 1 or 3
        result = suggest_multiplicity(10, 2)
        assert result % 2 == 1   # must be odd


# ---------------------------------------------------------------------------
# validate_charge_multiplicity  (FIX: parity logic rewritten)
# ---------------------------------------------------------------------------

class TestValidateChargeMultiplicity:
    def _water_mol(self):
        return _water()

    def test_neutral_singlet_water_is_valid(self):
        mol = self._water_mol()
        result = validate_charge_multiplicity(mol, [], 1, [], 0, 1)
        assert result["valid"] is True
        assert result["total_electrons"] == 10   # O(8) + 2H(1) = 10

    def test_wrong_multiplicity_caught(self):
        mol = self._water_mol()
        result = validate_charge_multiplicity(mol, [], 1, [], 0, 2)
        assert result["valid"] is False
        assert "mismatch" in result["message"].lower()

    def test_multiplicity_below_one_rejected(self):
        mol = self._water_mol()
        result = validate_charge_multiplicity(mol, [], 1, [], 0, 0)
        assert result["valid"] is False

    def test_unknown_symbol_skips_electron_check(self):
        mol = Molecule([Atom("Xx", 0, 0, 0)])
        result = validate_charge_multiplicity(mol, [], 1, [], 0, 1)
        # Can't determine electrons → validation skipped but not failed
        assert result["unknown_symbols"] == ["Xx"]
        assert result["valid"] is True  # skipped, not failed


# ---------------------------------------------------------------------------
# generate_cluster  (FIX 1: continue vs break; FIX 2: vectorised clash)
# ---------------------------------------------------------------------------

class TestGenerateCluster:
    def test_returns_molecule(self):
        rng = __import__("random").Random(42)
        water = _water()
        result = generate_cluster(water, [water], [1], rng, max_att=100)
        assert result is not None
        assert result.n_atoms == 6   # 2 × water

    def test_empty_guest_does_not_abort_remaining_copies(self):
        """
        FIX: with empty guest, success=True + continue (not break).
        All n_copies iterations should complete → cluster should still assemble.
        """
        rng = __import__("random").Random(7)
        water = _water()
        empty = Molecule([])
        # 2 copies of empty guest — should all succeed trivially
        result = generate_cluster(water, [empty], [2], rng, max_att=20)
        assert result is not None
        # Only anchor atoms present (empty guest contributes nothing)
        assert result.n_atoms == 3

    def test_no_guests_returns_anchor(self):
        rng = __import__("random").Random(0)
        water = _water()
        result = generate_cluster(water, [], [0], rng)
        assert result is not None
        assert result.n_atoms == 3

    def test_clash_free(self):
        """No two atoms from DIFFERENT fragment placements should be within 1.1 Å."""
        rng = __import__("random").Random(99)
        water = _water()
        result = generate_cluster(water, [water], [1], rng, max_att=200)
        if result is None:
            return  # Placement failed — not the fix being tested here
        # The first 3 atoms are the anchor, atoms 3-5 are the placed guest.
        # Only check inter-fragment distances; intra-molecule O-H bonds are ~0.96 Å.
        c = result.coords_array()
        anchor = c[:3]
        guest = c[3:]
        for pa in anchor:
            for pg in guest:
                dist = np.linalg.norm(pa - pg)
                assert dist > 1.1, f"Inter-fragment clash: {dist:.3f} Å"


# ---------------------------------------------------------------------------
# _has_clash  (vectorised, FIX vs v11.2)
# ---------------------------------------------------------------------------

class TestHasClash:
    def test_identical_points_clash(self):
        c = np.array([[0.0, 0.0, 0.0]])
        assert _has_clash(c, c, cutoff=1.25) is True

    def test_distant_points_no_clash(self):
        c1 = np.array([[0.0, 0.0, 0.0]])
        c2 = np.array([[10.0, 0.0, 0.0]])
        assert _has_clash(c1, c2, cutoff=1.25) is False

    def test_borderline(self):
        c1 = np.array([[0.0, 0.0, 0.0]])
        c2 = np.array([[1.24, 0.0, 0.0]])   # just under cutoff
        assert _has_clash(c1, c2, cutoff=1.25) is True
        c3 = np.array([[1.26, 0.0, 0.0]])   # just over cutoff
        assert _has_clash(c1, c3, cutoff=1.25) is False


# ---------------------------------------------------------------------------
# normalize_reaction_type  (FIX: now logs WARNING for unknown types)
# ---------------------------------------------------------------------------

class TestNormalizeReactionType:
    def test_canonical_passthrough(self):
        assert normalize_reaction_type("Non-covalent") == "Non-covalent"

    def test_alias(self):
        assert normalize_reaction_type("nucleophillic") == "Nucleophilic"

    def test_case_insensitive(self):
        assert normalize_reaction_type("ADDITION") == "Addition"

    def test_unknown_defaults_to_non_covalent(self, caplog):
        import logging
        with caplog.at_level(logging.WARNING, logger="IAK"):
            result = normalize_reaction_type("MagicReaction")
        assert result == "Non-covalent"
        assert "Unknown reaction type" in caplog.text

    def test_empty_string(self):
        assert normalize_reaction_type("") == "Non-covalent"

    def test_none(self):
        assert normalize_reaction_type(None) == "Non-covalent"


# ---------------------------------------------------------------------------
# Formula helpers
# ---------------------------------------------------------------------------

class TestAtomCounts:
    def test_water_formula(self):
        mol = _water()
        counts = atom_counts_for_molecule(mol)
        assert counts == {"H": 2, "O": 1}

    def test_formula_string_hill_order(self):
        counts = {"H": 4, "C": 2, "N": 1}
        # Hill order: C first, then H, then others alphabetically
        formula = atom_counts_to_formula(counts)
        assert formula.startswith("C2")
        assert "H4" in formula
        assert "N" in formula

    def test_compare_matching(self):
        counts = {"H": 2, "O": 1}
        ok, msg = compare_atom_counts(counts, counts)
        assert ok is True

    def test_compare_mismatch(self):
        ref = {"H": 2, "O": 1}
        obs = {"H": 2, "O": 2}
        ok, msg = compare_atom_counts(ref, obs)
        assert ok is False
        assert "mismatch" in msg.lower()


# ---------------------------------------------------------------------------
# H-bond site detection
# ---------------------------------------------------------------------------

class TestHBondSites:
    def test_water_has_one_acceptor(self):
        mol = _water()
        acc = find_hbond_acceptors(mol)
        assert 0 in acc   # O is index 0

    def test_water_has_two_donors(self):
        mol = _water()
        donors = find_hbond_donors(mol)
        assert len(donors) == 2

    def test_ammonia_acceptor(self):
        mol = _ammonia()
        acc = find_hbond_acceptors(mol)
        assert 0 in acc   # N is index 0


# ---------------------------------------------------------------------------
# Atomic numbers completeness
# ---------------------------------------------------------------------------

class TestAtomicNumbers:
    def test_standard_elements(self):
        for sym, expected_z in [("H", 1), ("C", 6), ("N", 7), ("O", 8), ("Fe", 26), ("Au", 79)]:
            assert ATOMIC_NUMBERS[sym] == expected_z

    def test_all_118_elements_present(self):
        assert len(ATOMIC_NUMBERS) == 118

    def test_oganesson(self):
        assert ATOMIC_NUMBERS["Og"] == 118


# ---------------------------------------------------------------------------
# Molecule n_atoms is a property (regression against calling it as method)
# ---------------------------------------------------------------------------

class TestNAtomsIsProperty:
    def test_no_call_syntax_needed(self):
        mol = _water()
        # This would raise TypeError in the old code if n_atoms were still
        # a method and someone tried to use it as a property
        count = mol.n_atoms
        assert count == 3

    def test_not_callable(self):
        mol = _water()
        # n_atoms should NOT be callable (it is a property)
        with pytest.raises(TypeError):
            mol.n_atoms()  # type: ignore[operator]
